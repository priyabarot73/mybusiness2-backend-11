<?php

namespace App\Helpers;

use Carbon\Carbon;
use Exception;
use Illuminate\Support\Collection;

class CurrentTermHelper
{
    /**
     * @throws Exception
     *
     * Returns the current term and its progress percentage.
     */
    public static function getCurrentTermWithProgress(Collection $terms): array
    {
        try {
            $currentDate = Carbon::now();

            $currentTerm = $terms
                ->sortByDesc('number')
                ->first(function ($t) use ($currentDate) {
                    return Carbon::parse($t->begin_dt_for_apt)->startOfDay() <= $currentDate &&
                        Carbon::parse($t->close_end_dt)->endOfDay() >= $currentDate;
                }) ?? $terms->first();

            $beginDate = Carbon::parse($currentTerm->begin_dt_for_apt);
            $endDate = Carbon::parse($currentTerm->close_end_dt);

            $daysPassed = $beginDate->diffInDays($currentDate);
            $totalDays = $beginDate->diffInDays($endDate);
            $remainingDays = max($totalDays - $daysPassed, 0);
            $progress = $totalDays > 0 ? round(($daysPassed / $totalDays) * 100) : 0;

            return [
                'term' => $currentTerm,
                'progress' => $progress,
                'daysPassed' => $daysPassed,
                'totalDays' => $totalDays,
                'remainingDays' => $remainingDays,
            ];
        } catch (Exception $e) {
            throw new Exception("Error determining the current term and progress.", 1);
        }
    }
}
