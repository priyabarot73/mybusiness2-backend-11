<?php

namespace App\Helpers;

class ScheduleUniqueSectionsByInstructorReportHelper
{
    /**
     * Map raw query results to a structured report response.
     *
     * @param array $queryResults
     * @return array
     */
    public static function formatReport(array $queryResults): array
    {
        // First filter out cancelled classes
        $filteredResults = array_filter($queryResults, function($result) {
            $result = (array) $result;
            $comments = $result['comments'] ?? '';
            return !str_contains($comments, '**CANCELLED**');
        });

        // Convert to array and reset keys
        $filteredResults = array_values($filteredResults);

        // Map the results without numeric keys
        return array_map(function ($result) {
            $result = (array) $result;
            return [
                'semester' => $result['semester'] ?? null,
                'course' => $result['course'] ?? null,
                'class_number' => $result['class_number'] ?? null,
                'course_name' => $result['course_name'] ?? null,
                'department' => $result['department'] ?? null,
                'instructor_name' => $result['instructor_name'] ?? null,
                'instructor_pid' => $result['instructor_pid'] ?? null,
                'instructor_type' => $result['instructor_type'] ?? null,
                'salary_admin_plan' => $result['salary_admin_plan'] ?? null,
                'instructor_workload' => $result['instructor_workload'] ?? null,
                'instructor_total_workload' => $result['instructor_total_workload'] ?? null,
                'instructor_adjusted' => $result['instructor_adjusted'] ?? null,
                'instructor_overload' => $result['instructor_overload'] ?? null,
                'adj_addl' => $result['adj_addl'] ?? null,
                'instructor_acad_org' => $result['instructor_acad_org'] ?? null,
                'tenure_status' => $result['tenure_status'] ?? null,
                'instructional_mode' => $result['instructional_mode'] ?? null,
                'primary_instructional_mode' => $result['primary_instructional_mode'] ?? null,
                'capacity' => $result['capacity'] ?? null,
                'enrollment' => $result['enrollment'] ?? null,
                'start_date' => $result['start_date'] ?? null,
                'end_date' => $result['end_date'] ?? null,
                'days' => $result['days'] ?? null,
                'time' => $result['time'] ?? null,
                'facility' => $result['facility'] ?? null,
                'campus' => $result['campus'] ?? null,
                'combined_programs' => $result['combined_programs'] ?? null,
                'cohort' => $result['cohort'] ?? null,
                'credits' => $result['credits'] ?? null,
                'course_level' => $result['course_level'] ?? null,
            ];
        }, $filteredResults);
    }
}
