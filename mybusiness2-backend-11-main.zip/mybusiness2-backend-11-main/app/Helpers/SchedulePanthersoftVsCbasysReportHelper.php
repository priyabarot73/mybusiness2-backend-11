<?php

namespace App\Helpers;

class SchedulePanthersoftVsCbasysReportHelper
{
    /**
     * Map raw query results to a structured report response.
     *
     * @param array $queryResults
     * @return array
     */
    public static function formatReport(array $queryResults): array
    {
        return array_map(function ($result) {
            $result = (array) $result;
            return [
                'sts' => $result['Sts'] ?? null,
                'num' => $result['Num'] ?? null,
                'course' => $result['Course'] ?? null,
                'ps_sect' => $result['PSSect'] ?? null,
                'cba_sect' => $result['CBASect'] ?? null,
                'psd' => $result['PSD'] ?? null,
                'cbad' => $result['CBAD'] ?? null,
                'ps_days' => $result['PSDays'] ?? null,
                'cba_days' => $result['CBADays'] ?? null,
                'ps_time' => $result['PSTime'] ?? null,
                'cba_time' => $result['CBATime'] ?? null,
                'ps_cap' => $result['PSCap'] ?? null,
                'cba_cap' => $result['CBACap'] ?? null,
                'ps_instructors' => $result['PSInstructors'] ?? null,
                'cba_instructors' => $result['CBAInstructors'] ?? null,
                'cba_program' => $result['CBA Program'] ?? null,
                'department' => $result['Department'] ?? null,
                'ps_mode' => $result['PS Mode'] ?? null,
                'cba_mode' => $result['CBA Mode'] ?? null,
                'ps_facility' => $result['PS Facility'] ?? null,
                'cba_facility' => $result['CBA Facility'] ?? null,
                'pschp' => $result['PSchP'] ?? null,
                'cba_schp' => $result['CBASchP'] ?? null,
                'cons' => $result['Cons'] ?? null,
                'ps_dates' => $result['PSDates'] ?? null,
                'ps_loc' => $result['PSLoc'] ?? null,
                'calc_req' => $result['Calc Req'] ?? null,
                'ps_campus' => $result['PSCampus'] ?? null,
                'cba_dates' => $result['CBADates'] ?? null,
                'cba_campus' => $result['CBACampus'] ?? null,
                'comments' => $result['Comments'] ?? null,
                'notes' => $result['Notes'] ?? null,
                'campus_location' => $result['Campus Location'] ?? null,
            ];
        }, $queryResults);
    }
}
