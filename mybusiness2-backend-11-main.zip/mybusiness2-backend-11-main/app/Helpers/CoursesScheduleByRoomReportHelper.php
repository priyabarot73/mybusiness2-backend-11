<?php

namespace App\Helpers;

class CoursesScheduleByRoomReportHelper
{
    /**
     * Map raw query results to a structured report response.
     *
     * @param array $queryResults
     * @return array
     */
    public static function formatReport(array $queryResults): array
    {
        // First filter out cancelled classes
        $filteredResults = array_filter($queryResults, function($result) {
            $result = (array) $result;
            $comments = $result['comments'] ?? '';
            return !str_contains($comments, '**CANCELLED**');
        });

        // Convert to array and reset keys
        $filteredResults = array_values($filteredResults);

        // Map the results without numeric keys
        return array_map(function ($result) {
            $result = (array) $result;
            return [
               'section_id'=>$result['section_id'] ?? null,
                'day' => $result['day'] ?? null,
                'start_time' => $result['start_time'] ?? null,
                'end_time' => $result['end_time'] ?? null,
                'course' => $result['course'] ?? null,
                'section' => $result['section'] ?? null,
                'instructor' => $result['instructor'] ?? null,
                'location' => $result['location'] ?? null,
                'cap' => $result['cap'] ?? null,
                'program' => $result['program'] ?? null,

            ];
        }, $filteredResults);
    }
}
