<?php

namespace App\Helpers;

class ScheduleUniqueSectionsReportHelper
{
    /**
     * Map raw query results to a structured report response.
     *
     * @param array $queryResults
     * @return array
     */
    public static function formatReport(array $queryResults): array
    {
        // First filter out cancelled classes
        $filteredResults = array_filter($queryResults, function($result) {
            $result = (array) $result;
            $comments = $result['comments'] ?? '';
            return !str_contains($comments, '**CANCELLED**');
        });

        // Convert to array and reset keys
        $filteredResults = array_values($filteredResults);

        // Map the results without numeric keys
        return array_map(function ($result) {
            $result = (array) $result;
            return [
                'semester' => $result['semester'] ?? null,
                'course' => $result['course'] ?? null,
                'section' => $result['section'] ?? null,
                'session' => $result['session'] ?? null,
                'course_name' => $result['course_name'] ?? null,
                'department' => $result['department'] ?? null,
                'instructor_name' => $result['instructor_name'] ?? null,
                'instructor_pid' => $result['instructor_pid'] ?? null,
                'instructional_mode' => $result['instructional_mode'] ?? null,
                'primary_instructional_mode' => $result['primary_instructional_mode'] ?? null,
                'capacity' => $result['capacity'] ?? null,
                'enrollment' => $result['enrollment'] ?? null,
                'start_date' => $result['start_date'] ?? null,
                'end_date' => $result['end_date'] ?? null,
                'days' => $result['days'] ?? null,
                'time' => $result['time'] ?? null,
                'facility' => $result['facility'] ?? null,
                'campus' => $result['campus'] ?? null,
                'primary_program' => $result['primary_program'] ?? null,
                'combined_programs' => $result['combined_programs'] ?? null,
                'cohort' => $result['cohort'] ?? null,
                'course_level' => $result['course_level'] ?? null,
                'class_roster' => $result['class_roster'] ?? null,
            ];
        }, $filteredResults);
    }
}
