<?php

namespace App\Helpers;

class InstructorWorkloadReportHelper
{
    /**
     * Format instructor workload data for reports.
     *
     * @param array $workloadResults
     * @return array
     */
    public static function formatReport(array $workloadResults): array
    {
        // Map each workload result to a structured format
        return array_map(function ($result) {
            $result = (array) $result;

            return [
                'workload_id'   => $result['workload_id'] ?? null,
                'instructor_id' => $result['instructor_id'] ?? null,
                'academic_year' => $result['academic_year'] ?? null,
                'workload'      => $result['workload'] ?? 0,
                'courses'       => $result['courses'] ?? 0,
                'adjusted'      => $result['adjusted'] ?? 0,
                'overload'      => $result['overload'] ?? 0,
                'effective'     => $result['effective'] ?? 0,
                'release'       => $result['release'] ?? 0,
                'releaseType'   => $result['releaseType'] ?? null,
                'error'         => $result['error'] ?? 0,
                'instructor_data'     => $result['instructor_data'] ?? null,
            ];
        }, $workloadResults);
    }
}
