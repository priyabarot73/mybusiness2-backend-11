<?php

namespace App\Helpers;

class ScheduleSectionsReportHelper
{
    /**
     * Map raw query results to a structured report response.
     *
     * @param array $queryResults
     * @return array
     */
    public static function formatReport(array $queryResults): array
    {
        // First filter out cancelled classes
        $filteredResults = array_filter($queryResults, function($result) {
            $result = (array) $result;
            $comments = $result['comments'] ?? '';
            return !str_contains($comments, '**CANCELLED**');
        });

        // Convert to array and reset keys
        $filteredResults = array_values($filteredResults);

        // Map the results without numeric keys
        return array_map(function ($result) {
            $result = (array) $result;
            return [
                'academic_year' => $result['academic_year'] ?? null,
                'semester' => $result['semester'] ?? null,
                'reference_number' => $result['reference_number'] ?? null,
                'course' => $result['course'] ?? null,
                'section' => $result['section'] ?? null,
                'session' => $result['session'] ?? null,
                'pry' => $result['pry'] ?? null,
                'course_name' => $result['course_name'] ?? null,
                'instructor' => $result['instructor'] ?? null,
                'panther_id' => $result['panther_id'] ?? null,
                'class' => $result['class'] ?? null,
                'department' => $result['department'] ?? null,
                'instructional_mode' => $result['instructional_mode'] ?? null,
                'capacity' => $result['capacity'] ?? null,
                'enrollment' => $result['enrollment'] ?? null,
                'adjusted' => $result['adjusted'] ?? null,
                'overload' => $result['overload'] ?? null,
                'value' => $result['value'] ?? null,
                'on_contract' => $result['on_contract'] ?? null,
                'grade_option' => $result['grade_option'] ?? null,
                'permits' => $result['permits'] ?? null,
                'credit' => $result['credit'] ?? null,
                'dynamic' => $result['dynamic'] ?? null,
                'start_date' => $result['start_date'] ?? null,
                'end_date' => $result['end_date'] ?? null,
                'day' => $result['day'] ?? null,
                'time' => $result['time'] ?? null,
                'facility' => $result['facility'] ?? null,
                'campus' => $result['campus'] ?? null,
                'program' => $result['program'] ?? null,
                'cohort' => $result['cohort'] ?? null,
                'comments' => $result['comments'] ?? null,
                'internal_notes' => $result['internal_notes'] ?? null,
                'LMS' => $result['LMS'] ?? null,
                'adj_addl' => $result['adj_addl'] ?? null,
            ];
        }, $filteredResults);
    }
}
