<?php

namespace App\Helpers;

use App\Models\general\ActivityTimeLine;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log as LaravelLog;
use Exception;

class ActivityTimeLineHelper
{
    /**
     * Saves a record in the logs table.
     *
     * @param string $actionId    UUID or ID of the affected entity
     * @param string $action      Action performed (create, update, delete, etc.)
     * @param string $category    Category or type of entity (e.g., BusinessUnitType)
     * @param string $description Description of the event
     */

    public static function store(string $actionId, string $action, string $category, string $description): void
    {
        try {
            $pantherId = Auth::user()->panther_id ?? null;
            LaravelLog::info($pantherId);

            if ($pantherId) {
                ActivityTimeLine::create([
                    'panther_id'  => $pantherId,
                    'action_id'   => $actionId,
                    'action'      => $action,
                    'category'    => $category,
                    'description' => $description,
                ]);
            }
        } catch (Exception $e) {
            LaravelLog::error('Error saving user log: ' . $e->getMessage());
        }
    }
}

