<?php

namespace App\Helpers;

class FacultyReportHelper
{
    /**
     * Format the Faculty Report rows (new DB version).
     * Keep output keys stable — this is the contract the frontend reads.
     */
    public static function formatReport(array $queryResults): array
    {
        $rows = array_values(array_map(fn ($r) => (array) $r, $queryResults));

        return array_map(function (array $r) {

            $statusLabel = self::statusLabel($r['status_raw'] ?? null);

            $fall   = (int) ($r['sections_fall'] ?? 0);
            $spring = (int) ($r['sections_spring'] ?? 0);
            $summer = (int) ($r['sections_summer'] ?? 0);

            return [
                // Columns you listed
                'faculty_name'        => $r['faculty_name'] ?? null,
                'panther_id'          => $r['panther_id'] ?? null,
                'email'               => $r['email'] ?? null,
                'appointment_date'    => $r['appointment_date'] ?? null,
                'highest_degree'      => $r['highest_degree'] ?? null,
                'type'                => $r['employee_type_display'] ?? ($r['employee_type_code'] ?? null),
                'involvement'         => $r['involvement'] ?? null,
                'job_title'           => $r['job_title'] ?? null,
                'qualifications'      => $r['qualifications'] ?? null,
                'tenure'              => $r['tenure'] ?? null,
                'academic_department' => $r['academic_department'] ?? null,
                'academic_area'       => $r['academic_area'] ?? null,
                'home_department'     => $r['home_department'] ?? null,
                'sections_f_sp_su' => "{$fall}-{$spring}-{$summer}",
                'curriculum_vitae'    => $r['curriculum_vitae'] ?? null,

                // Helpful extras (optional)
                'status'              => $statusLabel,
                'employee_type_code'  => $r['employee_type_code'] ?? null,
            ];
        }, $rows);
    }

    private static function statusLabel(mixed $raw): string
    {
        if ($raw === null) return 'Unknown';

        // If raw is a boolean-ish flag
        if ($raw === 1 || $raw === true || $raw === '1' || strtoupper((string) $raw) === 'TRUE') {
            return 'Active';
        }
        if ($raw === 0 || $raw === false || $raw === '0' || strtoupper((string) $raw) === 'FALSE') {
            return 'Inactive';
        }

        $v = strtoupper(trim((string) $raw));
        if ($v === 'TERMINATED' || $v === 'INACTIVE') return 'Inactive';

        return 'Active';
    }
}
