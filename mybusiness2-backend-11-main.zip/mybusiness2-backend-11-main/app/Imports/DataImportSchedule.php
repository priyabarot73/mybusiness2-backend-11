<?php

namespace App\Imports;

use App\Models\general\SchedulePanther180;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithChunkReading;

class DataImportSchedule implements ToModel, WithHeadingRow, WithChunkReading
{
    public function model(array $row): SchedulePanther180
    {
        return new SchedulePanther180([
            'class_nbr' => $row['Class Nbr'],
            'subject' => $row['Subject'],
            'catalog' => $row['Catalog'],
            'section' => $row['Section'],
            'session' => $row['Session'],
            'term' => $row['Term'],
            'level' => $row['Level'],
            'title' => $row['Title'],
            'cap' => $row['Cap'],
            'enrl' => $row['Enrl'],
            'enrl_waitlist' => $row['Enrl Waitlist'],
            'wait_cap' => $row['Wait Cap'],
            'wait_tot' => $row['Wait Tot'],
            'department' => $row['Department'],
            'department_formal' => $row['DepartmentFormal'],
            'campus' => $row['Campus'],
            'location' => $row['Location'],
            'mode' => $row['Mode'],
            'units' => $row['Units'],
            'grading' => $row['Grading'],
            'facility' => $row['Facility'],
            'meeting_time' => $row['Meeting Time'],
            'meeting_days' => $row['Meeting Days'],
            'last_name' => $row['Last Name'],
            'first_name' => $row['First Name'],
            'middle' => $row['Middle'],
            'notes' => $row['Notes'],
            'class_stat' => $row['Class Stat'],
            'cancel_dt' => $row['Cancel Dt'],
            'sch_print' => $row['Sch Print'],
            'consent' => $row['Consent'],
            'acad_group' => $row['Acad Group'],
            'start_date' => $row['Start Date'],
            'end_date' => $row['End Date'],
            'course_id' => $row['Course ID'],
            'offer_nbr' => $row['Offer Nbr'],
            'include' => $row['Include'],
            'calc_reqd' => $row['Calc Reqd'],
            'extract_type' => $row['Extract Type'],
            'lms_group_id' => $row['LMS Group ID'],
            'lms_url' => $row['LMS URL'],
            'class_ext_dttm' => $row['Class Ext Dttm'],
            'enrl_ext_dttm' => $row['Enrl Ext Dttm'],
            'authentication' => $row['Authentication'],
            'instructor_id' => $row['Instructor ID'],
            'component' => $row['Component'],
            'location_descr' => $row['Location Descr'],
        ]);
    }

    // This method defines how many rows are processed per batch
    public function chunkSize(): int
    {
        // I can increase it to 200, 500, etc. depending on the available RAM
        return 100;
    }
}
