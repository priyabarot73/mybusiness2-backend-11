<?php

namespace App\Traits;

//GLOBAL IMPORT
use Illuminate\Support\Facades\Config;

trait DbDefaultTrait
{
    public function getDbDefault(string $table): string
    {
        $db = Config::get('database.default');
        return $db.'.'.$table;
    }
}
