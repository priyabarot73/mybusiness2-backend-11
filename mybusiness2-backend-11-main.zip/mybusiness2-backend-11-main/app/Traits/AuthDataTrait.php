<?php

namespace App\Traits;

//GLOBAL IMPORT
use Carbon\Carbon;
use Laravel\Passport\PersonalAccessTokenResult;

//LOCAL IMPORT
use App\Models\User;

trait AuthDataTrait
{
    public function getAuthData(User $user): array
    {
        return [
            'user'         => $user,
            'access_token' => $this->createAuthToken($user)->accessToken, //$tokenInstance->accessToken,
            'token_type'   => 'Bearer',
            'expires_at'   => Carbon::parse($this->createAuthToken($user)->token->expires_at)->toDateTimeString()
        ];
    }

    public function createAuthToken(User $user): PersonalAccessTokenResult
    {
        return $user->createToken('authToken');
    }
}
