<?php

namespace App\Http\Requests\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class JobTitleRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title_id' => ['required','integer',Rule::unique($this->getDbDefault('hr.job_titles'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.job_titles'))->ignore($this->id)],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/job_title.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/job_title.custom');
    }
}
