<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class ContractStateTransitionRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'source_state_id' => ['uuid','max:36','required'],
            'target_state_id' => ['uuid','max:36','required'],
            'name' => ['required','string','max:255'],
            'code' => ['nullable', 'integer', 'min:0'],
            'message' => ['nullable','string','max:255'],
            'order' => ['required', 'numeric'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_state_transition.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_state_transition.custom');
    }
}
