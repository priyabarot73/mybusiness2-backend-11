<?php

namespace App\Http\Requests\v1\hr;

use Illuminate\Foundation\Http\FormRequest;

class ContractStatusReportRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'term_ids' => ['required', 'array', 'min:1'],
            'term_ids.*' => ['required', 'uuid'],

            'employee_id' => ['nullable', 'uuid'],
            'department_id' => ['nullable', 'uuid'],
            'employee_type_id' => ['nullable', 'uuid'],

            'program_codes' => ['nullable', 'array'],
            'program_codes.*' => ['required', 'string'],

            'activity_numbers' => ['nullable', 'array'],
            'activity_numbers.*' => ['string', 'max:50'],

            'status' => ['nullable', 'string', 'max:50'], //
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_status_report.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_status_report.custom');
    }
}
