<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class UnitStatusRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.unit_statuses'))->ignore($this->id)],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/unit_status.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/unit_status.custom');
    }
}
