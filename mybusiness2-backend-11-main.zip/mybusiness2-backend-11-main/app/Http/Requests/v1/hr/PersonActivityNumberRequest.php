<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class PersonActivityNumberRequest extends ApiFormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'person_id' => ['uuid', 'max:36', 'required'],
            'activity_numbers' => 'nullable|array',
            'activity_numbers.*' => ['required', 'uuid']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/person_activity_number.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/person_activity_number.custom');
    }
}
