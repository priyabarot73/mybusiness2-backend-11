<?php

namespace App\Http\Requests\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class SecondaryTeachingAppointmentRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.secondary_teaching_appointments'))->ignore($this->id)],
            'description' => ['string','max:255','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/secondary_teaching_appointment.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/secondary_teaching_appointment.custom');
    }
}
