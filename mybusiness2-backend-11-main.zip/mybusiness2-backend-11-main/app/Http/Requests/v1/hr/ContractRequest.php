<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

class ContractRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Detect current id for update (works with ?id=..., /contracts/{id}, or route-model-binding {contract})
        $currentId = $this->id
            ?? optional($this->route('id'))->id
            ?? optional($this->route('contract'))->id;

        return [
            // Base contract
            'contract_name' => ['required','string','max:255'],
            'lump_sum' => ['required','boolean'],
            'person_id' => ['required','uuid'],
            'job_title_id' => ['required','uuid'],
            'department_id' => ['required','uuid'],
            'supervisor_id' => ['required','uuid'],
            'contract_type_id' => ['required','uuid'],
            'secondary_teaching_appointment_id' => ['nullable','uuid'],
            'term_id' => ['required','uuid'],
            'course_id' => ['nullable','uuid'],
            'enrollment' => ['required','integer','min:0'],
            'start_date' => ['required','date'],
            'end_date' => ['required','date','after_or_equal:start_date'],
            'cost_pid' => ['required','string','max:255'],
            'cost_pid_value' => ['required','numeric'],
            'hours_worked' => ['required','numeric','min:0'],
            'amount_pay' => ['required','numeric','min:0'],
            'explanation_justification' => ['nullable','string'],
            'selection_justification' => ['nullable','string'],
            'why_cant' => ['nullable','string'],
            'erac_number' => [
                'nullable','string','max:255',
                Rule::unique($this->getDbDefault('hr.contracts'))->ignore($currentId),
            ],
            'contract_number' => [
                'nullable','string','max:255',
                Rule::unique($this->getDbDefault('hr.contracts'))->ignore($currentId),
            ],

            'internal_comment' => ['nullable','string'],
            'category' => ['required','string'],
            'employee_type' => ['required','string'],

            // NUEVOS CAMPOS (superseding)
            'superseding' => ['nullable','boolean'],
            // Si quieres que estos sean obligatorios solo cuando superseding=true:
            'superseding_contract_number' => ['nullable','numeric','required_if:superseding,true'],
            'superseding_contract_enrollment' => ['nullable','numeric','required_if:superseding,true'],
            'superseding_contract_amount' => ['nullable','numeric','min:0','required_if:superseding,true'],

            // Children
            'secondary_employment_work_schedules' => ['array'],
            'secondary_employment_work_schedules.*.day' => ['required_with:secondary_employment_work_schedules','string'],
            'secondary_employment_work_schedules.*.from' => ['required_with:secondary_employment_work_schedules','date_format:H:i'],
            'secondary_employment_work_schedules.*.to' => ['required_with:secondary_employment_work_schedules','date_format:H:i'],

            'contract_compensation_details' => ['array'],
            'contract_compensation_details.*.subject' => ['required','string','max:50'],
            'contract_compensation_details.*.catalog' => ['required','string','max:50'],
            'contract_compensation_details.*.section' => ['required','string','max:50'],
            'contract_compensation_details.*.program' => ['nullable','string','max:255'],
            'contract_compensation_details.*.activity_number' => ['nullable','string','max:50'],
            'contract_compensation_details.*.enrolled' => ['nullable','integer','min:0'],
            'contract_compensation_details.*.hours' => ['required','numeric','min:0'],
            'contract_compensation_details.*.base' => ['required','numeric'],
            'contract_compensation_details.*.credits' => ['required','numeric','min:0'],
            'contract_compensation_details.*.overload' => ['required','boolean'],
            'contract_compensation_details.*.weight' => ['required','numeric'],
            'contract_compensation_details.*.amount' => ['required','numeric','min:0'],

            'contract_question_answers' => ['array'],
            'contract_question_answers.*.question_id' => ['required','uuid'],
            'contract_question_answers.*.answer' => ['required'],

            'contract_attachments' => ['array'],
            'contract_attachments.*.attachment_filename' => ['required','string'],

            'contract_activities' => ['array'],
            'contract_activities.*.activity_number_id' => ['required','uuid'],
            'contract_activities.*.amount' => ['nullable','numeric','min:0'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract.custom');
    }

    protected function prepareForValidation(): void
    {
        // Normalize common boolean inputs arriving as strings or integers
        $data = $this->all();

        // Top-level booleans
        if (array_key_exists('lump_sum', $data)) {
            $data['lump_sum'] = filter_var($data['lump_sum'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        }

        // NUEVO: normalizar 'superseding'
        if (array_key_exists('superseding', $data)) {
            $data['superseding'] = filter_var($data['superseding'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        }

        // Nested booleans in compensation details
        if (!empty($data['contract_compensation_details']) && is_array($data['contract_compensation_details'])) {
            foreach ($data['contract_compensation_details'] as $i => $row) {
                if (is_array($row) && array_key_exists('overload', $row)) {
                    $data['contract_compensation_details'][$i]['overload'] =
                        filter_var($row['overload'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                }
            }
        }

        $this->replace($data);
    }
}
