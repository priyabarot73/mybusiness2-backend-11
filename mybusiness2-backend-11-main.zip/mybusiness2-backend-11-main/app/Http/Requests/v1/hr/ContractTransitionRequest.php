<?php

namespace App\Http\Requests\v1\hr;


// GLOBAL IMPORT
use Illuminate\Validation\Rule;

//LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ContractTransitionRequest extends ApiFormRequest
{
    use DbDefaultTrait;
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'contract_id'   => ['required', 'uuid', Rule::exists($this->getDbDefault('hr.contracts'), 'id'),
            ],
            'transition_id' => ['required', 'uuid', Rule::exists($this->getDbDefault('hr.contract_state_transitions'), 'id'),
            ],
            'comment'       => ['nullable', 'string', 'max:255'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract.custom');
    }
}
