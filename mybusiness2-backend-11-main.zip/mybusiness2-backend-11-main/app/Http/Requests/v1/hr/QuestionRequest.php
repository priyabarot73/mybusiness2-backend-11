<?php

namespace App\Http\Requests\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

//LOCAL IMPORT

class QuestionRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'text' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.questions'))->ignore($this->id)],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/question.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/question.custom');
    }
}
