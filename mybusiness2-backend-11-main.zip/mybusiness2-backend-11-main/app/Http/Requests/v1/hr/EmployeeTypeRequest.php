<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

class EmployeeTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.employee_types'))->ignore($this->id)],
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.employee_types'))->ignore($this->id)],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/employee_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/employee_type.custom');
    }
}
