<?php

namespace App\Http\Requests\v1\hr;

use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;

class SuffixRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.suffixes'))->ignore($this->id)],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/suffix.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/suffix.custom');
    }
}
