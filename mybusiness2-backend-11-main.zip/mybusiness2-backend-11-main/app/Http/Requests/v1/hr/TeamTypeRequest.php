<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class TeamTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('hr.team_types'))->ignore($this->id)
            ],
            'active' => ['boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/team_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/team_type.custom');
    }
}
