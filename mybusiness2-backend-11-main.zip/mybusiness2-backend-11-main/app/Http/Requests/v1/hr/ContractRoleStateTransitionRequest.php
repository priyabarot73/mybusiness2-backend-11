<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;

class ContractRoleStateTransitionRequest extends ApiFormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'role' => ['required', 'uuid'],
            'transitions' => ['nullable', 'array'],
            'transitions.*' => ['uuid'],
            'active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_role_state_transition.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_role_state_transition.custom');
    }
}
