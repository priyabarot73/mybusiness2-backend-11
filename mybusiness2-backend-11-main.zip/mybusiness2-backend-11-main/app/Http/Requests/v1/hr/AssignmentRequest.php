<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class AssignmentRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'person_id' => ['uuid', 'max:36', 'required'],
            'original_hire_date' => ['date', 'required'],
            'salary_admin_plan_id' => ['uuid', 'max:36', 'nullable'],
            'employee_class_id' => ['uuid', 'max:36', 'nullable'],
            'employee_type_id' => ['uuid', 'max:36', 'nullable'],
            'employee_responsibility_id' => ['uuid', 'max:36', 'nullable'],
            'unit_status_id' => ['uuid', 'max:36', 'nullable'],
            'position_number' => ['string', 'max:100', 'nullable'],
            'fte' => ['string', 'max:255', 'nullable'],
            'job_title_id' => ['uuid', 'max:36', 'nullable'],
            'working_title_id' => ['uuid', 'max:36', 'nullable'],
            'action_id' => ['uuid', 'max:36', 'nullable'],
            'action_reason_id' => ['uuid', 'max:36', 'nullable'],
            'start_date' => ['date', 'required'],
            'end_date' => ['date', 'nullable'],
            'business_unit_id' => ['uuid', 'max:36', 'nullable'],
            'department_id' => ['uuid', 'max:36', 'nullable'],
            'sub_department_id' => ['uuid', 'max:36', 'nullable'],
            'academic_group_id' => ['uuid', 'max:36', 'nullable'],
            'academic_organization_id' => ['uuid', 'max:36', 'nullable'],
            'physical_location_id' => ['uuid', 'max:36', 'nullable'],
            'facility_id' => ['uuid', 'max:36', 'nullable'],
            'physical_public_establishment' => ['boolean', 'nullable'],
            'public_establishment_id' => ['uuid', 'max:36', 'nullable'],
            'public_facility_id' => ['uuid', 'max:36', 'nullable'],
            'supervisor_id' => ['uuid', 'max:36', 'nullable'],
            'active' => ['boolean', 'nullable'],

            // Updated to receive an object instead of an array
            'assignment_contract' => ['nullable'],
            'assignment_contract.assignment_id' => ['uuid', 'nullable'],
            'assignment_contract.contract_number' => ['string', 'max:100', 'nullable'],
            'assignment_contract.contract_category_id' => ['uuid', 'max:36', 'nullable'],
            'assignment_contract.contract_type_id' => ['uuid', 'max:36', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/assignment.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/assignment.custom');
    }
}
