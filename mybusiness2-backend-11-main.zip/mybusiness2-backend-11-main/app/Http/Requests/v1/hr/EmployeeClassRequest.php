<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class EmployeeClassRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.employee_classes'))->ignore($this->id)],
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('hr.employee_classes'))->ignore($this->id)],
            'set_id' => ['nullable', 'string', 'max:255'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/employee_class.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/employee_class.custom');
    }
}
