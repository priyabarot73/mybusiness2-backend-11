<?php

namespace App\Http\Requests\v1\hr;

use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ContractRoleStatusRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'role' => ['required', 'uuid'],
            'status' => ['nullable', 'array'],
            'status.*' => ['uuid'],
            'active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_role_status.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_role_status.custom');
    }
}
