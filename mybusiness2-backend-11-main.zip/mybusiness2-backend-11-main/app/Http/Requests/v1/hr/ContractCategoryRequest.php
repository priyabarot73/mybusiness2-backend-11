<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ContractCategoryRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['string', 'required','max:255', Rule::unique($this->getDbDefault('hr.contract_categories'))->ignore($this->id)],
            'description' => ['string', 'nullable'],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_category.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_category.custom');
    }
}
