<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

// LOCAL IMPORT
class PersonRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'panther_id' => ['required','max:7',Rule::unique($this->getDbDefault('hr.persons'))->ignore($this->id)],
            'prefix' => ['nullable','max:255'],
            'first_name' => ['required','max:255'],
            'middle_name' => ['nullable','max:255'],
            'last_name' => ['required','max:255'],
            'second_last_name' => ['nullable','max:255'],
            'generational_title_id' => ['string','max:36','nullable'],
            'suffix_id' => ['string','max:36','nullable'],
            'nickname' => ['nullable','max:255'],
            'birth_country' => ['nullable','max:255'],
            'birth_city' => ['nullable','max:255'],
            'gender' => ['nullable','max:255'],
            'marital_status_id' => ['string','max:36','nullable'],
            'as_of' => ['date','nullable'],
            'disability' => ['nullable','boolean'],
            'citizenship_type_id' => ['string','max:36','nullable'],
            'citizenship_date' => ['nullable','date'],
            'visa_type_id' => ['string','max:36','nullable'],
            'visa_date' => ['nullable','date'],
            'driver_license' => ['nullable','max:255'],
            'country' => ['nullable','max:255'],
            'city' => ['nullable','max:255'],
            'military_status' => ['nullable','max:255'],
            'ethnic_id' => ['string','max:36','nullable'],
            'address' => ['nullable','max:255'],
            'address_country' => ['nullable','max:255'],
            'address_city' => ['nullable','max:255'],
            'address_postal' => ['nullable','max:255'],
            'business_phone_number' => ['nullable','max:255'],
            'business_phone_number_ext' => ['nullable','max:255'],
            'business_phone_number_usa' => ['nullable','boolean'],
            'business_phone_number_public' => ['nullable','boolean'],
            'personal_phone_number' => ['nullable','max:255'],
            'personal_phone_number_ext' => ['nullable','max:255'],
            'personal_phone_number_usa' => ['nullable','boolean'],
            'personal_phone_number_public' => ['nullable','boolean'],
            'business_email' => ['required','email','max:255',Rule::unique($this->getDbDefault('hr.persons'))->ignore($this->id)],
            'business_email_public' => ['nullable','boolean'],
            'personal_email' => ['email','max:255',Rule::unique($this->getDbDefault('hr.persons'))->ignore($this->id)],
            'personal_email_public' => ['nullable','boolean'],
            'active' => ['nullable','boolean'],
            'department_id' => ['string','max:36','nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/person.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/person.custom');
    }
}
