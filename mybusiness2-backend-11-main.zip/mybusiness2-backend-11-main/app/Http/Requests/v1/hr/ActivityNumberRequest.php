<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class ActivityNumberRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'number' => ['required','numeric','max:9999999999',Rule::unique($this->getDbDefault('hr.activity_numbers'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.activity_numbers'))->ignore($this->id)],
            'department_id' => ['uuid','max:36','nullable'],
            'program_id' => ['uuid','max:36','nullable'],
            'responsible_id' => ['uuid','max:36','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/activity_number.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/activity_number.custom');
    }
}
