<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class TeamRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('hr.teams'))->ignore($this->id)
            ],
            'team_type_id' => [
                'required',
                'uuid',
                Rule::exists($this->getDbDefault('hr.team_types'), 'id')
            ],
            'active' => ['boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/team.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/team.custom');
    }
}
