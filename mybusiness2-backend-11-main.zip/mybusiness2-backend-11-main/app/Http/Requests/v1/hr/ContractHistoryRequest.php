<?php

namespace App\Http\Requests\v1\hr;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class ContractHistoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'contract_id' => ['uuid','max:36','required'],
            'state_id' => ['uuid','max:36','required'],
            'date' => ['date','required'],
            'notification_count' => ['integer','nullable'],
            'supervisor_id' => ['uuid','max:36','nullable']
        ];
    }

    public function messages():array
    {
        return [
            'contract_id.required' => 'Required field.',
            'contract_id.uuid' => 'Field must be an UUID.',
            'contract_id.max' => 'Field must have a maximum of 36 characters.',
            'state_id.required' => 'Required field.',
            'state_id.uuid' => 'Field must be an UUID.',
            'state_id.max' => 'Field must have a maximum of 36 characters.',
            'date.required' => 'Required field.',
            'notification_count.integer' => 'Field must be an integer.',
            'supervisor_id.uuid' => 'Field must be an UUID.',
            'supervisor_id.max' => 'Field must have a maximum of 36 characters.',
        ];
    }
}
