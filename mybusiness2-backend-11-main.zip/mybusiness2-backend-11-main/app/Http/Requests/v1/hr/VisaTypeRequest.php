<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class VisaTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique($this->getDbDefault('hr.visa_types'))->ignore($this->id),
            ],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/visa_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/visa_type.custom');
    }
}
