<?php

namespace App\Http\Requests\v1\hr;

//Global Import
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;

//LOCAL IMPORT
class ContractStateRequest extends ApiFormRequest
{
    use DbDefaultTrait;
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255'],
            'contract_option_id' => ['uuid','max:36','required'],
            'code' => ['nullable', 'integer', 'min:0'],
            'action' => ['required','string','max:1'],
            'active' => ['boolean','nullable']
        ];

    }

    public function attributes(): array
    {
        return __('validation/hr/contract_state.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_state.custom');
    }
}
