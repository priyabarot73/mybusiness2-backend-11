<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

//LOCAL IMPORT

class SalaryAdminPlanRequest extends ApiFormRequest
{
    use DbDefaultTrait;
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.salary_admin_plans'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.salary_admin_plans'))->ignore($this->id)],
            'pay_group_id' => ['uuid','nullable'],
            'employee_classification_id' => ['uuid','nullable'],
            'employee_type_id' => ['uuid','nullable'],
            'person_organization_relationship_type_id' => ['uuid','nullable'],
            'used_in' => ['required','string','max:2'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/salary_admin_plan.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/salary_admin_plan.custom');
    }
}
