<?php

namespace App\Http\Requests\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class ContractTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.contract_types'))->ignore($this->id)],
            'description' => ['string','max:255','nullable'],
            'teaching_duties' => ['boolean'],
            'teaching_credit_courses' => ['boolean'],
            'contract_type_level' => ['boolean'],
            'sec_employee_type_level' => ['boolean'],
            'active' => ['boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_type.custom');
    }
}
