<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

//LOCAL IMPORT

class ContractOptionRequest extends ApiFormRequest
{
    use DbDefaultTrait;
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.contract_options'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.contract_options'))->ignore($this->id)],
            'active' => ['boolean','nullable']
        ];
    }
    public function messages():array
    {
        return [
            'code.required' => 'Required field.',
            'code.unique' => 'There is already a employee type with this name.',
            'code.max' => 'Field must have a maximum of 255 characters.',
            'name.required' => 'Required field.',
            'name.unique' => 'There is already a employee classification with this name.',
            'name.max' => 'Field must have a maximum of 255 characters.',
            'active.boolean' => 'Field must be type 1 or 0.'
        ];
    }
}
