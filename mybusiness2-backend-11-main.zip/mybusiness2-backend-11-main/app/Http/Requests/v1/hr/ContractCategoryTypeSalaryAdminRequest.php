<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class ContractCategoryTypeSalaryAdminRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'contract_category_id' => ['required', 'uuid'],
            'contract_type_id' => ['nullable', 'uuid'],
            'salary_admin_plan_id' => ['nullable', 'uuid'],
        ];
    }

    /**
     * Use translation files for attributes and custom messages
     */
    public function attributes(): array
    {
        return __('validation/hr/contract_category_type_salary_admin.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_category_type_salary_admin.custom');
    }
}
