<?php

namespace App\Http\Requests\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class ContractTypeQuestionRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'contract_type_id' => ['uuid','max:36','required'],
            'questions' => 'nullable|array',
            'questions.*' => ['required','uuid']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_type_question.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_type_question.custom');
    }
}
