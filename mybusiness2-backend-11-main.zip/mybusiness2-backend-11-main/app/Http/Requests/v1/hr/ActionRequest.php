<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class ActionRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.actions'))->ignore($this->id)],
            'job_status' => ['string','max:255','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/action.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/action.custom');
    }
}
