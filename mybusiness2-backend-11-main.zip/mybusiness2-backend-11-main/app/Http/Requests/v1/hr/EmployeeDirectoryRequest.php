<?php

namespace App\Http\Requests\v1\hr;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

class EmployeeDirectoryRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'person_id' => [
                'required',
                'uuid',
                Rule::exists($this->getDbDefault('hr.persons'), 'id')
            ],
            'team_id' => [
                'required',
                'uuid',
                Rule::exists($this->getDbDefault('hr.teams'), 'id')
            ],
            'appearance' => ['integer', 'nullable'],
            'role' => ['string', 'max:255', 'nullable'],
            'locked' => ['boolean', 'nullable'],
            'start_date' => ['date', 'nullable'],
            'end_date' => ['date', 'nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/employee_directory.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/employee_directory.custom');
    }
}
