<?php

namespace App\Http\Requests\v1\hr;

use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ContractRateByProgramRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'program_id' => ['required', 'uuid'],
            'contract_rate' => ['required', 'numeric', 'min:1', 'max:30000'],
            'active' => ['nullable', 'boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_rate_by_program.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_rate_by_program.custom');
    }
}
