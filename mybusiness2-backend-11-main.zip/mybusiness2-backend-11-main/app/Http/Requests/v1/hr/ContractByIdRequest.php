<?php

namespace App\Http\Requests\v1\hr;

use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ContractByIdRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'contract_id' => ['required', 'uuid'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/contract_by_id.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/contract_by_id.custom');
    }
}
