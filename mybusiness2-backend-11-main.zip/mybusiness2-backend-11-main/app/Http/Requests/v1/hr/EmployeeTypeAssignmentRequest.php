<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

class EmployeeTypeAssignmentRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('hr.employee_type_assignments'))->ignore($this->id)
            ],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/employee_type_assignment.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/employee_type_assignment.custom');
    }
}
