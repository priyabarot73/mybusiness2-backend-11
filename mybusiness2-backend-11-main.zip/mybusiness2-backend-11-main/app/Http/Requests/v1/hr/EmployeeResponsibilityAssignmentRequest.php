<?php

namespace App\Http\Requests\v1\hr;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class EmployeeResponsibilityAssignmentRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required', 'string', 'max:255',
                Rule::unique($this->getDbDefault('hr.employee_responsibility_assignments'))->ignore($this->id)
            ],
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique($this->getDbDefault('hr.employee_responsibility_assignments'))->ignore($this->id)
            ],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/hr/employee_responsibility_assignment.attributes');
    }

    public function messages(): array
    {
        return __('validation/hr/employee_responsibility_assignment.custom');
    }
}
