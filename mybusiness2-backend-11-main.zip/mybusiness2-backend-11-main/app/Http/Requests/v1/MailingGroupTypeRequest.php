<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MailingGroupTypeRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'reference_contract_id' => ['uuid', 'max:36', 'nullable'],
            'contract_state_id' => ['required', 'string', 'max:255'],
            'active' => ['boolean', 'nullable']
        ];
    }
}
