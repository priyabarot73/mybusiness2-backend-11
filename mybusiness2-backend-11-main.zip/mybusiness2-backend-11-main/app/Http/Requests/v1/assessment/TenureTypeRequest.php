<?php

namespace App\Http\Requests\v1\assessment;

// global import
use Illuminate\Validation\Rule;

// local import
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;



class TenureTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('ass.tenure_types'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('ass.tenure_types'))->ignore($this->id)],
            'description' => ['nullable','string','max:255'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/assessment/tenure_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/assessment/tenure_type.custom');
    }
}
