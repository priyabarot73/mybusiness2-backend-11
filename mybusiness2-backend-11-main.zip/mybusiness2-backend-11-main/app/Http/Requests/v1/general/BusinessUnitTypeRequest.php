<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class BusinessUnitTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'level' => ['required','numeric'],
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.business_unit_types'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.business_unit_types'))->ignore($this->id)],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/business_unit_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/business_unit_type.custom');
    }
}
