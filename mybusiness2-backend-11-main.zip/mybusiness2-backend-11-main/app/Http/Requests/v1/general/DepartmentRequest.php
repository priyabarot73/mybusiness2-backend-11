<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class DepartmentRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'number' => ['required','numeric',Rule::unique($this->getDbDefault('gn.departments'))->ignore($this->id)],
            'name' => ['required','string','max:200',Rule::unique($this->getDbDefault('gn.departments'))->ignore($this->id)],
            'description' => ['string','max:255','nullable'],
            'business_unit_id' => ['uuid','max:36','nullable'],
            'person_id' => ['uuid','max:36','nullable'],
            'job_title_id' => ['uuid','max:36','nullable'],
            'academic_organization_id' => ['uuid','max:36','nullable'],
            'academic_group_id' => ['uuid','max:36','nullable'],
            'parent_department_id' => ['uuid','max:36','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/department.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/department.custom');
    }
}
