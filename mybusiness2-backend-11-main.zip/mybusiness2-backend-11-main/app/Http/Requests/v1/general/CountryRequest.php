<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Validation\Rule;

class CountryRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'country_code' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('gn.countries'))->ignore($this->id)
            ],
            'country_short_code' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('gn.countries'))->ignore($this->id)
            ],
            'country_desc' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('gn.countries'))->ignore($this->id)
            ],
            'country_short_desc' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('gn.countries'))->ignore($this->id)
            ],
            'active' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/country.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/country.custom');
    }
}
