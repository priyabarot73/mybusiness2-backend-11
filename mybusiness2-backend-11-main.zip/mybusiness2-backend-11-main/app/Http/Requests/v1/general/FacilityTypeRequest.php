<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class FacilityTypeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('gn.facility_types'))->ignore($this->id)],
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('gn.facility_types'))->ignore($this->id)],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/facility_type.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/facility_type.custom');
    }
}
