<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class AcademicGroupRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.academic_groups'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.academic_groups'))->ignore($this->id)],
            'description' => ['string','max:255','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/academic_group.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/academic_group.custom');
    }
}
