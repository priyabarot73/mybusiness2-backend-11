<?php

namespace App\Http\Requests\v1\general;

use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class ImportJobRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'file_path' => ['required', 'string'],
            'file_name' => ['required', 'string'],
            'scheduled_time' => ['required', 'date_format:H:i:s'],
        ];
    }

    /**
     * Custom attributes for validation errors.
     *
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return __('validation/general/import_job.attributes');
    }

    /**
     * Custom messages for validation errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return __('validation/general/import_job.custom');
    }
}
