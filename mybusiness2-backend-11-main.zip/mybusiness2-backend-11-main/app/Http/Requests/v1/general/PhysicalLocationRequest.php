<?php

namespace App\Http\Requests\v1\general;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class PhysicalLocationRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('gn.physical_locations'))->ignore($this->id)],
            'description' => ['nullable','string','max:255'],
            'short_description' => ['nullable','string','max:255'],
            'address' => ['nullable','string','max:255'],
            'city' => ['nullable','string','max:255'],
            'zip_code' => ['nullable','numeric'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/physical_location.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/physical_location.custom');
    }
}
