<?php

namespace App\Http\Requests\v1\general;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class CollegeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'string',
                'max:20',
                Rule::unique($this->getDbDefault('gn.colleges'))->ignore($this->id)
            ],
            'name' => [
                'string',
                'max:200',
                Rule::unique($this->getDbDefault('gn.colleges'))->ignore($this->id)
            ],
            'university_name' => ['string', 'max:200', 'nullable'],
            'state'           => ['string', 'max:100', 'nullable'],
            'country'         => ['string', 'max:100', 'nullable'],
            'email'           => ['email', 'max:255', 'nullable'],
            'phone'           => ['string', 'max:50', 'nullable'],
            'address'         => ['string', 'max:255', 'nullable'],
            'url' => ['string', 'max:255', 'nullable'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/college.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/college.custom');
    }
}
