<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class FacilityRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:200', Rule::unique($this->getDbDefault('gn.facilities'))->ignore($this->id)],
            'floor' => ['required', 'numeric'],
            'room' => ['required', 'string', 'max:200'],
            'capacity' => ['required', 'numeric'],
            'address' => ['nullable', 'string', 'max:255'],
            'description' => ['nullable', 'string', 'max:255'],
            'academic_group_id' => ['uuid', 'max:36', 'nullable'],
            'facility_type_id' => ['nullable', 'uuid', 'max:36'],
            'building_id' => ['required', 'uuid', 'max:36'],
            'active' => ['nullable', 'boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/facility.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/facility.custom');
    }
}
