<?php

namespace App\Http\Requests\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class BuildingRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'max:25',
                Rule::unique($this->getDbDefault('gn.buildings'))->ignore($this->id)
            ],
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique($this->getDbDefault('gn.buildings'))->ignore($this->id)
            ],
            'campus_id' => ['uuid', 'max:36', 'nullable'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/building.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/building.custom');
    }
}
