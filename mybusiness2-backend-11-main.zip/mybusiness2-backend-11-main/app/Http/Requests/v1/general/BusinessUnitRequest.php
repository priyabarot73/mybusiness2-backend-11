<?php

namespace App\Http\Requests\v1\general;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class BusinessUnitRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.business_units'))->ignore($this->id)],
            'name' => ['required','string','max:255',Rule::unique($this->getDbDefault('hr.business_units'))->ignore($this->id)],
            'business_unit_type_id' => ['uuid','max:36','nullable'],
            'academic_group_id' => ['uuid','max:36','nullable'],
            'job_title_id' => ['uuid','max:36','nullable'],
            'person_id' => ['uuid','max:36','nullable'],
            'active' => ['boolean','nullable']
        ];
    }

    public function attributes(): array
    {
        return __('validation/general/business_unit.attributes');
    }

    public function messages(): array
    {
        return __('validation/general/business_unit.custom');
    }
}
