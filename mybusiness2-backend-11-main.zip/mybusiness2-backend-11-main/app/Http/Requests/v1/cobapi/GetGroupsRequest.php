<?php

namespace App\Http\Requests\v1\cobapi;

use Illuminate\Foundation\Http\FormRequest;

class GetGroupsRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'filterType' => ['nullable', 'string', 'max:100'],
            'filterID'   => ['nullable', 'string', 'max:100'],
        ];
    }
}
