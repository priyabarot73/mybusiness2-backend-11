<?php

namespace App\Http\Requests\v1;

//GLOBAL IMPORT
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

//LOCAL IMPORT
use App\Traits\DbDefaultTrait;

class UserRequest extends ApiFormRequest
{
    use DbDefaultTrait;
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'max:255',
                'panther_id' => ['required','max:7',Rule::unique($this->getDbDefault('users'))->ignore($this->id)],
            ],
            'email' => [
                'required',
                'email',
                'max:255',
                Rule::unique($this->getDbDefault('users'))->ignore($this->id),
            ],
            'panther_id' => [
                'required',
                'max:7',
                Rule::unique($this->getDbDefault('users'))->ignore($this->id),
            ],
            'avatar' => ['nullable','max:255'],
            'created_at'=>['date','nullable'],
            'updated_at'=>['date','nullable'],
            'active' => ['boolean','required'],
            'roles'=>['array','nullable'],
            'permissions'=>['array','nullable'],
            'person_id' => ['string','max:36','nullable'],

        ];
    }
    public function messages(): array
    {
        return [
            'name.required' => 'Required field.',
            'name.unique' => 'The user name is already being used by another user.',
            'name.max' => 'This field must have a maximum of 255 characters.',
            'email.required' => 'Required field.',
            'email.email' => 'It is not a valid mail.!',
            'email.max' => 'This field must have a maximum of 255 characters.',
            'email.unique' => 'The email is already being used by another user.',
            'panther_id'=>'This field is required!',
            'panther_id.max' => 'This field must have a maximum of 7 characters.',
            'panther_id.unique' => 'There is already a Panther with this number.',
            'avatar.max' => 'This field must have a maximum of 255 characters.',
            'active.required' => 'Required field.',
            'active.integer' => 'Field must be 0 or 1, true or false.',
            'roles.array' => 'Field must be type string array.',
            'permissions.array' => 'Field must be type string array.',
            'person_id.max' => 'Field must have a maximum of 36 characters.',
        ];
    }
}
