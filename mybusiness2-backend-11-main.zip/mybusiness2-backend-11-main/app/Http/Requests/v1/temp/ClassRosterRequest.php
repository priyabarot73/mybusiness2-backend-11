<?php

namespace App\Http\Requests\v1\temp;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;

class ClassRosterRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'course_section' => ['required', 'string'],
            'term' => ['required', 'digits:4'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/temp/class_roster.attributes');
    }

    public function messages(): array
    {
        return __('validation/temp/class_roster.custom');
    }
}
