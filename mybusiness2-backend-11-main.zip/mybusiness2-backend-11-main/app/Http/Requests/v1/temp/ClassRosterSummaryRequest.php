<?php

namespace App\Http\Requests\v1\temp;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;


class ClassRosterSummaryRequest extends ApiFormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'term' => ['required', 'digits:4'],
            'panther_id' => ['nullable', 'digits:7'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/temp/class_roster_summary.attributes');
    }

    public function messages(): array
    {
        return __('validation/temp/class_roster_summary.custom');
    }
}
