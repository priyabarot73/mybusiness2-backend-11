<?php

namespace App\Http\Requests\v1;

//GLOBAL IMPORT
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;


class ApiFormRequest extends FormRequest
{
    use ResponseTrait;

    /**
     * Handle a failed validation attempt.
     *
     * @param  Validator  $validator
     * @return void
     *
     */
    protected function failedValidation(Validator $validator): void
    {
        throw new HttpResponseException(
            $this->response(Response::HTTP_NOT_FOUND,"error",[],(new ValidationException($validator))->errors())
        );
    }
}
