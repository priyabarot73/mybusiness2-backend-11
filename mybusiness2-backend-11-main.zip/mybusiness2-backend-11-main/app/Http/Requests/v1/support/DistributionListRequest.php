<?php

namespace App\Http\Requests\v1\support;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;

//LOCAL IMPORT
use App\Traits\DbDefaultTrait;

class DistributionListRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
            'description' => ['nullable', 'string'],

            // members (users)
            'members' => ['nullable', 'array'],
            'members.*.user_id' => ['required_with:members', 'uuid', Rule::exists($this->getDbDefault('users'), 'id')],
            'members.*.is_active' => ['nullable', 'boolean'],

            // roles
            'roles' => ['nullable', 'array'],
            'roles.*.role_id' => ['required_with:roles', 'uuid', Rule::exists($this->getDbDefault('roles'), 'id')],
            'roles.*.is_active' => ['nullable', 'boolean'],
        ];
    }
}
