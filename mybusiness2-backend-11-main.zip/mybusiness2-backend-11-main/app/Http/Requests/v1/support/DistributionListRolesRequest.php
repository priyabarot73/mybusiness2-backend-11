<?php

namespace App\Http\Requests\v1\support;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;

//LOCAL IMPORT
use App\Traits\DbDefaultTrait;

class DistributionListRolesRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool { return true; }

    public function rules(): array
    {
        return [
            'roles' => ['required', 'array', 'min:1'],
            'roles.*.role_id' => ['required_with:roles', 'uuid', Rule::exists($this->getDbDefault('roles'), 'id')],
            'roles.*.is_active' => ['nullable', 'boolean'],
        ];
    }
}
