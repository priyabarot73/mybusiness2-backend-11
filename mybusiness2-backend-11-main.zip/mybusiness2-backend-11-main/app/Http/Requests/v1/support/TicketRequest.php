<?php

namespace App\Http\Requests\v1\support;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class TicketRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['nullable', 'string', 'max:255', Rule::unique($this->getDbDefault('su.tickets'))->ignore($this->id)],
            'subject' => ['required', 'string', 'max:255'],
            'description' => ['required', 'string'],

            'status' => ['nullable', 'string', Rule::in(['open','pending','resolved','closed'])],
            'priority' => ['nullable', 'string', Rule::in(['low','medium','high','urgent'])],
            'category' => ['nullable', 'string', 'max:255'],

            'user_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('users'), 'id')],
            'assigned_to' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('users'), 'id')],

            'closed_at' => ['nullable', 'date'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/support/ticket.attributes');
    }

    public function messages(): array
    {
        return __('validation/support/ticket.custom');
    }
}
