<?php

namespace App\Http\Requests\v1\support;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class TicketMessageRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'ticket_id' => ['required', 'uuid', Rule::exists($this->getDbDefault('su.tickets'), 'id')],

            // Si no lo envías, el repo usa auth()->id()
            'user_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('users'), 'id')],

            'message' => ['required', 'string'],
            'is_internal' => ['nullable', 'boolean'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/support/ticket_message.attributes');
    }

    public function messages(): array
    {
        return __('validation/support/ticket_message.custom');
    }
}
