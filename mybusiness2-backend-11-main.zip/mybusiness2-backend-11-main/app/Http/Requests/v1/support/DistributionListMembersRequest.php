<?php

namespace App\Http\Requests\v1\support;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;

//LOCAL IMPORT
use App\Traits\DbDefaultTrait;
class DistributionListMembersRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            // members, roles, both
            'members' => ['nullable', 'array'],
            'members.*.user_id' => ['required_with:members', 'uuid', Rule::exists($this->getDbDefault('users'), 'id')],
            'members.*.is_active' => ['nullable', 'boolean'],

            'roles' => ['nullable', 'array'],
            'roles.*.role_id' => ['required_with:roles', 'uuid'],
            'roles.*.is_active' => ['nullable', 'boolean'],
        ];
    }
}
