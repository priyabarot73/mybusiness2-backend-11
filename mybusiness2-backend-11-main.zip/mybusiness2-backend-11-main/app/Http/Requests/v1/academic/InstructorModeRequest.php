<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class InstructorModeRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'max:1',
                Rule::unique($this->getDbDefault('ac.instructor_modes'))->ignore($this->id),
            ],
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique($this->getDbDefault('ac.instructor_modes'))->ignore($this->id),
            ],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/instructor_mode.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/instructor_mode.attributes');
    }
}
