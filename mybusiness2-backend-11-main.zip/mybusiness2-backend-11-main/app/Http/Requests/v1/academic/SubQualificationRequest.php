<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class SubQualificationRequest extends ApiFormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['integer', 'required', 'min:1'],
            'description' => ['string', 'nullable'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/sub_qualification.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/sub_qualification.attributes');
    }
}
