<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;

class SectionRequest extends ApiFormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'caps' => ['boolean', 'nullable'],
            'term_id' => ['required', 'uuid', 'max:36'],
            'course_id' => ['required', 'uuid', 'max:36'],
            'sec_code' => ['required', 'string', 'max:5'],
            'sec_number' => ['required', 'string', 'max:5'],
            'sec_sess' => ['nullable', 'string', 'max:5'],
            'cap' => ['integer', 'nullable'],
            'instructor_mode_id' => ['required', 'uuid', 'max:36'],
            'campus_id' => ['required', 'uuid', 'max:36'],
            'starting_date' => ['required', 'date'],
            'ending_date' => ['required', 'date'],
            'program_id' => ['required', 'uuid', 'max:36'],
            'cohorts' => ['string', 'nullable', 'max:255'],
            'status' => ['string', 'nullable', 'max:100'],
            'comment' => ['string', 'nullable', 'max:255'],
            'internal_note' => ['string', 'nullable', 'max:255'],
            'meeting_patterns' => 'nullable|array',
            'meeting_patterns.*.day' => ['required', 'string'],
            'meeting_patterns.*.start_time' => 'required|date_format:H:i:s',
            'meeting_patterns.*.end_time' => 'required|date_format:H:i:s',
            'meeting_patterns.*.facility_id' => ['required', 'uuid'],
            'meeting_patterns.*.instructor_id' => ['required', 'uuid'],
            'meeting_patterns.*.primary_instructor' => ['nullable', 'integer', 'min:0', 'max:5'],
            'meeting_pattern_hybrids' => 'nullable|array',
            'meeting_pattern_hybrids.*.day' => ['required', 'string'],
            'meeting_pattern_hybrids.*.date' => ['required', 'date'],
            'meeting_pattern_hybrids.*.start_time' => 'required|date_format:H:i:s',
            'meeting_pattern_hybrids.*.end_time' => 'required|date_format:H:i:s',
            'meeting_pattern_hybrids.*.facility_id' => ['required', 'uuid'],
            'meeting_pattern_hybrids.*.instructor_id' => ['required', 'uuid'],
            'meeting_pattern_hybrids.*.primary_instructor' => ['nullable', 'integer', 'min:0', 'max:5'],
            'combined_sections' => ['array', 'nullable'],
        ];
    }

    public function attributes(): array
    {
        return __('validation/academic/section.attributes');
    }

    public function messages(): array
    {
        return __('validation/academic/section.custom');
    }
}
