<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;

class SectionCombinedRequest extends ApiFormRequest
{
    public function rules(): array
    {
        return [
            'termId' => ['uuid', 'max:36', 'required'],
            'criteria' => ['string', 'max:25', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/section_combined.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/section_combined.attributes');
    }
}
