<?php

namespace App\Http\Requests\v1\academic;

use Illuminate\Foundation\Http\FormRequest;

class WorkloadRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'instructor_id' => ['required', 'uuid', 'max:36'],
            'section_id' => ['nullable', 'uuid', 'max:36'],
            'workload' => ['required', 'numeric'],
            'release' => ['required', 'numeric'],
            'release_type' => ['nullable', 'string', 'max:255'],
            'academic_year' => ['required', 'string', 'max:10'],
            'semester' => ['required', 'string', 'max:20'],
            'on_sabbatical' => ['nullable', 'boolean'],
            'on_sick_leave' => ['nullable', 'boolean'],
            'on_paternity_leave' => ['nullable', 'boolean'],
            'comments' => ['string', 'nullable', 'max:255'],
            'workload_course' => ['nullable','array'],
            'workload_course.*.course_id' => ['nullable', 'uuid'],
            'workload_course.*.value' => ['nullable', 'numeric'],
            'workload_course.*.overload' => ['nullable', 'boolean'],
            'workload_course.*.adjusted' => ['nullable', 'numeric'],
            'workload_course.*.on_contract' => ['nullable', 'boolean']
        ];
    }

    public function attributes(): array
    {
        return __('validation/academic/workload.attributes');
    }

    public function messages(): array
    {
        return __('validation/academic/workload.custom');
    }
}
