<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class CourseRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:25', Rule::unique($this->getDbDefault('ac.courses'))->ignore($this->id)],
            'name' => ['string', 'max:200', 'nullable'],
            'credit' => ['required', 'numeric'],
            'hour' => ['required', 'numeric'],
            'references_number' => ['numeric', 'nullable'],
            'description' => ['string', 'max:255', 'nullable'],
            'department_id' => ['uuid', 'max:50', 'nullable'],
            'program_id' => ['uuid', 'max:50', 'nullable'],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/course.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/course.attributes');
    }
}
