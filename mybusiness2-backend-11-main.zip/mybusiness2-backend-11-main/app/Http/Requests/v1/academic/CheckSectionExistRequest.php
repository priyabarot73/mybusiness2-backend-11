<?php

namespace App\Http\Requests\v1\academic;

//GLOBAL IMPORT
use Illuminate\Contracts\Validation\ValidationRule;

// local import
use App\Http\Requests\v1\ApiFormRequest;

class CheckSectionExistRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'term_id' => ['required','string','max:36'],
            'course_id' => ['required','string','max:36'],
            'sec_code' => ['required','string','max:5'],
            'sec_number' => ['required','string','max:5'],
            'sec_sess' => ['nullable','string','max:5']
        ];
    }

    public function attributes(): array
    {
        return __('validation/academic/check_section_exist.attributes');
    }

    public function messages(): array
    {
        return __('validation/academic/check_section_exist.custom');
    }
}
