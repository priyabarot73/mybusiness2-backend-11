<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Validation\Rule;

class OfferingRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'max:25',
                Rule::unique($this->getDbDefault('ac.offerings'))->ignore($this->id),
            ],
            'name' => [
                'required',
                'string',
                'max:255',
            ],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/offering.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/offering.attributes');
    }
}
