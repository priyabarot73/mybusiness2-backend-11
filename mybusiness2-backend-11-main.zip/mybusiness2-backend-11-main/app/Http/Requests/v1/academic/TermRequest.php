<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class TermRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'number' => ['required','integer',Rule::unique($this->getDbDefault('ac.terms'))->ignore($this->id)],
            'semester' => ['required','string','max:10'],
            'year' => ['required','integer'],
            'academic_year' => ['required','string','max:9'],
            'fiu_academic_year' => ['string','max:9'],
            'description' => ['string','max:100','nullable'],
            'description_short' => ['string','max:50','nullable'],
            'begin_dt_for_apt' => ['date','nullable'],
            'begin_dt' => ['date','nullable'],
            'end_dt' => ['date','nullable'],
            'close_end_dt' => ['date','nullable'],
            'fas_begin_dt' => ['date','nullable'],
            'fas_end_dt' => ['date','nullable'],
            'session' => ['string','max:10','nullable'],
            'academic_year_full' => ['string', 'max:9','nullable'],
            'fiu_grade_date' => ['date','nullable'],
            'fiu_grade_date_a' => ['date','nullable'],
            'fiu_grade_date_b' => ['date','nullable'],
            'fiu_grade_date_c' => ['date','nullable'],
            'p180_status_term_id' => ['string', 'max:50','nullable'],
            'active' => ['boolean','nullable'],
        ];
    }

    /**
     * Custom messages for validator errors.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return __('validation/academic/term.custom');
    }

    /**
     * Custom attributes for validator errors.
     *
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return __('validation/academic/term.attributes');
    }
}
