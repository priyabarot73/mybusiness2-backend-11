<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use App\Http\Requests\v1\ApiFormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class SectionDuplicateRequest extends ApiFormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'term_id_origin' => ['required', 'uuid', 'max:36'],
            'term_id_destination' => ['required', 'uuid', 'max:36'],
            'user_id' => ['uuid', 'max:36', 'nullable'],
            'undergraduate' => ['nullable', 'boolean'],
            'graduate' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/section_duplicate.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/section_duplicate.attributes');
    }
}
