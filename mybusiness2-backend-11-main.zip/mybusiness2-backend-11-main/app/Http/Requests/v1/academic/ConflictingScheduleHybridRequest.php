<?php

namespace App\Http\Requests\v1\academic;

//GLOBAL IMPORT
use Illuminate\Contracts\Validation\ValidationRule;

// local import
use App\Http\Requests\v1\ApiFormRequest;

class ConflictingScheduleHybridRequest extends ApiFormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     *
     */
    public function rules(): array
    {
        return [
            'term_id' => ['required','string','max:36'],
            'instructor_id' => ['required','string','max:36'],
            'day' => ['required','string','max:15'],
            'date' => ['required', 'date'],
            'start_time' => 'required|date_format:H:i:s',
            'end_time' => 'required|date_format:H:i:s'
        ];
    }

    public function attributes(): array
    {
        return __('validation/academic/conflicting_schedule_hybrid.attributes');
    }

    public function messages(): array
    {
        return __('validation/academic/conflicting_schedule_hybrid.custom');
    }
}
