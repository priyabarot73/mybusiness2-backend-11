<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class InstructorRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'person_id' => ['nullable', 'uuid', Rule::unique($this->getDbDefault('ac.instructors'))->ignore($this->id)],
            'employee_type_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('hr.employee_types'), 'id')],
            'tenure_type_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('ass.tenure_types'), 'id')],
            'doctorate' => ['nullable', 'boolean'],
            'qualification' => ['nullable', 'string', 'max:255'],
            'sub_qualification_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('ac.sub_qualifications'), 'id')],
            'qualification_type_id' => ['nullable', 'uuid', Rule::exists($this->getDbDefault('ac.qualification_types'), 'id')],
            'aacsb' => ['nullable', 'string', 'max:255'],
            'active' => ['boolean'],
        ];
    }

    /**
     * Get custom attribute names for validator errors.
     */
    public function attributes(): array
    {
        return __('validation/academic/instructor.attributes');
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return __('validation/academic/instructor.custom');
    }
}
