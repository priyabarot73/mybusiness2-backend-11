<?php

namespace App\Http\Requests\v1\academic;

//GLOBAL IMPORT
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\ValidationRule;

class WorkloadIndexRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array|string>
     */
    public function rules(): array
    {
        return [
            'academic_year' => ['required', 'string', 'max:10'],
            'semester' => ['nullable', 'array'],
            'workload_type' => ['required', 'string', 'max:2'],
            'department' => ['nullable', 'uuid'],
        ];
    }
    public function attributes(): array
    {
        return __('validation/academic/index_workload.attributes');
    }

    public function messages(): array
    {
        return __('validation/academic/index_workload.custom');
    }
}
