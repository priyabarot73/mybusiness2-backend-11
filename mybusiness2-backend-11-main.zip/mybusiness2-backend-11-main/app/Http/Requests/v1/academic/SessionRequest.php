<?php

namespace App\Http\Requests\v1\academic;

use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;
use Illuminate\Contracts\Validation\ValidationRule;

class SessionRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['nullable', 'string', 'max:5'],
            'number' => ['nullable', 'string', 'max:5'],
            'sess' => ['nullable', 'string', 'max:5'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/session.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/session.attributes');
    }
}
