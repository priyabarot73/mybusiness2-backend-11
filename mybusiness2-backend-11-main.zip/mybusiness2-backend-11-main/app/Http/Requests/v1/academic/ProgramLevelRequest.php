<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ProgramLevelRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique($this->getDbDefault('ac.program_levels'))->ignore($this->id)
            ],
            'level' => ['required', 'numeric', 'max:9'],
            'active' => ['boolean', 'nullable']
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/program_level.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/program_level.attributes');
    }
}
