<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class AccessPeriodRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'term_id' => ['required', 'uuid', Rule::unique($this->getDbDefault('ac.access_periods'))->ignore($this->id)],
            'admin_beginning_date' => ['required', 'date'],
            'admin_ending_date' => ['required', 'date'],
            'admin_cancel_section_date' => ['required', 'date'],
            'depart_beginning_date' => ['required', 'date'],
            'depart_ending_date' => ['required', 'date'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/access_period.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/access_period.attributes');
    }
}
