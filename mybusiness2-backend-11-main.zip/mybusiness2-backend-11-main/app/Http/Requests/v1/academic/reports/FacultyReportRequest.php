<?php

namespace App\Http\Requests\v1\academic\reports;

use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;

class FacultyReportRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            // route param mapped in prepareForValidation()
            'acadYear' => [
                'required',
                'string',
                Rule::exists($this->getDbDefault('ac.terms'), 'academic_year'),
            ],

            // term toggles
            'fall'   => ['sometimes', 'boolean'],
            'spring' => ['sometimes', 'boolean'],
            'summer' => ['sometimes', 'boolean'],

            // status
            'status' => ['sometimes', 'string', Rule::in(['active', 'inactive', 'all'])],

            // employee types (we normalize to array in prepareForValidation)
            'employeeTypes' => ['sometimes', 'array', 'min:1'],
            'employeeTypes.*' => ['string', Rule::in(['FAC','ADJ','GA'])],

            // paging/sort/search
            'pageSize' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'page' => ['sometimes', 'integer', 'min:1'],
            'search' => ['sometimes', 'nullable', 'string'],
            'sortColumn' => ['sometimes', 'string'],
            'sortDirection' => ['sometimes', 'in:asc,desc'],
        ];
    }

    protected function prepareForValidation(): void
    {
        // academic year: query param wins, otherwise route param
        $acadYear = $this->query('academic_year') ?? $this->route('acad_year');

        /**
         * TERMS:
         * Accept either:
         *  - term_options[] = fall|spring|summer
         *  - fall/spring/summer booleans
         *
         * Defaults: fall=true, spring=true, summer=false
         */
        $termOptions = $this->query('term_options', null);

        if (is_array($termOptions)) {
            $termOptions = array_map(fn($v) => strtolower(trim((string) $v)), $termOptions);

            $fall   = in_array('fall', $termOptions, true);
            $spring = in_array('spring', $termOptions, true);
            $summer = in_array('summer', $termOptions, true);

            // If provided but empty, default to all
            if (!$fall && !$spring && !$summer) {
                $fall = $spring = $summer = true;
            }
        } else {
            // fallback to booleans
            $fall   = $this->has('fall')   ? filter_var($this->query('fall'), FILTER_VALIDATE_BOOLEAN)   : true;
            $spring = $this->has('spring') ? filter_var($this->query('spring'), FILTER_VALIDATE_BOOLEAN) : true;
            $summer = $this->has('summer') ? filter_var($this->query('summer'), FILTER_VALIDATE_BOOLEAN) : false;

            if (!$fall && !$spring && !$summer) {
                $fall = $spring = $summer = true;
            }
        }

        /**
         * EMPLOYEE TYPES:
         * Accept either:
         *  - employee_types[] = FAC|ADJ|GA
         *  - employeeTypes (array or "FAC,ADJ,GA")
         */
        $rawTypes = $this->query('employee_types', null);

        if ($rawTypes === null) {
            $rawTypes = $this->query('employeeTypes', ['FAC','ADJ','GA']);
        }

        if (is_string($rawTypes)) {
            $rawTypes = array_map('trim', explode(',', $rawTypes));
        }
        if (!is_array($rawTypes)) {
            $rawTypes = ['FAC','ADJ','GA'];
        }

        $types = [];
        foreach ($rawTypes as $t) {
            $t = strtoupper(trim((string) $t));
            if ($t === 'FACULTY') $t = 'FAC';
            if ($t === 'ADJUNCT') $t = 'ADJ';
            if ($t === 'GRADUATE ASSISTANT') $t = 'GA';
            if (in_array($t, ['FAC','ADJ','GA'], true)) $types[] = $t;
        }
        $types = array_values(array_unique($types));
        if (empty($types)) $types = ['FAC','ADJ','GA'];

        /**
         * SORT:
         * FE sends sort=asc|desc, backend might use sortDirection
         */
        $sortDirection = $this->query('sortDirection', null);
        if ($sortDirection === null) {
            $sortDirection = $this->query('sort', 'asc');
        }
        $sortDirection = strtolower((string) $sortDirection) === 'desc' ? 'desc' : 'asc';

        $this->merge([
            // keep your existing key used in rules()
            'acadYear' => $acadYear,

            // normalized flags repo can use
            'fall' => $fall,
            'spring' => $spring,
            'summer' => $summer,

            // normalized employee types
            'employeeTypes' => $types,

            // normalized sort direction
            'sortDirection' => $sortDirection,

            // normalize status casing (optional)
            'status' => strtolower((string) $this->query('status', 'all')),
        ]);
    }

    public function messages(): array
    {
        $v = trans('validation/academic/reports/faculty_report.custom');
        return is_array($v) ? $v : [];
    }

    public function attributes(): array
    {
        $v = trans('validation/academic/reports/faculty_report.attributes');
        return is_array($v) ? $v : [];
    }
}
