<?php

namespace App\Http\Requests\v1\academic\reports;

use Illuminate\Validation\Rule;
use App\Http\Requests\v1\ApiFormRequest;
use App\Traits\DbDefaultTrait;

class ScheduleSectionsReportRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'termNumber' => [
                'required',
                'integer',
                Rule::exists($this->getDbDefault('ac.terms'), 'number')
            ],
            'pageSize' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'page' => ['sometimes', 'integer', 'min:1'],
            'search' => ['sometimes', 'nullable','string'],
            'sortColumn' => ['sometimes', 'string'],
            'sortDirection' => ['sometimes', 'in:asc,desc'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'termNumber' => $this->route('termNumber'),
        ]);
    }

    public function messages(): array
    {
        return __('validation/academic/reports/schedule_sections_report.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/reports/schedule_sections_report.attributes');
    }
}
