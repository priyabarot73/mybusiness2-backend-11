<?php

namespace App\Http\Requests\v1\academic;

use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ProgramRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => ['required', 'string', 'max:25', Rule::unique($this->getDbDefault('ac.programs'))->ignore($this->id)],
            'name' => ['required', 'string', 'max:255', Rule::unique($this->getDbDefault('ac.programs'))->ignore($this->id)],
            'degree_id' => ['required', 'uuid', 'max:36'],
            'offering_id' => ['required', 'uuid', 'max:36'],
            'program_level_id' => ['uuid', 'max:36', 'nullable'],
            'program_grouping_id' => ['uuid', 'max:36', 'nullable'],
            'fte' => ['boolean', 'nullable'],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/program.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/program.attributes');
    }
}
