<?php

namespace App\Http\Requests\v1\academic;

// GLOBAL IMPORT
use Illuminate\Validation\Rule;
use Illuminate\Contracts\Validation\ValidationRule;

// LOCAL IMPORT
use App\Traits\DbDefaultTrait;
use App\Http\Requests\v1\ApiFormRequest;

class ProgramGroupingRequest extends ApiFormRequest
{
    use DbDefaultTrait;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => [
                'required',
                'string',
                'max:25',
                Rule::unique($this->getDbDefault('ac.program_groupings'))->ignore($this->id)
            ],
            'name' => [
                'required',
                'string',
                'max:255',
                Rule::unique($this->getDbDefault('ac.program_groupings'))->ignore($this->id)
            ],
            'active' => ['boolean', 'nullable'],
        ];
    }

    public function messages(): array
    {
        return __('validation/academic/program_grouping.custom');
    }

    public function attributes(): array
    {
        return __('validation/academic/program_grouping.attributes');
    }
}
