<?php

namespace App\Http\Controllers\v2;

//GLOBAL IMPORT
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

/**
 * @OA\Info(
 *      version="2.0",
 *      x={
 *          "logo": {
 *              "url": "https://via.placeholder.com/190x90.png?text=L5-Swagger"
 *          }
 *      },
 *      title="MyBusiness 2.0 API V2",
 *      description="MyBusiness API documentation",
 *      @OA\Contact(
 *          email="sgg.2020@gmail.com"
 *      ),
 * )
 * @OA\Tag(
 *     name="Session",
 *     description="Insert Description of Session Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 */

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
}

