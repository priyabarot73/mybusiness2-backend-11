<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\general\CountryRequest;
use App\Repositories\v1\general\CountryRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class CountryController extends Controller
{
    protected CountryRepository $countryRepository;
    use ResponseTrait;

    public function __construct(CountryRepository $countryRepository)
    {
        $this->countryRepository = $countryRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/country/index",
     *     tags={"Country"},
     *     summary="Get all countries",
     *     operationId="indexCountry",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexCountry(): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.index'),
                $this->countryRepository->viewAll(),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get countries by status
     * @OA\Get(
     *     path="/api/v1/country/status/{status}",
     *     tags={"Country"},
     *     operationId="showCountryByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param int $status
     * @return JsonResponse
     */
    public function showCountryByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.status'),
                $this->countryRepository->viewAllByStatus($status),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get country by ID
     * @OA\Get(
     *     path="/api/v1/country/{id}",
     *     tags={"Country"},
     *     operationId="showCountry",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showCountry(string $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.id'),
                $this->countryRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create country
     * @OA\Post (
     *     path="/api/v1/country/add",
     *     tags={"Country"},
     *     operationId="addCountry",
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="country_code", type="string"),
     *                      @OA\Property(property="country_short_code", type="string"),
     *                      @OA\Property(property="country_desc", type="string"),
     *                      @OA\Property(property="country_short_desc", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "country_code": "USA",
     *                      "country_short_code": "US",
     *                      "country_desc": "United States of America",
     *                      "country_short_desc": "United States",
     *                      "active": true
     *                 }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function addCountry(CountryRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.add'),
                $this->countryRepository->create($request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update country
     * @OA\Put (
     *     path="/api/v1/country/update/{id}",
     *     tags={"Country"},
     *     operationId="updateCountry",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="country_code", type="string"),
     *                      @OA\Property(property="country_short_code", type="string"),
     *                      @OA\Property(property="country_desc", type="string"),
     *                      @OA\Property(property="country_short_desc", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "country_code": "USA",
     *                      "country_short_code": "US",
     *                      "country_desc": "United States of America",
     *                      "country_short_desc": "United States",
     *                      "active": true
     *                 }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function updateCountry(string $id, CountryRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.update'),
                $this->countryRepository->update($id, $request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete country by ID
     * @OA\Delete(
     *     path="/api/v1/country/delete/{id}",
     *     tags={"Country"},
     *     operationId="deleteCountry",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteCountry(string $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/country.delete'),
                $this->countryRepository->delete($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
