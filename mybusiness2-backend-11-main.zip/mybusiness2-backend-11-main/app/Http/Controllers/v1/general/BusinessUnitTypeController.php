<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\general\BusinessUnitTypeRequest;
use App\Repositories\v1\general\BusinessUnitTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class BusinessUnitTypeController
{
    protected BusinessUnitTypeRepository $businessUnitTypeRepository;
    use ResponseTrait;
    public function __construct(BusinessUnitTypeRepository $businessUnitTypeRepository)
    {
        $this->businessUnitTypeRepository = $businessUnitTypeRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/business_unit_type/index",
     *     tags={"Business Unit Type"},
     *     summary="Get all Business Unit Types",
     *     operationId="indexBusinessUnitType",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexBusinessUnitType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit_type.index'), $this->businessUnitTypeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/business_unit_type/status/{status}",
     *     tags={"Business Unit Type"},
     *     summary="Get all Business Unit Types",
     *     operationId="indexBusinessUnitTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showBusinessUnitTypeByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit_type.status'), $this->businessUnitTypeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Business Unit Type
     * @OA\Post (
     *     path="/api/v1/business_unit_type/add",
     *     tags={"Business Unit Type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="level",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "level": "0",
     *                      "code": "INST",
     *                      "name": "Instution",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addBusinessUnitType(BusinessUnitTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit_type.add'), $this->businessUnitTypeRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
     /**
     * Update a Business Unit Type
     * @OA\Put (
     *     path="/api/v1/business_unit_type/update/{id}",
     *     tags={"Business Unit Type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="level",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "level": "0",
     *                      "code": "INST",
     *                      "name": "Instution",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateBusinessUnitType(string $id, BusinessUnitTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit_type.update'), $this->businessUnitTypeRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
