<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\general\BusinessUnitRequest;
use App\Repositories\v1\general\BusinessUnitRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class BusinessUnitController
{
    protected BusinessUnitRepository $businessUnitRepository;
    use ResponseTrait;
    public function __construct(BusinessUnitRepository $businessUnitRepository)
    {
        $this->businessUnitRepository = $businessUnitRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/business_unit/index",
     *     tags={"Business Unit"},
     *     summary="Get all Business Units",
     *     operationId="indexBusinessUnit",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexBusinessUnit(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit.index'), $this->businessUnitRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/business_unit/status/{status}",
     *     tags={"Business Unit"},
     *     summary="Get all Business Units by Status",
     *     operationId="showBusinessUnitByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showBusinessUnitByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit.status'), $this->businessUnitRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Business Unit
     * @OA\Post (
     *     path="/api/v1/business_unit/add",
     *     tags={"Business Unit"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_unit_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="job_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="person_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "AACBA",
     *                      "name": "College of Business",
     *                      "business_unit_type_id": "C022CAD7-3E28-4320-9D25-44369D0A2FC3",
     *                      "academic_group_id": "6B5E60B1-FA8A-4EE2-A7C8-F8ECFEE7486C",
     *                      "job_title_id": "75778D66-F283-4FC5-931C-1DF36E7596C7",
     *                      "person_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addBusinessUnit(BusinessUnitRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit.add'), $this->businessUnitRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Business Unit
     * @OA\Put (
     *     path="/api/v1/business_unit/update/{id}",
     *     tags={"Business Unit"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_unit_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="job_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="person_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "AACBA",
     *                      "name": "College of Business",
     *                      "business_unit_type_id": "C022CAD7-3E28-4320-9D25-44369D0A2FC3",
     *                      "academic_group_id": "6B5E60B1-FA8A-4EE2-A7C8-F8ECFEE7486C",
     *                      "job_title_id": "75778D66-F283-4FC5-931C-1DF36E7596C7",
     *                      "person_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function updateBusinessUnit(string $id, BusinessUnitRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/business_unit.update'), $this->businessUnitRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
