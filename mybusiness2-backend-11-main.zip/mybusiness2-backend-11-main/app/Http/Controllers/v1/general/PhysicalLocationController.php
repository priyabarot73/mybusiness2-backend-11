<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\general\PhysicalLocationRequest;
use App\Repositories\v1\general\PhysicalLocationRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class PhysicalLocationController
{
    protected PhysicalLocationRepository $physicalRepository;
    use ResponseTrait;

    public function __construct(PhysicalLocationRepository $physicalRepository)
    {
        $this->physicalRepository = $physicalRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/physical_location/index",
     *     tags={"Physical Location"},
     *     summary="Get all Physical Locations",
     *     operationId="indexPhysicalLocation",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexPhysicalLocation(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/physical_location.index'), $this->physicalRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/physical_location/status/{status}",
     *     tags={"Physical Location"},
     *     summary="Get all Physical Locations by status",
     *     operationId="showPhysicalLocationByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showPhysicalLocationByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/physical_location.show'), $this->physicalRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }


    public function showPhysicalLocation(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/physical_location.show'), $this->physicalRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

/**
     * Create a Physical Location
     * @OA\Post (
     *     path="/api/v1/physical_location/add",
     *     tags={"Physical Location"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="short_description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="zip_code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "University Park Campus",
     *                      "description": "University Park Campus",
     *                      "short_description": "Univ Park",
     *                      "address": "11200 S.W. 8th St",
     *                      "city": "Miami",
     *                      "zip_code": "33199",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addPhysicalLocation(PhysicalLocationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/physical_location.add'), $this->physicalRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

/**
     * Update a Physical Location
     * @OA\Put (
     *     path="/api/v1/physical_location/update/{id}",
     *     tags={"Physical Location"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="short_description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="zip_code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "University Park Campus - Updated",
     *                      "description": "University Park Campus - Updated",
     *                      "short_description": "Univ Park",
     *                      "address": "11200 S.W. 8th St",
     *                      "city": "Miami",
     *                      "zip_code": "33199",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updatePhysicalLocation(string $id, PhysicalLocationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/physical_location.update'), $this->physicalRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
