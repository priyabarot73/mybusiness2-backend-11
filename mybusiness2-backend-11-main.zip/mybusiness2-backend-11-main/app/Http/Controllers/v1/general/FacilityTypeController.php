<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\general\FacilityTypeRequest;
use App\Repositories\v1\general\FacilityTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class FacilityTypeController
{
    protected FacilityTypeRepository $facilityTypeRepository;
    use ResponseTrait;
    public function __construct(FacilityTypeRepository $facilityTypeRepository)
    {
        $this->facilityTypeRepository = $facilityTypeRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/facility_type/index",
     *     tags={"Facility Type"},
     *     summary="Get all Facility Types",
     *     operationId="indexFacilityType",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexFacilityType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/facility_type.index'), $this->facilityTypeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/facility_type/status/{status}",
     *     tags={"Facility Type"},
     *     summary="Get Facility Types",
     *     operationId="showFacilityTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showFacilityTypeByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/facility_type.status'), $this->facilityTypeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create a Facility Type
     * @OA\Post (
     *     path="/api/v1/facility_type/add",
     *     tags={"Facility Type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "LAB",
     *                      "name": "Laboratory",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addFacilityType(FacilityTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/facility_type.add'), $this->facilityTypeRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update a Facility Type
     * @OA\Put (
     *     path="/api/v1/facility_type/update/{id}",
     *     tags={"Facility Type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "LAB - Update",
     *                      "name": "Laboratory - Update",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateFacilityType(string $id, FacilityTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/facility_type.update'), $this->facilityTypeRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
