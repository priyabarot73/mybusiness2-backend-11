<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Repositories\v1\general\ActivityTimeLineRepository;

class ActivityTimeLineController
{
    use ResponseTrait;

    protected ActivityTimeLineRepository $repository;

    public function __construct(ActivityTimeLineRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexLog(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/activity_time_line.index'), $this->repository->all($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showLog(Request $request, string $actionId): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('general/activity_time_line.show'),
                $this->repository->getAllByActionRange($request, $actionId),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

}
