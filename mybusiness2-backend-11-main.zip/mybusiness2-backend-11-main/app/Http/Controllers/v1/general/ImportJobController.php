<?php

namespace App\Http\Controllers\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\general\ImportJobRequest;
use App\Repositories\v1\general\ImportJobRepository;

class ImportJobController
{
    use ResponseTrait;
    protected ImportJobRepository $repository;
    public function __construct(ImportJobRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexImportJob(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/import_job.index'), $this->repository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function createImportJob(ImportJobRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/import_job.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateImportJob(string $id, ImportJobRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('general/import_job.update'), $this->repository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
