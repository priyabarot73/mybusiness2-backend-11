<?php

namespace App\Http\Controllers\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Http\Requests\v1\UserHasPermissionRequest;
use App\Repositories\v1\UserHasPermissionRepository;
use App\Traits\ResponseTrait;

class UserHasPermissionController extends Controller
{
    use ResponseTrait;
    protected UserHasPermissionRepository $userHasPermissionRepository;

    public function __construct(UserHasPermissionRepository $userHasPermissionRepository)
    {
        $this->userHasPermissionRepository = $userHasPermissionRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/user_permission/index",
     *     tags={"User has permission"},
     *     summary="Get all users and permissions",
     *     operationId="indexUserHasPermission",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexUserHasPermission(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user_has_permission.index'), $this->userHasPermissionRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get permissions by user ID
     * @OA\Get(
     *     path="/api/v1/user_permission/{id}",
     *     tags={"User has permission"},
     *     operationId="showPermissionsByUserId",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="bde0046b-83c0-4fda-9a81-05a4faf06b79",
     *             type="string"
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showPermissionsByUserId(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user_has_permission.userId'), $this->userHasPermissionRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

     /**
     * Assign permissions to user by user ID
     * @OA\Put (
     *     path="/api/v1/user_permission/add/{id}",
     *     tags={"User has permission"},
     *     operationId="assignPermissionToUserById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="bde0046b-83c0-4fda-9a81-05a4faf06b79",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="multipart/form-data",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="permissions",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"List roles","Update terms"}),
     *                      )
     *                 )
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     *
     * *
     * @param string $id
     * @param UserHasPermissionRequest $request
     * @return JsonResponse
     */
    public function assignPermissionToUserById(UserHasPermissionRequest $request,string $id):JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user_has_permission.aggregate'), $this->userHasPermissionRepository->assignPermissions($request,$id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Revoke permissions to user by user ID
     * @OA\Delete (
     *     path="/api/v1/user_permission/delete/{id}",
     *     tags={"User has permission"},
     *     operationId="deletePermissionToUserById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="bde0046b-83c0-4fda-9a81-05a4faf06b79",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="multipart/form-data",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="permissions",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"List roles","Update terms"}),
     *                      )
     *                 )
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     *
     * *
     * @param string $id
     * @param UserHasPermissionRequest $request
     * @return JsonResponse
     */
    public function deletePermissionToUserById(UserHasPermissionRequest $request,string $id):JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user_has_permission.delete'), $this->userHasPermissionRepository->deletePermissions($request,$id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
