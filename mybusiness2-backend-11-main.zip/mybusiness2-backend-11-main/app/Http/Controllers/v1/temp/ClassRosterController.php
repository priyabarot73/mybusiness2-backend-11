<?php

namespace App\Http\Controllers\v1\temp;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\temp\ClassRosterRequest;
use App\Repositories\v1\tem\ClassRosterRepository;
use App\Http\Requests\v1\temp\ClassRosterSummaryRequest;

class ClassRosterController
{
    protected ClassRosterRepository $repository;
    use ResponseTrait;


    public function __construct(ClassRosterRepository $repository)
    {
        $this->repository = $repository;
    }

    public function getClassRosterSummary(ClassRosterSummaryRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("temp/class_roster.summary"), $this->repository->getCourseSectionsSummary($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getClassRoster(ClassRosterRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("temp/class_roster.section"), $this->repository->getCourseSections($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
