<?php

namespace App\Http\Controllers\v1;

use App\Http\Requests\MailingGroupTypeRequest;
use Exception;
use Illuminate\Http\Request;
use App\Traits\ResponseTrait;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use App\Repositories\v1\MailingGroupTypeRepository;

class MailingGroupTypeController
{
    protected MailingGroupTypeRepository $mailingGroupTypeRepository;
    use ResponseTrait;

    public function __construct(MailingGroupTypeRepository $mailingGroupTypeRepository)
    {
        $this->mailingGroupTypeRepository = $mailingGroupTypeRepository;
    }
    public function indexMailingGroupType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('mailing_group_type.index'), $this->mailingGroupTypeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function indexMailingGroupTypeByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('mailing_group_type.index'), $this->mailingGroupTypeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function createMailingGroupType(MailingGroupTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('mailing_group_type.create'), $this->mailingGroupTypeRepository->create($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
