<?php

namespace App\Http\Controllers\v1;

//Global Import 
use Exception;
use Illuminate\Http\Request;
use App\Traits\ResponseTrait;

//Local Import
use Illuminate\Http\JsonResponse;
use App\Repositories\v1\EmailRepository;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Requests\v1\ContractNotificationEmailRequest;

class EmailController
{
    protected EmailRepository $emailRepository;
    use ResponseTrait;

    public function __construct(EmailRepository $emailRepository)
    {
        $this->emailRepository = $emailRepository;
    }
//First Stage of Contract

    public function contractCreationNotification(ContractNotificationEmailRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('E-Mail Sent'), $this->emailRepository->contractCreationNotification($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    public function contractUpdateNotification(ContractNotificationEmailRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('E-Mail Sent'), $this->emailRepository->contractUpdateNotification($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    
}
