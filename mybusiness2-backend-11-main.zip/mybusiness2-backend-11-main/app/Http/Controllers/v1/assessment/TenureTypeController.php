<?php

namespace App\Http\Controllers\v1\assessment;

//global import
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//local importT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\assessment\TenureTypeRequest;
use App\Repositories\v1\assessment\TenureTypeRepository;

class TenureTypeController
{
    use ResponseTrait;
    protected TenureTypeRepository $repository;
    public function __construct(TenureTypeRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexTenureType(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('assessment/tenure_type.index'), $this->repository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showTenureTypeByStatus(Request $request,int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('assessment/tenure_type.show'), $this->repository->viewAllByStatus($request,$status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function addTenureType(TenureTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('assessment/tenure_type.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateTenureType(string $id, TenureTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('assessment/tenure_type.update'), $this->repository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
