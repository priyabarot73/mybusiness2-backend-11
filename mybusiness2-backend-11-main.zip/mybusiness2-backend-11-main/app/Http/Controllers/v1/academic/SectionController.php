<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\SectionRequest;
use App\Repositories\v1\academic\SectionRepository;
use App\Http\Requests\v1\academic\SectionDuplicateRequest;
use App\Http\Requests\v1\academic\CheckSectionExistRequest;
use App\Http\Requests\v1\academic\ConflictingScheduleRequest;
use App\Http\Requests\v1\academic\ConflictingScheduleHybridRequest;

class SectionController extends Controller
{
    use ResponseTrait;
    protected SectionRepository $sectionRepository;

    public function __construct(SectionRepository $sectionRepository)
    {
        $this->sectionRepository = $sectionRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/section/index",
     *     tags={"Section"},
     *     summary="Get all sections",
     *     operationId="indexSection",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexSection(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.index'), $this->sectionRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function infoDashboard(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.index'), $this->sectionRepository->infoDashboard(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create a new section
     * @OA\Post (
     *     path="/api/v1/section/add",
     *     tags={"Section"},
     *     operationId="addSection",
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="caps",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="term_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="course_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_sess",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="cap",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="instructor_mode_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="campus_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="starting_date",
     *                          type="datetime"
     *                      ),
     *                      @OA\Property(
     *                          property="ending_date",
     *                          type="datetime"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="cohorts",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="status",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="combined",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="created_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="updated_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                      property="created_by",
     *                      type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="comment",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="internal_note",
     *                          type="string",
     *                      ),
     *                      @OA\Property(
     *                          property="meeting_patterns",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(
     *                              ref="#/components/schemas/MeetingPattern"
     *                          )
     *                      ),
     *                 ),
     *                 example={
     *                      "caps": "0",
     *                      "term_id": "a8099df4-621c-4ace-8331-056d9d4d30ce",
     *                      "course_id": "05eabc49-8144-4fff-b09f-d677ecc70118",
     *                      "sec_code":"A",
     *                      "sec_number":"02",
     *                      "sec_sess":"B",
     *                      "cap": 60,
     *                      "instructor_mode_id": "cca7158e-53c0-44e6-810a-77aa69a5fdfe",
     *                      "campus_id": "2a0cb279-e7a8-4cba-a261-08856e63415c",
     *                      "starting_date": "2024-01-07 02:47:48.000",
     *                      "ending_date": "2025-04-20 01:47:48.000",
     *                      "program_id": "caba3c5d-0fc9-4ab7-9e9f-3d4ada1ba509",
     *                      "cohorts": "2B",
     *                      "status": "New",
     *                      "comment": "",
     *                      "internal_note": "",
     *
     *                      "meeting_patterns": {
     *                          {
     *                              "day": "Monday",
     *                              "start_time": "11:00",
     *                              "end_time": "11:00",
     *                              "facility_id": "c237f96f-1e2f-4f8f-9cee-02292ea31a8c",
     *                              "user_id": "72e229d6-3059-4841-9e52-d052581d4ae2",
     *                              "primary_instructor": 1
     *                          }
     *                       },
     *                      "combined_sections": {}
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */

    public function addSection(SectionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.add'), $this->sectionRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update a Section
     * @OA\Put (
     *     path="/api/v1/section/update/{id}",
     *     tags={"Section"},
     *      operationId="updateSection",
     *      @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="caps",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="term_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="course_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_sess",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="cap",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="instructor_mode_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="campus_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="starting_date",
     *                          type="datetime"
     *                      ),
     *                      @OA\Property(
     *                          property="ending_date",
     *                          type="datetime"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="cohorts",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="status",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="combined",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="created_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="updated_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                      property="created_by",
     *                      type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="comment",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="internal_note",
     *                          type="string",
     *                      ),
     *                      @OA\Property(
     *                          property="meeting_patterns",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(
     *                              ref="#/components/schemas/MeetingPattern"
     *                          )
     *                      ),
     *                 ),
     *                 example={
     *                      "caps": "0",
     *                      "term_id": "a8099df4-621c-4ace-8331-056d9d4d30ce",
     *                      "course_id": "05eabc49-8144-4fff-b09f-d677ecc70118",
     *                      "sec_code":"A",
     *                      "sec_number":"02",
     *                      "sec_sess":"B",
     *                      "cap": 60,
     *                      "instructor_mode_id": "cca7158e-53c0-44e6-810a-77aa69a5fdfe",
     *                      "campus_id": "2a0cb279-e7a8-4cba-a261-08856e63415c",
     *                      "starting_date": "2024-01-07 02:47:48.000",
     *                      "ending_date": "2025-04-20 01:47:48.000",
     *                      "program_id": "caba3c5d-0fc9-4ab7-9e9f-3d4ada1ba509",
     *                      "cohorts": "2B",
     *                      "status": "New",
     *                      "comment": "",
     *                      "internal_note": "",
     *
     *                      "meeting_patterns": {
     *                          {
     *                              "day": "Monday",
     *                              "start_time": "11:00",
     *                              "end_time": "11:00",
     *                              "facility_id": "c237f96f-1e2f-4f8f-9cee-02292ea31a8c",
     *                              "user_id": "72e229d6-3059-4841-9e52-d052581d4ae2",
     *                              "primary_instructor": 1
     *                          }
     *                       },
     *                      "combined_sections": {}
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function updateSection(string $id, SectionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.update'), $this->sectionRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete Section by id
     * @OA\Delete(
     *     path="/api/v1/section/delete/{id}",
     *     tags={"Section"},
     *     operationId="deleteSection",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteSection(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.delete'), $this->sectionRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /* Clone a single section*/
    public function cloneSection(SectionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.cloneSingle'), $this->sectionRepository->cloneSection($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Clone sections from Term A to Term B
     * @OA\Post (
     *     path="/api/v1/section/clone",
     *     tags={"Section"},
     *     operationId="cloneSections",
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="term_id_origin",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="term_id_destination",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="user_id",
     *                          type="string",
     *                          format="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="comment",
     *                          type="string"
     *                      )
     *                 ),
     *                 example={
     *                      "term_id_origin": "a8099df4-621c-4ace-8331-056d9d4d30ce",
     *                      "term_id_destination": "ac2f8ddb-5ab0-4ebb-9f82-5c3efdd6de4e",
     *                      "user_id": "72e229d6-3059-4841-9e52-d052581d4ae2",
     *                      "comment":"I have duplicated the section from term A to term B",
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function cloneSections(SectionDuplicateRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.cloned'), $this->sectionRepository->cloneSections($request),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function quantitySection(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.quantity'), $this->sectionRepository->termInstructorQuantity(),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getTermsInfo(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.info'), $this->sectionRepository->getTermsInfo(),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/section/list/{term_id}",
     *     tags={"Section"},
     *     summary="Get sections by Term ID",
     *     operationId="getSectionsByTermId",
     *     @OA\Parameter(
     *         name="term_id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function getSectionsByTermId(Request $request,string $termId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.info'), $this->sectionRepository->viewAllSectionsByTermID($request,$termId),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getSectionsByTermIdToCombined(string $termId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.info'), $this->sectionRepository->viewAllSectionsByTermIDCombined($termId),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/section/{id}",
     *     tags={"Section"},
     *     summary="Get section by ID",
     *     operationId="showSection",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showSection(string $Id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.exceptionSuccessSectionInfo'), $this->sectionRepository->viewByID($Id),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /* Check for conflict in meeting pattern when create section */
    public function hasConflictingSchedule(ConflictingScheduleRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.conflict'), $this->sectionRepository->hasConflictingSchedule($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /* Check for conflict in meeting pattern hybrid when create section */
    public function hasConflictingScheduleHybrid(ConflictingScheduleHybridRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.conflict'), $this->sectionRepository->hasConflictingScheduleHybrid($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /* Check for conflict in meeting pattern when create section */
    public function checkIfSectionExists(CheckSectionExistRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.checkSection'), $this->sectionRepository->checkIfSectionExists($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function deleteClonedSection(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.deleteCloneSection'), $this->sectionRepository->deleteClonedSectionsByTerm($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getSectionsByTermIdInstructorId(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/section.info'), $this->sectionRepository->viewByTermAndInstructor($request),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
