<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT

use App\Http\Controllers\v1\Controller;
use App\Repositories\v1\academic\MeetingPatternRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class MeetingPatternController extends Controller
{
    protected MeetingPatternRepository $meetingPatternRepository;
    use ResponseTrait;

    public function __construct(MeetingPatternRepository $meetingPatternRepository)
    {
        $this->meetingPatternRepository = $meetingPatternRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/meeting_pattern/index",
     *     tags={"Meeting pattern"},
     *     summary="Get all Meeting patterns",
     *     operationId="indexMeetingPattern",
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexMeetingPattern(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('meeting_pattern.index'), $this->meetingPatternRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get meeting pattern by ID
     * @OA\Get(
     *     path="/api/v1/meeting_pattern/{id}",
     *     tags={"Meeting pattern"},
     *     operationId="showMeetingPattern",
     *     @OA\Parameter(
     *         name="day",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="Monday",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="hour",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="19:00",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="facility id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $day
     * @param string $hour
     * @param string $facility_id
     * @return JsonResponse
     */
    public function showMeetingPattern(string $day, string $hour,string $facility_id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('meeting_pattern.byIdDayHourRoom'), $this->meetingPatternRepository->viewByDayHourRoomId($day, $hour,$facility_id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create meeting pattern
     * @OA\Post (
     *     path="/api/v1/meeting_pattern/add",
     *     tags={"Meeting pattern"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="day",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="hour",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="facility_id",
     *                          type="uuid"
     *                      )
     *                 ),
     *                 example={
     *                      "day": "Monday",
     *                      "hour": "19:00",
     *                      "facility_id": "e8356132-0e8c-4448-b547-6254094ddd3b"
     *                }
     *             )
     *         )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addMeetingPattern(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('meeting_pattern.add'), $this->meetingPatternRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update meeting pattern
     * @OA\Put (
     *     path="/api/v1/meeting_pattern/update/{id}",
     *     tags={"Meeting pattern"},
     *     @OA\Parameter(
     *         name="day",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="Monday",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="hour",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="19:00",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="facility id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="day",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="hour",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="facility_id",
     *                          type="uuid"
     *                      )
     *                 ),
     *                 example={
     *                      "day": "Monday",
     *                      "hour": "19:00",
     *                      "facility_id": "e8356132-0e8c-4448-b547-6254094ddd3b"
     *                }
     *             )
     *         )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateMeetingPattern(string $day, string $hour,string $facility_id, Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('meeting_pattern.update'), $this->meetingPatternRepository->update($day,$hour,$facility_id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete meeting pattern by id
     * @OA\Delete(
     *     path="/api/v1/meeting_pattern/delete/{id}",
     *     tags={"Meeting pattern"},
     *     operationId="deleteMeetingPattern",
     *     @OA\Parameter(
     *         name="day",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="Monday",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="hour",
     *         in="path",
     *         description="String",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="19:00",
     *             type="string",
     *         )
     *     ),
     *     @OA\Parameter(
     *         name="facility id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $day
     * @param string $hour
     * @param string $facility_id
     * @return JsonResponse
     */
    public function deleteMeetingPattern(string $day, string $hour,string $facility_id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('meeting_pattern.delete'), $this->meetingPatternRepository->delete($day,$hour,$facility_id),null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
