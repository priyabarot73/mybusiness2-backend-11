<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use App\Http\Requests\v1\academic\QualificationTypeRequest;
use App\Repositories\v1\academic\QualificationTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class QualificationTypeController
{
    protected QualificationTypeRepository $qualificationTypeRepository;
    use ResponseTrait;
    public function __construct(QualificationTypeRepository $qualificationTypeRepository)
    {
        $this->qualificationTypeRepository = $qualificationTypeRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/qualification_type/index",
     *     tags={"Qualification type"},
     *     summary="Get all qualification types",
     *     operationId="indexQualificationType",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexQualificationType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/qualification_type.index'), $this->qualificationTypeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/qualification_type/status/{status}",
     *     tags={"Qualification type"},
     *     summary="Get all Qualification types by status",
     *     operationId="showQualificationTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showQualificationTypeByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/qualification_type.status'), $this->qualificationTypeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Qualification Type
     * @OA\Post (
     *     path="/api/v1/qualification_type/add",
     *     tags={"Qualification type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "ENB",
     *                      "name": "Exempt Non Benefit",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addQualificationType(QualificationTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/qualification_type.add'), $this->qualificationTypeRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Qualification Type
     * @OA\Put (
     *     path="/api/v1/qualification_type/update/{id}",
     *     tags={"Qualification type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "ENB - Updated",
     *                      "name": "Exempt Non Benefit - Updated",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateQualificationType(string $id, QualificationTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/qualification_type.update'), $this->qualificationTypeRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
