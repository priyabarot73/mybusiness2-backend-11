<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use App\Http\Controllers\v1\Controller;
use App\Repositories\v1\academic\ControlCloneSectionRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ControlCloneSectionController extends Controller
{
    protected ControlCloneSectionRepository $controlCloneSectionRepository;
    use ResponseTrait;
    public function __construct(ControlCloneSectionRepository $controlCloneSectionRepository)
    {
        $this->controlCloneSectionRepository = $controlCloneSectionRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/clone/index",
     *     tags={"Control clone section"},
     *     summary="Get all clone sections",
     *     operationId="indexControlCloneSection",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexControlCloneSection(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("control_clone_section.controlDuplicateSection"), $this->controlCloneSectionRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/clone/user",
     *     tags={"Control clone section"},
     *     summary="Get user for clone sections",
     *     operationId="getUserClone",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function getUserClone(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("control_clone_section.user"), $this->controlCloneSectionRepository->getUser(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
