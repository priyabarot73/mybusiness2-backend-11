<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
//use App\Http\Requests\v1\academic\reports\CoursesScheduleByRoomReportRequest;
use App\Repositories\v1\academic\reports\ScheduleComparisonEnrollmentReportRepository;


class ScheduleComparisonEnrollmentReportController extends Controller
{
    protected ScheduleComparisonEnrollmentReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(ScheduleComparisonEnrollmentReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate comparison enrollment report
     * @OA\Get(
     *     path="/api/v1/schedule_comparison_enrollment_report/generate/{termNumber}",
     *     tags={"Comparison Enrollment Report"},
     *     summary="Generate comparison enrollment report",
     *     description="It returns information related to student enrollments grouped by program and takes into account the selected term and the term preceding the selected term.",
     *     @OA\Parameter(
     *         name="termNumber",
     *         in="path",
     *         description="Term Number",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     // ... rest of your OpenAPI documentation
     * )
     */

    public function scheduleComparisonEnrollmentReport(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, "Success", $this->reportRepository->build($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
