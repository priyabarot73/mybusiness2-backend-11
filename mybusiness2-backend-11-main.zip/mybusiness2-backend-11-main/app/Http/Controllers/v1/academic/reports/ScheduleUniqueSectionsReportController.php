<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\reports\ScheduleUniqueSectionsReportRequest;
use App\Repositories\v1\academic\reports\ScheduleUniqueSectionsReportRepository;

class ScheduleUniqueSectionsReportController extends Controller
{
    protected ScheduleUniqueSectionsReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(ScheduleUniqueSectionsReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate schedule unique sections report
     * @OA\Get(
     *     path="/api/v1/schedule_unique_sections_report/generate/{termNumber}",
     *     tags={"Schedule Unique Sections Report"},
     *     summary="Generate paginated schedule unique sections report",
     *     description="Returns a paginated list of schedule unique sections for the specified term number",
     *     @OA\Parameter(
     *         name="termNumber",
     *         in="path",
     *         description="Term Number",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     // ... rest of your OpenAPI documentation
     * )
     */
    public function generateReport(ScheduleUniqueSectionsReportRequest $request, string $termNumber): JsonResponse
    {
        try {
//            $validated = $request->validated();
//            $result = ;

            return $this->response(
                Response::HTTP_OK,
                trans("academic/reports.schedule_unique_sections_report.success"),
                $this->reportRepository->generateReport($request, $termNumber),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
