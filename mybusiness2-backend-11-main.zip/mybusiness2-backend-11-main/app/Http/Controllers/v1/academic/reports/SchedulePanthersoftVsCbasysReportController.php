<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\reports\SchedulePanthersoftVsCbasysReportRequest;
use App\Repositories\v1\academic\reports\SchedulePanthersoftVsCbasysReportRepository;

class SchedulePanthersoftVsCbasysReportController extends Controller
{
    protected SchedulePanthersoftVsCbasysReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(SchedulePanthersoftVsCbasysReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate schedule panthersoft vs cbasys report
     * @OA\Get(
     *     path="/api/v1/schedule_panthersoft_vs_cbasys_report/generate/{termNumber}",
     *     tags={"Schedule PantherSoft VS CBASYS Report"},
     *     summary="Generate paginated schedule panthersoft vs cbasys report",
     *     description="Returns a paginated list of panthersoft vs cbasys comparisons for the specified term number",
     *     @OA\Parameter(
     *         name="termNumber",
     *         in="path",
     *         description="Term Number",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     // ... rest of your OpenAPI documentation
     * )
     */
    public function generateReport(SchedulePanthersoftVsCbasysReportRequest $request, string $termNumber): JsonResponse
    {
        try {
//            $validated = $request->validated();
//            $result = ;

            return $this->response(
                Response::HTTP_OK,
                trans("academic/reports.schedule_panthersoft_vs_cbasys_report.success"),
                $this->reportRepository->generateReport($request, $termNumber),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
