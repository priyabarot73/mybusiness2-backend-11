<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\reports\CoursesScheduleByRoomReportRequest;
use App\Repositories\v1\academic\reports\CoursesScheduleByRoomReportRepository;

class CoursesScheduleByRoomReportController extends Controller
{
    protected CoursesScheduleByRoomReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(CoursesScheduleByRoomReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate schedule sections report
     * @OA\Get(
     *     path="/api/v1/schedule_sections_report/generate/{termNumber}",
     *     tags={"Schedule Sections Report"},
     *     summary="Generate paginated schedule sections report",
     *     description="Returns a paginated list of schedule sections for the specified term number",
     *     @OA\Parameter(
     *         name="termNumber",
     *         in="path",
     *         description="Term Number",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     // ... rest of your OpenAPI documentation
     * )
     */
    public function generateReport(CoursesScheduleByRoomReportRequest $request, string $termNumber): JsonResponse
    {
        try {
//            $validated = $request->validated();
//            $result = ;

            return $this->response(
                Response::HTTP_OK,
                trans("academic/reports.courses_schedule_by_room_report.success"),
                $this->reportRepository->generateReport($request, $termNumber),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
