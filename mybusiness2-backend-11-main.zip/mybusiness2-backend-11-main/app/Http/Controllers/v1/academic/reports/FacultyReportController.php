<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\reports\FacultyReportRequest;
use App\Repositories\v1\academic\reports\FacultyReportRepository;

class FacultyReportController extends Controller
{
    protected FacultyReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(FacultyReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate faculty report
     * @OA\Get(
     *     path="/api/v1/faculty_report/generate/{acad_year}",
     *     tags={"Faculty Report"},
     *     summary="Generate paginated faculty report",
     *     description="Returns a paginated list of faculty for the specified academic year",
     *     @OA\Parameter(
     *         name="acadYear",
     *         in="path",
     *         description="Academic Year",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     * )
     */
    public function generateReport(FacultyReportRequest $request, ?string $acadYear = null): JsonResponse
    {
        try {
            // Support BOTH:
            // /faculty_report/{acad_year}
            // /faculty_report?academic_year=2025-2026
            $acadYear = $acadYear ?? $request->input('academic_year');

            if (empty($acadYear)) {
                return $this->response(
                    Response::HTTP_UNPROCESSABLE_ENTITY,
                    'academic_year is required.',
                    [],
                    ['academic_year' => ['The academic_year field is required.']]
                );
            }

            return $this->response(
                Response::HTTP_OK,
                trans("academic/reports.faculty_report.success"),
                $this->reportRepository->generateReport($request, $acadYear),
                null
            );

        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    public function inputs(): JsonResponse
    {
        try {
            $academicYears = DB::table('ac.terms')
                ->whereNotNull('academic_year')
                ->select('academic_year')
                ->groupBy('academic_year')
                ->orderByRaw("CAST(LEFT(academic_year, 4) AS INT) DESC")
                ->pluck('academic_year')
                ->values()
                ->toArray();

            $employeeTypeOptions = DB::table('hr.employee_types')
                ->selectRaw("RTRIM(code) as code, RTRIM(name) as name")
                ->whereIn('code', ['FAC', 'ADJ', 'GA'])
                ->orderByRaw("
                CASE RTRIM(code)
                    WHEN 'FAC' THEN 1
                    WHEN 'ADJ' THEN 2
                    WHEN 'GA'  THEN 3
                    ELSE 99
                END
            ")
                ->get()
                ->map(fn ($r) => [
                    'code' => $r->code,
                    'name' => match ($r->code) {
                        'FAC' => 'Faculty',
                        'ADJ' => 'Adjunct',
                        'GA'  => 'Graduate Assistant',
                        default => $r->name,
                    },
                ])
                ->values()
                ->all();

            $payload = [
                'academic_years' => $academicYears,
                'term_options' => [
                    ['key' => 'fall', 'label' => 'Fall'],
                    ['key' => 'spring', 'label' => 'Spring'],
                    ['key' => 'summer', 'label' => 'Summer'],
                ],
                'status_options' => [
                    ['key' => 'active', 'label' => 'Active'],
                    ['key' => 'inactive', 'label' => 'Inactive'],
                    ['key' => 'all', 'label' => 'All'],
                ],
                'employee_types' => $employeeTypeOptions,
                'defaults' => [
                    'academic_year' => $academicYears[0] ?? null,
                    'term_options' => ['fall', 'spring'],
                    'status' => 'all',
                    'employee_types' => array_map(fn ($x) => $x['code'], $employeeTypeOptions) ?: ['FAC','ADJ','GA'],
                ],
            ];

            return $this->response(
                Response::HTTP_OK,
                'Faculty report inputs loaded.',
                $payload,
                null
            );

        } catch (Exception $e) {
            Log::error('FacultyReportController@inputs error: '.$e->getMessage());

            return $this->response(
                Response::HTTP_INTERNAL_SERVER_ERROR,
                $e->getMessage(),
                [],
                $e->getMessage()
            );
        }
    }
}
