<?php

namespace App\Http\Controllers\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\reports\InstructorWorkloadReportRequest;
use App\Repositories\v1\academic\reports\InstructorWorkloadReportRepository;

class InstructorWorkloadReportController extends Controller
{
    protected InstructorWorkloadReportRepository $reportRepository;
    use ResponseTrait;

    public function __construct(InstructorWorkloadReportRepository $reportRepository)
    {
        $this->reportRepository = $reportRepository;
    }

    /**
     * Generate schedule sections report
     * @OA\Get(
     *     path="/api/v1/schedule_sections_report/generate/{termNumber}",
     *     tags={"Schedule Sections Report"},
     *     summary="Generate paginated schedule sections report",
     *     description="Returns a paginated list of schedule sections for the specified term number",
     *     @OA\Parameter(
     *         name="termNumber",
     *         in="path",
     *         description="Term Number",
     *         required=true,
     *         @OA\Schema(type="integer")
     *     ),
     *     // ... rest of your OpenAPI documentation
     * )
     */
    public function generateReport(InstructorWorkloadReportRequest $request, string $termNumber): JsonResponse
    {
        try {
//            $validated = $request->validated();
//            $result = ;

            return $this->response(
                Response::HTTP_OK,
                trans("academic/reports.instructor_workload_report.success"),
                $this->reportRepository->generateReport($request, $termNumber),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
