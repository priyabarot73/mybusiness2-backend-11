<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\CourseRequest;
use App\Repositories\v1\academic\CourseRepository;

class CourseController extends Controller
{
    protected CourseRepository $courseRepository;
    use ResponseTrait;

    public function __construct(CourseRepository $courseRepository)
    {
        $this->courseRepository = $courseRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/course/index",
     *     tags={"Course"},
     *     summary="Get all course",
     *     operationId="indexCourse",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexCourse(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.index'), $this->courseRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get courses by status
     * @OA\Get(
     *     path="/api/v1/course/status/{status}",
     *     tags={"Course"},
     *     operationId="showCoursesByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param int $status
     * @return JsonResponse
     */
    public function showCourseByStatus(Request $request,int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.status'), $this->courseRepository->viewAllByStatus($request,$status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get course by ID
     * @OA\Get(
     *     path="/api/v1/course/{id}",
     *     tags={"Course"},
     *     operationId="showCourse",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showCourse(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.id'), $this->courseRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get course by value
     * @OA\Get(
     *     path="/api/v1/course/find/{value}",
     *     tags={"Course"},
     *     operationId="findByValue",
     *     @OA\Parameter(
     *         name="value",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="code,name, references number",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $value
     * @return JsonResponse
     */
    public function findByValue(string $value): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.value'), $this->courseRepository->findByCodeNameOrReference($value), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create course
     * @OA\Post (
     *     path="/api/v1/course/add",
     *     tags={"Course"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="references_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="credit",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="hour",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "MSG",
     *                      "references_number": "87654",
     *                      "name": "Master",
     *                      "credit": 3.0,
     *                      "hour": 3.0,
     *                      "description": "Degree details",
     *                      "department_id": "e5040c40-0a22-469b-8194-34f722aeffc2",
     *                      "program_id": "e5040c40-0a22-469b-8194-34f722aeffc2",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addCourse(CourseRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.add'), $this->courseRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update course
     * @OA\Put (
     *     path="/api/v1/course/update/{id}",
     *     tags={"Course"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="references_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="credit",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="hour",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "MSG",
     *                      "references_number": "87654",
     *                      "name": "Master Update",
     *                      "credit": 3.0,
     *                      "hour": 3.0,
     *                      "description": "Degree details",
     *                      "department_id": "e5040c40-0a22-469b-8194-34f722aeffc2",
     *                      "program_id": "e5040c40-0a22-469b-8194-34f722aeffc2",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateCourse(string $id, CourseRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.update'), $this->courseRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete course by id
     * @OA\Delete(
     *     path="/api/v1/course/delete/{id}",
     *     tags={"Course"},
     *     operationId="deleteCourse",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteCourse(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.delete'), $this->courseRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Endpoint to fetch courses:
     *  - If instructor_id + term_id are provided → return courses assigned in that term.
     *  - If not provided → return active courses.
     */
    public function findByInstructorAndTerm(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/course.index'), $this->courseRepository->viewCoursesByInstructorAndTerm($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
