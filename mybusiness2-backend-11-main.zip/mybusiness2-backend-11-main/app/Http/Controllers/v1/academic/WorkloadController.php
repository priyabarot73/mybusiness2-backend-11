<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\WorkloadRequest;
use App\Repositories\v1\academic\WorkLoadRepository;
use App\Http\Requests\v1\academic\WorkloadIndexRequest;

class WorkloadController extends Controller
{
    use ResponseTrait;
    protected WorkLoadRepository $workloadRepository;

    public function __construct(WorkLoadRepository $workloadRepository)
    {
        $this->workloadRepository = $workloadRepository;
    }

    /**
     * @OA\Post(
     *     path="/api/v1/workload/all",
     *     tags={"Workload"},
     *     summary="Get all workloads by Term ID - Does not work",
     *     operationId="viewAllWorkload",
     *     @OA\Parameter(
     *         name="term_id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function viewAllWorkload($id = null): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/workload.index'), $this->workloadRepository->viewAll($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Show Workload by ID
     * @OA\Get(
     *     path="/api/v1/workload/{id}",
     *     tags={"Workload"},
     *     operationId="showWorkload",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showWorkload($ids): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.id"), $this->workloadRepository->viewById($ids), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function indexWorkload(WorkloadIndexRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.index"), $this->workloadRepository->viewIndex($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create a new workload
     * @OA\Post (
     *     path="/api/v1/workload/add",
     *     tags={"Workload"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="term_id",
     *                          type="string",
     *                          format = "uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="user_id",
     *                          type="string",
     *                          format = "uuid",
     *                      ),
     *                      @OA\Property(
     *                          property="workload",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="release",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="release_type",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="on_sabbatical",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="on_sick_leave",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="on_paternity_leave",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="workload_type",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="comments",
     *                          type="string"
     *                      )
     *                 ),
     *                 example={
     *                      "term_id": "034e180f-9973-4ca8-8d46-b7beb121e961",
     *                      "user_id": "034e180f-9973-4ca8-8d46-b7beb121e962",
     *                      "workload": 3.0,
     *                      "release": 3.0,
     *                      "release_type": "Administrative",
     *                      "academic_year": "2024-2025",
     *                      "semester": "Fall-Spring",
     *                      "on_sabbatical": 1,
     *                      "on_sick_leave": 1,
     *                      "on_paternity_leave": 1,
     *                      "workload_type": "F",
     *                      "comment": "Comment"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */

    public function addWorkload(WorkloadRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.add"), $this->workloadRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update a workload
     * @OA\Put (
     *     path="/api/v1/workload/update/{id}",
     *     tags={"Workload"},
     *      @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="user_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="workload",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="release",
     *                          type="float"
     *                      ),
     *                      @OA\Property(
     *                          property="release_type",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="semester",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="on_sabbatical",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="on_sick_leave",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="on_paternity_leave",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="workload_type",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="comments",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="workload_course",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(
     *                              ref="#/components/schemas/WorkloadCourse"
     *                          )
     *                      ),
     *                 ),
     *                 example={
     *                      "term_id": "034e180f-9973-4ca8-8d46-b7beb121e961",
     *                      "user_id": "034e180f-9973-4ca8-8d46-b7beb121e962",
     *                      "workload": 3.0,
     *                      "release": 3.0,
     *                      "release_type": "Administrative",
     *                      "academic_year": "2024-2025",
     *                      "semester": "Fall-Spring",
     *                      "on_sabbatical": 1,
     *                      "on_sick_leave": 1,
     *                      "on_paternity_leave": 1,
     *                      "workload_type": "F",
     *                      "comment": "This Workload has been updated",
     *                      "workload_course": {
     *                          {
     *                              "section_id": "E063A7A5-13BA-4D58-B92F-4205ED4A7128",
     *                              "course_id": "A0C8D1C3-D5AF-4E36-95BE-AE4738E3DF54",
     *                              "value": 0.5,
     *                              "overload": true,
     *                              "adjusted": 1,
     *                              "on_contract": true
     *                          },
     *                       }
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function updateWorkload($id,WorkloadRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.update"), $this->workloadRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete Workload by id
     * @OA\Delete(
     *     path="/api/v1/workload/delete/{id}",
     *     tags={"Workload"},
     *     operationId="deleteWorkload",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteWorkload($id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.delete"), $this->workloadRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
/**
     * * Show Workload info
     * @OA\Post(
     *     path="/api/v1/workload/info",
     *     tags={"Workload"},
     *     operationId="infoWorkload",
     *      @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="academic_year",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="workload_type",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="semesters",
     *                          type="array",
     *                          @OA\Items(
     *                              type="string"
     *                          )
     *                      ),
     *                 ),
     *                 example={
     *                      "academic_year": "2024-2025",
     *                      "semesters": {
     *                                      {"Summer"}
     *                       },
     *                      "workload_type": "F"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function infoWorkload(WorkloadIndexRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/workload.info"), $this->workloadRepository->calculateWorkloadInfo($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
