<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use App\Http\Requests\v1\academic\SubQualificationRequest;
use App\Repositories\v1\academic\SubQualificationRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class SubQualificationController
{
    protected SubQualificationRepository $subQualificationRepository;
    use ResponseTrait;
    public function __construct(SubQualificationRepository $subQualificationRepository)
    {
        $this->subQualificationRepository = $subQualificationRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/sub_qualification/index",
     *     tags={"Sub Qualification"},
     *     summary="Get all qualification types",
     *     operationId="indexSubQualification",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexSubQualification(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/sub_qualification.index'), $this->subQualificationRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/sub_qualification/status/{status}",
     *     tags={"Sub Qualification"},
     *     summary="Get all Qualification types by status",
     *     operationId="showSubQualificationByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showSubQualificationByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/sub_qualification.status'), $this->subQualificationRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Sub Qualification
     * @OA\Post (
     *     path="/api/v1/sub_qualification/add",
     *     tags={"Sub Qualification"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="sub_qualification_type",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                       @OA\Property(
     *                           property="qualification_type_id",
     *                           type="uuid"
     *                       ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "sub_qualification_type": "1",
     *                      "description": "Exempt Non Benefit",
     *                      "qualification_type_id": "D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addSubQualification(SubQualificationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/sub_qualification.add'), $this->subQualificationRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Sub Qualification
     * @OA\Put (
     *     path="/api/v1/sub_qualification/update/{id}",
     *     tags={"Sub Qualification"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="sub_qualification_type",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                           property="qualification_type_id",
     *                           type="uuid"
     *                       ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "sub_qualification_type": "1",
     *                      "description": "Exempt Non Benefit - Updated",
     *                      "qualification_type_id": "D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateSubQualification(string $id, SubQualificationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/sub_qualification.update'), $this->subQualificationRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
