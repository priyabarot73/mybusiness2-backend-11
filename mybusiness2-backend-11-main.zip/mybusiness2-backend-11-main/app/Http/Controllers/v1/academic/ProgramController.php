<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\academic\ProgramRequest;
use App\Repositories\v1\academic\ProgramRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ProgramController extends Controller
{
    protected ProgramRepository $programRepository;
    use ResponseTrait;

    public function __construct(ProgramRepository $programRepository)
    {
        $this->programRepository = $programRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/program/index",
     *     tags={"Program"},
     *     summary="Get all program",
     *     operationId="indexProgram",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexProgram(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.index'), $this->programRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get program by ID
     * @OA\Get(
     *     path="/api/v1/program/{id}",
     *     tags={"Program"},
     *     operationId="showProgram",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showProgram(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.id'), $this->programRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get program by status
     * @OA\Get(
     *     path="/api/v1/program/status/{status}",
     *     tags={"Program"},
     *     operationId="showProgramByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param int $status
     * @return JsonResponse
     */
    public function showProgramByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.status'), $this->programRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get program by code
     * @OA\Get(
     *     path="/api/v1/program/code/{code}",
     *     tags={"Program"},
     *     operationId="existProgramCode",
     *     @OA\Parameter(
     *         name="code",
     *         in="path",
     *         description="String Code",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="Demo",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $code
     * @return JsonResponse
     */
    public function existProgramCode(string $code): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.code'), $this->programRepository->validateCodeExist($code), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create program
     * @OA\Post (
     *     path="/api/v1/program/add",
     *     tags={"Program"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="program_level_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="program_grouping_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="offering_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="degree_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="fte",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "MSG",
     *                      "name": "Master",
     *                      "program_level_id": "df0665be-d14f-426e-bfb3-066abe4ae02e",
     *                      "program_grouping_id": "df0665be-d14f-426e-bfb3-066abe4ae02e",
     *                      "degree_id": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *                      "offering_id": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *                      "fte": "1",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addProgram(ProgramRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK,trans('academic/program.add'), $this->programRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update program
     * @OA\Put (
     *     path="/api/v1/program/update/{id}",
     *     tags={"Program"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="program_level_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="program_grouping_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="offering_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="degree_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="fte",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "MSG",
     *                      "name": "Master",
     *                      "program_level_id": "df0665be-d14f-426e-bfb3-066abe4ae02e",
     *                      "program_grouping_id": "df0665be-d14f-426e-bfb3-066abe4ae02e",
     *                      "degree_id": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *                      "offering_id": "0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *                      "fte": "1",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateProgram(string $id, ProgramRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.update'), $this->programRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Delete program by ID
     * @OA\Delete(
     *     path="/api/v1/program/delete/{id}",
     *     tags={"Program"},
     *     operationId="deleteProgram",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteProgram(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('academic/program.deleted'), $this->programRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
