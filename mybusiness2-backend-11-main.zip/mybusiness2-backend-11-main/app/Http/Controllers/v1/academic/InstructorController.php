<?php

namespace App\Http\Controllers\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\academic\InstructorRequest;
use App\Repositories\v1\academic\InstructorRepository;

class InstructorController
{
    protected InstructorRepository $instructorRepository;
    use ResponseTrait;

    public function __construct(InstructorRepository $instructorRepository)
    {
        $this->instructorRepository = $instructorRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/instructor/index",
     *     tags={"Instructors"},
     *     summary="Get all instructors",
     *     operationId="indexInstructor",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexInstructor(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/instructor.index"), $this->instructorRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Get instructors by status
     * @OA\Get(
     *     path="/api/v1/instructor/status/{status}",
     *     tags={"Instructors"},
     *     operationId="showInstructorByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default= 1,
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param int $status
     * @return JsonResponse
     */
    public function showInstructorByStatus(Request $request,int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/instructor.index"), $this->instructorRepository->viewAllByStatus($request,$status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create instructor
     * @OA\Post (
     *     path="/api/v1/instructor/add",
     *     tags={"Instructor"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="person_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the person"
     *                 ),
     *                 @OA\Property(
     *                     property="employee_type_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the employee type"
     *                 ),
     *                 @OA\Property(
     *                     property="tenure",
     *                     type="string",
     *                     nullable=true,
     *                     description="Tenure information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="doctorate",
     *                     type="boolean",
     *                     nullable=true,
     *                     description="Indicates if the instructor holds a doctorate degree"
     *                 ),
     *                 @OA\Property(
     *                     property="qualification",
     *                     type="string",
     *                     nullable=true,
     *                     description="Qualification information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="sub_qualification_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the sub-qualification"
     *                 ),
     *                 @OA\Property(
     *                     property="qualification_type_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the qualification type"
     *                 ),
     *                 @OA\Property(
     *                     property="aacsb",
     *                     type="string",
     *                     nullable=true,
     *                     description="AACSB qualification information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="active",
     *                     type="boolean",
     *                     description="Indicates if the instructor is active"
     *                 ),
     *                 example={
     *                     "person_id": "123e4567-e89b-12d3-a456-426614174000",
     *                     "employee_type_id": "123e4567-e89b-12d3-a456-426614174001",
     *                     "tenure": "Tenured",
     *                     "doctorate": true,
     *                     "qualification": "PhD in Computer Science",
     *                     "sub_qualification_id": "123e4567-e89b-12d3-a456-426614174002",
     *                     "qualification_type_id": "123e4567-e89b-12d3-a456-426614174003",
     *                     "aacsb": "AACSB-accredited",
     *                     "active": true
     *                 }
     *             )
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *         @OA\JsonContent(
     *             @OA\Property(property="meta", type="object"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error",
     *         @OA\JsonContent(
     *             @OA\Property(property="errors", type="object")
     *         )
     *     )
     * )
     */

    public function addInstructor(InstructorRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/instructor.add"), $this->instructorRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update instructor
     * @OA\Put (
     *     path="/api/v1/instructor/update/{id}",
     *     tags={"Instructors"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the instructor to be updated",
     *         required=true,
     *         @OA\Schema(
     *             type="string",
     *             format="uuid",
     *             example="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A"
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="person_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the person"
     *                 ),
     *                 @OA\Property(
     *                     property="employee_type_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the employee type"
     *                 ),
     *                 @OA\Property(
     *                     property="tenure",
     *                     type="string",
     *                     nullable=true,
     *                     description="Tenure information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="doctorate",
     *                     type="boolean",
     *                     nullable=true,
     *                     description="Indicates if the instructor holds a doctorate degree"
     *                 ),
     *                 @OA\Property(
     *                     property="qualification",
     *                     type="string",
     *                     nullable=true,
     *                     description="Qualification information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="sub_qualification_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the sub-qualification"
     *                 ),
     *                 @OA\Property(
     *                     property="qualification_type_id",
     *                     type="string",
     *                     format="uuid",
     *                     nullable=true,
     *                     description="UUID of the qualification type"
     *                 ),
     *                 @OA\Property(
     *                     property="aacsb",
     *                     type="string",
     *                     nullable=true,
     *                     description="AACSB qualification information, max 255 characters"
     *                 ),
     *                 @OA\Property(
     *                     property="active",
     *                     type="boolean",
     *                     description="Indicates if the instructor is active"
     *                 ),
     *                 example={
     *                     "person_id": "123e4567-e89b-12d3-a456-426614174000",
     *                     "employee_type_id": "123e4567-e89b-12d3-a456-426614174001",
     *                     "tenure": "Tenured",
     *                     "doctorate": true,
     *                     "qualification": "PhD in Computer Science",
     *                     "sub_qualification_id": "123e4567-e89b-12d3-a456-426614174002",
     *                     "qualification_type_id": "123e4567-e89b-12d3-a456-426614174003",
     *                     "aacsb": "AACSB-accredited",
     *                     "active": true
     *                 }
     *             )
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Success",
     *         @OA\JsonContent(
     *             @OA\Property(property="meta", type="object"),
     *             @OA\Property(property="data", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error",
     *         @OA\JsonContent(
     *             @OA\Property(property="errors", type="object")
     *         )
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Bad request",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="An error occurred")
     *         )
     *     )
     * )
     */

    public function updateInstructor(string $id, InstructorRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("academic/instructor.update"), $this->instructorRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
