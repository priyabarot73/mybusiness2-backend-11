<?php

namespace App\Http\Controllers\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Http\Requests\v1\UserRequest;
use App\Repositories\v1\UserRepository;
use App\Traits\ResponseTrait;

class UserController extends Controller
{
    use ResponseTrait;
    protected UserRepository $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/user/index",
     *     tags={"User"},
     *     summary="Get all user with roles and permission",
     *     operationId="indexUsers",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexUser(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.index'), $this->userRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get user by ID
     * @OA\Get(
     *     path="/api/v1/user/{id}",
     *     tags={"User"},
     *     operationId="showUser",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function showUser(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.id'), $this->userRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * * Get users by role
     * @OA\Get(
     *     path="/api/v1/user/role/{name}",
     *     tags={"User"},
     *     operationId="indexUserByRole",
     *     @OA\Parameter(
     *         name="name",
     *         in="path",
     *         description="Role name",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="instructor",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $name
     * @return JsonResponse
     */
    public function indexUserByRole(string $name): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.indexByRole'), $this->userRepository->viewUsersByRole($name), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST,  $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create user
     * @OA\Post (
     *     path="/api/v1/user/add",
     *     tags={"User"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="user_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="first_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="middle_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="panther_id",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="avatar",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="instructor",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="student",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="password",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="created_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="updated_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="roles",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"Instructor","Secretary."}),
     *                      ),
     *                      @OA\Property(
     *                          property="permissions",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"List roles","Update terms"}),
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Demo",
     *                      "user_name": "demo",
     *                      "first_name": "first",
     *                      "last_name": "last",
     *                      "middle_name": "demos",
     *                      "email": "demo@fiu.edu",
     *                      "panther_id": "6447394",
     *                      "avatar": "./../avatar",
     *                      "instructor": 1,
     *                      "student": 1,
     *                      "email_verified_at": "",
     *                      "password":"123",
     *                      "active": "1",
     *                      "created_at": "2024-01-10T22:18:54.927000Z",
     *                      "updated_at": "2024-01-10T22:18:54.927000Z",
     *                      "department_id": null,
     *                      "roles": {"Instructor","Secretary."},
     *                      "permissions": {"List roles","Update terms"}
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function createUser(UserRequest $request):JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.add'), $this->userRepository->create($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST,  $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update user
     * @OA\Put (
     *     path="/api/v1/user/update/{id}",
     *     tags={"User"},
     *     operationId="updateUser",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="user_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="first_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="middle_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="panther_id",
     *                          type="integer"
     *                      ),
     *                      @OA\Property(
     *                          property="avatar",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="instructor",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="student",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="password",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="created_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="updated_at",
     *                          type="date"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="uuid"
     *                      ),
     *                      @OA\Property(
     *                          property="roles",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"Instructor","Secretary."}),
     *                      ),
     *                      @OA\Property(
     *                          property="permissions",
     *                          type="array",
     *                          collectionFormat="multi",
     *                          @OA\Items(type="string", format="string", example={"List roles","Update terms"}),
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Demo",
     *                      "user_name": "demo-update",
     *                      "first_name": "first",
     *                      "last_name": "last",
     *                      "middle_name": "demos",
     *                      "email": "demo@fiu.edu",
     *                      "panther_id": "6447394",
     *                      "avatar": "./../avatar",
     *                      "instructor": 1,
     *                      "student": 1,
     *                      "email_verified_at": "",
     *                      "password":"123",
     *                      "active": "1",
     *                      "created_at": "2024-01-10T22:18:54.927000Z",
     *                      "updated_at": "2024-01-10T22:18:54.927000Z",
     *                      "department_id": null,
     *                      "roles": {"Instructor","Secretary."},
     *                      "permissions": {"List roles","Update terms"}
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     *
     * *
     * @param string $id
     * @param UserRequest $request
     * @return JsonResponse
     */
    public function updateUser(string $id, UserRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.update'), $this->userRepository->update($id,$request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Delete user
     * @OA\Delete(
     *     path="/api/v1/user/delete/{id}",
     *     tags={"User"},
     *     operationId="deleteUser",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="String ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="0C6A36BA-10E4-438F-BA86-0D5B68A2BB15",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     * @param string $id
     * @return JsonResponse
     */
    public function deleteUser(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('user.delete'), $this->userRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
