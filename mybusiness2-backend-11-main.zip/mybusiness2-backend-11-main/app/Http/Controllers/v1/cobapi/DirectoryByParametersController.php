<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\DirectoryFacultyDTO;
use App\Repositories\v1\cobapi\DirectoryByParametersRepository;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DirectoryByParametersController
{
    protected DirectoryByParametersRepository $repo;

    public function __construct(DirectoryByParametersRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(Request $request): JsonResponse
    {
        try {
            $keyword = $request->query('keyword');
            $department = $request->query('department');

            $directoryRows = $this->repo->fetchDirectoryRows($keyword, $department);

            // ✅ Faculty180 interests
            $interestsByEmployeeId = $this->repo->fetchInterestsByEmployeeId($directoryRows);

            $out = [];
            foreach ($directoryRows as $r) {
                $out[] = DirectoryFacultyDTO::fromRow($r, $interestsByEmployeeId);
            }

            return response()->json([
                'Faculty' => $out,
            ], 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
