<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\DirectoryFacultyDTO;
use App\Repositories\v1\cobapi\GetAllFacultyByExpertiseRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class GetAllFacultyByExpertiseController
{
    protected GetAllFacultyByExpertiseRepository $repo;

    public function __construct(GetAllFacultyByExpertiseRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(string $current_expertise): JsonResponse
    {
        try {
            $expertise = trim((string)$current_expertise);

            if ($expertise === '') {
                return response()->json([
                    'error' => "The current expertises is not valid or does not exits",
                ], 404);
            }

            $rows = $this->repo->fetchFacultyByExpertise($expertise);

            // interests not available yet (same as before)
            $interestsByEmployeeId = [];

            $out = [];
            foreach ($rows as $r) {
                $out[] = DirectoryFacultyDTO::fromRow($r, $interestsByEmployeeId);
            }

            return response()->json([
                'Faculty' => $out,
            ], 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
