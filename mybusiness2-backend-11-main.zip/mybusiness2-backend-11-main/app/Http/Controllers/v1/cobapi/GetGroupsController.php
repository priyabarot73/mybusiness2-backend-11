<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\GetEmployeesByGroupAndFilterDTO;
use App\DTOs\cobapi\GetGroupsDTO;
use App\Http\Requests\v1\cobapi\GetGroupsRequest;
use App\Repositories\v1\cobapi\GetGroupsRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class GetGroupsController
{
    protected GetGroupsRepository $repo;

    public function __construct(GetGroupsRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(GetGroupsRequest $request): JsonResponse
    {
        try {
            $filterType = $request->query('filterType');
            $filterID   = $request->query('filterID');

            // Legacy behavior:
            // if both present -> return employees ARRAY (not wrapped)
            if (!empty($filterType) && !empty($filterID)) {
                $rows = $this->repo->viewEmployeesByGroupAndFilter($filterType, $filterID);

                // legacy behavior: returns ARRAY of employees, not wrapped
                return response()->json(
                    \App\DTOs\cobapi\GetEmployeesByGroupAndFilterDTO::fromRows($rows),
                    200
                );
            }

            // else -> return groups object { "groups": [...] }
            $rows = $this->repo->viewAll($filterType, null);
            return response()->json([
                'groups' => GetGroupsDTO::fromRows($rows),
            ], 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
