<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\GetAllDepartmentsDTO;
use App\Repositories\v1\cobapi\GetAllDepartmentsRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class GetAllDepartmentsController
{
    protected GetAllDepartmentsRepository $repo;

    public function __construct(GetAllDepartmentsRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->viewAll();

            // legacy-ish shape: { "Departments": [ { department_desc: ... }, ... ] }
            return response()->json([
                'allDepartment' => GetAllDepartmentsDTO::fromRows($rows),
            ], 200);
        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
