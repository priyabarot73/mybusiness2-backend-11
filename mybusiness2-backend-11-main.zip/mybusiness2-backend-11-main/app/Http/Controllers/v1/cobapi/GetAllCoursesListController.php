<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\GetAllCoursesListDTO;
use App\Repositories\v1\cobapi\GetAllCoursesListRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class GetAllCoursesListController
{
    protected GetAllCoursesListRepository $repo;

    public function __construct(GetAllCoursesListRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->viewAll();

            // legacy shape: { "Courses": [ ... ] }
            return response()->json([
                'Courses' => GetAllCoursesListDTO::fromRows($rows),
            ], 200);
        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
