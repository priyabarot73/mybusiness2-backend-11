<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\ListAllInstructorsDTO;
use App\Repositories\v1\cobapi\ListAllInstructorsRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class ListAllInstructorsController
{
    protected ListAllInstructorsRepository $repo;

    public function __construct(ListAllInstructorsRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->viewAll();

            // Legacy wrapper object (like AllInstructorsList)
            return response()->json([
                'Instructors' => ListAllInstructorsDTO::fromRows($rows),
            ], 200);
        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
