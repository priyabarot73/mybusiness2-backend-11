<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\ListAllTermsDTO;
use App\Repositories\v1\cobapi\ListAllTermsRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class ListAllTermsController
{
    protected ListAllTermsRepository $repo;

    public function __construct(ListAllTermsRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->viewAll();

            // legacy wrapper object (adjust key if old API used "ListTerms")
            return response()->json([
                'Terms' => ListAllTermsDTO::fromRows($rows),
            ], 200);
        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
