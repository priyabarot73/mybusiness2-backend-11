<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\BasicFacultyDTO;
use App\Repositories\v1\cobapi\AllFacultyByKeywordRepository;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AllFacultyByKeywordController
{
    public function __construct(
        protected AllFacultyByKeywordRepository $repo
    ) {}

    public function index(Request $request): JsonResponse
    {
        try {
            $first = (string)$request->query('first_name', '');
            $last  = (string)$request->query('last_name', '');
            $kw    = (string)$request->query('keyword', '');

            $result = $this->repo->fetchFacultyByKeyword($first, $last, $kw);

            // result includes:
            // - rows (directory-style)
            // - interestsByEmployeeId (legacy shape: [{interest: "..."}])
            $rows = $result['rows'];
            $interestsByEmployeeId = $result['interestsByEmployeeId'];

            $out = [];
            foreach ($rows as $r) {
                $out[] = BasicFacultyDTO::fromRow($r, $interestsByEmployeeId);
            }

            // IMPORTANT: match your front-end expectations (your JS uses data.faculty)
            return response()->json([
                'faculty' => $out,
            ], 200);

        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
}
