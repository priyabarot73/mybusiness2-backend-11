<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\DirectoryFacultyDTO;
use App\Repositories\v1\cobapi\DirectoryByLetterRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class DirectoryByLetterController
{
    protected DirectoryByLetterRepository $repo;

    public function __construct(DirectoryByLetterRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(string $current_letter): JsonResponse
    {
        try {
            $letter = strtoupper(substr((string)$current_letter, 0, 1));

            if ($letter === '' || !preg_match('/^[A-Z]$/', $letter)) {
                return response()->json([
                    'error' => 'The current letter is not valid or does not exits',
                ], 404);
            }

            $directoryRows = $this->repo->fetchDirectoryRows($letter);

            // ✅ interests
            $interestsByEmployeeId = $this->repo->fetchInterestsByEmployeeId($directoryRows);

            $out = [];
            foreach ($directoryRows as $r) {
                $out[] = DirectoryFacultyDTO::fromRow($r, $interestsByEmployeeId);
            }

            return response()->json([
                'faculty' => $out,
            ], 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
