<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\CountryDTO;
use App\Repositories\v1\cobapi\AllCountriesRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class AllCountriesController
{
    public function __construct(
        protected AllCountriesRepository $repo
    ) {}

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->fetchAllCountriesRows();

            $out = [];
            foreach ($rows as $r) {
                $out[] = CountryDTO::fromRow($r);
            }

            // keep naming consistent with your other endpoints (faculty/expertises)
            return response()->json([
                'countries' => $out,
            ], 200);

        } catch (Exception $e) {
            return response()->json(['error' => $e->getMessage()], 400);
        }
    }
}
