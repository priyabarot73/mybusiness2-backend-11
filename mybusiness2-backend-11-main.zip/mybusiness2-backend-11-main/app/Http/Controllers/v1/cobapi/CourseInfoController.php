<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\CourseInfoDTO;
use App\Repositories\v1\cobapi\CourseInfoRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class CourseInfoController
{
    protected CourseInfoRepository $repo;

    public function __construct(CourseInfoRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(string $courseID): JsonResponse
    {
        try {
            $courseID = trim((string)$courseID);

            // Route param exists, but keep a small guard anyway
            if ($courseID === '') {
                return response()->json([
                    'error' => 'The courseID is not valid or does not exist',
                ], 404);
            }

            $row = $this->repo->viewOne($courseID);

            // Legacy behavior: return a single object (not wrapped)
            return response()->json(CourseInfoDTO::fromRow($row), 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
