<?php

namespace App\Http\Controllers\v1\cobapi;

use App\Repositories\v1\cobapi\ListExpertisesRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class ListExpertisesController
{
    protected ListExpertisesRepository $repo;

    public function __construct(ListExpertisesRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->viewAll();

            return response()->json([
                'Expertises' => $rows,
            ], 200);
        } catch (Exception $exception) {
            return response()->json([
                'error' => $exception->getMessage()
            ], 400);
        }
    }
}
