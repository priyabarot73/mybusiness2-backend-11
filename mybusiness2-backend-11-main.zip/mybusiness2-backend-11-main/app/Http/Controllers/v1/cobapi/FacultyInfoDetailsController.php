<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\FacultyMemberDTO;
use App\Repositories\v1\cobapi\FacultyInfoDetailsRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class FacultyInfoDetailsController
{
    public function __construct(
        protected FacultyInfoDetailsRepository $repo
    ) {}

    public function show(string $employeeID): JsonResponse
    {
        try {
            $employeeID = trim((string)$employeeID);

            if ($employeeID === '') {
                return response()->json([
                    'error' => 'panther ID is not valid or does not exits',
                ], 404);
            }

            $data = $this->repo->fetchFacultyMemberInfo($employeeID);

            if (!$data) {
                return response()->json([
                    'error' => 'Faculty member not found',
                ], 404);
            }

            // Legacy behavior: return a single object (not wrapped)
            return response()->json(FacultyMemberDTO::fromArray($data), 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
