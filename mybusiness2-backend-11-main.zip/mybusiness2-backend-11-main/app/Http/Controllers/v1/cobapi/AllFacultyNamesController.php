<?php

namespace App\Http\Controllers\v1\cobapi;

use App\DTOs\cobapi\BasicFacultyDTO;
use App\Repositories\v1\cobapi\AllFacultyNamesRepository;
use Exception;
use Illuminate\Http\JsonResponse;

class AllFacultyNamesController
{
    protected AllFacultyNamesRepository $repo;

    public function __construct(AllFacultyNamesRepository $repo)
    {
        $this->repo = $repo;
    }

    public function index(): JsonResponse
    {
        try {
            $rows = $this->repo->fetchAllFacultyRows();

            // Interests not migrated yet => keep empty and omitted by DTO
            $interestsByEmployeeId = [];

            $out = [];
            foreach ($rows as $r) {
                $out[] = BasicFacultyDTO::fromRow($r, $interestsByEmployeeId);
            }

            return response()->json([
                'faculty' => $out,
            ], 200);

        } catch (Exception $exception) {
            return response()->json(['error' => $exception->getMessage()], 400);
        }
    }
}
