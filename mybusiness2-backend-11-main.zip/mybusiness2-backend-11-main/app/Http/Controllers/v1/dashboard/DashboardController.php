<?php

namespace App\Http\Controllers\v1\dashboard;

//GLOBAL IMPORT
use App\Repositories\v1\dashboard\DashboardRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

// LOCAL IMPORT

class DashboardController
{
    protected DashboardRepository $repository;
    use ResponseTrait;


    public function __construct(DashboardRepository $repository)
    {
        $this->repository = $repository;
    }

    public function cardQuantity(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("dashboard/dashboard.cards"), $this->repository->cardDataQuantity(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function graphInstructorPerTerm(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("dashboard/dashboard.instructors_by_term"), $this->repository->graphInstructorTerm(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function graphCombinedPerTerm(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("dashboard/dashboard.combined"), $this->repository->graphCombinedSectionsLastTerms(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function carousel(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("dashboard/dashboard.carousel"), $this->repository->termCarousel(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
