<?php

namespace App\Http\Controllers\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Http\Requests\v1\LoginRequest;
use App\Http\Requests\v1\RegisterRequest;
use App\Repositories\v1\AuthRepository;
use App\Traits\ResponseTrait;

class AuthController extends Controller
{
    use ResponseTrait;

    public function __construct(private AuthRepository $auth)
    {
        $this->auth = $auth;
    }

    /**
     * @OA\POST(
     *     path="/api/v1/login",
     *     tags={"Authentication"},
     *     summary="Login",
     *     description="Login to system demo",
     *     operationId="login",
     *     @OA\RequestBody(
     *         description="User and password",
     *         required=true,
     *         @OA\MediaType(
     *             mediaType="application/x-www-form-urlencoded",
     *            @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="panther_id",
     *                     description="User Panther ID",
     *                     type="string"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     description="User password",
     *                     type="string"
     *                 ),
     *                 required={"panther_id", "password"}
     *             )
     *         ),
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid input"
     *     )
     * )
     */
    public function login(LoginRequest $request): JsonResponse
    {
        try {
            $data = $this->auth->login($request->all());
            return $this->response(Response::HTTP_OK,trans('auth.success'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);
        }

    } public function loginDemo(LoginRequest $request): JsonResponse
    {
        try {
            $data = $this->auth->loginDemo($request->all());
            return $this->response(Response::HTTP_OK,trans('auth.success'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);
        }
    }

    /**
     * @OA\POST(
     *     path="/api/v1/register",
     *     tags={"Authentication"},
     *     summary="Register",
     *     description="Register to system.",
     *     operationId="register",
     *     @OA\RequestBody(
     *         description="Register user",
     *         required=true,
     *         @OA\MediaType(
     *             mediaType="application/json",
     *            @OA\Schema(
     *                 type="object",
     *                 @OA\Property(
     *                     property="name",
     *                     description="User Name",
     *                     type="string",
     *                     example="Salvador Gonzalez"
     *                 ),
     *                 @OA\Property(
     *                     property="email",
     *                     description="User Email",
     *                     type="string",
     *                     example="demo@example.com"
     *                 ),
     *                 @OA\Property(
     *                     property="password",
     *                     description="User password",
     *                     type="string",
     *                     example="12345678"
     *                 ),
     *                 @OA\Property(
     *                     property="password_confirmation",
     *                     description="User confirm password",
     *                     type="string",
     *                     example="12345678"
     *                 ),
     *                 required={"name", "email", "password", "password_confirmation"}
     *             )
     *         ),
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid input"
     *     )
     * )
     */
    public function register(RegisterRequest $request): JsonResponse
    {
        try {
            $data = $this->auth->register($request->all());
            return $this->response(Response::HTTP_OK,trans('auth.register'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);

        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/profile",
     *     tags={"Authentication"},
     *     summary="User profile",
     *     description="User profile",
     *     operationId="profile",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthennticated"
     *     )
     * )
     */
    public function profile(): JsonResponse
    {
        try {
            $data = $this->auth->profile();
            return $this->response(Response::HTTP_OK,trans('auth.fetched'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);

        }
    }

    public function verifyToken(Request $request): JsonResponse
    {
        try {
            $data = $this->auth->verifyAuthenticatedToken($request);
            return $this->response(Response::HTTP_OK,trans('auth.fetched'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);
        }
    }

    /**
     * @OA\POST(
     *     path="/api/v1/logout",
     *     tags={"Authentication"},
     *     summary="User logout",
     *     description="User logout",
     *     operationId="logout",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=401,
     *         description="Unauthenticated"
     *     )
     * )
     */
    public function logout(Request $request): JsonResponse
    {
        try {
            $user = Auth::guard()->user();
            $token = $request->user()->token();
            $token->revoke();
            $token->delete();

            return $this->response(Response::HTTP_OK, trans('auth.fetched'), [], null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(), [], null);
        }
    }

    public function verifyCasTicket(Request $request): JsonResponse
    {
        try {
            $data = $this->auth->validateCasTicket($request);
            return $this->response(Response::HTTP_OK,trans('auth.ticket'),$data,null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_NOT_FOUND, $exception->getMessage(),[],null);
        }
    }
}
