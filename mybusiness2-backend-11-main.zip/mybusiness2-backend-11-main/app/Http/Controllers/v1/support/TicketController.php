<?php

namespace App\Http\Controllers\v1\support;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\support\TicketRequest;
use App\Repositories\v1\support\TicketRepository;

class TicketController
{
    use ResponseTrait;

    protected TicketRepository $ticketRepository;

    public function __construct(TicketRepository $ticketRepository)
    {
        $this->ticketRepository = $ticketRepository;
    }

    public function indexTicket(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.index"), $this->ticketRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showTicketById(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.show"), $this->ticketRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function addTicket(TicketRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.add"), $this->ticketRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateTicket(TicketRequest $request, string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.update"), $this->ticketRepository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function assignTicket(Request $request, string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.assign"), $this->ticketRepository->assign($id, $request->input('assigned_to')), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function closeTicket(Request $request, string $id): JsonResponse
    {
        try {
            $finalStatus = $request->input('status', 'closed'); // closed|resolved
            return $this->response(Response::HTTP_OK, trans("support/ticket.close"), $this->ticketRepository->close($id, $finalStatus), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function reopenTicket(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.reopen"), $this->ticketRepository->reopen($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function deleteTicket(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket.delete"), $this->ticketRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
