<?php

namespace App\Http\Controllers\v1\support;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\support\DistributionListRequest;
use App\Http\Requests\v1\support\DistributionListMembersRequest;
use App\Repositories\v1\support\DistributionListRepository;

class DistributionListController
{
    use ResponseTrait;

    protected DistributionListRepository $distributionListRepository;

    public function __construct(DistributionListRepository $distributionListRepository)
    {
        $this->distributionListRepository = $distributionListRepository;
    }

    public function index(Request $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.index"),
                $this->distributionListRepository->viewAll($request),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function show(string $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.show"),
                $this->distributionListRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function store(DistributionListRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.add"),
                $this->distributionListRepository->create($request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function update(DistributionListRequest $request, string $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.update"),
                $this->distributionListRepository->update($id, $request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function delete(string $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.delete"),
                $this->distributionListRepository->delete($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    // Sync members
    public function syncMembers(DistributionListMembersRequest $request, string $id): JsonResponse
    {
        try {
            $members = $request->input('members', null);
            $roles = $request->input('roles', null);

            // "members", sync members
            if (is_array($members)) {
                $this->distributionListRepository->syncMembers($id, $members);
            }

            // "roles", sync roles
            if (is_array($roles)) {
                $this->distributionListRepository->syncRoles($id, $roles);
            }

            return $this->response(
                Response::HTTP_OK,
                trans("support/distribution_list.membersUpdated"),
                $this->distributionListRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function emailsByCategory(Request $request): JsonResponse
    {
        try {
            $category = (string) $request->query('category', '');

            if (empty($category)) {
                return $this->response(
                    Response::HTTP_BAD_REQUEST,
                    'Category is required.',
                    [],
                    'Category is required.'
                );
            }

            $emails = $this->distributionListRepository->getActiveEmailsByCategory($category);

            return $this->response(
                Response::HTTP_OK,
                'Distribution list emails retrieved successfully.',
                $emails,
                null
            );
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }


}
