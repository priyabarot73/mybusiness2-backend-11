<?php

namespace App\Http\Controllers\v1\support;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\support\TicketMessageRequest;
use App\Repositories\v1\support\TicketMessageRepository;

class TicketMessageController
{
    use ResponseTrait;

    protected TicketMessageRepository $ticketMessageRepository;

    public function __construct(TicketMessageRepository $ticketMessageRepository)
    {
        $this->ticketMessageRepository = $ticketMessageRepository;
    }

    public function indexTicketMessage(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.index"), $this->ticketMessageRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function indexTicketMessageByTicket(Request $request, string $ticketId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.indexByTicket"), $this->ticketMessageRepository->viewAllByTicket($request, $ticketId), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showTicketMessageById(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.show"), $this->ticketMessageRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function addTicketMessage(TicketMessageRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.add"), $this->ticketMessageRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateTicketMessage(TicketMessageRequest $request, string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.update"), $this->ticketMessageRepository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function deleteTicketMessage(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans("support/ticket_message.delete"), $this->ticketMessageRepository->delete($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
