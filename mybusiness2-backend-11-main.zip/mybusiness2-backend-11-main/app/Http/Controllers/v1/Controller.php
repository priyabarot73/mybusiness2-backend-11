<?php

namespace App\Http\Controllers\v1;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

/**
 * @OA\Info(
 *      version="1.0",
 *      x={
 *          "logo": {
 *              "url": "https://via.placeholder.com/190x90.png?text=L5-Swagger"
 *          }
 *      },
 *      title="MyBusiness 2.0 API",
 *      description="MyBusiness API documentation",
 *      @OA\Contact(
 *          email="sgg.2020@gmail.com"
 *      ),
 * )
 * @OA\Tag(
 *     name="Authentication",
 *     description="Authenticate User Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 * @OA\Tag(
 *     name="Access period",
 *     description="Insert Description of Access Period Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 
 * @OA\Tag(
 *     name="Control clone section",
 *     description="Insert Description of Control clone section",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 * @OA\Tag(
 *     name="Instructor mode",
 *     description="Insert Description of Instructor Mode Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 *  * @OA\Tag(
 *     name="Meeting pattern",
 *     description="Deprecated/Obsolete",
 * )
 * @OA\Tag(
 *     name="Section",
 *     description="Insert Description of Section Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 * @OA\Tag(
 *     name="Session",
 *     description="Insert Description of Session Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 *  * @OA\Tag(
 *     name="Workload",
 *     description="Insert Description of Workload Here",
 *     @OA\ExternalDocumentation(
 *         description="Find out more",
 *         url="http://swagger.io"
 *     )
 * )
 */

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;
}
