<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\ContractStateTransitionRequest;
use App\Repositories\v1\hr\ContractStateTransitionRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ContractStateTransitionController
{
    protected ContractStateTransitionRepository $contractStateTransitionRepository;
    use ResponseTrait;
    public function __construct(ContractStateTransitionRepository $contractStateTransitionRepository)
    {
        $this->contractStateTransitionRepository = $contractStateTransitionRepository;
    }

    public function indexContractStateTransition(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state_transition.index'), $this->contractStateTransitionRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function createContractStateTransition(ContractStateTransitionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state_transition.add'), $this->contractStateTransitionRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateContractStateTransition($id, ContractStateTransitionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state_transition.update'), $this->contractStateTransitionRepository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
