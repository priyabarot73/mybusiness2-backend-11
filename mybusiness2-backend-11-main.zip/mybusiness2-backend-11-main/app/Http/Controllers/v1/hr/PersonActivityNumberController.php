<?php

namespace App\Http\Controllers\v1\hr;

//Global Import
use App\Http\Requests\v1\hr\PersonActivityNumberRequest;
use App\Repositories\v1\hr\PersonActivityNumberRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//Local Import

class PersonActivityNumberController
{
    protected PersonActivityNumberRepository $personActivityNumberRepository;
    use ResponseTrait;
    public function __construct(PersonActivityNumberRepository $personActivityNumberRepository)
    {
        $this->personActivityNumberRepository = $personActivityNumberRepository;
    }

    public function indexPersonActivityNumber(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_activity_number.index'), $this->personActivityNumberRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function viewAllPersonActivityNumberById(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_activity_number.index'), $this->personActivityNumberRepository->viewAllPersonActivityNumbersById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function assignPersonActivityNumber(PersonActivityNumberRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_activity_number.add'), $this->personActivityNumberRepository->assignPersonActivityNumbers($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
