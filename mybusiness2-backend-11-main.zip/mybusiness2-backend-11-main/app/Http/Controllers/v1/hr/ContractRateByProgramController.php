<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\hr\ContractRateByProgramRequest;
use App\Repositories\v1\hr\ContractRateByProgramRepository;

class ContractRateByProgramController
{
    protected ContractRateByProgramRepository $repository;
    use ResponseTrait;
    public function __construct(ContractRateByProgramRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexContractRateByProgram(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_rate_by_program.index'), $this->repository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function createContractRateByProgram(ContractRateByProgramRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_rate_by_program.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function updateContractRateByProgram($id, ContractRateByProgramRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_rate_by_program.update'), $this->repository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
