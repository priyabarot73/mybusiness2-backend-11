<?php

namespace App\Http\Controllers\v1\hr;

// Global Imports
use App\Http\Requests\v1\hr\EmployeeDirectoryRequest;
use App\Repositories\v1\hr\EmployeeDirectoryRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EmployeeDirectoryController
{
    use ResponseTrait;

    protected EmployeeDirectoryRepository $employeeDirectoryRepository;

    public function __construct(EmployeeDirectoryRepository $employeeDirectoryRepository)
    {
        $this->employeeDirectoryRepository = $employeeDirectoryRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/employee-directory/index",
     *     tags={"Employee Directory"},
     *     summary="Get all Employee Directory records",
     *     operationId="indexEmployeeDirectory",
     *     @OA\Response(response=200, description="Successful operation"),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=400, description="Invalid request")
     * )
     */
    public function indexEmployeeDirectory(): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/employee_directory.index'),
                $this->employeeDirectoryRepository->viewAll(),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/employee-directory/id/{id}",
     *     tags={"Employee Directory"},
     *     summary="Get Employee Directory record by ID",
     *     operationId="indexEmployeeDirectoryById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the employee directory record",
     *         required=true,
     *         @OA\Schema(type="string", example="081B9F40-9A85-43B3-B360-D65CE0746867")
     *     ),
     *     @OA\Response(response=200, description="Successful operation"),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=400, description="Invalid ID value")
     * )
     */
    public function indexEmployeeDirectoryById($id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/employee_directory.show'),
                $this->employeeDirectoryRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Post(
     *     path="/api/v1/employee-directory/add",
     *     tags={"Employee Directory"},
     *     summary="Create a new Employee Directory record",
     *     operationId="createEmployeeDirectory",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="person_id", type="string"),
     *             @OA\Property(property="team_id", type="string"),
     *             @OA\Property(property="job_title", type="string"),
     *             @OA\Property(property="email", type="string"),
     *             @OA\Property(property="phone", type="string"),
     *             example={
     *                 "person_id": "b8132ff1-df52-4d21-81a9-bcbd7de2f89f",
     *                 "team_id": "a9a1fabe-fc99-48d2-8259-1b2a0c3e3c21",
     *                 "job_title": "HR Coordinator",
     *                 "email": "jane.doe@example.com",
     *                 "phone": "+1-555-555-5555"
     *             }
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=200, description="Success"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function createEmployeeDirectory(EmployeeDirectoryRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/employee_directory.add'),
                $this->employeeDirectoryRepository->create($request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Put(
     *     path="/api/v1/employee-directory/update/{id}",
     *     tags={"Employee Directory"},
     *     summary="Update an Employee Directory record",
     *     operationId="updateEmployeeDirectory",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the employee directory record",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             type="object",
     *             @OA\Property(property="team_id", type="string"),
     *             @OA\Property(property="job_title", type="string"),
     *             @OA\Property(property="email", type="string"),
     *             @OA\Property(property="phone", type="string"),
     *             example={
     *                 "team_id": "a9a1fabe-fc99-48d2-8259-1b2a0c3e3c21",
     *                 "job_title": "Senior HR Coordinator",
     *                 "email": "updated.jane@example.com",
     *                 "phone": "+1-555-555-5556"
     *             }
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=200, description="Success"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function updateEmployeeDirectory(Request $request, $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/employee_directory.update'),
                $this->employeeDirectoryRepository->update($id, $request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Delete(
     *     path="/api/v1/employee-directory/delete/{id}",
     *     tags={"Employee Directory"},
     *     summary="Delete an Employee Directory record",
     *     operationId="deleteEmployeeDirectory",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the employee directory record",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=200, description="Deleted successfully"),
     *     @OA\Response(response=400, description="Error deleting record")
     * )
     */
    public function deleteEmployeeDirectory($id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/employee_directory.delete'),
                $this->employeeDirectoryRepository->delete($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
