<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\EmployeeResponsibilityAssignmentRequest;
use App\Repositories\v1\hr\EmployeeResponsibilityAssignmentRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class EmployeeResponsibilityAssignmentController
{
    protected EmployeeResponsibilityAssignmentRepository $employeeRepository;
    use ResponseTrait;
    public function __construct(EmployeeResponsibilityAssignmentRepository $employeeRepository)
    {
        $this->employeeRepository = $employeeRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/employee_responsibility_assignment/index",
     *     tags={"Employee Responsibility Assignment"},
     *     summary="Get all Employee Responsibility Assignments",
     *     operationId="indexEmployeeResponsibilityAssignment",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     */
    public function indexEmployeeResponsibilityAssignment(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/employee_responsibility_assignment.index'), $this->employeeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/employee_responsibility_assignment/status/{status}",
     *     tags={"Employee Responsibility Assignment"},
     *     summary="Get all Employee Responsibility Assignments By Status",
     *     operationId="showEmployeeResponsibilityAssignmentByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     *
     */
    public function showEmployeeResponsibilityAssignmentByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/employee_responsibility_assignment.show'), $this->employeeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create an Employee Responsibility Assignment
     * @OA\Post (
     *     path="/api/v1/employee_responsibility_assignment/add",
     *     tags={"Employee Responsibility Assignment"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "ST",
     *                      "name": "Staff",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addEmployeeResponsibilityAssignment(EmployeeResponsibilityAssignmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/employee_responsibility_assignment.add'), $this->employeeRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update an Employee Responsibility Assignment
     * @OA\Put (
     *     path="/api/v1/employee_responsibility_assignment/update/{id}",
     *     tags={"Employee Responsibility Assignment"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "code": "ST",
     *                      "name": "Staff",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function updateEmployeeResponsibilityAssignment(string $id, EmployeeResponsibilityAssignmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/employee_responsibility_assignment.update'), $this->employeeRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
