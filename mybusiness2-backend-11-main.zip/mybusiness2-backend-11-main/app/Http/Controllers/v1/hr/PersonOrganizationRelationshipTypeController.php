<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\PersonOrganizationRelationshipTypeRequest;
use App\Repositories\v1\hr\PersonOrganizationRelationshipTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class PersonOrganizationRelationshipTypeController
{
    protected PersonOrganizationRelationshipTypeRepository $personORTRepository;
    use ResponseTrait;
    public function __construct(PersonOrganizationRelationshipTypeRepository $personORTRepository)
    {
        $this->personORTRepository = $personORTRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/person_organization_relationship_type/index",
     *     tags={"Person Organization Relationship Type"},
     *     summary="Get all Person Organization Relationship Types",
     *     operationId="indexPersonORType",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexPersonORType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_org_rel_type.index'), $this->personORTRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/person_organization_relationship_type/status/{status}",
     *     tags={"Person Organization Relationship Type"},
     *     summary="Get all Person Organization Relationship Types by status",
     *     operationId="showPersonORTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showPersonORTypeByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_org_rel_type.status'), $this->personORTRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Person Organization Relationship Type
     * @OA\Post (
     *     path="/api/v1/person_organization_relationship_type/add",
     *     tags={"Person Organization Relationship Type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "STAFF",
     *                      "name": "Staff",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addPersonORType(PersonOrganizationRelationshipTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_org_rel_type.add'), $this->personORTRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Person Organization Relationship Type
     * @OA\Put (
     *     path="/api/v1/person_organization_relationship_type/update/{id}",
     *     tags={"Person Organization Relationship Type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "STAFF - Updated",
     *                      "name": "Staff - Updated",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updatePersonORType(string $id, PersonOrganizationRelationshipTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person_org_rel_type.update'), $this->personORTRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
