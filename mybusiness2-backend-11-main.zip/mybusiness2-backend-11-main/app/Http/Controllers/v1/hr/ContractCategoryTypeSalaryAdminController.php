<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\ContractCategoryTypeSalaryAdminRequest;
use App\Repositories\v1\hr\ContractCategoryTypeSalaryAdminRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ContractCategoryTypeSalaryAdminController
{
    protected ContractCategoryTypeSalaryAdminRepository $repository;
    use ResponseTrait;

    public function __construct(ContractCategoryTypeSalaryAdminRepository $repository)
    {
        $this->repository = $repository;
    }
    public function indexContractCategoryTypeSalary(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_category_type_salary_admin.index'), $this->repository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    public function indexAllByContractCategory($id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_category_type_salary_admin.index'), $this->repository->viewAllByContractCategoryId($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function addContractCategoryTypeSalary(ContractCategoryTypeSalaryAdminRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_category_type_salary_admin.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    public function updateContractCategoryTypeSalary(string $id, ContractCategoryTypeSalaryAdminRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_category_type_salary_admin.update'), $this->repository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
