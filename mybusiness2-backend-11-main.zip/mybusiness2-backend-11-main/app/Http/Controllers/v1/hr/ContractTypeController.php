<?php

namespace App\Http\Controllers\v1\hr;

//Global Import
use App\Http\Requests\v1\hr\ContractTypeRequest;
use App\Repositories\v1\hr\ContractTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

//Local Import

class ContractTypeController
{
    protected ContractTypeRepository $contractTypeRepository;
    use ResponseTrait;
    public function __construct(ContractTypeRepository $contractTypeRepository)
    {
        $this->contractTypeRepository = $contractTypeRepository;
    }
     /**
     * @OA\Get(
     *     path="/api/v1/contract_type/index",
     *     tags={"Contract Type"},
     *     summary="Get all Contract Types",
     *     operationId="indexContractType",
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexContractType(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type.index'), $this->contractTypeRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/contract_type/status/{status}",
     *     tags={"Contract Type"},
     *     summary="Get all Contract Types by status",
     *     operationId="indexContractTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean id",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexContractTypeByStatus($status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type.status'), $this->contractTypeRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/contract_type/id/{id}",
     *     tags={"Contract Type"},
     *     summary="Get Contract Types by ID",
     *     operationId="indexContractTypeById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexContractTypeById($id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type.id'), $this->contractTypeRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Contract Type
     * @OA\Post (
     *     path="/api/v1/contract_type/add",
     *     tags={"Contract Type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="teaching_duties",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="teaching_credit_courses",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="contract_type_level",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_employee_type_level",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Student Contract",
     *                      "description": "Student contract description",
     *                      "teaching_duties": 1,
     *                      "teaching_credit_courses": 1,
     *                      "contract_type_level": 1,
     *                      "sec_employee_type_level": 1,
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function createContractType(ContractTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type.add'), $this->contractTypeRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Contract Type
     * @OA\Put (
     *     path="/api/v1/contract_type/update/{id}",
     *     tags={"Contract Type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="teaching_duties",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="teaching_credit_courses",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="contract_type_level",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="sec_employee_type_level",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Student Contract",
     *                      "description": "Student contract description",
     *                      "teaching_duties": 1,
     *                      "teaching_credit_courses": 1,
     *                      "contract_type_level": 1,
     *                      "sec_employee_type_level": 1,
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateContractType(Request $request, $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type.update'), $this->contractTypeRepository->update($id,$request->all() ), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
