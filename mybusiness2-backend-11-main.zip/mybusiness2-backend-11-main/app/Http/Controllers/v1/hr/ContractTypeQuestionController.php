<?php

namespace App\Http\Controllers\v1\hr;

//Global Import
use App\Http\Requests\v1\hr\ContractTypeQuestionRequest;
use App\Repositories\v1\hr\ContractTypeQuestionRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//Local Import

class ContractTypeQuestionController
{
    protected ContractTypeQuestionRepository $contractTypeQuestionRepository;
    use ResponseTrait;
    public function __construct(ContractTypeQuestionRepository $contractTypeQuestionRepository)
    {
        $this->contractTypeQuestionRepository = $contractTypeQuestionRepository;
    }

    public function indexContractTypeQuestion(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type_question.index'), $this->contractTypeQuestionRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function viewAllContractTypeQuestionById(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type_question.index'), $this->contractTypeQuestionRepository->viewAllContractTypeQuestionById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function assignContractTypeQuestion(ContractTypeQuestionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_type_question.add'), $this->contractTypeQuestionRepository->assignContractTypeQuestion($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
