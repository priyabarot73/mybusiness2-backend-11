<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\SalaryAdminPlanRequest;
use App\Repositories\v1\hr\SalaryAdminPlanRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
class SalaryAdminPlanController
{
    protected SalaryAdminPlanRepository $salaryAPRepository;
    use ResponseTrait;
    public function __construct(SalaryAdminPlanRepository $salaryAPRepository)
    {
        $this->salaryAPRepository = $salaryAPRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/salary_admin_plan/index",
     *     tags={"Salary Admin Plan"},
     *     summary="Get all Salary Admin Plans",
     *     operationId="indexSalaryAdminPlan",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexSalaryAdminPlan(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/salary_admin_plan.index'), $this->salaryAPRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
     /**
     * @OA\Get(
     *     path="/api/v1/salary_admin_plan/status/{status}",
     *     tags={"Salary Admin Plan"},
     *     summary="Get all Salary Admin Plans by status",
     *     operationId="showSalaryAdminPlanByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showSalaryAdminPlanByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/salary_admin_plan.status'), $this->salaryAPRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showSalaryAdminPlanUsedIn(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/salary_admin_plan.index'), $this->salaryAPRepository->viewAllByUsedIn($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Salary Admin Plan
     * @OA\Post (
     *     path="/api/v1/salary_admin_plan/add",
     *     tags={"Salary Admin Plan"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="pay_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_classification_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="person_organization_relationship_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "001",
     *                      "name": "Temporary",
     *                      "pay_group_id":"ec8a8dff-63bf-4a15-95e0-5943bab4f5b3",
     *                      "employee_classification_id":"2875682c-c863-422b-9a59-304a05441bf9",
     *                      "employee_type_id":"c69e45a8-1367-498f-80d5-481f5e3067d6",
     *                      "person_organization_relationship_type_id":"f1d3ae12-1f4e-49cc-aada-e96b8a5e32f4",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addSalaryAdminPlan(SalaryAdminPlanRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/salary_admin_plan.add'), $this->salaryAPRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
     /**
     * Update a Salary Admin Plan
     * @OA\Put (
     *     path="/api/v1/salary_admin_plan/update/{id}",
     *     tags={"Salary Admin Plan"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="code",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="pay_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_classification_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="person_organization_relationship_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "code": "002",
     *                      "name": "Temporary - Updated",
     *                      "pay_group_id":"ec8a8dff-63bf-4a15-95e0-5943bab4f5b3",
     *                      "employee_classification_id":"2875682c-c863-422b-9a59-304a05441bf9",
     *                      "employee_type_id":"c69e45a8-1367-498f-80d5-481f5e3067d6",
     *                      "person_organization_relationship_type_id":"f1d3ae12-1f4e-49cc-aada-e96b8a5e32f4",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateSalaryAdminPlan(string $id, SalaryAdminPlanRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/salary_admin_plan.update'), $this->salaryAPRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
