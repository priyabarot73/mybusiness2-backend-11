<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\ContractRoleStateTransitionRequest;
use App\Repositories\v1\hr\ContractRoleStateTransitionRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ContractRoleStateTransitionController
{
    protected ContractRoleStateTransitionRepository $repository;
    use ResponseTrait;
    public function __construct(ContractRoleStateTransitionRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexContractRoleStateTransition(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_role_state_transition.index'), $this->repository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    public function getAllTransitionByRoleId(string $roleId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_role_state_transition.id'), $this->repository->viewByRoleId($roleId), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function createContractRoleStateTransition(ContractRoleStateTransitionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_role_state_transition.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

}
