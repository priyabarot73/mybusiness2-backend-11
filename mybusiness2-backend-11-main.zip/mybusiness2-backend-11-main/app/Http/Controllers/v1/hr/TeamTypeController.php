<?php

namespace App\Http\Controllers\v1\hr;

// Global Imports
use App\Http\Requests\v1\hr\TeamTypeRequest;
use App\Repositories\v1\hr\TeamTypeRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TeamTypeController
{
    protected TeamTypeRepository $teamTypeRepository;
    use ResponseTrait;

    public function __construct(TeamTypeRepository $teamTypeRepository)
    {
        $this->teamTypeRepository = $teamTypeRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team_type/index",
     *     tags={"Team Type"},
     *     summary="Get all Team Types",
     *     operationId="indexTeamType",
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexTeamType(): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team_type.index'),
                $this->teamTypeRepository->viewAll(),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team_type/status/{status}",
     *     tags={"Team Type"},
     *     summary="Get all Team Types by status",
     *     operationId="indexTeamTypeByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean id",
     *         required=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexTeamTypeByStatus($status): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team_type.status'),
                $this->teamTypeRepository->viewAllByStatus($status),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team_type/id/{id}",
     *     tags={"Team Type"},
     *     summary="Get Team Type by ID",
     *     operationId="indexTeamTypeById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexTeamTypeById($id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team_type.id'),
                $this->teamTypeRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * Create a Team Type
     * @OA\Post (
     *     path="/api/v1/team_type/add",
     *     tags={"Team Type"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="name", type="string"),
     *                      @OA\Property(property="description", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "name": "Research Team",
     *                      "description": "Handles faculty research activities",
     *                      "active": "1"
     *                 }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *          @OA\JsonContent(
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function createTeamType(TeamTypeRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team_type.add'),
                $this->teamTypeRepository->create($request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * Update a Team Type
     * @OA\Put (
     *     path="/api/v1/team_type/update/{id}",
     *     tags={"Team Type"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="name", type="string"),
     *                      @OA\Property(property="description", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "name": "Updated Research Team",
     *                      "description": "Updated description",
     *                      "active": "1"
     *                 }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *          @OA\JsonContent(
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     * )
     */
    public function updateTeamType(Request $request, $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team_type.update'),
                $this->teamTypeRepository->update($id, $request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
