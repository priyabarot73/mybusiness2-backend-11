<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\SecondaryTeachingAppointmentRequest;
use App\Repositories\v1\hr\SecondaryTeachingAppointmentRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class SecondaryTeachingAppointmentController
{
    protected SecondaryTeachingAppointmentRepository $secondary;
    use ResponseTrait;
    public function __construct(SecondaryTeachingAppointmentRepository $secondary)
    {
        $this->secondary = $secondary;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/secondary_teaching_appointment/index",
     *     tags={"Secondary Teaching Appointment"},
     *     summary="Get all Secondary Teaching Appointments",
     *     operationId="indexSecondaryTeachingAppoint",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexSecondaryTeachingAppoint(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/secondary_teaching_appointment.index'), $this->secondary->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/secondary_teaching_appointment/status/{status}",
     *     tags={"Secondary Teaching Appointment"},
     *     summary="Get all Secondary Teaching Appointments by status",
     *     operationId="showSecondaryTeachingAppointByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showSecondaryTeachingAppointByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/secondary_teaching_appointment.index'), $this->secondary->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Secondary Teaching Appointment
     * @OA\Post (
     *     path="/api/v1/secondary_teaching_appointment/add",
     *     tags={"Secondary Teaching Appointment"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Administrative",
     *                      "description":"Admin",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addSecondaryTeachingAppoint(SecondaryTeachingAppointmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/secondary_teaching_appointment.add'), $this->secondary->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Secondary Teaching Appointment
     * @OA\Put (
     *     path="/api/v1/secondary_teaching_appointment/update/{id}",
     *     tags={"Secondary Teaching Appointment"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Administrative - Update",
     *                      "description":"Admin",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateSecondaryTeachingAppoint(string $id, SecondaryTeachingAppointmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/secondary_teaching_appointment.update'), $this->secondary->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
