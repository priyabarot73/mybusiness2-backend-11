<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\EthnicityRequest;
use App\Repositories\v1\hr\EthnicityRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
class EthnicityController
{
    protected EthnicityRepository $ethnicityRepository;
    use ResponseTrait;
    public function __construct(EthnicityRepository $ethnicityRepository)
    {
        $this->ethnicityRepository = $ethnicityRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/ethnicity/index",
     *     tags={"Ethnicity"},
     *     summary="Get all Ethnicities",
     *     operationId="indexEthnicity",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexEthnicity(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/ethnicity.index'), $this->ethnicityRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/ethnicity/status/{status}",
     *     tags={"Ethnicity"},
     *     summary="Get all Ethnicities by status",
     *     operationId="showEthnicityByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showEthnicityByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/ethnicity.status'), $this->ethnicityRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create an Ethnicity
     * @OA\Post (
     *     path="/api/v1/ethnicity/add",
     *     tags={"Ethnicity"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "Hispanic or Latino",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addEthnicity(EthnicityRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/ethnicity.add'), $this->ethnicityRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update an Ethnicity
     * @OA\Put (
     *     path="/api/v1/ethnicity/update/{id}",
     *     tags={"Ethnicity"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "Hispanic or Latino - Updated",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateEthnicity(string $id, EthnicityRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/ethnicity.update'), $this->ethnicityRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
