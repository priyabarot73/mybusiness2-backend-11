<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\hr\ContractRequest;
use App\Repositories\v1\hr\ContractRepository;
use App\Http\Requests\v1\hr\ContractByIdRequest;
use App\Http\Requests\v1\hr\ContractTransitionRequest;
use App\Http\Requests\v1\hr\ContractStatusReportRequest;
use App\Http\Requests\v1\hr\ContractRequestReportRequest;

class ContractController
{
    protected ContractRepository $repository;
    use ResponseTrait;

    public function __construct(ContractRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexContract(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.index'), $this->repository->getContracts($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getContractById(ContractByIdRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.id'), $this->repository->getContractById($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    // List of employees for whom a contract can be created
    public function getEmployees(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.persons_success'), $this->repository->getEmployees($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getDepartmentResponsible(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.persons_success'), $this->repository->getResponsiblePersons(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getVisibleActivityNumbers(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.activity_number_success'), $this->repository->getVisibleActivityNumbers(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getVisibleContractStateTransitions(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.contract_state_transition_success'), $this->repository->getVisibleStateTransitions($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getContractCompensation(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.contract_compensation_success'), $this->repository->computeForTermAndInstructor($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function create(ContractRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.create'), $this->repository->createContract($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function update(ContractRequest $request, $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.update'), $this->repository->updateContract($request, $id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function getAvailableTransitions(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.available_transitions'), $this->repository->getAvailableTransitions($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function transitionContract(ContractTransitionRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract.apply_transition_success'), $this->repository->transitionContractById($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function contractRequestReport(ContractRequestReportRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, 'Contract report data', $this->repository->getContractRequestReport($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function contractStatusReport(ContractStatusReportRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, 'Contract report data', $this->repository->getContractStatusReport($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
