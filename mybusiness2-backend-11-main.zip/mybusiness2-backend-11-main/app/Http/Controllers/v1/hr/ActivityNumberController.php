<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\ActivityNumberRequest;
use App\Repositories\v1\hr\ActivityNumberRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class ActivityNumberController
{
    use ResponseTrait;
    protected ActivityNumberRepository $activityRepository;
    public function __construct(ActivityNumberRepository $activityRepository)
    {
        $this->activityRepository = $activityRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/activity_number/index",
     *     tags={"Activity Number"},
     *     summary="Get all Activity Numbers",
     *     operationId="indexActivityNumber",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexActivityNumber(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/activity_number.index'), $this->activityRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/activity_number/status/{status}",
     *     tags={"Activity Number"},
     *     summary="Get all Activity Numbers by Status",
     *     operationId="indexActivityNumberByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showActivityNumberByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/activity_number.show'), $this->activityRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
     /**
     * Create an Activity Number
     * @OA\Post (
     *     path="/api/v1/activity_number/add",
     *     tags={"Activity Number"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="responsible_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "number": "2320020001",
     *                      "name": "School of Accounting",
     *                      "department_id": "57e2e038-ca6e-46fe-8c1f-fe37bbb4a334",
     *                      "program_id": "1290a1b8-2545-45bb-8417-d70e008dcc62",
     *                      "responsible_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function addActivityNumber(ActivityNumberRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/activity_number.add'), $this->activityRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
     /**
     * Update an Activity Number
     * @OA\Put (
     *     path="/api/v1/activity_number/update/{id}",
     *     tags={"Activity Number"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="program_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="responsible_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "number": "2320020001",
     *                      "name": "School of Accounting",
     *                      "department_id": "57e2e038-ca6e-46fe-8c1f-fe37bbb4a334",
     *                      "program_id": "1290a1b8-2545-45bb-8417-d70e008dcc62",
     *                      "responsible_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateActivityNumber(string $id, ActivityNumberRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/activity_number.update'), $this->activityRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
