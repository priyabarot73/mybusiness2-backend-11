<?php

namespace App\Http\Controllers\v1\hr;

// Global Imports
use App\Http\Requests\v1\hr\TeamRequest;
use App\Repositories\v1\hr\TeamRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TeamController
{
    protected TeamRepository $teamRepository;
    use ResponseTrait;

    public function __construct(TeamRepository $teamRepository)
    {
        $this->teamRepository = $teamRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team/index",
     *     tags={"Team"},
     *     summary="Get all Teams",
     *     operationId="indexTeam",
     *     @OA\Response(response=200, description="successful operation"),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=400, description="Invalid status value")
     * )
     */
    public function indexTeam(): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team.index'),
                $this->teamRepository->viewAll(),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team/status/{status}",
     *     tags={"Team"},
     *     summary="Get all Teams by status",
     *     operationId="indexTeamByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Active status (1 or 0)",
     *         required=true,
     *         @OA\Schema(type="integer", default="1")
     *     ),
     *     @OA\Response(response=200, description="successful operation"),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=400, description="Invalid status value")
     * )
     */
    public function indexTeamByStatus($status): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team.status'),
                $this->teamRepository->viewAllByStatus($status),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/team/id/{id}",
     *     tags={"Team"},
     *     summary="Get Team by ID",
     *     operationId="indexTeamById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the team",
     *         required=true,
     *         @OA\Schema(type="string", default="081B9F40-9A85-43B3-B360-D65CE0746867")
     *     ),
     *     @OA\Response(response=200, description="successful operation"),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=400, description="Invalid ID value")
     * )
     */
    public function indexTeamById($id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team.id'),
                $this->teamRepository->viewById($id),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * Create a Team
     * @OA\Post(
     *     path="/api/v1/team/add",
     *     tags={"Team"},
     *     summary="Create a new Team",
     *     operationId="createTeam",
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="name", type="string"),
     *                      @OA\Property(property="description", type="string"),
     *                      @OA\Property(property="team_type_id", type="string"),
     *                      @OA\Property(property="department_id", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "name": "Finance Team",
     *                      "description": "Handles financial operations",
     *                      "team_type_id": "b8132ff1-df52-4d21-81a9-bcbd7de2f89f",
     *                      "department_id": "a9a1fabe-fc99-48d2-8259-1b2a0c3e3c21",
     *                      "active": true
     *                 }
     *             )
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=200, description="Success"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function createTeam(TeamRequest $request): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team.add'),
                $this->teamRepository->create($request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }

    /**
     * Update a Team
     * @OA\Put(
     *     path="/api/v1/team/update/{id}",
     *     tags={"Team"},
     *     summary="Update a Team",
     *     operationId="updateTeam",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="UUID of the team",
     *         required=true,
     *         @OA\Schema(type="string")
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(property="name", type="string"),
     *                      @OA\Property(property="description", type="string"),
     *                      @OA\Property(property="team_type_id", type="string"),
     *                      @OA\Property(property="department_id", type="string"),
     *                      @OA\Property(property="active", type="boolean")
     *                 ),
     *                 example={
     *                      "name": "Updated Finance Team",
     *                      "description": "Updated description",
     *                      "team_type_id": "b8132ff1-df52-4d21-81a9-bcbd7de2f89f",
     *                      "department_id": "a9a1fabe-fc99-48d2-8259-1b2a0c3e3c21",
     *                      "active": true
     *                 }
     *             )
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(response=200, description="Success"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function updateTeam(Request $request, $id): JsonResponse
    {
        try {
            return $this->response(
                Response::HTTP_OK,
                trans('hr/team.update'),
                $this->teamRepository->update($id, $request->all()),
                null
            );
        } catch (Exception $exception) {
            return $this->response(
                Response::HTTP_BAD_REQUEST,
                $exception->getMessage(),
                [],
                $exception->getMessage()
            );
        }
    }
}
