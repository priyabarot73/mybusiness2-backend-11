<?php

namespace App\Http\Controllers\v1\hr;

//Global Import

use App\Http\Controllers\v1\Controller;
use App\Http\Requests\v1\hr\ContractHistoryRequest;
use App\Repositories\v1\hr\ContractHistoryRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//Local Import

class ContractHistoryController extends Controller
{
    use ResponseTrait;
    protected ContractHistoryRepository $contractHistoryRepository;
    public function __construct(ContractHistoryRepository $contractHistoryRepository)
    {
        $this->contractHistoryRepository = $contractHistoryRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/contract_history/index",
     *     tags={"Contract History"},
     *     summary="Get all Contract Histories",
     *     operationId="showContractHistory",
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showContractHistory()
    {
        try {
            return $this->response(Response::HTTP_OK, trans('contract_history.index'), $this->contractHistoryRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/contract_history/id/{id}",
     *     tags={"Contract History"},
     *     summary="Show Contract History by ID",
     *     operationId="showContractHistoryById",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showContractHistoryById($id)
    {
        try {
            return $this->response(Response::HTTP_OK, trans('contract_history.id'), $this->contractHistoryRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/contract_history/contract/{id}",
     *     tags={"Contract History"},
     *     summary="Show Contract History by Contract ID",
     *     operationId="showContractHistoryByContractId",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Contract Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showContractHistoryByContractId($id)
    {
        try {
            return $this->response(Response::HTTP_OK, trans('contract_history.index'), $this->contractHistoryRepository->viewByContractId($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Contract History
     * @OA\Post (
     *     path="/api/v1/contract_history/add",
     *     tags={"Contract History"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="parent_contract_state_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "contract_id": "081b9f40-9a85-43b3-b360-d65ce0746867",
     *                      "supervisor_id": "c0642f02-e91f-4902-8ab7-3a0fea7d04fc",
     *                      "state_id": "4e90caa1-0af7-4438-b2b1-5992a1c7afb8",
     *                      "date": "2022-02-02",
     *                      "notification_count": 0,
     *                      "current_active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function createContractHistory(ContractHistoryRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('contract_history.add'), $this->contractHistoryRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Put(
     *     path="/api/v1/contract_history/increment/{id}",
     *     tags={"Contract History"},
     *     summary="Increment Notification Count",
     *     operationId="incrementNotificationCount",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Contract Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="081B9F40-9A85-43B3-B360-D65CE0746867",
     *             type="string",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function incrementNotificationCount($id)
    {
        try {
            return $this->response(Response::HTTP_OK, trans('contract_history.increment'), $this->contractHistoryRepository->incrementNotifCount($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
