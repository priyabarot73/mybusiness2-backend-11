<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\SuffixRequest;
use App\Repositories\v1\hr\SuffixRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
class SuffixController
{
    use ResponseTrait;
    protected SuffixRepository $suffixRepository;
    public function __construct(SuffixRepository $suffixRepository)
    {
        $this->suffixRepository = $suffixRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/suffix/index",
     *     tags={"Suffix"},
     *     summary="Get all Suffixes",
     *     operationId="indexSuffix",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexSuffix(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/suffix.index'), $this->suffixRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/suffix/status/{status}",
     *     tags={"Suffix"},
     *     summary="Get all Suffixes by status",
     *     operationId="showSuffixByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showSuffixByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/suffix.status'), $this->suffixRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create a Suffix
     * @OA\Post (
     *     path="/api/v1/suffix/add",
     *     tags={"Suffix"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "MBA, PMP",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function addSuffix(SuffixRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/suffix.add'), $this->suffixRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update a Suffix
     * @OA\Put (
     *     path="/api/v1/suffix/update/{id}",
     *     tags={"Suffix"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "MBA, PMP - updated",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function updateSuffix(string $id, SuffixRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/suffix.update'), $this->suffixRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
