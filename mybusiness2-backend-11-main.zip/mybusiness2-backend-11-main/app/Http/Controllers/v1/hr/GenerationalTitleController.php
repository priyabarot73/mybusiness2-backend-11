<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\GenerationalTitleRequest;
use App\Repositories\v1\hr\GenerationalTitleRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
class GenerationalTitleController
{
    protected GenerationalTitleRepository $gtRepository;
    use ResponseTrait;
    public function __construct(GenerationalTitleRepository $gtRepository)
    {
        $this->gtRepository = $gtRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/generational_title/index",
     *     tags={"Generational Title"},
     *     summary="Get all Generational Titles",
     *     operationId="indexGt",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexGt(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/generational_title.index'), $this->gtRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/generational_title/status/{status}",
     *     tags={"Generational Title"},
     *     summary="Get all Generational Titles by status",
     *     operationId="showGtByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showGtByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/generational_title.status'), $this->gtRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create a Generational Title
     * @OA\Post (
     *     path="/api/v1/generational_title/add",
     *     tags={"Generational Title"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "Jr.",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addGt(GenerationalTitleRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/generational_title.add'), $this->gtRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

     /**
     * Update a Generational Title
     * @OA\Put (
     *     path="/api/v1/generational_title/update/{id}",
     *     tags={"Generational Title"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "Jr. - Updated",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateGt(string $id, GenerationalTitleRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/generational_title.update'), $this->gtRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
