<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\AssignmentRequest;
use App\Repositories\v1\hr\AssignmentRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class AssignmentController
{
    use ResponseTrait;

    protected AssignmentRepository $assignmentRepository;

    public function __construct(AssignmentRepository $assignmentRepository)
    {
        $this->assignmentRepository = $assignmentRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/assignment/index",
     *     tags={"Assignment"},
     *     summary="Get all Assignments",
     *     operationId="indexAssignment",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexAssignment(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.index'), $this->assignmentRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/assignment/status/{status}",
     *     tags={"Assignment"},
     *     summary="Get all Assignments",
     *     operationId="showAssignmentByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showAssignmentByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.show'), $this->assignmentRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showAssignmentByPersonId(string $personId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.show'), $this->assignmentRepository->viewAssignmentByPersonId($personId), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function showAssignmentById(string $assignmentId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.show'), $this->assignmentRepository->viewAssignmentById($assignmentId), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create an Assignment
     * @OA\Post (
     *     path="/api/v1/assignment/add",
     *     tags={"Assignment"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="person_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="original_hire_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="salary_admin_plan_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_class_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_responsibility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="unit_status_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="position_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="fte",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="job_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="working_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action_reason_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="start_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="end_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="business_unit_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sub_department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_organization_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="physical_location_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="facility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="physical_public_establishment",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="public_establishment_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="public_facility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="supervisor_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                  "person_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                  "original_hire_date": "2019-11-20T00:00:00Z",
     *                  "salary_admin_plan_id": "dad68bfe-7185-4a35-bad0-ccf3db20ddb0",
     *                  "employee_class_id": "3346E613-7384-4E2B-8EA1-51C3B64CB25A",
     *                  "employee_type_id":"C69E45A8-1367-498F-80D5-481F5E3067D6",
     *                  "employee_responsibility_id": "4e77a696-66bf-4455-85bf-3ad60d4eab79",
     *                  "unit_status_id": "4c540727-97fe-44ef-bc81-1f195deb40c4",
     *                  "position_number": "1234567",
     *                  "fte": "fte",
     *                  "job_title_id": "75778D66-F283-4FC5-931C-1DF36E7596C7",
     *                  "working_title_id": "d1da36f4-3bed-4aef-b25e-aa51aa2b6d37",
     *                  "action_id": "6CF8EE0B-3D43-4081-942C-5F37A8C5C052",
     *                  "action_reason_id": "7E47C4C0-8A09-431D-B7F4-3EB6A5832869",
     *                  "start_date": "2019-11-20T00:00:00Z",
     *                  "end_date": "2019-11-20T00:00:00Z",
     *                  "business_unit_id": "0475AB06-1FA3-4D68-8173-A08F00189A00",
     *                  "department_id": "57E2E038-CA6E-46FE-8C1F-FE37BBB4A334",
     *                  "sub_department_id": null,
     *                  "academic_group_id": "6B5E60B1-FA8A-4EE2-A7C8-F8ECFEE7486C",
     *                  "academic_organization_id": "7B2510C3-AACA-42C5-AF6F-CAAD00AFFBE9",
     *                  "physical_location_id": "2fd92e93-3756-4683-bebb-90dc30ce707a",
     *                  "facility_id": "b709c0d0-fffd-465e-b5b2-d4b8d705d78d",
     *                  "physical_public_establishment": "1",
     *                  "public_establishment_id": "2FD92E93-3756-4683-BEBB-90DC30CE707A",
     *                  "public_facility_id": "b709c0d0-fffd-465e-b5b2-d4b8d705d78d",
     *                  "supervisor_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                  "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function addAssignment(AssignmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.add'), $this->assignmentRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update an Assignment
     * @OA\Put (
     *     path="/api/v1/assignment/update/{id}",
     *     tags={"Assignment"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="person_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="original_hire_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="salary_admin_plan_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_class_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_responsibility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="unit_status_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="position_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="fte",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="job_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="working_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action_reason_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="start_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="end_date",
     *                          type="string",
     *                          format="date-time"
     *                      ),
     *                      @OA\Property(
     *                          property="business_unit_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="sub_department_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_group_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="academic_organization_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="physical_location_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="facility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="physical_public_establishment",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="public_establishment_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="public_facility_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="supervisor_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                  "person_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                  "original_hire_date": "2019-11-20T00:00:00Z",
     *                  "salary_admin_plan_id": "dad68bfe-7185-4a35-bad0-ccf3db20ddb0",
     *                  "employee_class_id": "3346E613-7384-4E2B-8EA1-51C3B64CB25A",
     *                  "employee_type_id":"C69E45A8-1367-498F-80D5-481F5E3067D6",
     *                  "employee_responsibility_id": "4e77a696-66bf-4455-85bf-3ad60d4eab79",
     *                  "unit_status_id": "4c540727-97fe-44ef-bc81-1f195deb40c4",
     *                  "position_number": "1234567",
     *                  "fte": "fte",
     *                  "job_title_id": "75778D66-F283-4FC5-931C-1DF36E7596C7",
     *                  "working_title_id": "d1da36f4-3bed-4aef-b25e-aa51aa2b6d37",
     *                  "action_id": "6CF8EE0B-3D43-4081-942C-5F37A8C5C052",
     *                  "action_reason_id": "7E47C4C0-8A09-431D-B7F4-3EB6A5832869",
     *                  "start_date": "2019-11-20T00:00:00Z",
     *                  "end_date": "2019-11-20T00:00:00Z",
     *                  "business_unit_id": "0475AB06-1FA3-4D68-8173-A08F00189A00",
     *                  "department_id": "57E2E038-CA6E-46FE-8C1F-FE37BBB4A334",
     *                  "sub_department_id": null,
     *                  "academic_group_id": "6B5E60B1-FA8A-4EE2-A7C8-F8ECFEE7486C",
     *                  "academic_organization_id": "7B2510C3-AACA-42C5-AF6F-CAAD00AFFBE9",
     *                  "physical_location_id": "2fd92e93-3756-4683-bebb-90dc30ce707a",
     *                  "facility_id": "b709c0d0-fffd-465e-b5b2-d4b8d705d78d",
     *                  "physical_public_establishment": "1",
     *                  "public_establishment_id": "2FD92E93-3756-4683-BEBB-90DC30CE707A",
     *                  "public_facility_id": "b709c0d0-fffd-465e-b5b2-d4b8d705d78d",
     *                  "supervisor_id": "081b9f40-9a85-43b3-b360-d65ce0746866",
     *                  "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateAssignment(string $id, AssignmentRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.update'), $this->assignmentRepository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/assignment/details/{personId}",
     *      tags={"Assignment"},
     *      summary="Get assignment details for a specific person",
     *      operationId="getAssignmentDetails",
     *      security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function getAssignmentDetails(string $personId): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/assignment.details'), $this->assignmentRepository->getAssignmentsWithAndWithoutContracts($personId), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
