<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use App\Http\Requests\v1\hr\AcademicOrganizationRequest;
use App\Repositories\v1\hr\AcademicOrganizationRepository;
use App\Traits\ResponseTrait;
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class AcademicOrganizationController
{
    use ResponseTrait;
    protected AcademicOrganizationRepository $academicRepository;
    public function __construct(AcademicOrganizationRepository $academicRepository)
    {
        $this->academicRepository = $academicRepository;
    }
     /**
      * @OA\Get(
      * path="/api/v1/academic_organization/index",
      * tags={"Academic Organization"},
      * summary="Get all Academic Organizations",
      * operationId="indexAcademicOrganization",
      * security={{"bearer":{}}},
      * @OA\Response(
      * response=200,
      * description="successful operation",
      * ),
      * @OA\Response(
      * response=400,
      * description="Invalid status value"
      * )
      * )
      * /
      * public function indexAcademicOrganization(): JsonResponse
      * {
      * try {
      * return $this->response(Response::HTTP_OK, trans('hr/academic_organization.index'), $this->academicRepository->viewAll(), null);
      * } catch (Exception $exception) {
      * return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
      * }
      * }
      *
      * /**
      * @OA\Get(
      * path="/api/v1/academic_organization/status/{status}",
      * tags={"Academic Organization"},
      * summary="Get all Academic Organizations",
      * operationId="indexAcademicOrganizationByStatus",
      * @OA\Parameter(
      * name="status",
      * in="path",
      * description="Boolean ID",
      * required=true,
      * explode=true,
      * @OA\Schema(
      * default="1",
      * type="integer",
      * )
      * ),
      * security={{"bearer":{}}},
      * @OA\Response(
      * response=200,
      * description="successful operation",
      * ),
      * @OA\Response(
      * response=400,
      * description="Invalid status value"
      * )
      * )
      * /
      *
      * public function showAcademicOrganizationByStatus(int $status): JsonResponse
      * {
      * try {
      * return $this->response(Response::HTTP_OK, trans('hr/academic_organization.show'), $this->academicRepository->viewAllByStatus($status), null);
      * } catch (Exception $exception) {
      * return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
      * }
      * }
      *
      * /**
      * Create an Academic Organization
      * @OA\Post (
      * path="/api/v1/academic_organization/add",
      * tags={"Academic Organization"},
      * @OA\RequestBody(
      * @OA\MediaType(
      * mediaType="application/json",
      * @OA\Schema(
      * @OA\Property(
      * @OA\Property(
      * property="name",
      * type="string"
      * ),
      * @OA\Property(
      * property="description",
      * type="string"
      * ),
      * @OA\Property(
      * property="active",
      * type="boolean"
      * ),
      * ),
      * example={
      * "name": "FIU Board of Trustees",
      * "description": "FIU Board of Trustees",
      * "active": "1"
      * }
      * )
      * )
      * ),
      * security={{"bearer":{}}},
      * @OA\Response(
      * response=200,
      * description="Success",
      * @OA\JsonContent(
      * @OA\Property(property="meta", type="object"),
      * @OA\Property(property="data", type="object")
      * )
      * ),
      * @OA\Response(
      * response=422,
      * description="Validation error",
      * @OA\Property(property="data", type="object", example={}),
      * )
      * )
      * /
      *
      * public function addAcademicOrganization(AcademicOrganizationRequest $request): JsonResponse
      * {
      * try {
      * return $this->response(Response::HTTP_OK, trans('hr/academic_organization.add'), $this->academicRepository->create($request->all()), null);
      * } catch (Exception $exception) {
      * return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
      * }
      * }
      * /**
      * Update an Academic Organization
      * @OA\Put (
      * path="/api/v1/academic_organization/update/{id}",
      * tags={"Academic Organization"},
      * @OA\Parameter(
      * name="id",
      * in="path",
      * description="Uuid",
      * required=true,
      * explode=true,
      * @OA\Schema(
      * default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
      * type="string",
      * )
      * ),
      * @OA\RequestBody(
      * @OA\MediaType(
      * mediaType="application/json",
      * @OA\Schema(
      * @OA\Property(
      * @OA\Property(
      * property="name",
      * type="string"
      * ),
      * @OA\Property(
      * property="description",
      * type="string"
      * ),
      * @OA\Property(
      * property="active",
      * type="boolean"
      * ),
      * ),
      * example={
      * "name": "FIU Board of Trustees",
      * "description": "FIU Board of Trustees",
      * "active": "1"
      * }
      * )
      * )
      * ),
      * security={{"bearer":{}}},
      * @OA\Response(
      * response=200,
      * description="Success",
      * @OA\JsonContent(
      * @OA\Property(property="meta", type="object"),
      * @OA\Property(property="data", type="object")
      * )
      * ),
      * @OA\Response(
      * response=422,
      * description="Validation error",
      * @OA\Property(property="data", type="object", example={}),
      * )
      * )
      * /
      * public function updateAcademicOrganization(string $id, AcademicOrganizationRequest $request): JsonResponse
      * {
      * try {
      * return $this->response(Response::HTTP_OK, trans('hr/academic_organization.update'), $this->academicRepository->update($id,$request->all()), null);
      * } catch (Exception $exception) {
      * return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
      * }
      * }
      * }
     * @OA\Get(
     *     path="/api/v1/academic_organization/index",
     *     tags={"Academic Organization"},
     *     summary="Get all Academic Organizations",
     *     operationId="indexAcademicOrganization",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexAcademicOrganization(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/academic_organization.index'), $this->academicRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/academic_organization/status/{status}",
     *     tags={"Academic Organization"},
     *     summary="Get all Academic Organizations",
     *     operationId="indexAcademicOrganizationByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */

    public function showAcademicOrganizationByStatus(int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/academic_organization.show'), $this->academicRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Create an Academic Organization
     * @OA\Post (
     *     path="/api/v1/academic_organization/add",
     *     tags={"Academic Organization"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "FIU Board of Trustees",
     *                      "description": "FIU Board of Trustees",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function addAcademicOrganization(AcademicOrganizationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/academic_organization.add'), $this->academicRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update an Academic Organization
     * @OA\Put (
     *     path="/api/v1/academic_organization/update/{id}",
     *     tags={"Academic Organization"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="description",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      ),
     *                 ),
     *                 example={
     *                      "name": "FIU Board of Trustees",
     *                      "description": "FIU Board of Trustees",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *     security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updateAcademicOrganization(string $id, AcademicOrganizationRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/academic_organization.update'), $this->academicRepository->update($id,$request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}

