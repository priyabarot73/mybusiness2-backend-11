<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\hr\PersonRequest;
use App\Repositories\v1\hr\PersonRepository;

class PersonController
{
    protected PersonRepository $personRepository;
    use ResponseTrait;

    public function __construct(PersonRepository $personRepository)
    {
        $this->personRepository = $personRepository;
    }
    /**
     * @OA\Get(
     *     path="/api/v1/person/index",
     *     tags={"Person"},
     *     summary="Get all Persons",
     *     operationId="indexPerson",
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexPerson(Request $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person.index'), $this->personRepository->viewAll($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/person/status/{status}",
     *     tags={"Person"},
     *     summary="Get all Persons by status",
     *     operationId="showPersonsByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showPersonsByStatus(Request $request,int $status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person.status'), $this->personRepository->viewAllByStatus($request,$status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * @OA\Get(
     *     path="/api/v1/person/{id}",
     *     tags={"Person"},
     *     summary="Get Person by id",
     *     operationId="showPerson",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showPerson(string $id): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person.id'), $this->personRepository->viewById($id), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Person
     * @OA\Post (
     *     path="/api/v1/person/add",
     *     tags={"Person"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="avatar",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="panther_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="prefix",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="first_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="middle_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="second_last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="generational_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="suffix_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="nickname",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="birth_country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="birth_city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="gender",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="marital_status_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="as_of",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="disability",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="citizenship_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="citizenship_date",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="visa_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="visa_date",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="driver's_license",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="military_status",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="ethnic_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_postal",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_ext",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_usa",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_ext",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_usa",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="business_email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_email_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_email_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "avatar": null,
     *                      "panther_id": "1234567",
     *                      "prefix": "Mr.",
     *                      "first_name": "John",
     *                      "middle_name": "A",
     *                      "last_name": "Doe",
     *                      "second_last_name": "Smith",
     *                      "suffix_id": "b899121c-777a-4794-bb32-f02b90c64d8a",
     *                      "nickname": "johnny",
     *                      "birth_country": "USA",
     *                      "birth_city": "New York",
     *                      "gender": "male",
     *                      "martial_status_id": "fe464c0a-15ca-447e-bc4b-d6bad6ee7275",
     *                      "as_of": "2023-06-01T12:00:00Z",
     *                      "citizenship_type_id": "126d6a3a-6a16-49a2-9f59-c665d6432bf5",
     *                      "citizenship_date": "2020-01-15T00:00:00Z",
     *                      "visa_type_id": "5efd467a-2a28-4553-9a50-6f843e20095e",
     *                      "driver_license": "D1234567",
     *                      "country": "USA",
     *                      "city": "Miami",
     *                      "military_status": "None",
     *                      "ethnic_id": "516ef5f0-ec7c-41f7-b547-6b5752dd0745",
     *                      "address": "123 Main Street",
     *                      "address_country": "USA",
     *                      "address_city": "Orlando",
     *                      "address_postal": "32801",
     *                      "business_phone_number": "+1-800-555-1234",
     *                      "business_phone_number_ext": "123",
     *                      "business_phone_number_usa": true,
     *                      "business_phone_number_public": true,
     *                      "personal_phone_number": "+1-800-555-1234",
     *                      "personal_phone_number_ext": "123",
     *                      "personal_phone_number_usa": true,
     *                      "personal_phone_number_public": true,
     *                      "business_email": "john.doe@business.com",
     *                      "business_email_public": true,
     *                      "personal_email": "john.doe@personal.com",
     *                      "personal_email_public": true,
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function addPerson(PersonRequest $request):JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person.add'), $this->personRepository->create($request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST,  $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Update a Person
     * @OA\Put (
     *     path="/api/v1/person/update/{id}",
     *     tags={"Person"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="D9B7E73F-9E5B-4884-AF72-1FE5934A6E3A",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      @OA\Property(
     *                          property="avatar",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="panther_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="prefix",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="first_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="middle_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="second_last_name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="generational_title_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="suffix_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="nickname",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="birth_country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="birth_city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="gender",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="marital_status_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="as_of",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="disability",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="citizenship_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="citizenship_date",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="visa_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="visa_date",
     *                          type="string",
     *                          format="date"
     *                      ),
     *                      @OA\Property(
     *                          property="driver's_license",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="military_status",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="ethnic_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_country",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_city",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="address_postal",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_ext",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_usa",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="business_phone_number_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_ext",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_usa",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_phone_number_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="business_email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="business_email_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_email",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="personal_email_public",
     *                          type="boolean"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "avatar": null,
     *                      "panther_id": "1234569",
     *                      "prefix": "Mr.",
     *                      "first_name": "John",
     *                      "middle_name": "A",
     *                      "last_name": "Doe",
     *                      "second_last_name": "Smith",
     *                      "suffix_id": "b899121c-777a-4794-bb32-f02b90c64d8a",
     *                      "nickname": "johnny",
     *                      "birth_country": "USA",
     *                      "birth_city": "New York",
     *                      "gender": "male",
     *                      "martial_status_id": "fe464c0a-15ca-447e-bc4b-d6bad6ee7275",
     *                      "as_of": "2023-06-01T12:00:00Z",
     *                      "citizenship_type_id": "126d6a3a-6a16-49a2-9f59-c665d6432bf5",
     *                      "citizenship_date": "2020-01-15T00:00:00Z",
     *                      "visa_type_id": "5efd467a-2a28-4553-9a50-6f843e20095e",
     *                      "driver_license": "D1234567",
     *                      "country": "USA",
     *                      "city": "Miami",
     *                      "military_status": "None",
     *                      "ethnic_id": "516ef5f0-ec7c-41f7-b547-6b5752dd0745",
     *                      "address": "123 Main Street",
     *                      "address_country": "USA",
     *                      "address_city": "Orlando",
     *                      "address_postal": "32801",
     *                      "business_phone_number": "+1-800-555-1234",
     *                      "business_phone_number_ext": "123",
     *                      "business_phone_number_usa": true,
     *                      "business_phone_number_public": true,
     *                      "personal_phone_number": "+1-800-555-1234",
     *                      "personal_phone_number_ext": "123",
     *                      "personal_phone_number_usa": true,
     *                      "personal_phone_number_public": true,
     *                      "business_email": "john.doe3@business.com",
     *                      "business_email_public": true,
     *                      "personal_email": "john.doe3@personal.com",
     *                      "personal_email_public": true,
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function updatePerson(string $id, PersonRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/person.update'), $this->personRepository->update($id,$request), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
