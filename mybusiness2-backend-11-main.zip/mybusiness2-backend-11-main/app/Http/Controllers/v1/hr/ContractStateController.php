<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\hr\ContractStateRequest;
use App\Repositories\v1\hr\ContractStateRepository;

class ContractStateController
{
    protected ContractStateRepository $contractStateRepository;
    use ResponseTrait;
    public function __construct(ContractStateRepository $contractStateRepository)
    {
        $this->contractStateRepository = $contractStateRepository;
    }

    /**
     * @OA\Get(
     *     path="/api/v1/contract_state/index",
     *     tags={"Contract State"},
     *     summary="Get all Contract States",
     *     operationId="indexContractState",
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function indexContractState(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state.index'), $this->contractStateRepository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * @OA\Get(
     *     path="/api/v1/contract_state/status/{status}",
     *     tags={"Contract State"},
     *     summary="Get all Contract States by Status",
     *     operationId="showContractStateByStatus",
     *     @OA\Parameter(
     *         name="status",
     *         in="path",
     *         description="Boolean ID",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="1",
     *             type="integer",
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="successful operation",
     *     ),
     *     security={{"bearer":{}}},
     *     @OA\Response(
     *         response=400,
     *         description="Invalid status value"
     *     )
     * )
     */
    public function showContractStateByStatus($status): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state.index'), $this->contractStateRepository->viewAllByStatus($status), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
    /**
     * Create a Contract State
     * @OA\Post (
     *     path="/api/v1/contract_state/add",
     *     tags={"Contract State"},
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Stay in Pending Revision",
     *                      "employee_type_id": "c69e45a8-1367-498f-80d5-481f5e3067d6",
     *                      "action": "cancel",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */
    public function createContractState(ContractStateRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state.add'), $this->contractStateRepository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    /**
     * Update a Contract State
     * @OA\Put (
     *     path="/api/v1/contract_state/update/{id}",
     *     tags={"Contract State"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         description="Uuid",
     *         required=true,
     *         explode=true,
     *         @OA\Schema(
     *             default="4e90caa1-0af7-4438-b2b1-5992a1c7afb8",
     *             type="string",
     *         )
     *     ),
     *     @OA\RequestBody(
     *         @OA\MediaType(
     *             mediaType="application/json",
     *             @OA\Schema(
     *                 @OA\Property(
     *                      type="object",
     *                      @OA\Property(
     *                          property="name",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="employee_type_id",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="action",
     *                          type="string"
     *                      ),
     *                      @OA\Property(
     *                          property="active",
     *                          type="boolean"
     *                      )
     *                 ),
     *                 example={
     *                      "name": "Stay in Pending Revision",
     *                      "employee_type_id": "c69e45a8-1367-498f-80d5-481f5e3067d6",
     *                      "action": "cancel",
     *                      "active": "1"
     *                }
     *             )
     *         )
     *      ),
     *      security={{"bearer":{}}},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              @OA\Property(property="meta", type="object"),
     *              @OA\Property(property="data", type="object")
     *          )
     *      ),
     *      @OA\Response(
     *          response=422,
     *          description="Validation error",
     *              @OA\Property(property="data", type="object", example={}),
     *          )
     *      )
     */

    public function updateContractState($id, ContractStateRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_state.update'), $this->contractStateRepository->update($id, $request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
