<?php

namespace App\Http\Controllers\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Traits\ResponseTrait;
use App\Http\Requests\v1\hr\ContractRoleStatusRequest;
use App\Repositories\v1\hr\ContractRoleStatusRepository;

class ContractRoleStatusController
{
    protected ContractRoleStatusRepository $repository;
    use ResponseTrait;

    public function __construct(ContractRoleStatusRepository $repository)
    {
        $this->repository = $repository;
    }

    public function indexContract(): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_role_status.index'), $this->repository->viewAll(), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }

    public function assignContract(ContractRoleStatusRequest $request): JsonResponse
    {
        try {
            return $this->response(Response::HTTP_OK, trans('hr/contract_role_status.add'), $this->repository->create($request->all()), null);
        } catch (Exception $exception) {
            return $this->response(Response::HTTP_BAD_REQUEST, $exception->getMessage(), [], $exception->getMessage());
        }
    }
}
