<?php

namespace App\Http\Middleware;

//GLOBAL IMPORT
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

//LOCAL IMPORT
use App\Traits\ResponseTrait;

class CheckPermission
{
    use ResponseTrait;

    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure(Request): (Response) $next
     * @param $permission
     * @return Response
     */
    public function handle(Request $request, Closure $next, $permission): Response
    {
        // Verificar si el usuario está autenticado y si ha verificado su correo electrónico
        if (Auth::check() && Auth::user()->email_verified_at !== null) {
            // Verificar si el usuario tiene los permisos necesarios
            if (!Auth::user()->can($permission)) {
                return $this->response(response::HTTP_FORBIDDEN, "Unauthorized access.", [], null);
            } else {
                return $next($request);
            }
        }

        // Si el usuario no está autenticado o no ha verificado su correo electrónico, redirigirlo o retornar un error según sea necesario.
        // Por ejemplo:
        // return redirect()->route('verification.notice'); // Redirigir al usuario a la página de verificación de correo electrónico
        // O puedes devolver un error
        return $this->response(response::HTTP_FORBIDDEN, "Email not verified or user not authenticated.", [], null);
    }
}
