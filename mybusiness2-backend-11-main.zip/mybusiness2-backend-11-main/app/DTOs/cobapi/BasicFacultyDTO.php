<?php

namespace App\DTOs\cobapi;

class BasicFacultyDTO
{
    private static function clean(string $val): string
    {
        // Mirrors Go Validate(): remove <BR>/<br> at edges + trim
        $val = trim($val);
        $val = preg_replace('/^(<br>|<BR>)+/i', '', $val);
        $val = preg_replace('/(<br>|<BR>)+$/i', '', $val);
        return trim($val);
    }

    /**
     * @param object|array $row
     * @param array<string, array<int, array{interest:string}>> $interestsByEmployeeId
     */
    public static function fromRow(object|array $row, array $interestsByEmployeeId = []): array
    {
        $r = (array) $row;

        $employeeId = (string)($r['employeeID'] ?? $r['EMPLOYEE_ID'] ?? '');

        $out = [
            'employeeID'      => self::clean($employeeId),
            'last_name'       => self::clean((string)($r['last_name'] ?? $r['LAST_NAME'] ?? '')),
            'first_name'      => self::clean((string)($r['first_name'] ?? $r['FIRST_NAME'] ?? '')),
            'department_desc' => self::clean((string)($r['department_desc'] ?? $r['DEPARTMENT_DESC'] ?? '')),
            'email'           => self::clean((string)($r['email'] ?? $r['EMAIL'] ?? '')),
            'phone'           => self::clean((string)($r['phone'] ?? $r['PHONE'] ?? '')),
            'profile_picture' => self::clean((string)($r['profile_picture'] ?? $r['PROFILE_PICTURE'] ?? '')),
            'location'        => self::clean((string)($r['location'] ?? $r['LOCATION'] ?? '')),
            'title'           => self::clean((string)($r['title'] ?? $r['TITLE'] ?? '')),
            'facility'        => self::clean((string)($r['facility'] ?? $r['FACILITY'] ?? '')),
            'profile_url'     => self::clean((string)($r['profile_url'] ?? $r['PROFILE_URL'] ?? '')),
            'faculty_class'   => self::clean((string)($r['faculty_class'] ?? $r['FACULTY_CLASS'] ?? '')),
        ];

        // Legacy: only include interests when non-empty (omitempty behavior)
        if (!empty($interestsByEmployeeId[$employeeId])) {
            $out['interests'] = $interestsByEmployeeId[$employeeId];
        }

        return $out;
    }
}
