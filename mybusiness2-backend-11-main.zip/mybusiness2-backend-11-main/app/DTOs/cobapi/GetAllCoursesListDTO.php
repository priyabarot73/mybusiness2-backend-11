<?php

namespace App\DTOs\cobapi;

class GetAllCoursesListDTO
{
    public static function fromRow(object $row): array
    {
        return [
            'courseID'          => (string) ($row->courseID ?? ''),
            'courseName'        => (string) ($row->courseName ?? ''),
            'courseDescription' => (string) ($row->courseDescription ?? ''),
            'discontinueTerm'   => (string) ($row->discontinueTerm ?? '9999'),
        ];
    }

    /**
     * @param iterable<object> $rows
     */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
