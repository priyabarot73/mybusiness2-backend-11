<?php

namespace App\DTOs\cobapi;

class ExpertiseDTO
{
    public static function fromRow(array $row): array
    {
        $type = trim((string)($row['expertise_type'] ?? ''));
        $letter = trim((string)($row['letter'] ?? ''));

        return [
            'expertise_type' => $type,
            'letter' => $letter !== '' ? $letter : strtoupper(substr($type, 0, 1)),
        ];
    }
}
