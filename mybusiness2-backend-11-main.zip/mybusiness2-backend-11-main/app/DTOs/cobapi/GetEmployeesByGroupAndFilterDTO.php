<?php

namespace App\DTOs\cobapi;

class GetEmployeesByGroupAndFilterDTO
{
    public static function fromRow(object $row): array
    {
        return [
            'employeeID'       => (string) ($row->employeeID ?? ''),
            'first_name'       => (string) ($row->first_name ?? ''),
            'last_name'        => (string) ($row->last_name ?? ''),
            'photo'            => (string) ($row->photo ?? ''),
            'title'            => (string) ($row->title ?? ''),
            'suffix'           => (string) ($row->suffix ?? ''),
            'location'         => (string) ($row->location ?? ''),
            'email'            => (string) ($row->email ?? ''),
            'phone'            => (string) ($row->phone ?? ''),
            'departmentPhone'  => (string) ($row->departmentPhone ?? ''),
            'orderBy'          => (string) ($row->orderBy ?? ''),
            'campus'           => (string) ($row->campus ?? ''),
            'cvLink'           => (string) ($row->cvLink ?? ''),
            'linkedin'         => (string) ($row->linkedin ?? ''),
            'personalWebUrl'   => (string) ($row->personalWebUrl ?? ''),
            'faculty'          => (string) ($row->faculty ?? ''),
            'faculty_class'    => (string) ($row->faculty_class ?? ''),
        ];
    }

    /** @param iterable<object> $rows */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
