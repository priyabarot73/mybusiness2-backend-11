<?php

namespace App\DTOs\cobapi;

class GetAllDepartmentsDTO
{
    public static function fromRow(object $row): array
    {
        return [
            'department_desc' => (string) ($row->department_desc ?? ''),
        ];
    }

    /**
     * @param iterable<object> $rows
     */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
