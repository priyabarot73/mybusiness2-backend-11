<?php

namespace App\DTOs\cobapi;

class DirectoryFacultyDTO
{
    private static function clean(string $val): string
    {
        $val = trim($val);
        $val = preg_replace('/^(<br>|<BR>)+/i', '', $val);
        $val = preg_replace('/(<br>|<BR>)+$/i', '', $val);
        return trim($val);
    }

    /**
     * @param object|array $row Directory row
     * @param array<string, array<int, array{interest:string}>> $interestsByEmployeeId
     */
    public static function fromRow(object|array $row, array $interestsByEmployeeId): array
    {
        $r = (array) $row;

        $employeeId = (string)($r['EMPLOYEE_ID'] ?? $r['employeeID'] ?? '');

        return [
            'employeeID'      => self::clean($employeeId),
            'last_name'       => self::clean((string)($r['LAST_NAME'] ?? $r['last_name'] ?? '')),
            'first_name'      => self::clean((string)($r['FIRST_NAME'] ?? $r['first_name'] ?? '')),
            'department_desc' => self::clean((string)($r['DEPARTMENT_DESC'] ?? $r['department_desc'] ?? '')),
            'email'           => self::clean((string)($r['EMAIL'] ?? $r['email'] ?? '')),
            'phone'           => self::clean((string)($r['PHONE'] ?? $r['phone'] ?? '')),
            'profile_picture' => self::clean((string)($r['PROFILE_PICTURE'] ?? $r['profile_picture'] ?? '')),
            'location'        => self::clean((string)($r['LOCATION'] ?? $r['location'] ?? '')),
            'title'           => self::clean((string)($r['TITLE'] ?? $r['title'] ?? '')),
            'facility'        => self::clean((string)($r['FACILITY'] ?? $r['facility'] ?? '')),
            'profile_url'     => self::clean((string)($r['PROFILE_URL'] ?? $r['profile_url'] ?? '')),
            'faculty_class'   => self::clean((string)($r['FACULTY_CLASS'] ?? $r['faculty_class'] ?? '')),

            // include only when non-empty
            ...(empty($interestsByEmployeeId[$employeeId]) ? [] : ['interests' => $interestsByEmployeeId[$employeeId]]),
        ];
    }
}
