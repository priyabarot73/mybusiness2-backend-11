<?php

namespace App\DTOs\cobapi;

class CourseInfoDTO
{
    private static function clean(string $val): string
    {
        $val = trim($val);
        $val = preg_replace('/^(<br>|<BR>)+/i', '', $val);
        $val = preg_replace('/(<br>|<BR>)+$/i', '', $val);
        return trim($val);
    }

    public static function fromRow(object|array|null $row): array
    {
        if ($row === null) {
            // Legacy Go behavior: empty object if no rows returned
            return [
                'courseID' => '',
                'courseName' => '',
                'courseDescription' => '',
                'discontinueTerm' => '',
            ];
        }

        $r = (array) $row;

        return [
            'courseID'          => self::clean((string)($r['courseID'] ?? $r['CourseID'] ?? '')),
            'courseName'        => self::clean((string)($r['courseName'] ?? $r['CourseName'] ?? '')),
            'courseDescription' => self::clean((string)($r['courseDescription'] ?? $r['CourseDescription'] ?? '')),
            'discontinueTerm'   => self::clean((string)($r['discontinueTerm'] ?? $r['DiscontinueTerm'] ?? '')),
        ];
    }
}
