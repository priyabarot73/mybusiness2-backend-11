<?php

namespace App\DTOs\cobapi;

class FacultyMemberDTO
{
    private static function clean(string $val): string
    {
        $val = trim($val);
        $val = preg_replace('/^(<br>|<BR>)+/i', '', $val) ?? $val;
        $val = preg_replace('/(<br>|<BR>)+$/i', '', $val) ?? $val;
        return trim($val);
    }

    /**
     * @param array<string,mixed> $data
     */
    public static function fromArray(array $data): array
    {
        $out = [];

        $setStr = function (string $key) use (&$out, $data) {
            $v = self::clean((string)($data[$key] ?? ''));
            if ($v !== '') $out[$key] = $v;
        };

        $setArr = function (string $key) use (&$out, $data) {
            $v = $data[$key] ?? null;
            if (is_array($v) && count($v) > 0) $out[$key] = $v;
        };

        // strings
        $setStr('employeeid');
        $setStr('name');
        $setStr('imageUrl');
        $setStr('imageHighResUrl');
        $setStr('vitaeUrl');
        $setStr('email');
        $setStr('phoneNumber');
        $setStr('institution');
        $setStr('location');
        $setStr('professionalActivities');

        // arrays (omitempty)
        $setArr('Books');
        $setArr('educations');
        $setArr('interests');
        $setArr('publications');
        $setArr('subjects');
        $setArr('titles');

        return $out;
    }
}
