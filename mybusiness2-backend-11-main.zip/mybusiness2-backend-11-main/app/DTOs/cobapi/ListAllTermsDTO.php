<?php

namespace App\DTOs\cobapi;

class ListAllTermsDTO
{
    public static function fromRow(object $row): array
    {
        return [
            // keep legacy casing
            'Term'         => (string) ($row->Term ?? ''),
            'Semester'     => (string) ($row->Semester ?? ''),
            'Year'         => (string) ($row->Year ?? ''),
            'AcademicYear' => (string) ($row->AcademicYear ?? ''),

            // legacy keys are lowercase in model tags
            'starting'  => (string) ($row->starting ?? ''),
            'ending'    => (string) ($row->ending ?? ''),
            'startingA' => (string) ($row->startingA ?? ''),
            'endingA'   => (string) ($row->endingA ?? ''),
            'startingB' => (string) ($row->startingB ?? ''),
            'endingB'   => (string) ($row->endingB ?? ''),
        ];
    }

    /** @param iterable<object> $rows */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
