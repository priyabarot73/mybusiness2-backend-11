<?php

namespace App\DTOs\cobapi;

class GetGroupsDTO
{
    public static function fromRow(object $row): array
    {
        return [
            'filterType'        => (string) ($row->filterType ?? ''),
            'filterID'          => (string) ($row->filterID ?? ''),
            'filterName'        => (string) ($row->filterName ?? ''),
            'filterDescription' => (string) ($row->filterDescription ?? ''),
        ];
    }

    /**
     * @param iterable<object> $rows
     */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
