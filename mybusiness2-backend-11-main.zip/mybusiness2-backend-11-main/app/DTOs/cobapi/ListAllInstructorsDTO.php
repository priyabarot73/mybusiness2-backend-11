<?php

namespace App\DTOs\cobapi;

class ListAllInstructorsDTO
{
    public static function fromRow(object $row): array
    {
        return [
            'Instructor'   => (string) ($row->Instructor ?? ''),
            'FirstName'    => (string) ($row->FirstName ?? ''),
            'LastName'     => (string) ($row->LastName ?? ''),
            'InstructorID' => (string) ($row->InstructorID ?? ''),
        ];
    }

    /** @param iterable<object> $rows */
    public static function fromRows(iterable $rows): array
    {
        $out = [];
        foreach ($rows as $row) $out[] = self::fromRow($row);
        return $out;
    }
}
