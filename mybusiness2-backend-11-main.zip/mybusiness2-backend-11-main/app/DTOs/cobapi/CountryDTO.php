<?php

namespace App\DTOs\cobapi;

class CountryDTO
{
    private static function clean(string $val): string
    {
        return trim($val);
    }

    public static function fromRow(object|array $row): array
    {
        $r = (array) $row;

        return [
            'country_code' => self::clean((string)($r['country_code'] ?? $r['COUNTRY_SHORT_CODE'] ?? '')),
            'country_desc' => self::clean((string)($r['country_desc'] ?? $r['COUNTRY_DESC'] ?? '')),
        ];
    }
}
