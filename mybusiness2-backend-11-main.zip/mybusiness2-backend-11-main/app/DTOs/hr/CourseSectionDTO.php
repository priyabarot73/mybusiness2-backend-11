<?php

namespace App\DTOs\hr;

class CourseSectionDTO
{
    public function __construct(
        public string $course,
        public string $section,
        public string $courseName,
        public float $creditsMin,
        public float $creditsMax,
        public int $enrollment,
        public string $career,
        public string $mode,
        public string $program,
        public int $cohort,
        public float $overload,
        public ?string $startDate = null,
        public ?string $endDate = null,
    ) {}
}
