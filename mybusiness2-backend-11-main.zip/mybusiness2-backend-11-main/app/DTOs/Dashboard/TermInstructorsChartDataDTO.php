<?php

namespace App\DTOs\Dashboard;

class TermInstructorsChartDataDTO
{
    public function __construct(
        public array $series,
        public array $categories
    ) {}

    public static function fromTotals(array $totals, array $categories): self
    {
        return new self(
            series: [
                [
                    'name' => trans('dashboard/dashboard.instructor_term'),
                    'data' => $totals
                ]
            ],
            categories: $categories
        );
    }

    public function toArray(): array
    {
        return [
            'series' => $this->series,
            'categories' => $this->categories,
        ];
    }
}
