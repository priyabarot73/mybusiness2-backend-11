<?php

namespace App\DTOs\Dashboard;

class CarouselDTO
{
    public function __construct(
        public string $name,
        public string $semester,
        public string $startDate,
        public string $endDate,
        public int $daysPassed,
        public int $totalDays,
        public bool $current,
        public int $sections,
        public int $instructors,
        public array $states,
        public int $remainingDays,
        public int $progressValue,
        public array $quantity,
        public bool $sess,
    ) {}

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
