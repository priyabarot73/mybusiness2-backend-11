<?php

namespace App\DTOs\Dashboard;

class DashboardDataCardDTO
{
    public function __construct(
        public int $userCount,
        public int $personCount,
        public array $sectionCount,
        public int $programCount,
        public int $departmentCount,
        public int $instructorCount,
        public int $courseCount,
        public int $termCount,
    ) {}
}
