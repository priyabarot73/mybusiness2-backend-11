<?php

namespace App\DTOs\Dashboard;

class ChartDataDTO
{
    public function __construct(
        public array $series,
        public array $categories
    ) {}

    public static function fromValues(array $name, array $data, array $categories): self
    {
        return new self(
            series: [['name' => $name, 'data' => $data]],
            categories: $categories
        );
    }
}
