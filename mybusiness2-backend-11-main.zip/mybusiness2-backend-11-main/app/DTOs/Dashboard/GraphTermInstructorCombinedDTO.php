<?php

namespace App\DTOs\Dashboard;

class GraphTermInstructorCombinedDTO
{
    /**
     * @param CarouselDTO[] $terms
     */
    public function __construct(
        public array $terms,
    ) {}

    public function toArray(): array
    {
        return [
            'terms' => array_map(fn($term) => (array) $term, $this->terms),
        ];
    }
}
