<?php

namespace App\Repositories\v1\assessment;

// GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

// LOCAL IMPORT
use App\Models\assessment\TenureType;
use App\Exceptions\ResourceNotFoundException;

class TenureTypeRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = strtolower($request->query('sortDirection', 'desc'));

            // filters (can be array OR json string)
            $filterModel = $request->query('filters'); // array|string|null
            if (is_string($filterModel) && $filterModel !== '') {
                $decoded = json_decode($filterModel, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $filterModel = $decoded;
                }
            }

            // sanitize sort
            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'desc';
            }

            $query = TenureType::query();

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(code) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(name) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(description) LIKE ?", ["%{$search}%"]);
                });
            }

            // apply filters (DataGrid)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {

                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and|or

                $allowedColumns = ['code', 'name', 'description', 'created_at'];

                $query->where(function ($outer) use ($filterModel, $logic, $allowedColumns) {

                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        // If there is no field, or it is not allowed, ignore it.
                        if (!$field || !in_array($field, $allowedColumns)) {
                            continue;
                        }

                        // operators that do not need value
                        $noValueOps = ['isEmpty', 'isNotEmpty', 'isNull', 'isNotNull'];
                        if (!in_array($operator, $noValueOps) && ($value === null || $value === '')) {
                            continue;
                        }

                        $apply = function ($q) use ($field, $operator, $value) {

                            // created_at: normalmente lo filtras por equals / range en frontend.
                            // aquí lo dejamos soportando "equals" textual, y "contains" por CAST
                            if ($field === 'created_at') {
                                if ($operator === 'equals') {
                                    return $q->whereDate('created_at', $value);
                                }

                                if ($operator === 'contains') {
                                    return $q->whereRaw("CAST(created_at AS VARCHAR(30)) LIKE ?", ["%{$value}%"]);
                                }

                                if ($operator === 'isEmpty' || $operator === 'isNull') {
                                    return $q->whereNull('created_at');
                                }

                                if ($operator === 'isNotEmpty' || $operator === 'isNotNull') {
                                    return $q->whereNotNull('created_at');
                                }

                                return $q; // fallback
                            }

                            // strings: code/name/description
                            $val = strtolower(trim((string) $value));

                            return match ($operator) {
                                'equals', '=', 'is' =>
                                $q->whereRaw("LOWER({$field}) = ?", [$val]),

                                'startsWith' =>
                                $q->whereRaw("LOWER({$field}) LIKE ?", [$val . '%']),

                                'endsWith' =>
                                $q->whereRaw("LOWER({$field}) LIKE ?", ['%' . $val]),

                                'contains', 'includes' =>
                                $q->whereRaw("LOWER({$field}) LIKE ?", ['%' . $val . '%']),

                                'isEmpty', 'isNull' =>
                                $q->where(function ($z) use ($field) {
                                    $z->whereNull($field)->orWhere($field, '=', '');
                                }),

                                'isNotEmpty', 'isNotNull' =>
                                $q->where(function ($z) use ($field) {
                                    $z->whereNotNull($field)->where($field, '!=', '');
                                }),

                                default =>
                                $q->whereRaw("LOWER({$field}) LIKE ?", ['%' . $val . '%']),
                            };
                        };

                        if ($logic === 'or') {
                            $outer->orWhere(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        } else {
                            $outer->where(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        }
                    }
                });
            }

            //  apply sorting
            if (in_array($sortColumn, ['created_at', 'code', 'name', 'description'])) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('created_at', 'desc');
            }

            // paginate
            $tenureTypes = $query->paginate($perPage, ['*'], 'page', $page);

            if ($tenureTypes->isEmpty()) {
                throw new ResourceNotFoundException(trans('assessment/tenure_type.exceptionNotFound'));
            }

            return $tenureTypes;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus(Request $request, $status): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = $request->query('sortDirection', 'desc');

            $query = TenureType::where('active', $status);

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(conde) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(description) LIKE ?", ["%$search%"]);
                });
            }

            // apply sorting
            if (in_array($sortColumn, ['created_at', 'code', 'name', 'description'])) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // paginate
            $persons = $query->paginate($perPage, ['*'], 'page', $page);

            if ($persons->isEmpty()) {
                throw new ResourceNotFoundException(trans('assessment/tenure_type.exceptionNotFound'));
            }

            return $persons;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): array|Builder|Collection|Model
    {
        try {
            DB::beginTransaction();
            $tenureType = new TenureType();
            $tenureTypeNew = $this->dataFormat($request,$tenureType);
            $tenureTypeNew->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $tenureTypeNew->id,
                'created',
                'Tenure',
                'A new type of Tenure was created: ' . $tenureTypeNew->name,
            );

            DB::commit();
            return $tenureTypeNew;
        } catch (Exception $e){
            DB::rollBack();
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, array $request): object|null
    {
        try {
            DB::beginTransaction();
            $tenureType = TenureType::find($id);
            if(!$tenureType){
                throw new ResourceNotFoundException(trans('assessment/tenure_type.exceptionNotFoundById'));
            }
            $tenureTypeNew = $this->dataFormat($request,$tenureType);
            $tenureTypeNew->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $tenureTypeNew->id,
                'updated',
                'Tenure',
                'Tenure was updated: ' . $tenureTypeNew->name,
            );

            DB::commit();
            return $tenureTypeNew;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, TenureType $tenureType):object|null
    {
        try {
            $tenureType->code = $request['code'];
            $tenureType->name = $request['name'];
            $tenureType->description = $request['description'];
            $tenureType->active = $request['active'];
            return $tenureType;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }

}
