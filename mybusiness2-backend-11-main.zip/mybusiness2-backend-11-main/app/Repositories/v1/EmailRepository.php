<?php

namespace App\Repositories\v1;

//GLOBAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Mail\ContractCreationNotificationInstructor;
use App\Mail\ContractCreationNotificationResponsible;
use App\Models\academic\Instructor;
use App\Models\hr\ContractState;
use App\Models\hr\Person;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT

class EmailRepository
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */

     public function contractUpdateNotification($request):Array
     {

     }
    public function contractCreationNotification($request):void
    {
        try {
            //Portion of Code meant to send email to supervisor
            $supervisorEmails = [];
            foreach ($request['responsible'] as $responsible) {
                $email = Person::where('business_email', $responsible)->first();
                $newSupervisorEmailRequest = $this->dataFormatSupervisor($responsible, $request['instructor'], $request['contract_state'], $request['description']);
                Log::info($newSupervisorEmailRequest);
                Mail::to($newSupervisorEmailRequest['email'])->send(new ContractCreationNotificationResponsible($newSupervisorEmailRequest));
            }

            $instructorEmailRequest = $this->dataFormatInstructor($request);
            //pull all currently active members of a mailing
            Mail::to($instructorEmailRequest['email'])->send(new ContractCreationNotificationInstructor($instructorEmailRequest));


        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
#When Contract Is fully implemented, I'll be able to implement this code properly - Dillon
    public function dataFormatSupervisor($responsible, $instructor, $contractState, $description = ""):Array
    {

        Log::info(DB::connection()->getName());
        #$responsibleObject = Person::where('id', $responsible)->first();


        /* $person = Person::where('business_email', $request['person_email'])->first();
        if(!$person){
            throw new Exception("Email Not Found", response::HTTP_INTERNAL_SERVER_ERROR);
        }
        $person_id = $person->id; */
        Log::info($responsible);
        $supervisor = Person::where('id', $responsible)->first();
        Log::info($supervisor);
        $supervisorFirstName = Person::where('id',$responsible)->first()->first_name;
        $supervisorLastName = Person::where('id',$responsible)->first()->last_name;

        $supervisorName = $supervisorFirstName . ' ' . $supervisorLastName;
        $supervisorPrefix = Person::where('id',$responsible)->first()->prefix;
        $supervisorEmail = Person::where('id',$responsible)->first()->business_email;

        $instructorid = Instructor::where('id', $instructor)->first()->person_id;
        $instructorFirstName = Person::where('id', $instructorid)->first()->first_name;
        $instructorLastName = Person::where('id', $instructorid)->first()->last_name;
        $instructorName = $instructorFirstName . ' ' . $instructorLastName;

        $newRequest = [
            'date' => Carbon::now()->format('d-m-Y'),
            'prefix' => $supervisorPrefix,
            'contract_state' => ContractState::where('id',$contractState)->first()->name,
            'supervisor_name' => $supervisorName,
            'instructor_name' => $instructorName,
            'description' => $description,
            'email' => $supervisorEmail
        ];

        return $newRequest;
    }

    public function dataFormatInstructor($request)
    {
        $instructorid = Instructor::where('id', $request['instructor'])->first();
        $instructorPersonObject = Person::where('id', $instructorid->person_id)->first();
        $instructorName =  $instructorPersonObject->first_name . ' ' . $instructorPersonObject->last_name;
        $instructorPrefix = $instructorPersonObject->prefix;
        $instructorEmail = $instructorPersonObject->business_email;

        $newEmailRequest = [
            'date' => Carbon::now()->format('d-m-Y'),
            'prefix' => $instructorPrefix,
            'contract_state' => ContractState::where('id',$request['contract_state'])->first()->name,
            'instructor_name' => $instructorName,
            'description' => $request['description'],
            'email' =>  $instructorEmail
        ];

        return $newEmailRequest;
    }

}
