<?php

namespace App\Repositories\v1;

//GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;
use Spatie\Permission\Exceptions\RoleDoesNotExist;
use Spatie\Permission\Exceptions\PermissionDoesNotExist;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\Role;
use App\Models\User;
use App\Exceptions\ResourceNotFoundException;

class UserRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection|array
    {
        try {
            // Get all users who do not have the name 'Academic-qualified'
            $users = User::with('roles', 'permissions', 'person')
                ->where('panther_id', '!=', '9999999')
                ->get();

            if ($users->isEmpty()) {
                throw new ResourceNotFoundException(trans('user.exceptionNotFound'));
            }
            //Count active and inactive users
            $activeUsers = $users->where('active', true)->count();
            $inactiveUsers = $users->where('active', false)->count();
            $totalUsers = $users->count();


            // Get the number of unique roles associated with the obtained users
            $totalRoles = $users->pluck('roles')->flatten()->unique('id')->count();

            return [
                'users' => $users,
                'activeUsersCount' => $activeUsers,
                'inactiveUsersCount' => $inactiveUsers,
                'uniqueRolesCount' => $totalRoles,
                'totalUsersCount' => $totalUsers
            ];
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id): Model|Collection|Builder|array
    {
        try {
            $user = User::with('roles', 'permissions', 'person')->find($id);
            if (!$user) {
                throw new ResourceNotFoundException(trans('user.exceptionNotFoundById'));
            }
            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewUsersByRole($role)
    {
        try {
            $rol = Role::where('name', $role)->first();
            if (!$rol) {
                throw new ResourceNotFoundException(trans('role.exceptionNotFoundByName'));
            }
            $usersQuery = User::query();
            if ($role === 'Instructor') {
                $usersQuery->where('instructor', true);
            } elseif ($role === 'Student') {
                $usersQuery->where('student', true);
            } else {
                $usersQuery->whereHas('roles', function ($query) use ($role) {
                    $query->where('name', $role);
                });
            }
            $users = $usersQuery->get();
            if ($users->isEmpty()) {
                throw new ResourceNotFoundException(trans('user.exceptionNotFoundByRole'));
            }

            return $users;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage());
        }
    }

    /**
     * @throws Exception
     */
    public function create(Request $request): array|Builder|Collection|Model
    {
        try {
            $user = new User();
            $userNew = $this->dataFormat($request, $user,'create');
            $userNew->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $userNew->id,
                'created',
                'User',
                'A new user was created: ' . $userNew->name,
            );

            return $this->viewById($userNew->id);
        } catch (RoleDoesNotExist|PermissionDoesNotExist $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_NOT_FOUND);
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, Request $request): object|null
    {
        try {
            $user = User::find($id);
            if (!$user) {
                throw new ResourceNotFoundException(trans('user.exceptionNotFoundById'));
            }

            $userNew = $this->dataFormat($request, $user,'update');
            $userNew->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $userNew->id,
                'updated',
                'User',
                'User was updated: ' . $userNew->name,
            );

            return $this->viewById($userNew->id);
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (RoleDoesNotExist|PermissionDoesNotExist $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_NOT_FOUND);
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $user = User::find($id);
            if (!$user) {
                throw new ResourceNotFoundException(trans('user.exceptionNotFoundById'));
            }
            $user->active = 0;
            $user->update();
            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(Request $request, User $user, $action): User
    {
        try {
            $user->name = $request->input('name');
            $user->email = $request->input('email');
            $user->panther_id = $request->input('panther_id');
//            $user->avatar = $this->uploadImage($request);
            $user->active = $request->input('active');
            $user->created_at = Carbon::now();
            $user->updated_at = Carbon::now();
            $user->email_verified_at = Carbon::now();
            $user->person_id = $request->input('person_id');
            $user->syncRoles($request->input('roles'));
            $user->syncPermissions($request->input('permissions'));

            if ($action === 'create') {
                $user->password = strlen($request->input('password')) > 1 ? Hash::make($request->input('password')) : null;
            }

            return $user;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage());
        }
    }

    public function uploadImage(Request $request): ?string
    {
        if ($request->hasFile('avatar')) {
            $image = $request->file('avatar');
            $imageName = $request->input('panther_id') . '.' . $image->extension();
            $imagePath = env('IMAGE_PATH');
            $image->move($imagePath, $imageName);
            return $imageName;
        }
        return null;
    }
}
