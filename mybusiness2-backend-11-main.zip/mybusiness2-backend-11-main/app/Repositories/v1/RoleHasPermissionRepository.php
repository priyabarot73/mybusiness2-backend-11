<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Http\Requests\v1\RoleHasPermissionRequest;
use App\Models\Permission;
use App\Models\Role;

class  RoleHasPermissionRepository
{
    /**
     * @throws Exception
     */
    public function viewAllRolesPermission(): JsonResponse
    {
        try {
            $role = Role::all();
            $permission = Permission::all();
            if (!$role || !$permission) {
                throw new ResourceNotFoundException(trans('role_has_permission.exceptionNotFound'));
            }
            return response()->json([$role, $permission]);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewPermissionsByRoleId(string $id): JsonResponse
    {
        try {
            $permission = $this->viewRoleById($id)->getPermissionNames();
            if (!$permission) {
                throw new ResourceNotFoundException(trans('role_has_permission.exceptionNotFoundById'));
            }
            return response()->json($permission);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function assignPermissionToRoleByRoleId(RoleHasPermissionRequest $request, $id): string
    {
        try {
            if(!$this->viewRoleById($id)->syncPermissions($request['permissions'])){
                throw new ResourceNotFoundException(trans('role_has_permission.syncPermissionsWrong'));
            }
            return trans('role_has_permission.syncPermissionsOk');
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function deletePermissionToRoleByRoleId(RoleHasPermissionRequest $request, $id): string
    {
        try {
            if(!$this->viewRoleById($id)->revokePermissionTo($request['permissions'])){
                throw new ResourceNotFoundException(trans('role_has_permission.revokePermissionsWrong'));
            }
            return trans('role_has_permission.revokePermissionsOk');
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewRoleById(string $id):?object
    {
        try {
            $role = Role::find($id);
            if (!$role) {
                throw new ResourceNotFoundException(trans('role_has_permission.exceptionNotFoundById'));
            }
        return $role;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
