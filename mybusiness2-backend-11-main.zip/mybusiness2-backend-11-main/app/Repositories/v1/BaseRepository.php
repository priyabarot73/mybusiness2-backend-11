<?php

namespace App\Repositories\v1;

use Illuminate\Support\Facades\DB;

abstract class BaseRepository
{
    // Method to start transaction
    protected function startTransaction(): void
    {
        DB::beginTransaction();
    }

    // Method to commit
    protected function commitTransaction(): void
    {
        DB::commit();
    }

    // Method to rollback
    protected function rollbackTransaction(): void
    {
        DB::rollBack();
    }
}
