<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use App\Models\academic\Instructor;
use Exception;
use Illuminate\Http\Request;
use App\Models\academic\Section;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Course;
use App\Exceptions\ResourceNotFoundException;

class CourseRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'code');
            $sortDirection = $request->query('sortDirection', 'desc');

            // columns to sorting
            $sortableColumns = ['code', 'name', 'description', 'created_at'];

            $query = Course::with(['department', 'program']);

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw('LOWER(code) LIKE ?', ["%$search%"])
                        ->orWhereRaw('LOWER(name) LIKE ?', ["%$search%"])
                        ->orWhereRaw('LOWER(description) LIKE ?', ["%$search%"]);
                });
            }

            // apply ordering
            if (in_array($sortColumn, $sortableColumns)) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                // apply default ordering
                $query->orderBy('code', 'desc');
            }

            // paginate
            $courses = $query->paginate($perPage, ['*'], 'page', $page);

            if ($courses->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFound'));
            }

            return $courses;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByStatus(Request $request, $status): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'code');
            $sortDirection = $request->query('sortDirection', 'desc');

            // columns to sorting
            $sortableColumns = ['code', 'name', 'description', 'created_at'];

            $query = Course::with(['department', 'program'])
                ->where('ac.courses.active', '=', $status);

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw('LOWER(code) LIKE ?', ["%$search%"])
                        ->orWhereRaw('LOWER(name) LIKE ?', ["%$search%"])
                        ->orWhereRaw('LOWER(description) LIKE ?', ["%$search%"]);
                });
            }

            // apply ordering
            if (in_array($sortColumn, $sortableColumns)) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('code', 'desc'); // fallback per default
            }

            // paginate
            $courses = $query->paginate($perPage, ['*'], 'page', $page);

            if ($courses->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFoundByStatus'));
            }

            return $courses;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function findByCodeNameOrReference($searchTerm)
    {
        try {
            $courses = Course::where('code', $searchTerm)
                ->orWhere('name', 'like', '%' . $searchTerm . '%')
                ->first();
            if (!$courses) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFoundByStatus'));
            }
            return $courses;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $course = Course::find($id);
            if (!$course) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFoundById'));
            }
            return $course;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

//    /**
//     * Returns all courses assigned to an instructor in a given term.
//     * For each course, it also appends a "combined sections" field with
//     * all section codes concatenated as sec_code+sec_number+sec_sess separated by commas.
//     *
//     * @param Request $request
//     * @return LengthAwarePaginator
//     * @throws ResourceNotFoundException
//     * @throws Exception
//     */
//    public function viewCoursesByInstructorAndTerm(Request $request): LengthAwarePaginator
//    {
//        try {
//            // pagination & sorting
//            $perPage       = (int) $request->query('pageSize', 20);
//            $page          = (int) $request->query('page', 1);
//            $search        = $request->query('search');
//            $sortColumn    = $request->query('sortColumn', 'code');
//            $sortDirection = $request->query('sortDirection', 'desc');
//
//            // filters (work with JSON body or querystring)
//            $instructorId = trim((string) $request->input('instructor_id', ''));
//            $termId       = trim((string) $request->input('term_id', ''));
//
//            // allowed sort columns
//            $sortableColumns = ['code', 'name', 'description', 'created_at'];
//
//            // provided iff non-empty and not literal "null"
//            $hasInstructor = ($instructorId !== '' && strcasecmp($instructorId, 'null') !== 0);
//            $hasTerm       = ($termId !== '' && strcasecmp($termId, 'null') !== 0);
//
//            // ---------------------------------------------------------------------
//            // CASE 1) instructor_id & term_id provided -> build role-aware filtering
//            // ---------------------------------------------------------------------
//            if ($hasInstructor && $hasTerm) {
//
//                // Determine role (FAC vs others)
//                /** @var Instructor $inst */
//                $inst  = Instructor::with('employeeType')->findOrFail($instructorId);
//                $code  = strtoupper((string) optional($inst->employeeType)->code);
//                $isFac = ($code === 'FAC');
//
//                // Subquery A: ALL sections assigned to this instructor (MP ∪ MPH ∪ Workload), no overload filter.
//                // We use this for STRING_AGG so the course shows ALL the instructor's sections in the term.
//                $sectionsAssignedAll = function ($q) use ($instructorId) {
//                    $mp  = DB::table('ac.meeting_patterns as mp')
//                        ->select('mp.section_id')
//                        ->where('mp.instructor_id', $instructorId);
//
//                    $mph = DB::table('ac.meeting_pattern_hybrids as mph')
//                        ->select('mph.section_id')
//                        ->where('mph.instructor_id', $instructorId);
//
//                    $wc  = DB::table('ac.workload_courses as wc')
//                        ->join('ac.workloads as w', 'w.id', '=', 'wc.workload_id')
//                        ->where('w.instructor_id', $instructorId)
//                        ->select('wc.section_id');
//
//                    $q->fromSub($mp->union($mph)->union($wc), 'u')->select('u.section_id');
//                };
//
//                // Subquery B (FAC only): course_ids that have at least ONE overloaded section in this term for this instructor.
//                // This enforces the FAC rule without limiting the displayed section list.
//                $overloadedCourseIds = null;
//                if ($isFac) {
//                    $overloadedCourseIds = DB::table('ac.sections as s')
//                        ->join('ac.workload_courses as wc', 'wc.section_id', '=', 's.id')
//                        ->join('ac.workloads as w', 'w.id', '=', 'wc.workload_id')
//                        ->where('s.term_id', $termId)
//                        ->where('w.instructor_id', $instructorId)
//                        ->whereIn('wc.overload', [1, '1', true])
//                        ->distinct()
//                        ->select('s.course_id');
//                }
//
//                // Aggregate ALL instructor sections (by term) per course (role-agnostic aggregation)
//                $sectionsAggByCourse = DB::table('ac.sections as s')
//                    ->joinSub($sectionsAssignedAll, 'si', 'si.section_id', '=', 's.id')
//                    ->where('s.term_id', $termId)
//                    ->select(
//                        's.course_id',
//                        DB::raw("
//                        STRING_AGG(
//                            CONCAT(COALESCE(s.sec_code,''), COALESCE(s.sec_number,''), COALESCE(s.sec_sess,'')),
//                            ','
//                        ) AS sections_codes
//                    ")
//                    )
//                    ->groupBy('s.course_id');
//
//                // Main query: courses that have matching sections in the term for this instructor.
//                // If FAC, additionally require that the course_id is in the overloaded set (Subquery B).
//                $query = Course::query()
//                    ->from('ac.courses as c')
//                    ->joinSub($sectionsAggByCourse, 'x', 'x.course_id', '=', 'c.id')
//                    ->when($isFac, function ($q) use ($overloadedCourseIds) {
//                        // inner join with overloaded courses (eligibility filter)
//                        $q->joinSub($overloadedCourseIds, 'o', 'o.course_id', '=', 'c.id');
//                    })
//                    ->with(['department', 'program'])
//                    ->select([
//                        'c.id', 'c.code', 'c.name', 'c.credit', 'c.hour', 'c.description',
//                        'c.department_id', 'c.program_id', 'c.active', 'c.created_at',
//                        DB::raw('x.sections_codes AS sections_codes'),
//                        DB::raw("
//                        CASE
//                            WHEN x.sections_codes IS NULL OR x.sections_codes = '' THEN c.code
//                            ELSE CONCAT(c.code, ' (', x.sections_codes, ')')
//                        END AS code_with_sections
//                    "),
//                    ]);
//
//                // search (case-insensitive)
//                if (!empty($search)) {
//                    $needle = strtolower($search);
//                    $query->where(function ($q) use ($needle) {
//                        $q->whereRaw('LOWER(c.code) LIKE ?', ["%{$needle}%"])
//                            ->orWhereRaw('LOWER(c.name) LIKE ?', ["%{$needle}%"])
//                            ->orWhereRaw('LOWER(c.description) LIKE ?', ["%{$needle}%"]);
//                    });
//                }
//
//                // ordering
//                if (in_array($sortColumn, $sortableColumns, true)) {
//                    $query->orderBy('c.' . $sortColumn, $sortDirection);
//                } else {
//                    $query->orderBy('c.code', 'desc');
//                }
//
//                // paginate
//                $courses = $query->paginate($perPage, ['*'], 'page', $page);
//
//                if ($courses->isEmpty()) {
//                    throw new ResourceNotFoundException(trans('academic/course.exceptionNotFound'));
//                }
//
//                return $courses;
//            }
//
//            // ---------------------------------------------------------------------
//            // CASE 2) Fallback -> list courses (no "active" enforcement)
//            // ---------------------------------------------------------------------
//            $query = Course::with(['department', 'program']);
//
//            // apply search
//            if (!empty($search)) {
//                $needle = strtolower($search);
//                $query->where(function ($q) use ($needle) {
//                    $q->whereRaw('LOWER(code) LIKE ?', ["%{$needle}%"])
//                        ->orWhereRaw('LOWER(name) LIKE ?', ["%{$needle}%"])
//                        ->orWhereRaw('LOWER(description) LIKE ?', ["%{$needle}%"]);
//                });
//            }
//
//            // apply ordering
//            if (in_array($sortColumn, $sortableColumns, true)) {
//                $query->orderBy($sortColumn, $sortDirection);
//            } else {
//                $query->orderBy('code', 'desc');
//            }
//
//            // paginate
//            $courses = $query->paginate($perPage, ['*'], 'page', $page);
//
//            if ($courses->isEmpty()) {
//                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFound'));
//            }
//
//            return $courses;
//
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }


    /**
     * Returns all courses assigned to an instructor in a given term.
     * - FAC: solo secciones con overload > 0
     * - No-FAC: secciones con value > 0
     * - Si hay combinadas, se concatenan todas las secciones del grupo combinado.
     *
     * SQL Server: usa STRING_AGG sobre un subquery DISTINCT para evitar duplicados.
     *
     * @param Request $request
     * @return LengthAwarePaginator
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewCoursesByInstructorAndTerm(Request $request): LengthAwarePaginator
    {
        try {
            // pagination & sorting
            $perPage       = (int) $request->query('pageSize', 20);
            $page          = (int) $request->query('page', 1);
            $search        = $request->query('search');
            $sortColumn    = $request->query('sortColumn', 'code');
            $sortDirection = $request->query('sortDirection', 'desc');

            // filters (work with JSON body or querystring)
            $instructorId = trim((string) $request->input('instructor_id', ''));
            $termId       = trim((string) $request->input('term_id', ''));

            // allowed sort columns
            $sortableColumns = ['code', 'name', 'description', 'created_at'];

            // provided iff non-empty and not literal "null"
            $hasInstructor = ($instructorId !== '' && strcasecmp($instructorId, 'null') !== 0);
            $hasTerm       = ($termId !== '' && strcasecmp($termId, 'null') !== 0);

            // ---------------------------------------------------------------------
            // CASE 1) instructor_id & term_id provided -> build role-aware filtering
            // ---------------------------------------------------------------------
            if ($hasInstructor && $hasTerm) {

                // Determinar si el instructor es FAC
                /** @var Instructor $inst */
                $inst  = Instructor::with('employeeType')->findOrFail($instructorId);

                $code  = strtoupper((string) optional($inst->employeeType)->code);
                $isFac = ($code === 'FAC');

                // 1) Filtro base según rol (FAC: overload > 0 ; No-FAC: value > 0)
                $filterColumn = $isFac ? 'wc.overload' : 'wc.value';
                $filterOp     = '>';
                $filterValue  = 0;

                // 2) Secciones del instructor en el término aplicando filtro base (workload como fuente de verdad)
                $baseSections = DB::table('ac.sections as s')
                    ->join('ac.workload_courses as wc', 'wc.section_id', '=', 's.id')
                    ->join('ac.workloads as w', 'w.id', '=', 'wc.workload_id')
                    ->where('s.term_id', $termId)
                    ->where('w.instructor_id', $instructorId)
                    ->where($filterColumn, $filterOp, $filterValue)
                    ->distinct()
                    ->select([
                        's.id as section_id',
                        's.course_id',
                    ]);

                // 3) Pares de combinadas en ambos sentidos
                $combinedPairs = DB::table('ac.combined_sections as cs')
                    ->selectRaw('cs.section_id as a, cs.section_id_combined as b')
                    ->unionAll(
                        DB::table('ac.combined_sections as cs2')
                            ->selectRaw('cs2.section_id_combined as a, cs2.section_id as b')
                    );

                // 4) Expandir: por cada sección base, incluir también sus combinadas
                $expandedSectionIds = DB::query()
                    ->fromSub($baseSections, 'bo')
                    ->leftJoinSub($combinedPairs, 'cp', 'cp.a', '=', 'bo.section_id')
                    ->selectRaw('DISTINCT COALESCE(cp.b, bo.section_id) as section_id, bo.course_id');

                // 5) (SQL Server) Subquery DISTINCT de códigos por curso para luego hacer STRING_AGG
                $distinctCodes = DB::table('ac.sections as s')
                    ->joinSub($expandedSectionIds, 'es', 'es.section_id', '=', 's.id')
                    ->distinct()
                    ->selectRaw("
                    s.course_id,
                    CONCAT(
                        COALESCE(s.sec_code,''),
                        COALESCE(s.sec_number,''),
                        COALESCE(s.sec_sess,'')
                    ) AS code_concat
                ");

                // 6) Agregación final por curso usando STRING_AGG (sin DISTINCT, ya deduplicado arriba)
                //    Puedes ordenar dentro del aggregate si quieres consistencia visual:
                //    STRING_AGG(d.code_concat, ',') WITHIN GROUP (ORDER BY d.code_concat)
                $sectionsAggByCourse = DB::query()
                    ->fromSub($distinctCodes, 'd')
                    ->selectRaw("
                    d.course_id,
                    STRING_AGG(d.code_concat, ',') WITHIN GROUP (ORDER BY d.code_concat) AS sections_codes
                ")
                    ->groupBy('d.course_id');

                // 7) Query principal de cursos
                $query = Course::query()
                    ->from('ac.courses as c')
                    ->joinSub($sectionsAggByCourse, 'x', 'x.course_id', '=', 'c.id')
                    ->with(['department', 'program'])
                    ->select([
                        'c.id', 'c.code', 'c.name', 'c.credit', 'c.hour', 'c.description',
                        'c.department_id', 'c.program_id', 'c.active', 'c.created_at',
                        DB::raw('x.sections_codes AS sections_codes'),
                        DB::raw("
                        CASE
                            WHEN x.sections_codes IS NULL OR x.sections_codes = '' THEN c.code
                            ELSE CONCAT(c.code, ' (', x.sections_codes, ')')
                        END AS code_with_sections
                    "),
                    ]);

                // search (case-insensitive)
                if (!empty($search)) {
                    $needle = strtolower($search);
                    $query->where(function ($q) use ($needle) {
                        $q->whereRaw('LOWER(c.code) LIKE ?', ["%{$needle}%"])
                            ->orWhereRaw('LOWER(c.name) LIKE ?', ["%{$needle}%"])
                            ->orWhereRaw('LOWER(c.description) LIKE ?', ["%{$needle}%"]);
                    });
                }

                // ordering
                if (in_array($sortColumn, $sortableColumns, true)) {
                    $query->orderBy('c.' . $sortColumn, $sortDirection);
                } else {
                    $query->orderBy('c.code', 'desc');
                }

                // paginate
                $courses = $query->paginate($perPage, ['*'], 'page', $page);

                if ($courses->isEmpty()) {
                    throw new ResourceNotFoundException(trans('academic/course.exceptionNotFound'));
                }

                return $courses;
            }

            // ---------------------------------------------------------------------
            // CASE 2) Fallback -> lista de cursos sin filtros de instructor/término
            // ---------------------------------------------------------------------
            $query = Course::with(['department', 'program']);

            // apply search
            if (!empty($search)) {
                $needle = strtolower($search);
                $query->where(function ($q) use ($needle) {
                    $q->whereRaw('LOWER(code) LIKE ?', ["%{$needle}%"])
                        ->orWhereRaw('LOWER(name) LIKE ?', ["%{$needle}%"])
                        ->orWhereRaw('LOWER(description) LIKE ?', ["%{$needle}%"]);
                });
            }

            // apply ordering
            if (in_array($sortColumn, $sortableColumns, true)) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('code', 'desc');
            }

            // paginate
            $courses = $query->paginate($perPage, ['*'], 'page', $page);

            if ($courses->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFound'));
            }

            return $courses;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $course = new Course();
            $newCourse = $this->dataFormat($request, $course);
            $newCourse->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCourse->id,
                'created',
                'Course',
                'A new type of Course was created: ' . $newCourse->name,
            );

            return $newCourse;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $course = $this->viewById($id);
            if (!$course) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFoundById'));
            }
            $newCourse = $this->dataFormat($request, $course);
            $newCourse->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCourse->id,
                'updated',
                'Course',
                'Course was updated: ' . $newCourse->name,
            );

            return $newCourse;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $course = $this->viewById($id);
            if (!$course) {
                throw new ResourceNotFoundException(trans('academic/course.exceptionNotFoundById'));
            }
            $course->delete();
            return $course;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Course $course): object|null
    {
        $course->code = $request['code'];
        $course->name = $request['name'];
        $course->credit = $request['credit'];
        $course->hour = $request['hour'];
        $course->references_number = $request['references_number'];
        $course->description = $request['description'];
        $course->department_id = $request['department_id'];
        $course->program_id = $request['program_id'];
        $course->active = $request['active'];
        return $course;
    }
}
