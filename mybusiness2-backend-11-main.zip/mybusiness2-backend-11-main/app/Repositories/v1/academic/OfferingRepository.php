<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Offering;
use App\Exceptions\ResourceNotFoundException;

class OfferingRepository
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $offerings = Offering::where('active','=',$status)->get();
            if ($offerings->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/offering.exceptionNotFoundByStatus'));
            }
            return $offerings;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $offerings = Offering::orderBy('name','desc')->get();
            if ($offerings->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/offering.exceptionNotFound'));
            }
            return $offerings;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $offering = new Offering();
            $newOffering = $this->dataFormat($request,$offering);
            $newOffering->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newOffering->id,
                'created',
                'Offering',
                'A new type of Offering was created: ' . $newOffering->name,
            );

            return $newOffering;
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $offering =  Offering::find($id);
            if (!$offering){
                throw new ResourceNotFoundException(trans('academic/offering.exceptionNotFoundById'));
            }
            $newOffering = $this->dataFormat($request,$offering);
            $newOffering->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newOffering->id,
                'updated',
                'Offering',
                'Offering was updated: ' . $newOffering->name,
            );
            return $newOffering;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Offering $offering):object|null
    {
        $offering->code = $request['code'];
        $offering->name = $request['name'];
        $offering->active = $request['active'];
        return $offering;
    }
}
