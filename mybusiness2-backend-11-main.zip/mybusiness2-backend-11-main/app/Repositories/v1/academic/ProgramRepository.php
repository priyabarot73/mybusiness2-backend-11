<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Program;
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Exceptions\ResourceNotFoundException;

class ProgramRepository implements CrudInterface,ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $programs = Program::where('active','=',$status)->with(['degree', 'offering'])->get();
            if ($programs->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFoundByStatus'));
            }
            return $programs;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $programs = Program::with(['programLevel','programGrouping','degree','offering'])->get();
            if ($programs->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFound'));
            }
            return $programs;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $program = Program::find($id);
            if (!$program){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFoundById'));
            }
            return $program;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function validateCodeExist($code)
    {
        try {
            $program = Program::where('ac.programs.code','=', $code)->first();
            if (!$program){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFoundByCode'));
            }
            return $program;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $program = new Program();
            $newProgram = $this->dataForProgram($request,$program);
            $newProgram->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgram->id,
                'created',
                'Program',
                'A new type of Program was created: ' . $newProgram->name,
            );

            return $newProgram;
        }  catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $program = $this->viewById($id);
            if (!$program){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFoundById'));
            }
            $newProgram = $this->dataForProgram($request,$program);
            $newProgram->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgram->id,
                'updated',
                'Program',
                'Program was updated: ' . $newProgram->name,
            );

            return $newProgram;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $program = $this->viewById($id);
            if (!$program){
                throw new ResourceNotFoundException(trans('academic/program.exceptionNotFoundById'));
            }
            $program->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $program->id,
                'deleted',
                'Program',
                'Program was deleted: ' . $program->name,
            );

            return $program;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataForProgram(array $request, Program $program):object|null
    {
        $program->code = $request['code'];
        $program->name = $request['name'];
        $program->degree_id = $request['degree_id'];
        $program->offering_id = $request['offering_id'];
        $program->program_level_id = $request['program_level_id'];
        $program->program_grouping_id = $request['program_grouping_id'];
        $program->fte = $request['fte'];
        $program->active = $request['active'];
        return $program;
    }
}
