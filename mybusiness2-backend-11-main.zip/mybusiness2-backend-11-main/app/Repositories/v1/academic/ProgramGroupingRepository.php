<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Models\academic\ProgramGrouping;
use App\Exceptions\ResourceNotFoundException;

class ProgramGroupingRepository implements CrudInterface, ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $programGroupings = ProgramGrouping::where('ac.program_groupings.active','=',$status)->get();
            if ($programGroupings->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program_group.exceptionNotFoundByStatus'));
            }
            return $programGroupings;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $programGroupings = ProgramGrouping::orderBy('name', 'desc')->get();
            if ($programGroupings->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program_group.exceptionNotFound'));
            }
            return $programGroupings;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $programGrouping = ProgramGrouping::find($id);
            if (!$programGrouping){
                throw new ResourceNotFoundException(trans('academic/program_group.exceptionNotFoundById'));
            }
            return $programGrouping;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $exception){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $programGrouping = new ProgramGrouping();
            $newProgramGrouping = $this->dataForProgramGrouping($request,$programGrouping);
            $newProgramGrouping->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgramGrouping->id,
                'created',
                'Program grouping',
                'A new type of Program grouping was created: ' . $newProgramGrouping->name,
            );

            return $newProgramGrouping;
        }  catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $programGrouping = $this->viewById($id);
            if (!$programGrouping){
                throw new ResourceNotFoundException(trans('academic/program_group.exceptionNotFoundById'));
            }
            $newProgramGrouping = $this->dataForProgramGrouping($request,$programGrouping);
            $newProgramGrouping->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgramGrouping->id,
                'updated',
                'Program grouping',
                'Program grouping was updated: ' . $newProgramGrouping->name,
            );

            return $newProgramGrouping;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $programGrouping = $this->viewById($id);
            if (!$programGrouping){
                throw new ResourceNotFoundException(trans('academic/program_group.exceptionNotFoundById'));
            }
            $programGrouping->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $programGrouping->id,
                'deleted',
                'Program grouping',
                'Program grouping was deleted: ' . $programGrouping->name,
            );

            return $programGrouping;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataForProgramGrouping(array $request, ProgramGrouping $programGrouping):object|null
    {
        $programGrouping->code = $request['code'];
        $programGrouping->name = $request['name'];
        $programGrouping->active = $request['active'];
        return $programGrouping;
    }
}
