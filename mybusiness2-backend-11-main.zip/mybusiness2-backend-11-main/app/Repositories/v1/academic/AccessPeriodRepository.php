<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\CrudInterface;
use App\Models\academic\AccessPeriod;
use App\Exceptions\ResourceNotFoundException;

class AccessPeriodRepository implements CrudInterface
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $accessPeriods = AccessPeriod::with('term')->orderBy('term_id','desc')->get();
            if ($accessPeriods->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/access_period.not_found'));
            }
            return $accessPeriods;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $accessPeriod = AccessPeriod::find($id);
            if (!$accessPeriod){
                throw new ResourceNotFoundException(trans('academic/access_period.id'));
            }
            return $accessPeriod;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewByTermId($termId) {
        try {
            $accessPeriod = AccessPeriod::with('term')->where('term_id', '=', $termId)->first();
            if (!$accessPeriod){
                throw new ResourceNotFoundException(trans('academic/access_period.id'));
            }
            return [$accessPeriod];
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $accessPeriod = new AccessPeriod();
            $newAccessPeriod = $this->dataFormat($request,$accessPeriod);
            $newAccessPeriod->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAccessPeriod->id,
                'created',
                'Access period',
                'A new type of Access period was created: ' . $newAccessPeriod->name,
            );

            return $newAccessPeriod;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $accessPeriod = $this->viewById($id);
            if (!$accessPeriod){
                throw new ResourceNotFoundException(trans('academic/access_period.id'));
            }
            $newAccessPeriod = $this->dataFormat($request,$accessPeriod);
            $newAccessPeriod->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAccessPeriod->id,
                'updated',
                'Access period',
                'Access period was updated: ' . $newAccessPeriod->name,
            );

            return $newAccessPeriod;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $accessPeriod = $this->viewById($id);
            if (!$accessPeriod){
                throw new ResourceNotFoundException(trans('academic/access_period.id'));
            }
            $accessPeriod->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $accessPeriod->id,
                'deleted',
                'Access period',
                'Access period was deleted: ' . $accessPeriod->name,
            );

            return $accessPeriod;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/access_period.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, AccessPeriod $accessPeriod):object|null
    {
        $accessPeriod->term_id = $request['term_id'];
        $accessPeriod->admin_beginning_date = $request['admin_beginning_date'];
        $accessPeriod->admin_ending_date = $request['admin_ending_date'];
        $accessPeriod->admin_cancel_section_date = $request['admin_cancel_section_date'];
        $accessPeriod->depart_beginning_date = $request['depart_beginning_date'];
        $accessPeriod->depart_ending_date = $request['depart_ending_date'];
        return $accessPeriod;
    }
}
