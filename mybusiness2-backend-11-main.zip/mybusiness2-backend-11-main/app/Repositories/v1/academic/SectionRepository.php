<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use stdClass;
use Exception;
use Throwable;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Term;
use App\Models\general\Campus;
use App\Models\academic\Course;
use App\Models\academic\Program;
use App\Models\academic\Workload;
use App\Models\academic\Section;
use App\Models\general\Facility;
use App\Models\academic\Instructor;
use App\Models\academic\AccessPeriod;
use App\Models\academic\InstructorMode;
use App\Models\academic\MeetingPattern;
use App\Repositories\v1\BaseRepository;
use App\Models\academic\CombinedSection;
use App\Models\academic\ControlCloneSection;
use App\Exceptions\ResourceNotFoundException;
use App\Models\academic\MeetingPatternHybrid;
use App\Http\Requests\v1\academic\SectionDuplicateRequest;

class SectionRepository extends BaseRepository
{
    protected Carbon $currentDate;
    protected WorkLoadRepository $workloadRepository;

    // cache por request
    private array $auditNameCache = [
        'facility' => [],
        'instructor' => [],
    ];
    private array $auditSectionCache = [];

    public function __construct(WorkLoadRepository $workloadRepository)
    {
        $this->currentDate = Carbon::now();
        $this->workloadRepository = $workloadRepository;
    }

    /**
     *
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(Request $request): array
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = $request->query('sortDirection', 'desc');
            $termNumber = $request->query('termNumber', 1248);

            $term = Term::where('number', $termNumber)->first();

            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundById'));
            }
            // base query
            $query = Section::where('term_id', $term->id)
                ->with([
                    'term',
                    'course.department',
                    'instructorMode',
                    'campus',
                    'program',
                    'meetingPatterns.facility',
                    'meetingPatterns.instructor.person',
                    'combinedSections.combinedSection.course',
                    'meetingPatternHybrids.facility.facilityType',
                    'meetingPatternHybrids.instructor.person',
                ]);

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereHas('course', function ($q2) use ($search) {
                        $q2->whereRaw('LOWER(name) LIKE ?', ["%$search%"])
                            ->orWhereRaw('LOWER(code) LIKE ?', ["%$search%"]);
                    })
                        ->orWhereHas('meetingPatterns.instructor.person', function ($q2) use ($search) {
                            $q2->whereRaw('LOWER(first_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(last_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(middle_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(panther_id) LIKE ?', ["%$search%"]);
                        })
                        ->orWhereHas('meetingPatternHybrids.instructor.person', function ($q2) use ($search) {
                            $q2->whereRaw('LOWER(first_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(last_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(middle_name) LIKE ?', ["%$search%"])
                                ->orWhereRaw('LOWER(panther_id) LIKE ?', ["%$search%"]);
                        });
                });
            }

            // allowed columns for sorting ()
            $sortableColumns = ['created_at', 'updated_at', 'section_number'];

            // apply sorting
            if (in_array($sortColumn, $sortableColumns)) {
                $query->orderBy($sortColumn, $sortDirection)
                    ->orderBy('id'); // stable ordering
            } else {
                $query->orderBy('created_at', 'desc')
                    ->orderBy('id');
            }

            // paginate
            $sections = $query->paginate($perPage, ['*'], 'page', $page);

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.termNotFound'));
            }

            // permissions based on first section's term
            $permissions = $this->getPermissions($sections[0]->term);

            return [
                'sections' => $sections,
                'permissions' => $permissions
            ];
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
//            throw new Exception(trans('academic/section.error'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewById($id): Model|Collection|null
    {
        try {
            $section = Section::with(
                [
                    'term', 'course.department', 'instructorMode', 'campus', 'program',
                    'meetingPatterns.facility', 'meetingPatterns.instructor',
                    'combinedSections.combinedSection.course',
                    'meetingPatternHybrids.facility.facilityType',
                    'meetingPatternHybrids.instructor',
                ]
            )->find($id);

            if (!$section) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFoundById'));
            }
            return $section;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllSectionsByTermIDCombined($termId): array
    {
        try {
            //Step 1: Get all sections that belong to the term with the given ID
            $sections = Section::where('term_id', $termId)
                ->with(
                    [
                        'term', 'course.department', 'instructorMode', 'campus', 'program',
                        'meetingPatterns.facility', 'meetingPatterns.instructor',
                        'combinedSections.combinedSection.course',
                        'meetingPatternHybrids.facility.facilityType',
                        'meetingPatternHybrids.instructor',
                    ]
                )
                ->get();

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.termNotFound'));
            }

            //Step 2: Create an array of objects with the combination of session.code + course.name
            return $sections->map(function ($section) {
                return [
                    'code' => $section->sec_code . $section->sec_number . $section->sec_sess . '-' . $section->course->code,
                    'id' => $section->id
                ];
            })->unique('code')->values()->all();
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('section.error'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *
     * @throws ResourceNotFoundException
     * @throws Exception
     */

    public function viewAllSectionsByTermID(Request $request, $termId): array
    {
        try {

            Log::error($termId);

            // Pagination / sorting / search
            $perPage = (int)$request->query('pageSize', 10);
            $page = (int)$request->query('page', 1);
            $search = trim((string)$request->query('search', ''));
            $sortColumn = (string)$request->query('sortColumn', 'code');
            $sortDirection = strtolower((string)$request->query('sortDirection', $request->query('sort', 'asc')));

            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'asc';
            }

            // Filters (DataGrid) - can arrive as array or JSON
            $filterModel = $request->query('filters'); // array|string|null

            if (is_string($filterModel) && $filterModel !== '') {
                $decoded = json_decode($filterModel, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $filterModel = $decoded;
                }
            }

            // Base query (IMPORTANT: avoid joining meeting_patterns here)
            $query = Section::query()
                ->where('ac.sections.term_id', $termId)
                ->with([
                    'term',
                    'course.department',
                    'instructorMode',
                    'campus',
                    'program',
                    'meetingPatterns.facility',
                    'meetingPatterns.instructor.person',
                    'meetingPatternHybrids.facility',
                    'meetingPatternHybrids.instructor.person',
                    'combinedSections.combinedSection.course',
                ])
                // joins ONLY for sortable/filterable 1:1 columns
                ->leftJoin('ac.courses', 'ac.sections.course_id', '=', 'ac.courses.id')
                ->leftJoin('ac.instructor_modes', 'ac.sections.instructor_mode_id', '=', 'ac.instructor_modes.id')
                ->leftJoin('ac.programs', 'ac.sections.program_id', '=', 'ac.programs.id')
                ->select('ac.sections.*');

            // Global search
            if ($search !== '') {
                $searchExact = trim($search);
                $s = strtolower($searchExact);

                $query->where(function ($q) use ($searchExact, $s) {

                    // Search by section.id (UUID) without breaking when the search term is numeric.
                    $q->whereRaw('ac.sections.id = TRY_CONVERT(uniqueidentifier, ?)', [$searchExact])

                        // Course search
                        ->orWhereHas('course', function ($q2) use ($s) {
                            $q2->whereRaw('LOWER(name) LIKE ?', ["%{$s}%"])
                                ->orWhereRaw('LOWER(code) LIKE ?', ["%{$s}%"]);
                        })

                        // Instructor/person search (meeting_patterns)
                        ->orWhereHas('meetingPatterns.instructor.person', function ($q2) use ($s, $searchExact) {
                            $q2->whereRaw('LOWER(first_name) LIKE ?', ["%{$s}%"])
                                ->orWhereRaw('LOWER(last_name) LIKE ?', ["%{$s}%"])
                                // panther_id is INT -> CAST to LIKE
                                ->orWhereRaw("CAST(panther_id AS VARCHAR(50)) LIKE ?", ["%{$searchExact}%"]);
                        })

                        // Instructor/person search (hybrids)
                        ->orWhereHas('meetingPatternHybrids.instructor.person', function ($q2) use ($s, $searchExact) {
                            $q2->whereRaw('LOWER(first_name) LIKE ?', ["%{$s}%"])
                                ->orWhereRaw('LOWER(last_name) LIKE ?', ["%{$s}%"])
                                //  panther_id is INT -> CAST to LIKE
                                ->orWhereRaw("CAST(panther_id AS VARCHAR(50)) LIKE ?", ["%{$searchExact}%"]);
                        });
                });
            }


            // APPLY FILTER MODEL (DataGrid)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {

                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // 'and' | 'or'

                $makeLike = function ($value, $operator) {
                    $v = trim((string)$value);

                    // DataGrid typical ops: contains, equals, startsWith, endsWith
                    return match ($operator) {
                        'equals', '=', 'is' => $v,
                        'startsWith' => $v . '%',
                        'endsWith' => '%' . $v,
                        default => '%' . $v . '%', // contains
                    };
                };

                $query->where(function ($root) use ($filterModel, $logic, $makeLike) {

                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        // Important: MUI triggers filters with empty value while user is selecting operator/column
                        if (!$field || $value === null || $value === '') {
                            continue;
                        }

                        $applyOne = function ($q) use ($field, $operator, $value, $makeLike) {
                            $op = (string)$operator;
                            $rawValue = trim((string)$value);
                            $like = $makeLike($rawValue, $op);

                            // Column: term (term.shortName)
                            if ($field === 'term') {
                                $v = strtolower($rawValue);
                                return $q->whereExists(function ($sub) use ($v) {
                                    $sub->selectRaw('1')
                                        ->from('ac.terms as t')
                                        ->whereColumn('t.id', 'ac.sections.term_id')
                                        ->whereRaw('LOWER(t.short_name) LIKE ?', ["%{$v}%"]);
                                });
                            }

                            // Column: caps (boolean-ish)
                            if ($field === 'caps') {
                                // allow "I/A" or 0/1
                                $val = strtolower($rawValue);
                                if ($val === 'i') $val = '0';
                                if ($val === 'a') $val = '1';

                                return $q->where('ac.sections.caps', (int)$val);
                            }

                            // Column: references_number_panther (numeric/string)
                            if ($field === 'references_number_panther') {
                                // SQL Server: CAST to varchar to use LIKE safely
                                return $q->whereRaw(
                                    "CAST(ac.sections.references_number_panther AS VARCHAR(50)) LIKE ?",
                                    ['%' . $rawValue . '%']
                                );
                            }

                            // Column: secCodeNumber (your UI shows secFull)
                            // Filter using sec_code + sec_number (+ sec_sess if you want)
                            if ($field === 'secCodeNumber') {
                                // tweak concatenation if your "secFull" format differs
                                return $q->whereRaw(
                                    "LOWER(CONCAT(ISNULL(ac.sections.sec_code,''), '-', ISNULL(ac.sections.sec_number,''))) LIKE ?",
                                    [strtolower($like)]
                                );
                            }

                            // Column: code (course.code)
                            if ($field === 'code') {
                                return $q->whereRaw('LOWER(ac.courses.code) LIKE ?', [strtolower($like)]);
                            }

                            // Column: meetingPatterns (day/time)
                            // We'll filter by DAY only (because time is rendered, but DB stores start/end)
                            if ($field === 'meetingPatterns') {
                                $v = strtolower($rawValue);

                                return $q->where(function ($x) use ($v) {
                                    // meeting_patterns
                                    $x->whereExists(function ($sub) use ($v) {
                                        $sub->selectRaw('1')
                                            ->from('ac.meeting_patterns as mp')
                                            ->whereColumn('mp.section_id', 'ac.sections.id')
                                            ->whereRaw('LOWER(mp.day) LIKE ?', ["%{$v}%"]);
                                    })
                                        // hybrids
                                        ->orWhereExists(function ($sub) use ($v) {
                                            $sub->selectRaw('1')
                                                ->from('ac.meeting_pattern_hybrids as mph')
                                                ->whereColumn('mph.section_id', 'ac.sections.id')
                                                ->whereRaw('LOWER(mph.day) LIKE ?', ["%{$v}%"]);
                                        });
                                });
                            }

                            // Column: facility (facility.code)
                            if ($field === 'facility') {
                                $v = strtolower($rawValue);

                                return $q->where(function ($x) use ($v) {
                                    $x->whereExists(function ($sub) use ($v) {
                                        $sub->selectRaw('1')
                                            ->from('ac.meeting_patterns as mp')
                                            ->join('ac.facilities as f', 'f.id', '=', 'mp.facility_id')
                                            ->whereColumn('mp.section_id', 'ac.sections.id')
                                            ->whereRaw('LOWER(f.code) LIKE ?', ["%{$v}%"]);
                                    })
                                        ->orWhereExists(function ($sub) use ($v) {
                                            $sub->selectRaw('1')
                                                ->from('ac.meeting_pattern_hybrids as mph')
                                                ->join('ac.facilities as f', 'f.id', '=', 'mph.facility_id')
                                                ->whereColumn('mph.section_id', 'ac.sections.id')
                                                ->whereRaw('LOWER(f.code) LIKE ?', ["%{$v}%"]);
                                        });
                                });
                            }

                            // Column: cap (int)
                            if ($field === 'cap') {
                                return $q->where('ac.sections.cap', (int)$rawValue);
                            }

                            // Column: first_name (your instructors column)
                            // Should match person first/last/panther_id + instructor business_email too
                            if ($field === 'first_name') {
                                $v = strtolower(trim((string)$rawValue));
                                if ($v === '') return $q;

                                $like = "%{$v}%";

                                return $q->where(function ($x) use ($like) {

                                    // ---------- meeting_patterns ----------
                                    $x->whereExists(function ($sub) use ($like) {
                                        $sub->selectRaw('1')
                                            ->from('ac.meeting_patterns as mp')
                                            ->join('ac.instructors as ins', 'ins.id', '=', 'mp.instructor_id')
                                            ->join('hr.persons as p', 'p.id', '=', 'ins.person_id')
                                            ->whereColumn('mp.section_id', 'ac.sections.id')
                                            ->where(function ($w) use ($like) {
                                                $w->whereRaw("LOWER(ISNULL(p.first_name, '')) LIKE ?", [$like])
                                                    ->orWhereRaw("LOWER(ISNULL(p.last_name, '')) LIKE ?", [$like])
                                                    ->orWhereRaw("LOWER(CONCAT(ISNULL(p.first_name, ''), ' ', ISNULL(p.last_name, ''))) LIKE ?", [$like])
                                                    ->orWhereRaw("LOWER(CONCAT(ISNULL(p.last_name, ''), ' ', ISNULL(p.first_name, ''))) LIKE ?", [$like])
                                                    ->orWhereRaw("LOWER(ISNULL(p.panther_id, '')) LIKE ?", [$like]);

                                                // ->orWhereRaw("LOWER(ISNULL(p.email, '')) LIKE ?", [$like]);
                                                // ->orWhereRaw("LOWER(ISNULL(p.business_email, '')) LIKE ?", [$like]);
                                                // ->orWhereRaw("LOWER(ISNULL(p.personal_email, '')) LIKE ?", [$like]);
                                            });
                                    })

                                        // ---------- meeting_pattern_hybrids ----------
                                        ->orWhereExists(function ($sub) use ($like) {
                                            $sub->selectRaw('1')
                                                ->from('ac.meeting_pattern_hybrids as mph')
                                                ->join('ac.instructors as ins', 'ins.id', '=', 'mph.instructor_id')
                                                ->join('hr.persons as p', 'p.id', '=', 'ins.person_id')
                                                ->whereColumn('mph.section_id', 'ac.sections.id')
                                                ->where(function ($w) use ($like) {
                                                    $w->whereRaw("LOWER(ISNULL(p.first_name, '')) LIKE ?", [$like])
                                                        ->orWhereRaw("LOWER(ISNULL(p.last_name, '')) LIKE ?", [$like])
                                                        ->orWhereRaw("LOWER(CONCAT(ISNULL(p.first_name, ''), ' ', ISNULL(p.last_name, ''))) LIKE ?", [$like])
                                                        ->orWhereRaw("LOWER(CONCAT(ISNULL(p.last_name, ''), ' ', ISNULL(p.first_name, ''))) LIKE ?", [$like])
                                                        ->orWhereRaw("LOWER(ISNULL(p.panther_id, '')) LIKE ?", [$like]);

                                                    // ->orWhereRaw("LOWER(ISNULL(p.email, '')) LIKE ?", [$like]);
                                                    // ->orWhereRaw("LOWER(ISNULL(p.business_email, '')) LIKE ?", [$like]);
                                                    // ->orWhereRaw("LOWER(ISNULL(p.personal_email, '')) LIKE ?", [$like]);
                                                });
                                        });
                                });
                            }


                            // Column: instructor_mode_code
                            if ($field === 'instructor_mode_code') {
                                return $q->whereRaw('LOWER(ac.instructor_modes.code) LIKE ?', [strtolower($like)]);
                            }

                            // Column: program_code
                            if ($field === 'program_code') {
                                return $q->whereRaw('LOWER(ac.programs.code) LIKE ?', [strtolower($like)]);
                            }

                            // Column: status
                            if ($field === 'status') {
                                return $q->whereRaw('LOWER(ac.sections.status) LIKE ?', [strtolower($like)]);
                            }

                            // Column not supported -> ignore
                            return $q;
                        };

                        // Apply with logicOperator
                        if ($logic === 'or') {
                            $root->orWhere(function ($qq) use ($applyOne) {
                                $applyOne($qq);
                            });
                        } else {
                            $root->where(function ($qq) use ($applyOne) {
                                $applyOne($qq);
                            });
                        }
                    }
                });
            }

            // Sorting (ONLY safe columns to avoid SQL Server issues)
            $sortableColumns = [
                'caps',
                'references_number_panther',
                'secCodeNumber',
                'code',
                'cap',
                'instructor_mode_code',
                'program_code',
            ];

            if (in_array($sortColumn, $sortableColumns)) {
                $columnMap = [
                    'caps' => 'ac.sections.caps',
                    'references_number_panther' => 'ac.sections.references_number_panther',
                    'cap' => 'ac.sections.cap',
                    'code' => 'ac.courses.code',
                    'instructor_mode_code' => 'ac.instructor_modes.code',
                    'program_code' => 'ac.programs.code',
                ];

                if ($sortColumn === 'secCodeNumber') {
                    $query->orderByRaw("CONCAT(ISNULL(ac.sections.sec_code,''), '-', ISNULL(ac.sections.sec_number,'')) {$sortDirection}");
                } else {
                    $orderCol = $columnMap[$sortColumn] ?? 'ac.sections.created_at';
                    $query->orderBy($orderCol, $sortDirection);
                }
            } else {
                // default safe order
                $query->orderBy('ac.courses.code', 'asc');
            }

            // Paginate
            $sections = $query->paginate($perPage, ['*'], 'page', $page);

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.termNotFound'));
            }

            // permissions
            $permissions = $this->getPermissions($sections[0]->term);

            // combined sections
            $combined = $this->viewAllSectionsByTermIDCombined($termId);

            return [
                'sections' => $sections,
                'permissions' => $permissions,
                'combined' => $combined
            ];

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Create section, meeting_pattern, combine section, workload, workload course
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function create(array $request): object|array|null
    {
        DB::beginTransaction();

        try {
            // Step 0: Check if the section already exists
            if ($this->checkIfSectionExists($request)) {
                throw new Exception(trans('academic/section.exceptionAlreadyExist'), Response::HTTP_CONFLICT);
            }

            // Step 1: Verify that the section update request references valid objects that exist within the database
            $this->validateAndCheckMeetingPatterns($request, ['meeting_patterns', 'meeting_pattern_hybrids']);

            // Step 2: Create a new section
            $section = new Section();
            $newSection = $this->dataFormatSection($request, $section, false);
            $newSection->save();

            // Commit transaction to make sure section_id is available
            DB::commit(); // TEMPORARY: Commit the transaction to persist the section

            // Step 3: Assign the meeting patterns to the new section
            if (count($request['meeting_patterns']) > 0) {
                $this->createMeetingPattern($request, $newSection->id);
            }

            // Step 4: Assign the meeting patter hybrid
            if (count($request['meeting_pattern_hybrids']) > 0) {
                $this->createMeetingPatternHybrid($request, $newSection->id);
            }

            // Step 5: Assign the combined sections to the new section
            if (count($request['combined_sections']) > 0) {
                $this->createCombinedSection($request, $newSection->id);
            }

            // Step 6: Create workload course or update if exist
            $this->createWorkloadCourse($request, $newSection->id);

            DB::commit();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSection->id,
                'created',
                'Section',
                'A new type of Section was created: ' . $newSection->sec_code . ' ' . $newSection->sec_number . ' ' . $newSection->sec_sess,
            );

            // Step 7: Return the newly created section
            return $newSection;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Update section, workload, workload course, combine section
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            // Load relationships for audit (facility/instructor/combined section)
            $section = Section::with([
                'term',
                'course',
                'campus',
                'program',
                'instructorMode',
                'meetingPatterns.facility',
                'meetingPatterns.instructor.person',
                'meetingPatternHybrids.facility',
                'meetingPatternHybrids.instructor.person',
                'combinedSections.combinedSection.course',
                'workloadCourses.workload',
            ])->find($id);

            if (!$section) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFoundById'));
            }

            // Set values without touching created_by
            $updatedSection = $this->dataFormatSection($request, $section, true);

            // validar ids
            $this->validateAndCheckMeetingPatterns($request, ['meeting_patterns', 'meeting_pattern_hybrids']);

            // Build audit BEFORE save/delete (to compare old vs new)
            $auditDescription = $this->buildSectionAuditDescription($updatedSection, $request);

            // guardar sección
            $updatedSection->save();

            // meeting patterns (delete + recreate)
            $updatedSection->meetingPatterns()->delete();
            if (count($request['meeting_patterns'] ?? []) > 0) {
                $this->createMeetingPattern($request, $updatedSection->id);
            }

            // hybrid
            $updatedSection->meetingPatternHybrids()->delete();
            if (count($request['meeting_pattern_hybrids'] ?? []) > 0) {
                $this->createMeetingPatternHybrid($request, $updatedSection->id);
            }

            // combined
            $updatedSection->combinedSections()->delete();
            if (count($request['combined_sections'] ?? []) > 0) {
                $this->createCombinedSection($request, $updatedSection->id);
            }

            // workloads
            $updatedSection->workloadCourses()->each(function ($workloadCourse) {
                $workload = $workloadCourse->workload;
                $workloadCourse->delete();

                if ($workload && $workload->workloadCourses()->count() === 0) {
                    $workload->delete();
                }
            });

            $this->createWorkloadCourse($request, $updatedSection->id);

            // Timeline with actual changes (audit)
            ActivityTimeLineHelper::store(
                $updatedSection->id,
                'updated',
                'Section',
                $auditDescription
            );

            return $updatedSection;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Clone a single section
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function cloneSection(array $request): object|array|null
    {
        return DB::transaction(function () use ($request) {
            try {

                // Step 1: Verify that the section update request references valid objects that exist within the database
                $this->validateAndCheckMeetingPatterns($request, ['meeting_patterns', 'meeting_pattern_hybrids']);

                // Step 2: Create a new section
                $section = new Section();
                $newSection = $this->dataFormatSection($request, $section);
                $newSection->save();

                // Commit transaction to make sure section_id is available
                DB::commit(); // TEMPORARY: Commit the transaction to persist the section

                // Step 3: Assign the meeting patterns to the new section
                if (count($request['meeting_patterns']) > 0) {
                    $this->createMeetingPattern($request, $newSection->id);
                }

                // Step 4: Assign the meeting patter hybrid
                if (count($request['meeting_pattern_hybrids']) > 0) {
                    $this->createMeetingPatternHybrid($request, $newSection->id);
                }

                // Step 5: Assign the combined sections to the new section
                if (count($request['combined_sections']) > 0) {
                    $this->createCombinedSection($request, $newSection->id);
                }

                // Step 6: Create workload or update if exist
                $this->createWorkloadCourse($request, $newSection->id);

                // Store activity timeline
                ActivityTimeLineHelper::store(
                    $newSection->id,
                    'cloned',
                    'Section',
                    'Section was cloned: ' . $newSection->sec_code . ' ' . $newSection->sec_number . ' ' . $newSection->sec_sess,
                );

                // Step 7: Return the newly created section
                return $newSection;

            } catch (ResourceNotFoundException $e) {
                Log::error($e);
                throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
            } catch (Exception $e) {
                Log::error($e);
                throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
            }
        });
    }

    /**
     * Clone sections from Term A to Term B
     * @throws Exception
     */
    public function cloneSections(SectionDuplicateRequest $request): int
    {
        try {
            DB::beginTransaction();

            // Step 1: Declare the duplicate section counter
            $numberCloneSections = 0;
            $destinationTerm = Term::find($request['term_id_destination']);

            // Step 2: Get all sections of the origin term
            $sectionsQuery = Section::with('meetingPatterns', 'combinedSections', 'meetingPatternHybrids', 'workloadCourses.workload', 'program.offering')
                ->where('term_id', $request['term_id_origin']);

            $undergraduate = filter_var($request['undergraduate'], FILTER_VALIDATE_BOOLEAN);
            $graduate = filter_var($request['graduate'], FILTER_VALIDATE_BOOLEAN);

            // Whether to filter by type of offering
            if ($undergraduate || $graduate) {
                $codes = [];

                if ($undergraduate) {
                    $codes = array_merge($codes, ['UP', 'UCA']);
                }

                if ($graduate) {
                    $codes = array_merge($codes, ['GP', 'DP']);
                }

                $sectionsQuery->whereHas('program.offering', function ($query) use ($codes) {
                    $query->whereIn('code', $codes);
                });
            }

            $sections = $sectionsQuery->get();

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFound'));
            }

            // Step 3: Duplicate and save the sections in the destination term
            foreach ($sections as $section) {
                // Duplicate and save the section
                $section->starting_date = $destinationTerm->begin_dt;
                $section->ending_date = $destinationTerm->end_dt;
                $newSection = $section->replicate();
                $newSection->term_id = $request['term_id_destination'];
                $newSection->save();

                // Step 3.1: Duplicate and save the section meeting patterns
                foreach ($section->meetingPatterns as $meetingPattern) {
                    $newMeetingPattern = $meetingPattern->replicate();
                    $newMeetingPattern->section_id = $newSection->id;

                    // Assign instructor_id if provided
                    if ($request['instructor_id']) {
                        $newMeetingPattern->instructor_id = $request['instructor_id'];
                    }
                    $newMeetingPattern->save();
                }

                // Step 3.2: Duplicate and save the meeting pattern hybrids
                foreach ($section->meetingPatternHybrids as $meetingPatternHybrid) {
                    $newMeetingPatternHybrid = $meetingPatternHybrid->replicate();
                    $newMeetingPatternHybrid->section_id = $newSection->id;

                    // Assign instructor_id if provided
                    if ($request['instructor_id']) {
                        $newMeetingPatternHybrid->instructor_id = $request['instructor_id'];
                    }
                    $newMeetingPatternHybrid->save();
                }

                // Step 3.3: Duplicate and save the combined sections
                foreach ($section->combinedSections as $combinedSection) {
                    $newCombinedSection = $combinedSection->replicate();
                    $newCombinedSection->section_id = $newSection->id;
                    $newCombinedSection->save();
                }

                // Step 3.4: Duplicate and save the workload courses
                $clonedWorkloads = [];
                foreach ($section->workloadCourses as $workloadCourse) {
                    // Clone the workload (if it's not already duplicated)
                    $workload = $workloadCourse->workload;

                    // Check if the workload has already been cloned
                    if (!isset($clonedWorkloads[$workload->id])) {
                        // Clone the workload and save it in the array
                        $newWorkload = $workload->replicate();
                        $newWorkload->academic_year = $destinationTerm->year;
                        $newWorkload->semester = $destinationTerm->semester;
                        $newWorkload->save();

                        // Store the cloned workload in the array
                        $clonedWorkloads[$workload->id] = $newWorkload;
                    }

                    // Clone the workload_course and link it to the new workload and new section
                    $newWorkloadCourse = $workloadCourse->replicate();
                    $newWorkloadCourse->workload_id = $clonedWorkloads[$workload->id]->id;
                    $newWorkloadCourse->section_id = $newSection->id;
                    $newWorkloadCourse->save();
                }

                // Increment duplicate section counter
                $numberCloneSections++;
            }

            // Step 4: Get the terms of origin
            $originTerm = Term::find($request['term_id_origin']);

            // Step 5: Create and save ControlDuplicateSection record
            $control = new ControlCloneSection();
            $user = Auth::user();
            $control->user = $user->panther_id;
            $control->origin_term = $originTerm->semester . $originTerm->year;
            $control->destination_term = $destinationTerm->semester . $destinationTerm->year;
            $control->comment = $request['comment'];
            $control->save();

            DB::commit();

            // Step 6: Return the number of duplicate sections
            return $numberCloneSections;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * This method is used to delete all the sections that have been cloned
     *
     * @throws Exception
     */
    public function deleteClonedSectionsByTerm(array $request): int
    {
        try {
            $termId = $request['term_id'];

            DB::beginTransaction();

            // Search sections for the specific term
            $sections = Section::where('term_id', $termId)->get();

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFound'));
            }

            $deletedCount = 0;

            foreach ($sections as $section) {
                // Delete meeting patterns
                $section->meetingPatterns()->delete();

                // Remove hybrid patterns
                $section->meetingPatternHybrids()->delete();

                // Remove merged sections (where this section is the parent)
                $section->combinedSections()->delete();

                // Delete workload_courses and optionally associated workloads
                foreach ($section->workloadCourses as $workloadCourse) {
                    $workload = $workloadCourse->workload;
                    $workloadCourse->delete();

                    // If the workload is no longer associated with any other course, delete it
                    if ($workload && $workload->workloadCourses()->count() === 0) {
                        $workload->delete();
                    }
                }

                // Finally delete the section
                $section->delete();
                $deletedCount++;
            }

            // Remove clone control if it exists
            $term = Term::find($termId);
            if ($term) {
                $destinationTermValue = $term->semester . $term->year;
                ControlCloneSection::where('destination_term', $destinationTermValue)->delete();
            }

            DB::commit();

            return $deletedCount;

        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Delete section, meeting_pattern, combine section, workload, workload course
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function delete($sectionId)
    {
        try {
            $this->startTransaction();

            // Step 1: Find the section
            $section = Section::findOrFail($sectionId);
            if (!$section) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFound'));
            }

            // Step 2: Delete related meeting patterns
            $section->meetingPatterns()->each(function ($meetingPattern) {
                $meetingPattern->delete();
            });

            // Step 3: Delete related combined sections
            $section->combinedSections()->each(function ($combinedSection) {
                $combinedSection->delete();
            });

            // Step 4: Delete related workload courses and workloads
            $section->workloadCourses()->each(function ($workloadCourse) {
                $workload = $workloadCourse->workload;

                // Delete workload course
                $workloadCourse->delete();

                // Check if the workload has any remaining courses
                if ($workload && $workload->workloadCourses()->count() === 0) {
                    // Delete workload if no more courses are attached
                    $workload->delete();
                }
            });

            // Step 5: Delete the section
            $section->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $section->id,
                'deleted',
                'Section',
                'Section was deleted: ' . $section->sec_code . ' ' . $section->sec_number . ' ' . $section->sec_sess,
            );

            $this->commitTransaction();
            return $section;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        } finally {
            $this->rollbackTransaction();
        }
    }

    /**
     * Check if that term has its access period and if it does, check that the user has permission to create or edit any section for that term.
     * @throws ResourceNotFoundException
     */
    public function getPermissions($term): stdClass
    {
        try {
            // Step 1: Get the access period associated with the term
            $accessPeriod = AccessPeriod::where('term_id', $term->id)->first();
            $semester = strtolower($term->semester);
            $activeSess = $semester === 'summer';

            // If the AccessPeriod is not found, returns false permissions
            if (!$accessPeriod) {
                $permissions = new stdClass();
                $permissions->adminPermission = false;
                $permissions->departmentPermission = false;
                $permissions->cancelPermission = false;
                $permissions->activeSess = $activeSess;
                return $permissions;
            }

            // Step 2: Get current date
            $currentDate = Carbon::now()->startOfDay();

            // Step 3: Convert accessPeriod dates to Carbon instances
            $adminBeginningDate = Carbon::parse($accessPeriod->admin_beginning_date)->startOfDay();
            $adminEndingDate = Carbon::parse($accessPeriod->admin_ending_date)->startOfDay();
            $departBeginningDate = Carbon::parse($accessPeriod->depart_beginning_date)->startOfDay();
            $departEndingDate = Carbon::parse($accessPeriod->depart_ending_date)->startOfDay();
            $adminCancelSectionDate = Carbon::parse($accessPeriod->admin_cancel_section_date)->startOfDay();

            // Step 4: Check permissions based on AccessPeriod dates
            $adminPermission = $currentDate->greaterThanOrEqualTo($adminBeginningDate)
                && $currentDate->lessThanOrEqualTo($adminEndingDate);

            $departmentPermission = $currentDate->greaterThanOrEqualTo($departBeginningDate)
                && $currentDate->lessThanOrEqualTo($departEndingDate);

            $cancelPermission = $currentDate->lessThanOrEqualTo($adminCancelSectionDate);

            // Step 5: Create a stdClass object to encapsulate the permissions
            $permissions = new stdClass();
            $permissions->adminPermission = $adminPermission;
            $permissions->departmentPermission = $departmentPermission;
            $permissions->cancelPermission = $cancelPermission;
            $permissions->activeSess = $activeSess;

            // Step 6: Return permission object
            return $permissions;
        } catch (Exception $e) {
            // Return permissions in false in case of unexpected error
            $permissions = new stdClass();
            $permissions->adminPermission = false;
            $permissions->departmentPermission = false;
            $permissions->cancelPermission = false;
            $permissions->activeSess = false;
            return $permissions;
        }
    }

    /**
     * Checks if an object given its id exists in the database
     * @throws ResourceNotFoundException
     */
    private function checkIfExists(string $modelClass, string $id, string $exceptionMessageKey): void
    {
        if (!$modelClass::where('id', $id)->exists()) {
            throw new ResourceNotFoundException(trans("academic/section.$exceptionMessageKey"));
        }
    }

    /**
     * Get values from the request and assign these values to an object
     * @throws Exception
     */
    public function dataFormatSection(array $request, $section, bool $isUpdate = false): object|null
    {
        try {
            $user = Auth::user();

            $section->caps = $request['caps'];
            $section->term_id = $request['term_id'];
            $section->course_id = $request['course_id'];
            $section->sec_code = $request['sec_code'];
            $section->sec_number = $request['sec_number'];
            $section->sec_sess = $request['sec_sess'];
            $section->cap = $request['cap'];
            $section->instructor_mode_id = $request['instructor_mode_id'];
            $section->campus_id = $request['campus_id'];

            // Normaliza fechas
            $section->starting_date = $request['starting_date'] ? Carbon::parse($request['starting_date']) : null;
            $section->ending_date   = $request['ending_date'] ? Carbon::parse($request['ending_date']) : null;

            $section->program_id = $request['program_id'];
            $section->cohorts = $request['cohorts'];
            $section->status = $request['status'];
            $section->comment = $request['comment'];
            $section->internal_note = $request['internal_note'];

            // campo derivado
            $section->combined = count($request['combined_sections'] ?? []) > 0;

            // SOLO create
            if (!$isUpdate) {
                $section->created_by = strstr($user->email, '@', true);
            }

            return $section;
        } catch (Exception $e) {
            throw new Exception(trans('academic/section.request'));
        }
    }


    /**
     * @throws Exception
     */
    public function createMeetingPattern($request, $id): void
    {
        try {
            foreach ($request['meeting_patterns'] as $planning) {
                $meetingPattern = new MeetingPattern();
                $meetingPattern->day = $planning['day'];
                $meetingPattern->start_time = $planning['start_time'];
                $meetingPattern->end_time = $planning['end_time'];
                $meetingPattern->facility_id = $planning['facility_id'];
                $meetingPattern->section_id = $id;
                $meetingPattern->instructor_id = $planning['instructor_id'];
                $meetingPattern->primary_instructor = $planning['primary_instructor'];
                $meetingPattern->save();
            }
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/meeting_pattern.error'));
        }
    }

    /**
     * @throws Exception
     */
    public function createMeetingPatternHybrid($request, $id): void
    {
        try {
            foreach ($request['meeting_pattern_hybrids'] as $planning) {
                $meetingPatternHybrid = new MeetingPatternHybrid();
                $meetingPatternHybrid->day = $planning['day'];
                $meetingPatternHybrid->date = $planning['date'];
                $meetingPatternHybrid->start_time = $planning['start_time'];
                $meetingPatternHybrid->end_time = $planning['end_time'];
                $meetingPatternHybrid->facility_id = $planning['facility_id'];
                $meetingPatternHybrid->section_id = $id;
                $meetingPatternHybrid->instructor_id = $planning['instructor_id'];
                $meetingPatternHybrid->primary_instructor = $planning['primary_instructor'];
                $meetingPatternHybrid->save();
            }
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage());
        }
    }

    /**
     * Add id for a combined section
     * @throws Exception
     */
    public function createCombinedSection($request, $id): void
    {
        try {
            foreach ($request['combined_sections'] as $combined) {
                $combinedSection = new CombinedSection();
                $combinedSection->section_id = $id;
                $combinedSection->section_id_combined = $combined['section_id'];
                $combinedSection->save();
            }
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage());
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    // TODO: This method needs to be updated with the correct type of contract on this line: 'workload_type' => "F",
    public function createWorkloadCourse($request, $newSectionId): void
    {
        try {
            // Step 1: Find the corresponding term
            $term = Term::find($request['term_id']);
            $count = count($request['combined_sections']);

            // Step 2: Join both arrays (meeting_patterns y meeting_pattern_hybrids)
            $allMeetingPatterns = array_merge($request['meeting_patterns'] ?? [], $request['meeting_pattern_hybrids'] ?? []);


            //Moves the workload generation to the workload repository from section repository
            $this->workloadRepository->sectionCreate($allMeetingPatterns, $request, $newSectionId);

        } catch (Exception $e) {
            throw new Exception(trans('academic/section.workload'));
        }
    }

    /**
     * Validation and verification of the existence of objects
     * @throws ResourceNotFoundException
     */
    private function validateAndCheckMeetingPatterns(array $request, array $attributes): void
    {
        foreach ($attributes as $attribute) {
            // Check if the attribute exists in the request and is an array
            $meeting_patterns = $request[$attribute] ?? [];
            foreach ($meeting_patterns as $pattern) {
                if (isset($pattern['facility_id'])) {
                    $this->checkIfExists(Facility::class, $pattern['facility_id'], 'general/facility.exceptionNotFoundById');
                }
                if (isset($pattern['instructor_id'])) {
                    $this->checkIfExists(Instructor::class, $pattern['instructor_id'], 'academic/instructor.exceptionNotFoundById');
                }
            }
        }
    }

    /**
     * Validate if section already exists based on term_id, course_id, sec_code, and sec_number
     *
     * @param array $data
     * @return bool
     * @throws Exception
     */
    public function checkIfSectionExists(array $data): bool
    {
        try {
            return Section::where('term_id', $data['term_id'])
                ->where('course_id', $data['course_id'])
                ->where('sec_code', $data['sec_code'])
                ->when(isset($data['sec_number']), function ($query) use ($data) {
                    return $query->where('sec_number', $data['sec_number']);
                })
                ->exists();
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), Response::HTTP_CONFLICT);
        }
    }

    /**
     * @throws Exception
     *
     * Check for conflict in meeting pattern when creating section
     */
    public function hasConflictingSchedule(array $data): bool
    {
        try {
            // Parse the times
            $startTime = Carbon::parse($data['start_time']);
            $endTime = Carbon::parse($data['end_time']);

            // Check for conflicts in MeetingPattern
            return DB::table('ac.meeting_patterns')
                ->join('ac.sections', 'sections.id', '=', 'ac.meeting_patterns.section_id')
                ->where('ac.sections.term_id', $data['term_id'])
                ->where('ac.meeting_patterns.instructor_id', $data['instructor_id'])
                ->where('ac.meeting_patterns.day', $data['day'])
                ->where(function ($query) use ($startTime, $endTime) {
                    $query->whereTime('start_time', '<', $endTime)
                        ->whereTime('end_time', '>', $startTime);
                })
                ->exists();

        } catch (Exception $e) {
            throw new Exception($e->getMessage(), Response::HTTP_CONFLICT);
        }
    }

    /**
     * @throws Exception
     *
     * Check for conflict in meeting pattern hybrid when creating section
     */
    public function hasConflictingScheduleHybrid(array $data): bool
    {
        try {
            // Parse the times
            $startTime = Carbon::parse($data['start_time']);
            $endTime = Carbon::parse($data['end_time']);

            // Check for conflicts in Meeting Pattern Hybrid
            return DB::table('ac.meeting_pattern_hybrids')
                ->join('ac.sections', 'sections.id', '=', 'ac.meeting_pattern_hybrids.section_id')
                ->where('ac.sections.term_id', $data['term_id'])
                ->where('ac.meeting_pattern_hybrids.instructor_id', $data['instructor_id'])
                ->where('ac.meeting_pattern_hybrids.day', $data['day'])
                ->where('ac.meeting_pattern_hybrids.date', $data['date'])
                ->where(function ($query) use ($startTime, $endTime) {
                    $query->whereTime('start_time', '<', $endTime)
                        ->whereTime('end_time', '>', $startTime);
                })
                ->exists();
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), Response::HTTP_CONFLICT);
        }
    }

    /**
     * Returns all sections of a term in which the given instructor participates
     * + los workloads de ese instructor en ese term (tipo viewAll, pero filtrado).
     *
     * @param Request $request
     * @return Collection
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewByTermAndInstructor(Request $request)
    {
        try {
            $termId = $request['term_id'];
            $instructorId = $request['instructor_id'];

            $term = Term::find($termId);
            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundById'));
            }
            if (!Instructor::where('id', $instructorId)->exists()) {
                throw new ResourceNotFoundException(trans('academic/instructor.exceptionNotFoundById'));
            }

            $sections = Section::with([
                'term',
                'course',
                'instructorMode',
                'program.contractRates',
                'program.programLevel',
                'program.activityNumber',
                'meetingPatterns.facility',
                'meetingPatterns.instructor.person',
                //  active assignment and contract
                'meetingPatterns.instructor.activeAssignment.salaryAdminPlan',
                'meetingPatterns.instructor.activeAssignment.jobTitle',
                'meetingPatterns.instructor.activeAssignment.assignmentContract',
                'meetingPatterns.instructor.activeAssignmentContract',

                'meetingPatternHybrids.facility.facilityType',
                'meetingPatternHybrids.instructor.person',
                // hybrid
                'meetingPatternHybrids.instructor.activeAssignment.salaryAdminPlan',
                'meetingPatternHybrids.instructor.activeAssignment.jobTitle',
                'meetingPatternHybrids.instructor.activeAssignment.assignmentContract',
                'meetingPatternHybrids.instructor.activeAssignmentContract',

                'combinedSections.combinedSection.course',
                'workloadCourses.workload',
            ])
                ->where('term_id', $termId)
                ->where(function ($q) use ($instructorId) {
                    $q->whereHas('meetingPatterns', fn($q2) => $q2->where('instructor_id', $instructorId))
                        ->orWhereHas('meetingPatternHybrids', fn($q3) => $q3->where('instructor_id', $instructorId));
                })
                ->orderBy('sec_code')
                ->orderBy('sec_number')
                ->get();

            if ($sections->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFound'));
            }

            // 2) Storage WorkloadCourses in memory from the sections
            $workloadCourses = $sections->flatMap->workloadCourses;

            // 3) Make a map by workload_id with overload info
            $overloadByWorkloadId = $workloadCourses
                ->groupBy('workload_id')
                ->map(function ($items) {
                    $hasOverload = $items->contains(fn($wc) => (bool)$wc->overload);
                    $overloadTotal = (float)$items->where('overload', true)->sum(function ($wc) {
                        return (float)($wc->value ?? 0);
                    });

                    // Summary of courses that are in overload
                    $overloadCourses = $items->where('overload', true)->map(function ($wc) {
                        return [
                            'workload_course_id' => $wc->id,
                            'course_id' => $wc->course_id,
                            'section_id' => $wc->section_id,
                            'value' => (float)($wc->value ?? 0),
                            'overload' => (bool)$wc->overload,
                        ];
                    })->values();

                    return [
                        'has_overload' => $hasOverload,
                        'overload_total' => $overloadTotal,
                        'overload_courses' => $overloadCourses,
                    ];
                });

            // 4) Unique from the WorkloadCourses
            $workloads = $workloadCourses
                ->pluck('workload')
                ->filter()
                ->unique('id')
                ->values();

            // Filter by instructor/term/year
            $workloads = $workloads->filter(function ($w) use ($instructorId, $term) {
                $yearOk = (string)$w->academic_year === (string)$term->year
                    || (is_string($w->academic_year) && str_contains($w->academic_year, (string)$term->year));
                $semOk = trim((string)$w->semester) === trim((string)$term->semester);
                $instOk = (string)$w->instructor_id === (string)$instructorId;
                return $yearOk && $semOk && $instOk;
            })->values();

            // 5)Overload data
            $workloads = $workloads->map(function ($w) use ($overloadByWorkloadId) {
                $extra = $overloadByWorkloadId->get($w->id, [
                    'has_overload' => false,
                    'overload_total' => 0.0,
                    'overload_courses' => collect(),
                ]);

                // Derived fields
                $w->setAttribute('has_overload', (bool)($extra['has_overload'] ?? false));
                $w->setAttribute('overload_total', number_format((float)($extra['overload_total'] ?? 0), 2));

                // Overload details
                $w->setAttribute('overload_courses', $extra['overload_courses'] ?? collect());

                if (isset($w['workload'])) $w['workload'] = number_format((float)$w['workload'], 2);
                if (isset($w['release'])) $w['release'] = number_format((float)$w['release'], 2);

                return $w;
            });

            return $sections;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * Build a human-readable audit description for a Section update.
     * - Logs ONLY fields that truly changed
     * - Converts *_id fields to names/codes (no UUIDs)
     * - Normalizes types (bool/int/date) to avoid false positives
     *
     * Usage (inside update BEFORE save):
     *   $updatedSection = $this->dataFormatSection($request, $section, true);
     *   $description = $this->buildSectionAuditDescription($updatedSection, $request);
     */
    private function buildSectionAuditDescription(Section $section, array $request): string
    {
        $lines = [];

        $labels = $this->sectionFieldLabels();

        // If I do NOT want to audit calculated/derived fields, ignore it here.
        $ignoreFields = ['combined'];

        // Local cache to avoid repeatedly hitting DB
        $cache = [
            'term' => [],
            'course' => [],
            'campus' => [],
            'program' => [],
            'mode' => [],
        ];

        $dirty = $section->getDirty();

        foreach ($dirty as $field => $newValue) {

            // Only audit fields
            if (!array_key_exists($field, $labels)) continue;

            // I ignore derivatives
            if (in_array($field, $ignoreFields, true)) continue;

            $oldValue = $section->getOriginal($field);

            // Robust comparison (avoids false positives)
            $oldNorm = $this->normalizeForCompare($field, $oldValue);
            $newNorm = $this->normalizeForCompare($field, $newValue);

            if ($oldNorm === $newNorm) continue;

            // Clear display (name/code/term_number) instead of UUID
            $oldText = $this->resolveSectionFieldDisplayCached($section, $field, $oldValue, $cache);
            $newText = $this->resolveSectionFieldDisplayCached($section, $field, $newValue, $cache);

            if ($oldText === $newText) continue;

            $lines[] = sprintf('• %s: %s → %s', $labels[$field], $oldText, $newText);
        }

        // Relationships
        if (array_key_exists('meeting_patterns', $request)) {
            $lines = array_merge($lines, $this->diffMeetingPatterns($section, $request['meeting_patterns'] ?? []));
        }

        if (array_key_exists('meeting_pattern_hybrids', $request)) {
            $lines = array_merge($lines, $this->diffMeetingPatternHybrids($section, $request['meeting_pattern_hybrids'] ?? []));
        }

        if (array_key_exists('combined_sections', $request)) {
            $lines = array_merge($lines, $this->diffCombinedSections($section, $request['combined_sections'] ?? []));
        }

        return empty($lines)
            ? 'Section was updated (no detected changes).'
            : "Section was updated:\n" . implode("\n", $lines);
    }

    /**
     * Normalize values to compare reliably and avoid false positives.
     */
    private function normalizeForCompare(string $field, $value)
    {
        if ($value === null) return null;

        // bools
        if (in_array($field, ['caps', 'combined', 'dynamic'], true)) {
            // Maneja 0/1, "0"/"1", true/false, "true"/"false"
            $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            return $bool !== null ? $bool : (bool) $value;
        }

        // ints
        if (in_array($field, ['cap', 'capacity', 'student_enrollment'], true)) {
            return (int) $value;
        }

        // fechas
        if (in_array($field, ['starting_date', 'ending_date'], true)) {
            try {
                return Carbon::parse($value)->format('Y-m-d');
            } catch (\Throwable $e) {
                return trim((string) $value);
            }
        }

        return trim((string) $value);
    }

    /**
     * Resolve values for display (names/codes instead of UUIDs/IDs).
     * Uses a per-call cache to avoid repeated DB hits.
     */
    private function resolveSectionFieldDisplayCached(Section $section, string $field, $value, array &$cache): string
    {
        if ($value === null) return 'null';

        // Bool pretty
        if (in_array($field, ['caps', 'combined', 'dynamic'], true)) {
            return $this->normalizeForCompare($field, $value) ? 'Yes' : 'No';
        }

        // dates pretty
        if (in_array($field, ['starting_date', 'ending_date'], true)) {
            try { return Carbon::parse($value)->format('Y-m-d'); } catch (\Throwable $e) {}
            return $this->auditValueToText($value);
        }

        // term_id -> term_number
        if ($field === 'term_id') {
            if (!isset($cache['term'][$value])) {
                $term = $section->relationLoaded('term') ? $section->term : Term::find($value);
                $cache['term'][$value] = $term ? (string)($term->term_number ?? $term->name ?? $term->id) : (string)$value;
            }
            return $cache['term'][$value];
        }

        // course_id -> code/name
        if ($field === 'course_id') {
            if (!isset($cache['course'][$value])) {
                $course = $section->relationLoaded('course') ? $section->course : Course::find($value);
                $cache['course'][$value] = $course ? (string)($course->code ?? $course->name ?? $course->id) : (string)$value;
            }
            return $cache['course'][$value];
        }

        // campus_id -> name/code
        if ($field === 'campus_id') {
            if (!isset($cache['campus'][$value])) {
                $campus = $section->relationLoaded('campus') ? $section->campus : Campus::find($value);
                $cache['campus'][$value] = $campus ? (string)($campus->name ?? $campus->code ?? $campus->id) : (string)$value;
            }
            return $cache['campus'][$value];
        }

        // program_id -> name/code
        if ($field === 'program_id') {
            if (!isset($cache['program'][$value])) {
                $program = $section->relationLoaded('program') ? $section->program : Program::find($value);
                $cache['program'][$value] = $program ? (string)($program->name ?? $program->code ?? $program->id) : (string)$value;
            }
            return $cache['program'][$value];
        }

        // instructor_mode_id -> name/code
        if ($field === 'instructor_mode_id') {
            if (!isset($cache['mode'][$value])) {
                $mode = $section->relationLoaded('instructorMode')
                    ? $section->instructorMode
                    : InstructorMode::find($value);

                $cache['mode'][$value] = $mode ? (string)($mode->name ?? $mode->code ?? $mode->id) : (string)$value;
            }
            return $cache['mode'][$value];
        }

        return $this->auditValueToText($value);
    }

    /**
     * Basic value to text (fallback).
     */
    private function auditValueToText($value): string
    {
        if ($value === null) return 'null';
        if (is_bool($value)) return $value ? 'true' : 'false';
        if (is_array($value)) return json_encode($value);

        $v = trim((string) $value);
        return $v === '' ? '""' : $v;
    }


    /**
     * Friendly labels (so timeline reads nicely).
     * Ajusta a tus nombres reales de columna en ac.sections.
     */
    private function sectionFieldLabels(): array
    {
        return [
            'sec_code' => 'Course Code',
            'sec_number' => 'Section Number',
            'sec_sess' => 'Session',
            'status' => 'Status',
            'capacity' => 'Capacity',
            'starting_date' => 'Start Date',
            'ending_date' => 'End Date',
            'caps' => 'Caps',
            'term_id' => 'Term',
            'course_id' => 'Course',
            'cap' => 'Cap',
            'instructor_mode_id' => 'Instructor Mode',
            'campus_id' => 'Campus',
            'program_id' => 'Program',
            'cohorts' => 'Cohorts',
            'combined' => 'Combined',
            'dynamic' => 'Dynamic',
            'comment' => 'Comment',
            'internal_note' => 'Internal Note',
            'student_enrollment' => 'Student Enrollment',
        ];
    }

    private function diffMeetingPatterns(Section $section, array $newItems): array
    {
        // OLD (from BD)
        $oldItems = $section->meetingPatterns->map(function ($mp) {
            return [
                'day' => $mp->day,
                'start_time' => $mp->start_time,
                'end_time' => $mp->end_time,
                'facility_id' => $mp->facility_id,
                'instructor_id' => $mp->instructor_id,
                'primary_instructor' => $mp->primary_instructor,
            ];
        })->values()->all();

        // Index by key (without role) to detect "updates"
        $oldByKey = [];
        foreach ($oldItems as $o) {
            $oldByKey[$this->meetingPatternKey($o)] = $o;
        }

        $newByKey = [];
        foreach ($newItems as $n) {
            $newByKey[$this->meetingPatternKey($n)] = $n;
        }

        $lines = [];

        // 1) Detects updates (same key, different role)
        $updates = [];
        foreach ($newByKey as $key => $n) {
            if (!isset($oldByKey[$key])) continue;

            $o = $oldByKey[$key];

            $oldRole = is_numeric($o['primary_instructor'] ?? null) ? (int)$o['primary_instructor'] : ($o['primary_instructor'] ?? null);
            $newRole = is_numeric($n['primary_instructor'] ?? null) ? (int)$n['primary_instructor'] : ($n['primary_instructor'] ?? null);

            if ($oldRole !== $newRole) {
                $updates[] = [
                    'old' => $o,
                    'new' => $n,
                ];
            }
        }

        foreach ($updates as $u) {
            $base = $this->meetingPatternSignature([
                'day' => $u['new']['day'] ?? '',
                'start_time' => $u['new']['start_time'] ?? '',
                'end_time' => $u['new']['end_time'] ?? '',
                'facility_id' => $u['new']['facility_id'] ?? null,
                'instructor_id' => $u['new']['instructor_id'] ?? null,
                'primary_instructor' => $u['new']['primary_instructor'] ?? null,
            ], $section);

            $oldRoleLabel = $this->roleLabel($u['old']['primary_instructor'] ?? null);
            $newRoleLabel = $this->roleLabel($u['new']['primary_instructor'] ?? null);

            $lines[] = "• Meeting Pattern updated: {$base} (Role: {$oldRoleLabel} → {$newRoleLabel})";
        }

        // 2) Added: new keys
        $addedKeys = array_diff(array_keys($newByKey), array_keys($oldByKey));
        if (!empty($addedKeys)) {
            $addedSigs = [];
            foreach ($addedKeys as $k) {
                $addedSigs[] = $this->meetingPatternSignature($newByKey[$k], $section);
            }
            $lines[] = '• Meeting Patterns added: ' . implode(' | ', $addedSigs);
        }

        // 3) Removed: keys that are no longer there
        $removedKeys = array_diff(array_keys($oldByKey), array_keys($newByKey));
        if (!empty($removedKeys)) {
            $removedSigs = [];
            foreach ($removedKeys as $k) {
                $removedSigs[] = $this->meetingPatternSignature($oldByKey[$k], $section);
            }
            $lines[] = '• Meeting Patterns removed: ' . implode(' | ', $removedSigs);
        }

        return $lines;
    }

    private function diffMeetingPatternHybrids(Section $section, array $newItems): array
    {
        $old = $section->meetingPatternHybrids->map(fn($mp) => $this->meetingPatternHybridSignature([
            'day' => $mp->day,
            'date' => $mp->date,
            'start_time' => $mp->start_time,
            'end_time' => $mp->end_time,
            'facility_id' => $mp->facility_id,
            'instructor_id' => $mp->instructor_id,
            'primary_instructor' => $mp->primary_instructor,
        ]))->values()->all();

        $new = collect($newItems)->map(fn($mp) => $this->meetingPatternHybridSignature($mp))->values()->all();

        $added = array_values(array_diff($new, $old));
        $removed = array_values(array_diff($old, $new));

        $lines = [];
        if (!empty($added)) $lines[] = '• Hybrid Patterns added: ' . implode(' | ', $added);
        if (!empty($removed)) $lines[] = '• Hybrid Patterns removed: ' . implode(' | ', $removed);

        return $lines;
    }

    /**
     * combined_sections payload:
     *   [{ "section_id": "<uuid>" }, ...]
     *
     * DB combined table:
     *   section_id (main), section_id_combined (combined)
     *
     * Policy:
     * - NEVER show "removed"
     * - If there was any change, show the FINAL combined list
     */
    private function diffCombinedSections(Section $section, array $newItems): array
    {
        // OLD (from DB): section_id_combined
        $oldIds = $section->combinedSections
            ->pluck('section_id_combined')
            ->filter()
            ->map(fn($id) => (string)$id)
            ->values()
            ->all();

        // NEW (from request): section_id
        $newIds = collect($newItems)
            ->map(fn($item) => is_array($item) ? ($item['section_id'] ?? null) : $item)
            ->filter()
            ->map(fn($id) => (string)$id)
            ->values()
            ->all();

        // Compare as sets (order-independent)
        $oldSet = $oldIds; sort($oldSet);
        $newSet = $newIds; sort($newSet);

        // If no change, don't log combined
        if ($oldSet === $newSet) {
            return [];
        }

        // Show final list (human-readable)
        if (empty($newIds)) {
            // You can choose what you want to display when they remove all combined sections:
            // return ['• Combined Sections updated: (none)'];
            return ['• Combined Sections updated: (none)'];
        }

        $finalDisplay = array_map(fn($id) => $this->resolveSectionDisplay($id), $newIds);

        return [
            '• Combined Sections updated: ' . implode(' | ', $finalDisplay),
        ];
    }

    private function resolveSectionDisplay(string $sectionId): string
    {
        if (isset($this->auditSectionCache[$sectionId])) {
            return $this->auditSectionCache[$sectionId];
        }

        $s = Section::query()
            ->select(['id', 'sec_code', 'sec_number', 'sec_sess'])
            ->find($sectionId);

        if (!$s) {
            return $this->auditSectionCache[$sectionId] = $sectionId; // fallback
        }

        $code = trim((string)($s->sec_code ?? ''));
        $num  = trim((string)($s->sec_number ?? ''));
        $sess = trim((string)($s->sec_sess ?? ''));

        $label = trim($code . '-' . $num);

        // sec_sess puede ser null
        if ($sess !== '') {
            $label .= " (Sess {$sess})";
        }

        return $this->auditSectionCache[$sectionId] = ($label !== '' ? $label : $sectionId);
    }

    private function meetingPatternSignature(array $mp, ?Section $section = null): string
    {
        $day  = trim((string)($mp['day'] ?? ''));

        $from = $this->normalizeTime($mp['start_time'] ?? null);
        $to   = $this->normalizeTime($mp['end_time'] ?? null);

        $facilityId   = $mp['facility_id'] ?? null;
        $instructorId = $mp['instructor_id'] ?? null;

        $facilityName   = $this->resolveFacilityName($facilityId, $section);
        $instructorName = $this->resolveInstructorName($instructorId, $section);

        $roleValue = $mp['primary_instructor'] ?? null;
        $roleLabel = $this->roleLabel($roleValue);

        return "{$day} {$from}-{$to} | {$facilityName} | {$instructorName} | {$roleLabel}";
    }

    private function resolveFacilityName($facilityId, ?Section $section = null): string
    {
        if (!$facilityId) return '';

        if (isset($this->auditNameCache['facility'][$facilityId])) {
            return $this->auditNameCache['facility'][$facilityId];
        }

        // si ya está cargado por relación, úsalo
        if ($section && $section->relationLoaded('meetingPatterns')) {
            $found = $section->meetingPatterns->firstWhere('facility_id', $facilityId);
            if ($found && $found->relationLoaded('facility') && $found->facility) {
                return $this->auditNameCache['facility'][$facilityId] =
                    (string)($found->facility->name ?? $found->facility->code ?? $facilityId);
            }
        }

        // fallback: query
        $facility = Facility::find($facilityId);
        return $this->auditNameCache['facility'][$facilityId] =
            $facility ? (string)($facility->name ?? $facility->code ?? $facilityId) : (string)$facilityId;
    }

    private function resolveInstructorName($instructorId, ?Section $section = null): string
    {
        if (!$instructorId) return '';

        if (isset($this->auditNameCache['instructor'][$instructorId])) {
            return $this->auditNameCache['instructor'][$instructorId];
        }

        // If it's already loaded by relationship, I can use it.
        if ($section && $section->relationLoaded('meetingPatterns')) {
            $found = $section->meetingPatterns->firstWhere('instructor_id', $instructorId);
            if ($found && $found->relationLoaded('instructor') && $found->instructor) {

                // instructor.person
                if ($found->instructor->relationLoaded('person') && $found->instructor->person) {
                    $name = trim(($found->instructor->person->first_name ?? '') . ' ' . ($found->instructor->person->last_name ?? ''));
                    return $this->auditNameCache['instructor'][$instructorId] = ($name !== '' ? $name : (string)$instructorId);
                }

                // Instructor has direct fullName (if it exists)
                if (!empty($found->instructor->fullName)) {
                    return $this->auditNameCache['instructor'][$instructorId] = (string)$found->instructor->fullName;
                }
            }
        }

        $instructor = Instructor::with('person')->find($instructorId);

        if ($instructor && $instructor->person) {
            $name = trim(($instructor->person->first_name ?? '') . ' ' . ($instructor->person->last_name ?? ''));
            return $this->auditNameCache['instructor'][$instructorId] = ($name !== '' ? $name : (string)$instructorId);
        }

        return $this->auditNameCache['instructor'][$instructorId] = (string)$instructorId;
    }
    private function roleLabel($value): string
    {
        $map = [
            1 => 'Primary',
            2 => 'Secondary',
            3 => 'Course assistant',
            4 => 'Administrative',
        ];

        $v = is_numeric($value) ? (int)$value : null;

        return $v !== null && array_key_exists($v, $map)
            ? $map[$v]
            : ('Role ' . (string)$value);
    }

    private function normalizeTime($value): string
    {
        if ($value === null) return '';

        $s = trim((string)$value);
        if ($s === '') return '';

        // Remove fractions like .0000000 if they come from SQL Server
        $s = preg_replace('/\.\d+$/', '', $s);

        // If the full datetime is coming, try parsing it.
        try {
            return Carbon::parse($s)->format('H:i');
        } catch (Throwable $e) {
            // If it comes in HH:MM:SS
            if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $s)) {
                return substr($s, 0, 5); // HH:MM
            }
            // fallback
            return $s;
        }
    }

    private function meetingPatternHybridSignature(array $mp): string
    {
        $day = $mp['day'] ?? '';
        $date = $mp['date'] ?? '';
        $from = $mp['start_time'] ?? '';
        $to = $mp['end_time'] ?? '';
        $facility = $mp['facility_id'] ?? '';
        $instructor = $mp['instructor_id'] ?? '';
        $role = $mp['primary_instructor'] ?? '';

        return "{$day} {$date} {$from}-{$to} | facility={$facility} | instructor={$instructor} | role={$role}";
    }

    private function meetingPatternKey(array $mp): string
    {
        $day  = trim((string)($mp['day'] ?? ''));
        $from = $this->normalizeTime($mp['start_time'] ?? null);
        $to   = $this->normalizeTime($mp['end_time'] ?? null);

        $facilityId   = (string)($mp['facility_id'] ?? '');
        $instructorId = (string)($mp['instructor_id'] ?? '');

        return "{$day}|{$from}|{$to}|{$facilityId}|{$instructorId}";
    }

}
