<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Models\academic\ProgramLevel;
use App\Exceptions\ResourceNotFoundException;

class ProgramLevelRepository implements CrudInterface,ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $programLevel = ProgramLevel::where('ac.program_levels.active','=',$status)
                ->orderBy('level', 'desc')->get();
            if ($programLevel->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program_level.exceptionNotFoundByStatus'));
            }
            return $programLevel;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $programLevel = ProgramLevel::orderBy('level', 'desc')->get();
            if ($programLevel->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/program_level.exceptionNotFound'));
            }
            return $programLevel;
        } catch (ResourceNotFoundException $e){
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $programLevel = ProgramLevel::find($id);
            if (!$programLevel){
                throw new ResourceNotFoundException(trans('academic/program_level.exceptionNotFoundById'));
            }
            return $programLevel;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $programLevel = new ProgramLevel();
            $newProgramLevel = $this->dataForProgramLevel($request,$programLevel);
            $newProgramLevel->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgramLevel->id,
                'created',
                'Program level',
                'A new type of Program level was created: ' . $newProgramLevel->name,
            );

            return $newProgramLevel;
        }  catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $programLevel = $this->viewById($id);
            if (!$programLevel){
                throw new ResourceNotFoundException(trans('academic/program_level.exceptionNotFoundById'));
            }
            $newProgramLevel = $this->dataForProgramLevel($request,$programLevel);
            $newProgramLevel->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newProgramLevel->id,
                'updated',
                'Program level',
                'Program level was updated: ' . $newProgramLevel->name,
            );

            return $newProgramLevel;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $programLevel = $this->viewById($id);
            if (!$programLevel){
                throw new ResourceNotFoundException(trans('academic/program_level.exceptionNotFoundById'));
            }
            $programLevel->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $programLevel->id,
                'deleted',
                'Program level',
                'Program level was deleted: ' . $programLevel->name,
            );

            return $programLevel;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataForProgramLevel(array $request, ProgramLevel $programLevel):object|null
    {
        $programLevel->name = $request['name'];
        $programLevel->level = $request['level'];
        $programLevel->active = $request['active'];
        return $programLevel;
    }
}
