<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\academic\SubQualification;
use App\Exceptions\ResourceNotFoundException;

class SubQualificationRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
{
    try {
        $subQualification = SubQualification::orderBy('code', 'asc')->get();
        if ($subQualification->isEmpty()) {
            throw new ResourceNotFoundException(trans('academic/sub_qualification.exceptionNotFound'));
        }
        return $subQualification;
    } catch (ResourceNotFoundException $e) {
        Log::error($e);
        throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
    } catch (Exception $e) {
        Log::error($e);
        throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
    }
}

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
{
    try {
        $subQualification = SubQualification::where('active', $status)->orderBy('code', 'asc')->get();
        if ($subQualification->isEmpty()) {
            throw new ResourceNotFoundException(trans('academic/sub_qualification.exceptionNotFoundByStatus'));
        }
        return $subQualification;
    } catch (ResourceNotFoundException $e) {
        Log::error($e);
        throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
    } catch (Exception $e) {
        Log::error($e);
        throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
    }
}

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
{
    try {
        $subQualification = new SubQualification();
        $newSubQualification = $this->dataFormat($request, $subQualification);
        $newSubQualification->save();

        // Store activity timeline
        ActivityTimeLineHelper::store(
            $newSubQualification->id,
            'created',
            'Sub-Qualification',
            'A new type of Sub-Qualification was created: ' . $newSubQualification->name,
        );

        return $newSubQualification;
    } catch (Exception $e) {
        Log::error($e);
        throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
    }
}

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
{
    try {
        $subQualification = SubQualification::find($id);
        if (!$subQualification) {
            throw new ResourceNotFoundException(trans('academic/sub_qualification.exceptionNotFoundById'));
        }
        $newSubQualification = $this->dataFormat($request, $subQualification);
        $newSubQualification->update();

        // Store activity timeline
        ActivityTimeLineHelper::store(
            $newSubQualification->id,
            'updated',
            'Sub-Qualification',
            'Sub-Qualification was updated: ' . $newSubQualification->name,
        );

        return $newSubQualification;
    } catch (ResourceNotFoundException $e) {
        Log::error($e);
        throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
    } catch (Exception $e) {
        Log::error($e);
        throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
    }
}

    public function dataFormat(array $request, SubQualification $subQualification): object|null
{
    $subQualification->code = $request['code'];
    $subQualification->description = $request['description'];
    $subQualification->active = $request['active'];
    return $subQualification;
}
}
