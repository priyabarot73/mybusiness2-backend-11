<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT;
use App\Models\academic\Instructor;
use App\Exceptions\ResourceNotFoundException;

class InstructorRepository
{

    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'first_name');
            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'asc')));

            // filters (array)
            $filterModel = $request->query('filters'); // array|null

            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'asc';
            }

            $query = Instructor::query()
                ->with(['person', 'employeeType', 'qualificationType', 'subQualification', 'tenureType'])
                ->join('hr.persons', 'ac.instructors.person_id', '=', 'hr.persons.id')
                ->leftJoin('hr.employee_types', 'ac.instructors.employee_type_id', '=', 'hr.employee_types.id')
                ->leftJoin('ass.tenure_types', 'ac.instructors.tenure_type_id', '=', 'ass.tenure_types.id')
                ->leftJoin('ac.qualification_types', 'ac.instructors.qualification_type_id', '=', 'ac.qualification_types.id')
                ->leftJoin('ac.sub_qualifications', 'ac.instructors.sub_qualification_id', '=', 'ac.sub_qualifications.id')
                ->select('ac.instructors.*');

            // Search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(hr.persons.first_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.last_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.middle_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.panther_id) LIKE ?", ["%$search%"]);
                });
            }

            // Filters (server-side)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {
                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and | or

                $likePattern = function (string $value, string $operator): string {
                    $v = strtolower(trim($value));
                    return match ($operator) {
                        'equals', '=' => $v,
                        'startsWith' => $v . '%',
                        'endsWith' => '%' . $v,
                        default => '%' . $v . '%', // contains
                    };
                };

                $query->where(function ($q) use ($filterModel, $logic, $likePattern) {
                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        if (!$field || $value === null || $value === '') {
                            continue;
                        }

                        $apply = function ($subQ) use ($field, $operator, $value, $likePattern) {

                            // 1) Column "first_name"
                            if ($field === 'first_name') {
                                $pattern = $likePattern((string) $value, (string) $operator);

                                return $subQ->where(function ($x) use ($pattern) {
                                    $x->whereRaw("LOWER(hr.persons.first_name) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(hr.persons.last_name) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(hr.persons.middle_name) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(hr.persons.panther_id) LIKE ?", [$pattern]);
                                     $x->orWhereRaw("LOWER(hr.persons.business_email) LIKE ?", [$pattern]);
                                });
                            }

                            // 2) employeeType / tenureType / qualificationType / subQualification
                            if ($field === 'employeeType') {
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(hr.employee_types.code) LIKE ?", [$pattern]);
                            }

                            if ($field === 'tenureType') {
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(ass.tenure_types.code) LIKE ?", [$pattern]);
                            }

                            if ($field === 'qualificationType') {
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(ac.qualification_types.code) LIKE ?", [$pattern]);
                            }

                            if ($field === 'subQualification') {
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(ac.sub_qualifications.code) LIKE ?", [$pattern]);
                            }

                            // 3) qualification
                            if ($field === 'qualification') {
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(ac.instructors.qualification) LIKE ?", [$pattern]);
                            }

                            // 4) booleans in instructors
                            if (in_array($field, ['doctorate', 'active'])) {
                                $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                                return $subQ->where("ac.instructors.$field", $bool ? 1 : 0);
                            }

                            // 5) aacsb (if it's boolean in DB)
                            if ($field === 'aacsb') {
                                // Si en tu DB es boolean/tinyint:
                                $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);

                                if ($bool !== null) {
                                    return $subQ->where("ac.instructors.aacsb", $bool ? 1 : 0);
                                }

                                // If aacsb is string (e.g. 'Yes'/'No'), use LIKE:
                                $pattern = $likePattern((string) $value, (string) $operator);
                                return $subQ->whereRaw("LOWER(ac.instructors.aacsb) LIKE ?", [$pattern]);
                            }

                            return null;
                        };

                        if ($logic === 'or') {
                            $q->orWhere(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        } else {
                            $q->where(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        }
                    }
                });
            }

            // Sorting
            $sortableColumns = [
                'first_name', 'last_name', 'middle_name', 'panther_id',
                'created_at', 'doctorate', 'employeeType', 'qualification', 'aacsb',
                'tenureType', 'qualificationType', 'subQualification', 'active'
            ];

            if (in_array($sortColumn, $sortableColumns)) {
                $personsCols = ['first_name', 'last_name', 'middle_name', 'panther_id'];

                if (in_array($sortColumn, $personsCols)) {
                    $column = "hr.persons.$sortColumn";
                } elseif ($sortColumn === 'employeeType') {
                    $column = "hr.employee_types.code";
                } elseif ($sortColumn === 'tenureType') {
                    $column = "ass.tenure_types.code";
                } elseif ($sortColumn === 'qualificationType') {
                    $column = "ac.qualification_types.code";
                } elseif ($sortColumn === 'subQualification') {
                    $column = "ac.sub_qualifications.code";
                } else {
                    $column = "ac.instructors.$sortColumn";
                }

                $query->orderBy($column, $sortDirection);
            }

            $instructors = $query->paginate($perPage, ['*'], 'page', $page);

            if ($instructors->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/instructor.exceptionNotFound'));
            }

            return $instructors;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByStatus(Request $request, $status): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'first_name');
            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'asc')));

            // sanitize
            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'asc';
            }

            // base query with join for person
            $query = Instructor::query()
                ->where('ac.instructors.active', '=', $status)
                ->with([
                    'person',
                    'employeeType',
                    'qualificationType',
                    'subQualification',
                    'tenureType'
                ])
                ->join('hr.persons', 'ac.instructors.person_id', '=', 'hr.persons.id')
                ->leftJoin('hr.employee_types', 'ac.instructors.employee_type_id', '=', 'hr.employee_types.id')
                ->leftJoin('ass.tenure_types', 'ac.instructors.tenure_type_id', '=', 'ass.tenure_types.id')
                ->leftJoin('ac.qualification_types', 'ac.instructors.qualification_type_id', '=', 'ac.qualification_types.id')
                ->leftJoin('ac.sub_qualifications', 'ac.instructors.sub_qualification_id', '=', 'ac.sub_qualifications.id')
                ->select('ac.instructors.*');

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(hr.persons.first_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.last_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.middle_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.panther_id) LIKE ?", ["%$search%"]);
                });
            }

            // columns to sort
            $sortableColumns = ['first_name', 'last_name', 'middle_name', 'panther_id', 'created_at', 'doctorate','employeeType','qualification','aacsb','tenureType','qualificationType','subQualification'];

            // apply sorting
            if (in_array($sortColumn, $sortableColumns)) {
                $personsCols = ['first_name', 'last_name', 'middle_name', 'panther_id'];

                if (in_array($sortColumn, $personsCols)) {
                    $column = "hr.persons.$sortColumn";
                } elseif ($sortColumn === 'employeeType') {
                    $column = "hr.employee_types.code";
                } elseif ($sortColumn === 'tenureType') {
                    $column = "ass.tenure_types.code";
                } elseif ($sortColumn === 'qualificationType') {
                    $column = "ac.qualification_types.code";
                } elseif ($sortColumn === 'subQualification') {
                    $column = "ac.sub_qualifications.code";
                } else {
                    $column = "ac.instructors.$sortColumn";
                }

                $query->orderBy($column, $sortDirection);
            }

            // paginate
            $instructors = $query->paginate($perPage, ['*'], 'page', $page);

            if ($instructors->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/instructor.exceptionNotFoundByStatus'));
            }

            return $instructors;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $instructor = new Instructor();
            $newInstructor = $this->dataFormat($request,$instructor);
            $newInstructor->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newInstructor->id,
                'created',
                'Instructor',
                'A new type of Instructor was created: ' . $newInstructor->name,
            );

            return $newInstructor;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $instructor = Instructor::find($id);
            if (!$instructor){
                throw new ResourceNotFoundException(trans('academic/instructor.exceptionNotFoundById'));
            }
            $newInstructor = $this->dataFormat($request,$instructor);
            $newInstructor->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newInstructor->id,
                'updated',
                'Instructor',
                'A new type of Instructor was updated: ' . $newInstructor->name,
            );

            return $newInstructor;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Instructor $instructor):object|null
    {
        try {
            $instructor->person_id = $request['person_id'];
            $instructor->employee_type_id = $request['employee_type_id'];
            $instructor->tenure_type_id = $request['tenure_type_id'];
            $instructor->doctorate = $request['doctorate'];
            $instructor->qualification = $request['qualification'];
            $instructor->qualification_type_id = $request['qualification_type_id'];
            $instructor->sub_qualification_id = $request['sub_qualification_id'];
            $instructor->aacsb = $request['aacsb'];
            $instructor->active = $request['active'];
            return $instructor;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
