<?php

namespace App\Repositories\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Helpers\CoursesScheduleByRoomReportHelper;
use App\DTOs\CoursesScheduleByRoomReportDTO;

class CoursesScheduleByRoomReportRepository
{
    /**
     * Generate a report for a specific term with pagination and search
     *
     * @param Request $request
     * @param int $termNumber
     * @return array
     * @throws ResourceNotFoundException|Exception
     */
    public function generateReport(Request $request, string $termNumber): LengthAwarePaginator
    {
        try {
            // Get term ID first
            $term = DB::table('ac.terms')
                ->where('number', $termNumber)
                ->first();

            if (!$term) {
                throw new ResourceNotFoundException(
                    trans('academic/reports.courses_schedule_by_room_report.exceptionNotFound'),
                    Response::HTTP_NOT_FOUND
                );
            }

            // Extract pagination parameters
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn');
            $sortDirection = $request->query('sortDirection', 'desc');
            
            $query = DB::table('ac.sections')
                ->join('ac.terms', 'ac.sections.term_id', '=', 'ac.terms.id')
                ->leftJoin('ac.meeting_patterns', 'ac.sections.id', '=', 'ac.meeting_patterns.section_id')
                ->leftjoin('ac.courses', 'ac.sections.course_id', '=', 'ac.courses.id')
                ->leftJoin('ac.instructors', 'ac.meeting_patterns.instructor_id', '=', 'ac.instructors.id')
                ->leftJoin('hr.persons', 'ac.instructors.person_id', '=', 'hr.persons.id')
                ->leftJoin('ac.programs', 'ac.sections.program_id', '=', 'ac.programs.id')
                ->leftJoin('gn.campuses', 'ac.sections.campus_id', '=', 'gn.campuses.id')
                ->where('ac.terms.id', $term->id)
                ->select([
                    DB::raw('ac.sections.id as section_id'),
                    DB::raw('RTRIM(ac.meeting_patterns.day) as day'),
                    DB::raw("CONVERT(VARCHAR(5), ac.meeting_patterns.start_time, 108) as start_time"),
                    DB::raw("CONVERT(VARCHAR(5), ac.meeting_patterns.end_time, 108) as end_time"),
                    DB::raw('RTRIM(ac.courses.code) as course'),
                    DB::raw('RTRIM(ac.sections.sec_number) as section'),
                    DB::raw("CONCAT(hr.persons.first_name, ' ', hr.persons.last_name) as instructor"),
                    DB::raw('RTRIM(gn.campuses.name) as location'),
                    DB::raw('RTRIM(ac.sections.cap) as cap'),
                    DB::raw('RTRIM(ac.programs.code) as program')
                ])
                ->distinct()
                ->orderBy('section_id');

            // Apply search if provided
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(ac.meeting_patterns.day) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.sec_number) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.first_name + ' ' + hr.persons.last_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.campuses.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.programs.code) LIKE ?", ["%$search%"]);

                    /*$q->whereRaw("LOWER(ac.terms.academic_year) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.terms.semester + ' ' + CAST(ac.terms.year AS VARCHAR)) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.references_number_panther) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.sec_code + ac.sections.sec_number) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.sec_sess) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.departments.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.instructor_modes.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.campuses.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.programs.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.cohorts) LIKE ?", ["%$search%"]);*/
                });
            }

            // Apply sorting
            if ($sortColumn) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // Execute paginated query
            $results = $query->distinct()->paginate($perPage, ['*'], 'page', $page);

            // Reemplazar los items del paginador
            //$results->setCollection(collect(CoursesScheduleByRoomReportHelper::formatReport($results->items())));
            $results->setCollection(collect(CoursesScheduleByRoomReportHelper:: formatReport($results->items())));

            return $results;

        } catch (Exception $e) {
            Log::error('Error in generateReport: ' . $e->getMessage());
            throw $e;
        }
    }
}
