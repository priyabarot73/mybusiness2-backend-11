<?php

namespace App\Repositories\v1\academic\reports;

use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use App\Models\academic\Term;
use App\Models\academic\Workload;
use App\Models\academic\Instructor;
use App\Exceptions\ResourceNotFoundException;

class WorkloadInformationReportRepository
{
    /**
     * Generate a detailed Section-Level Workload Information Report
     *
     * @param Request $request
     * @param string $termNumber
     * @return LengthAwarePaginator
     * @throws ResourceNotFoundException|Exception
     */
    public function generateReport(Request $request, string $termNumber): LengthAwarePaginator
    {
        try {
            // Step 0: Load term
            $term = Term::where('number', $termNumber)->first();
            if (!$term) {
                throw new ResourceNotFoundException(
                    trans('academic/reports.instructor_workload_report.exceptionNotFound'),
                    Response::HTTP_NOT_FOUND
                );
            }

            // Pagination params
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');

            // Step 1: Load instructors (with optional search)
            $instructorsQuery = Instructor::with([
                'person.department',
                'workloads.workLoadCourses.course.program',
                'workloads.workLoadCourses.section'
            ]);

            if (!empty($search)) {
                $instructorsQuery->whereHas('person', function ($q) use ($search) {
                    $searchLower = strtolower($search);
                    $q->whereRaw("LOWER(first_name + ' ' + last_name) LIKE ?", ["%$searchLower%"]);
                });
            }

            $instructorIds = $instructorsQuery->pluck('id');

            // Step 2: Load workloads for term
            $workloadsQuery = Workload::whereIn('instructor_id', $instructorIds)
                ->where('academic_year', $term->academic_year)
                ->with([
                    'instructor.person.department',
                    'workLoadCourses.course.program',
                    'workLoadCourses.section'
                ]);

            $semester = strtolower($term->semester);

            if (str_contains($semester, 'summer')) {
                // Summer stands alone (Summer 2023 → Summer 2023)
                $workloadsQuery
                    ->where('semester', 'Summer')
                    ->where('academic_year', $term->academic_year);
            } else {
                // Fall + Spring belong to the same academic year
                // Fall 2024 → Fall 2024 + Spring 2025
                // Spring 2025 → Fall 2024 + Spring 2025
                $workloadsQuery
                    ->whereIn('semester', ['Fall', 'Spring'])
                    ->where('academic_year', $term->academic_year);
            }

            $workloads = $workloadsQuery->get();

            // Step 3: Preload combined_sections & meeting patterns for performance
            $sectionIds = $workloads->flatMap(fn($w) => $w->workLoadCourses->pluck('section_id'))->unique();

            // Preload combined_sections
            $combinedSections = DB::table('ac.combined_sections')
                ->whereIn('section_id', $sectionIds)
                ->pluck('section_id_combined', 'section_id');

            // Load references_number_panther for combined sections
            $combinedRefNumbers = DB::table('ac.sections')
                ->whereIn('id', $combinedSections->values())
                ->pluck('references_number_panther', 'id');

            // Preload meeting patterns
            $meetingPatterns = DB::table('ac.meeting_patterns')
                ->whereIn('section_id', $sectionIds)
                ->get()
                ->groupBy('section_id');

            $meetingHybrids = DB::table('ac.meeting_pattern_hybrids')
                ->whereIn('section_id', $sectionIds)
                ->get()
                ->groupBy('section_id');


            // Step 4: Build section-level report
            $data = [];

            foreach ($workloads as $workload) {
                $instructor = $workload->instructor;
                $person = $instructor->person;
                $department = $person->department->name ?? '';
                $semesterYear = $workload->semester === 'Spring'
                    ? $term->year + 1
                    : $term->year;

                $semester = $workload->semester . ' ' . $semesterYear;


                foreach ($workload->workLoadCourses as $wlc) {
                    $course = $wlc->course;
                    $section = $wlc->section;

                    // Resolve Combined Reference ID (references_number_panther of combined section)
                    $combinedSectionId = $combinedSections->get($section->id);

                    $combinedRef = $combinedSectionId
                        ? $combinedRefNumbers->get($combinedSectionId, '')
                        : '';

                    $mpPatterns = $meetingPatterns->get($section->id, collect());
                    $mpHybrids = $meetingHybrids->get($section->id, collect());

                    $mp = $mpPatterns->first(fn($m) => $m->instructor_id == $instructor->id && $m->primary_instructor == 1)
                        ?? $mpHybrids->first(fn($m) => $m->instructor_id == $instructor->id && $m->primary_instructor == 1);

                    $isPrimary = $mp ? 'Y' : 'N';
                    $location = '';

                    if ($mp && !empty($mp->facility_id)) {
                        $location = DB::table('gn.facilities')
                            ->where('id', $mp->facility_id)
                            ->value('code') ?? '';
                    }
                    $day = $mp->day ?? '';
                    
                    $time = '';

                    if ($mp && $mp->start_time && $mp->end_time) {
                        $startRaw = substr($mp->start_time, 0, 8); // HH:MM:SS
                        $endRaw   = substr($mp->end_time, 0, 8);   // HH:MM:SS

                        $start = Carbon::createFromFormat('H:i:s', $startRaw)->format('H:i');
                        $end   = Carbon::createFromFormat('H:i:s', $endRaw)->format('H:i');

                        $time = "{$start}-{$end}";
                    }

                    $comment = trim(preg_replace('/\s+/', ' ', $section->comment ?? ''));

                    $data[] = [
                        'Instructor Name' => trim(($person->first_name ?? '') . ' ' . ($person->last_name ?? '')),
                        'Panther ID' => $person->panther_id ?? '',
                        'Salary' => '$0.00',
                        'Department' => $department,
                        'Semester' => $semester,
                        'Program' => $course->program->code ?? '',
                        'Cohort' => $section->cohorts ?? '',
                        'Course' => $course->code ?? '',
                        'Section' => ($section->sec_code ?? '') . ($section->sec_number ?? ''),
                        'Reference ID' => $section->references_number_panther ?? '',
                        'Combined Reference ID' => $combinedRef,
                        'Primary' => $isPrimary,
                        'Instruction Mode' => $section->instructorMode->code ?? '',
                        'Course Name' => $course->name ?? '',
                        'Adjusted' => $wlc->adjusted ?? 0,
                        'Overload' => $wlc->overload ?? 0,
                        'On Contract' => '-',
                        'Capacity' => $section->cap ?? 0,
                        'Enrollment' => $section->student_enrollment ?? 0,
                        'Credit' => ($course->credit ?? '') . '-' . ($course->hour ?? ''),
                        'Location' => $location?? '',
                        'Day' => $day,
                        'Time' => $time,
                        'Comments' => $comment ?? '',
                    ];
                }
            }

            // Step 5: Paginate manually
            $total = count($data);
            $items = array_slice($data, ($page - 1) * $perPage, $perPage);
            return new \Illuminate\Pagination\LengthAwarePaginator($items, $total, $perPage, $page);

        } catch (Exception $e) {
            Log::error('Error in generateReport: ' . $e->getMessage());
            throw $e;
        }
    }
}
