<?php

namespace App\Repositories\v1\academic\reports;

use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use App\Models\academic\Term;
use App\Models\academic\Workload;
use App\Models\academic\Instructor;
use App\Exceptions\ResourceNotFoundException;

class InstructorWorkloadReportRepository
{
    /**
     * Generate a detailed instructor workload report
     *
     * @param Request $request
     * @param string $termNumber
     * @return LengthAwarePaginator
     * @throws ResourceNotFoundException|Exception
     */
    public function generateReport(Request $request, string $termNumber): LengthAwarePaginator
    {
        try {
            // Get term
            $term = Term::where('number', $termNumber)->first();
            if (!$term) {
                throw new ResourceNotFoundException(
                    trans('academic/reports.instructor_workload_report.exceptionNotFound'),
                    Response::HTTP_NOT_FOUND
                );
            }

            // Pagination params
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');

            // Step 1: Filter instructors
            $instructorsQuery = Instructor::with([
                'person.department',
                'employeeType',   
                'assignments',
                'workloads.workLoadCourses.course.program.offering',
                'workloads.workLoadCourses.section'
            ]);

            if (!empty($search)) {
                $instructorsQuery->whereHas('person', function ($q) use ($search) {
                    $searchLower = strtolower($search);
                    $q->whereRaw("LOWER(first_name + ' ' + last_name) LIKE ?", ["%$searchLower%"]);
                });
            }

            $instructorIds = $instructorsQuery->pluck('id');

            // Step 2: Get workloads for term
            $workloadsQuery = Workload::whereIn('instructor_id', $instructorIds)
                ->where('academic_year', $term->academic_year)
                ->with(['instructor.person.department', 'workLoadCourses.course.program.offering', 'workLoadCourses.section']);

            // Adjust semester selection
            if (str_contains(strtolower($term->semester), 'summer')) {
                // Only show summer
                $workloadsQuery->where('semester', $term->semester);
            } else {
                // Show Fall + Spring of the same academic year
                $workloadsQuery->whereIn('semester', ['Fall', 'Spring']);
            }

            $workloads = $workloadsQuery->get();


            // Step 3: Group workloads by instructor
            $grouped = $workloads->groupBy('instructor_id')->sortBy(function ($item) {
                return strtolower($item->first()->instructor->person->first_name ?? '');
            });

            $data = [];
            foreach ($grouped as $instructorId => $workloadsGroup) {
                $instructor = $workloadsGroup->first()->instructor;

                $termStart = Carbon::parse($term->begin_dt);
                $termEnd   = Carbon::parse($term->end_dt);

                /**
                 * Resolve assignment active during the selected term
                 */
                $assignment = $instructor->assignmentForTerm($termStart, $termEnd);

                $jobTitle = $assignment?->jobTitle?->name
                    ?? '';
                $salaryAdminPlan = $assignment?->salaryAdminPlan?->name
                    ?? '';

                $allCourses = $workloadsGroup->flatMap(fn($w) => $w->workLoadCourses);

                // Calculations
                $adjusted = $allCourses->sum('adjusted');
                $overload = $allCourses->where('overload', true)->count();
                $release = $workloadsGroup->sum('release');
                $workloadTotal = $workloadsGroup->sum('workload');
                $effective = abs($adjusted - $overload - $release);

                $undergradCourses = $allCourses->filter(fn($c) =>
                    in_array($c->course?->program?->offering?->code, ['UP', 'UCA'])
                )->count();

                $gradCourses = $allCourses->filter(fn($c) =>
                    $c->course?->program?->offering?->code === 'GP'
                )->count();

                $doctoralCourses = $allCourses->filter(fn($c) =>
                    $c->course?->program?->offering?->code === 'DP'
                )->count();


                $sectionCount = $allCourses->pluck('section_id')->unique()->count();

                $semesterDisplay = $term->semester;

                if (!str_contains(strtolower($term->semester), 'summer')) {
                    // If term is Fall or Spring, show both semesters
                    $semesterDisplay = 'Fall/Spring';
                }

                $data[] = [
                    'instructor' => trim($instructor->person->first_name . ' ' . $instructor->person->last_name),
                    'instructor_id' => $instructor->id ??'',
                    'type' => $instructor->employeeType->code ?? '',
                    'job_title' => $jobTitle ?? '',
                    'salary_admin_plan' => $salaryAdminPlan ?? '',
                    'tenure_type' => $instructor->tenureType->code ?? '',
                    'department' => $instructor->person->department->name ?? '',
                    'semester' => $semesterDisplay,
                    'workload' => $workloadsGroup->pluck('workload')->implode(' - '),
                    'total_workload' => $workloadTotal,
                    'teaching' => 0, // Placeholder if data exists
                    'intellectual' => 0, // Placeholder if data exists
                    'service' => 0,       // Placeholder if data exists
                    'administrative' => 0,// Placeholder if data exists
                    'release' => $release,
                    'release_type' => implode(', ', $workloadsGroup->pluck('release_type')->filter()->unique()->toArray()),
                    'number_of_sections' => $sectionCount,
                    'adjusted_courses' => $adjusted,
                    'undergrad_courses' => $undergradCourses,
                    'undergrad_inload_courses' => 0, // Placeholder
                    'grad_courses' => $gradCourses,
                    'grad_inload_courses' => 0,      // Placeholder
                    'overload' => $overload,
                    'effective' => $effective,
                    'notes' => $workloadsGroup -> pluck('comment'), 
                ];
            }

            // Step 4: Paginate manually
            $total = count($data);
            $items = array_slice($data, ($page - 1) * $perPage, $perPage);
            return new \Illuminate\Pagination\LengthAwarePaginator($items, $total, $perPage, $page);

        } catch (Exception $e) {
            Log::error('Error in generateReport: ' . $e->getMessage());
            throw $e;
        }
    }
}
