<?php

namespace App\Repositories\v1\academic\reports;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

use App\Exceptions\ResourceNotFoundException;
use App\Helpers\FacultyReportHelper;
use App\Repositories\v1\cobapi\clients\Faculty180Client;

class FacultyReportRepository
{
    public function __construct(protected Faculty180Client $faculty180) {}

    /**
     * New DB version (no stored procedures).
     *
     * Route param:
     *  - {acad_year} (example: "2025-2026")
     *
     * Query params (adjust names to match FE):
     *  - pageSize, page, search, sortColumn, sortDirection
     *  - status: active|inactive|all
     *  - scheduledToTeach: true|false
     *  - employeeTypes: "FAC,ADJ,GA" OR ["FAC","ADJ"]
     *  - fall, spring, summer: true|false
     */
    public function generateReport(Request $request, string $acadYear): LengthAwarePaginator
    {
        try {
            // Pagination / search / sort
            $perPage       = (int) $request->input('pageSize', 10);
            $page          = (int) $request->input('page', 1);
            $search        = $request->input('search');
            $sortColumn    = $request->input('sortColumn');
            $sortDirectionRaw = $request->input('sortDirection', $request->input('sort', 'asc'));
            $sortDirection = strtolower((string) $sortDirectionRaw) === 'desc' ? 'desc' : 'asc';

            // Filters
            $statusRaw = strtolower((string) $request->input('status', 'all')); // active|inactive|all
            $status = match ($statusRaw) {
                'active', 'a'   => 'active',
                'inactive', 'i' => 'inactive',
                default         => 'all',
            };

            $scheduledToTeach = filter_var($request->input('scheduledToTeach', false), FILTER_VALIDATE_BOOLEAN);

            // FE sends term_options[] = fall|spring|summer
            if (!$request->has('fall') && !$request->has('spring') && !$request->has('summer')) {
                $termOptions = $request->input('term_options', null);
                if (is_array($termOptions)) {
                    $termOptions = array_map(fn($v) => strtolower(trim((string) $v)), $termOptions);

                    $request->merge([
                        'fall'   => in_array('fall', $termOptions, true),
                        'spring' => in_array('spring', $termOptions, true),
                        'summer' => in_array('summer', $termOptions, true),
                    ]);
                }
            }

            // FE sends employee_types[] = FAC|ADJ|GA
            if (!$request->has('employeeTypes')) {
                $employeeTypes = $request->input('employee_types', null);
                if (is_array($employeeTypes)) {
                    $request->merge(['employeeTypes' => $employeeTypes]);
                }
            }

            // Term checkboxes (defaults: Fall+Spring checked, Summer unchecked)
            $includeFall   = $this->boolQuery($request, 'fall', true);
            $includeSpring = $this->boolQuery($request, 'spring', true);
            $includeSummer = $this->boolQuery($request, 'summer', false);

            // If user unchecks everything, default to all
            if (!$includeFall && !$includeSpring && !$includeSummer) {
                $includeFall = $includeSpring = $includeSummer = true;
            }

            // Employee types filter (FAC/ADJ/GA)
            $employeeTypes = $this->normalizeEmployeeTypes($request->input('employeeTypes', 'FAC,ADJ,GA'));
            if (empty($employeeTypes)) {
                $employeeTypes = ['FAC', 'ADJ', 'GA'];
            }

            // Ensure the academic year exists in ac.terms
            $hasAnyTerms = DB::table('ac.terms')
                ->where('academic_year', $acadYear)
                ->exists();

            if (!$hasAnyTerms) {
                throw new ResourceNotFoundException(
                    "Academic year not found: {$acadYear}",
                    Response::HTTP_NOT_FOUND
                );
            }

            /**
             * Section counts per instructor across selected semesters in the given academic year.
             * Count DISTINCT section IDs (meeting patterns can duplicate section rows).
             */
            $countsSub = DB::table('ac.meeting_patterns as mp')
                ->join('ac.sections as s', 's.id', '=', 'mp.section_id')
                ->join('ac.terms as t', 't.id', '=', 's.term_id')
                ->where('t.academic_year', '=', $acadYear)
                ->where(function ($q) use ($includeFall, $includeSpring, $includeSummer) {
                    $first = true;

                    if ($includeFall) {
                        $first
                            ? $q->whereRaw("UPPER(RTRIM(t.semester)) LIKE '%FALL%'")
                            : $q->orWhereRaw("UPPER(RTRIM(t.semester)) LIKE '%FALL%'");
                        $first = false;
                    }
                    if ($includeSpring) {
                        $first
                            ? $q->whereRaw("UPPER(RTRIM(t.semester)) LIKE '%SPRING%'")
                            : $q->orWhereRaw("UPPER(RTRIM(t.semester)) LIKE '%SPRING%'");
                        $first = false;
                    }
                    if ($includeSummer) {
                        $first
                            ? $q->whereRaw("UPPER(RTRIM(t.semester)) LIKE '%SUMMER%'")
                            : $q->orWhereRaw("UPPER(RTRIM(t.semester)) LIKE '%SUMMER%'");
                        $first = false;
                    }
                })
                ->groupBy('mp.instructor_id')
                ->select([
                    'mp.instructor_id',
                    DB::raw("COUNT(DISTINCT CASE WHEN UPPER(RTRIM(t.semester)) LIKE '%FALL%' THEN s.id END) as sections_fall"),
                    DB::raw("COUNT(DISTINCT CASE WHEN UPPER(RTRIM(t.semester)) LIKE '%SPRING%' THEN s.id END) as sections_spring"),
                    DB::raw("COUNT(DISTINCT CASE WHEN UPPER(RTRIM(t.semester)) LIKE '%SUMMER%' THEN s.id END) as sections_summer"),
                ]);

            /**
             * Main query: instructors + persons + employee_types + dept/BU + current assignment + job title + section counts.
             */
            $query = DB::table('ac.instructors as i')
                ->join('hr.persons as p', 'i.person_id', '=', 'p.id')
                ->leftJoin('hr.employee_types as et', 'i.employee_type_id', '=', 'et.id')
                ->leftJoin('ac.qualification_types as qt', 'i.qualification_type_id', '=', 'qt.id')
                ->leftJoin('ass.tenure_types as tt', 'i.tenure_type_id', '=', 'tt.id')

                // Department from hr.persons.department_id (your preference)
                ->leftJoin('gn.departments as d', 'd.id', '=', 'p.department_id')
                ->leftJoin('hr.business_units as bu', 'bu.id', '=', 'd.business_unit_id')

                // Current active assignment (latest start_date, not ended)
                ->leftJoin('hr.assignments as a', function ($join) {
                    $join->on('a.person_id', '=', 'p.id')
                        ->where('a.active', '=', 1)
                        ->whereRaw("(a.end_date IS NULL OR a.end_date >= CAST(GETDATE() AS DATE))")
                        ->whereRaw("
                            a.id = (
                                SELECT TOP 1 a3.id
                                FROM hr.assignments a3
                                WHERE a3.person_id = p.id
                                  AND a3.active = 1
                                  AND (a3.end_date IS NULL OR a3.end_date >= CAST(GETDATE() AS DATE))
                                ORDER BY a3.start_date DESC, a3.id DESC
                            )
                        ");
                })
                ->leftJoin('hr.job_titles as jt', 'a.job_title_id', '=', 'jt.id')
                ->leftJoin('hr.salary_admin_plans as sap', 'a.salary_admin_plan_id', '=', 'sap.id')

                ->leftJoinSub($countsSub, 'sc', function ($join) {
                    $join->on('sc.instructor_id', '=', 'i.id');
                })

                // Employee type filter (FAC/ADJ/GA)
                ->whereIn('et.code', $employeeTypes);

            // Status filter based on hr.persons.active
            if ($status === 'active') {
                $query->where('p.active', '=', 1);
            } elseif ($status === 'inactive') {
                $query->where('p.active', '=', 0);
            }

            // SELECT keys to match your helper contract
            $query->select([
                DB::raw("RTRIM(p.first_name) + ' ' + ISNULL(RTRIM(p.middle_name) + ' ', '') + RTRIM(p.last_name) as faculty_name"),
                DB::raw("RTRIM(p.panther_id) as panther_id"),
                DB::raw("RTRIM(p.business_email) as email"),

                // Appointment date = ORIGINAL HIRE DATE (requested)
                DB::raw("
                    CONVERT(VARCHAR, COALESCE(
                        a.original_hire_date,
                        (SELECT MIN(a2.original_hire_date)
                         FROM hr.assignments a2
                         WHERE a2.person_id = p.id AND a2.original_hire_date IS NOT NULL)
                    ), 110) as appointment_date
                "),

                // Placeholders until you map tables
                DB::raw("CAST(NULL AS VARCHAR(200)) as highest_degree"),
                DB::raw("CAST(NULL AS VARCHAR(100)) as involvement"),
                DB::raw("CAST(NULL AS VARCHAR(100)) as qualifications"),
                DB::raw("RTRIM(tt.code) as tenure"),
                DB::raw("CAST(NULL AS VARCHAR(200)) as academic_area"),
                DB::raw("CONCAT(COALESCE(sc.sections_fall,0), '-', COALESCE(sc.sections_spring,0), '-', COALESCE(sc.sections_summer,0)) as sections_f_sp_su"),

                // Employee type fields your helper expects
                DB::raw("RTRIM(et.code) as employee_type_code"),

                DB::raw("
                    RTRIM(et.code) +
                    CASE
                        WHEN sap.name IS NULL OR LTRIM(RTRIM(sap.name)) = '' THEN ''
                        ELSE ' - ' +
                            CASE
                                WHEN sap.name LIKE '%9 Month%'  THEN '9 Month'
                                WHEN sap.name LIKE '%12 Month%' THEN '12 Month'
                                ELSE
                                    -- fallback: remove common trailing words to keep it short
                                    LTRIM(RTRIM(
                                        REPLACE(
                                            REPLACE(
                                                REPLACE(sap.name, ' Faculty', ''),
                                            ' Graduate Assistant', ''),
                                        ' Adjunct', '')
                                    ))
                            END
                    END
                    as employee_type_display
                "),

                // Job title
                DB::raw("RTRIM(jt.name) as job_title"),

                // Department fields
                DB::raw("RTRIM(d.name) as academic_department"),
                DB::raw("
                    CASE
                        WHEN d.name IS NULL THEN ''
                        WHEN bu.code IS NULL OR RTRIM(bu.code) = '' THEN RTRIM(d.name)
                        ELSE RTRIM(d.name) + ' (' + RTRIM(bu.code) + ')'
                    END as home_department
                "),

                // Section counts (helper uses sections_fall/spring/summer/total)
                DB::raw("COALESCE(sc.sections_fall, 0) as sections_fall"),
                DB::raw("COALESCE(sc.sections_spring, 0) as sections_spring"),
                DB::raw("COALESCE(sc.sections_summer, 0) as sections_summer"),

                // Status raw that your helper converts to label
                DB::raw("p.active as status_raw"),
            ]);

            // Search
            if (!empty($search)) {
                $search = strtolower((string) $search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(p.first_name) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(p.last_name) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(p.panther_id) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(p.business_email) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(et.code) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(jt.name) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(d.name) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(bu.code) LIKE ?", ["%{$search}%"])
                        ->orWhereRaw("LOWER(sap.name) LIKE ?", ["%{$search}%"]);
                });
            }

            // Sorting whitelist
            $sortMap = [
                'name' => 'p.last_name',
                'faculty_name'     => 'p.last_name',
                'panther_id'       => 'p.panther_id',
                'email'            => 'p.business_email',
                'appointment_date' => 'a.original_hire_date',
                'job_title'        => 'jt.name',
                'academic_department' => 'd.name',
                'home_department'  => 'd.name',
                'type'             => 'et.code',
                'sections_f_sp_su' => 'sections_total',
                'qualifications' => 'qt.code',
                'tenure' => 'tt.code',
            ];

            if (!empty($sortColumn) && isset($sortMap[$sortColumn])) {
                if ($sortColumn === '#_sections_total') {
                    $query->orderByRaw("COALESCE(sc.sections_fall,0) + COALESCE(sc.sections_spring,0) + COALESCE(sc.sections_summer,0) {$sortDirection}");
                } else {
                    $query->orderByRaw($sortMap[$sortColumn] . ' ' . $sortDirection);
                }
            } else {
                $query->orderBy('p.last_name')
                    ->orderBy('p.first_name')
                    ->orderBy('p.middle_name');
            }

            $results = $query->paginate($perPage, ['*'], 'page', $page);

            // ---------------------------
            // Enrich page with Faculty180
            // ---------------------------
            $items = $results->items();

            // collect panther IDs from just this page
            $pidList = collect($items)
                ->map(fn ($r) => trim((string) ($r->panther_id ?? '')))
                ->filter()
                ->unique()
                ->values()
                ->all();

            // fetch highest degrees from Faculty180 (map: panther_id => degree)
            $degreeMap = [];
            foreach ($pidList as $pid) {
                $degreeMap[$pid] = Cache::remember(
                    "faculty180_highest_degree_summary_{$pid}",
                    3600,
                    fn () => $this->faculty180->highestDegreeSummaryForPid($pid)
                );
            }

            // attach to the row objects so your helper can read highest_degree
            foreach ($items as $row) {
                $pid = trim((string) ($row->panther_id ?? ''));
                $row->highest_degree = $degreeMap[$pid] ?? null;
            }

            // ---------------------------
            // Enrich: Faculty180 fields (Highest Degree + CV)
            // ---------------------------
            $items = $results->items();

            $pidList = collect($items)
                ->map(fn ($r) => trim((string) ($r->panther_id ?? '')))
                ->filter()
                ->unique()
                ->values()
                ->all();

            $degreeMap = [];
            $cvMap = [];

            foreach ($pidList as $pid) {
                $degreeMap[$pid] = Cache::remember(
                    "faculty180_highest_degree_summary_{$pid}",
                    3600,
                    fn () => $this->faculty180->highestDegreeSummaryForPid($pid)
                );

                $cvMap[$pid] = Cache::remember(
                    "faculty180_vitae_url_{$pid}",
                    3600,
                    fn () => $this->faculty180->vitaeDownloadUrlForPid($pid)
                );
            }

            foreach ($items as $row) {
                $pid = trim((string) ($row->panther_id ?? ''));
                $row->highest_degree = $degreeMap[$pid] ?? null;
                $row->curriculum_vitae = $cvMap[$pid] ?? null;
            }

            // Format rows using YOUR helper (unchanged)
            $results->setCollection(collect(FacultyReportHelper::formatReport($results->items())));

            return $results;


        } catch (Exception $e) {
            Log::error('Error in FacultyReportRepository::generateReport: ' . $e->getMessage());
            throw $e;
        }
    }

    private function boolQuery(Request $request, string $key, bool $default): bool
    {
        $val = $request->input($key, null);
        if ($val === null) return $default;
        return filter_var($val, FILTER_VALIDATE_BOOLEAN);
    }

    private function normalizeEmployeeTypes(mixed $raw): array
    {
        $vals = [];

        if (is_array($raw)) {
            $vals = $raw;
        } elseif (is_string($raw)) {
            $vals = array_map('trim', explode(',', $raw));
        }

        $out = [];
        foreach ($vals as $v) {
            $v = strtoupper(trim((string) $v));
            if ($v === '') continue;

            $v = match ($v) {
                'FACULTY', 'FAC' => 'FAC',
                'ADJUNCT', 'ADJ' => 'ADJ',
                'GRADUATE ASSISTANT', 'GRADUATE_ASSISTANT', 'GA' => 'GA',
                default => $v,
            };

            if (in_array($v, ['FAC', 'ADJ', 'GA'], true)) {
                $out[] = $v;
            }
        }

        return array_values(array_unique($out));
    }

}
