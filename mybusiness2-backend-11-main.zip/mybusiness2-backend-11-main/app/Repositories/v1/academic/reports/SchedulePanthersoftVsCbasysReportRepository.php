<?php

namespace App\Repositories\v1\academic\reports;

// GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;

class SchedulePanthersoftVsCbasysReportRepository
{
    /**
     * Generate the PantherSoft vs CBA Sys comparison report
     *
     * @param Request $request
     * @param string $termNumber
     * @return LengthAwarePaginator
     * @throws ResourceNotFoundException|Exception
     */
    public function generateReport(Request $request, string $termNumber): LengthAwarePaginator
    {
        try {
            // Get term ID
            $term = DB::table('ac.terms')
                ->where('number', $termNumber)
                ->first();

            if (!$term) {
                throw new ResourceNotFoundException(
                    trans('academic/reports.schedule_panthersoft_vs_cbasys_report.exceptionNotFound'),
                    Response::HTTP_NOT_FOUND
                );
            }

            // Pagination, search, sort
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn');
            $sortDirection = $request->query('sortDirection', 'desc');

            $psBase = DB::table('temp.PS_SCHEDULE as ps')
                ->join('ac.terms as t', 'ps.Term', '=', 't.number')
                ->where('t.id', $term->id)
                ->whereRaw("RTRIM(ps.[Class Stat]) <> 'X'")
                ->whereRaw("RTRIM(ps.[Department]) LIKE '%CBADM'")
                ->whereRaw("RTRIM(ps.[Acad Group]) = 'CBADM'")
                ->select([
                    // keep only the PS fields needed for downstream
                    DB::raw("RTRIM(ps.[Class Stat])     as ps_ClassStat"),
                    DB::raw("CAST(ps.[Class Nbr] AS VARCHAR) as ps_ClassNbr"),
                    DB::raw("RTRIM(ps.[Subject])        as ps_Subject"),
                    DB::raw("RTRIM(ps.[Catalog])        as ps_Catalog"),
                    DB::raw("RTRIM(ps.[Section])        as ps_Section"),
                    DB::raw("RTRIM(ps.[Session])        as ps_Session"),
                    DB::raw("RTRIM(ps.[Meeting Days])   as ps_MeetingDays"),
                    DB::raw("RTRIM(ps.[Meeting Time])   as ps_MeetingTime"),
                    DB::raw("CAST(ps.[Cap] AS INT)      as ps_Cap"),
                    DB::raw("RTRIM(ps.[Last Name])      as ps_LastName"),
                    DB::raw("RTRIM(ps.[First Name])     as ps_FirstName"),
                    DB::raw("RTRIM(ISNULL(ps.[Middle], '')) as ps_Middle"),
                    DB::raw("RTRIM(ps.[Mode])           as ps_Mode"),
                    DB::raw("RTRIM(ps.[Sch Print])      as ps_SchPrint"),
                    DB::raw("RTRIM(ps.[Consent])        as ps_Consent"),
                    DB::raw("CONVERT(VARCHAR(10), ps.[Start Date], 23) as ps_StartDate"),
                    DB::raw("CONVERT(VARCHAR(10), ps.[End Date], 23)   as ps_EndDate"),
                    DB::raw("RTRIM(ps.[Calc Reqd])      as ps_CalcReqd"),
                    DB::raw("RTRIM(ps.[Location])       as ps_Location"),
                    DB::raw("RTRIM(ps.[Campus])         as ps_Campus"),
                    DB::raw("RTRIM(ps.[Location Descr]) as ps_CampusLocation"),
                    DB::raw("RTRIM(ps.[Facility])       as ps_Facility"),
                    DB::raw("RTRIM(ps.[Department])     as ps_Department"),

                    // keep a trimmed join key for course id
                    DB::raw("RTRIM(ps.[Course ID]) as ps_CourseIdTrim")
                ]);

            // First matching WHEN passes; the second A is unreachable but preserved to mirror the old SP query.
            $cbaDynCase = "
              CASE
                WHEN s.[dynamic] = 1 THEN 'DYN'
                WHEN s.[sec_sess] = 'A' THEN '6W1'
                WHEN s.[sec_sess] = 'B' THEN '6W2'
                WHEN s.[sec_sess] = 'A' THEN '12W'
                ELSE '1'
              END
            ";

            // Build the main query FROM that subquery and LEFT JOIN everything
            $query = DB::query()
                ->fromSub($psBase, 'ps')   // <<— guarantees all matching PS rows are included
                // course match
                ->leftJoin('ac.courses as c', DB::raw('RTRIM(c.references_number)'), '=', DB::raw('ps.ps_CourseIdTrim'))
                // sections of same term and same section code
                ->leftJoin('ac.sections as s', function ($join) use ($term) {
                    $join->on('s.course_id', '=', 'c.id')
                        ->where('s.term_id', '=', $term->id)
                        ->whereRaw("RTRIM(s.[sec_code]) + RTRIM(s.[sec_number]) = ps.ps_Section");
                })

                // meeting patterns (can be 1:N)
                ->leftJoin('ac.meeting_patterns as mp', 'mp.section_id', '=', 's.id')
                // instructors to persons
                ->leftJoin('ac.instructors as i', 'i.id', '=', 'mp.instructor_id')
                ->leftJoin('hr.persons as p', 'p.id', '=', 'i.person_id')
                // programs, instructor modes, facilities, campuses
                ->leftJoin('ac.programs as programs', 'programs.id', '=', 's.program_id')
                ->leftJoin('ac.instructor_modes as im', 'im.id', '=', 's.instructor_mode_id')
                ->leftJoin('gn.facilities as f', 'f.id', '=', 'mp.facility_id')
                ->leftJoin('gn.campuses as campuses', 'campuses.id', '=', 's.campus_id')
                // SELECT — use the ps_ aliases from the subquery
                ->select([
                    // PS columns
                    DB::raw("ps.ps_ClassStat as Sts"),
                    DB::raw("ps.ps_ClassNbr  as Num"),
                    DB::raw("(ps.ps_Subject + ps.ps_Catalog) as Course"),
                    DB::raw("ps.ps_Section   as PSSect"),
                    DB::raw("ps.ps_Session   as PSD"),
                    DB::raw("ps.ps_MeetingDays as PSDays"),
                    DB::raw("ps.ps_MeetingTime as PSTime"),
                    DB::raw("ps.ps_Cap as PSCap"),
                    DB::raw("ps.ps_LastName + CASE WHEN LEN(ps.ps_LastName)=0 THEN '' ELSE ', ' END + ps.ps_FirstName + CASE WHEN LEN(ps.ps_Middle)=0 THEN '' ELSE ' ' + ps.ps_Middle END as PSInstructors"),
                    DB::raw("ps.ps_Mode      as [PS Mode]"),
                    DB::raw("ps.ps_SchPrint  as PSchP"),
                    DB::raw("ps.ps_Consent   as Cons"),
                    DB::raw("(ps.ps_StartDate + ' - ' + ps.ps_EndDate) as PSDates"),
                    DB::raw("ps.ps_CalcReqd  as [Calc Req]"),
                    DB::raw("ps.ps_Location  as PSLoc"),
                    DB::raw("ps.ps_Campus    as PSCampus"),
                    DB::raw("ps.ps_CampusLocation as [Campus Location]"),
                    DB::raw("ps.ps_Facility as [PS Facility]"),
                    DB::raw("ps.ps_Department as Department"),

                    // CBA side (nullable when no match)
                    DB::raw("RTRIM(ISNULL(s.[sec_code],'')) + RTRIM(ISNULL(s.[sec_number],'')) as CBASect"),

                    // Normalized CBA session/dynamic (as CBAD)
                    DB::raw("{$cbaDynCase} as CBAD"),
                    // Conflict column comparing PS session to normalized CBA value
                    DB::raw("
                      CASE
                        WHEN ISNULL(RTRIM(ps.ps_Session), '') = ({$cbaDynCase})
                        THEN 'OK' ELSE 'CONFLICT'
                      END as DynConflict
                    "),

                    DB::raw("CONVERT(VARCHAR(10), s.[starting_date], 23) + ' - ' + CONVERT(VARCHAR(10), s.[ending_date], 23) as CBADates"),
                    DB::raw("RTRIM(mp.[day]) as CBADays"),
                    DB::raw("
                          CASE
                            WHEN mp.start_time IS NULL OR mp.end_time IS NULL THEN NULL
                            ELSE REPLACE(CONVERT(VARCHAR(5), mp.start_time, 108), ':','')
                                 + '-' +
                                 REPLACE(CONVERT(VARCHAR(5), mp.end_time, 108), ':','')
                          END as CBATime
                        "),
                                    DB::raw("CAST(s.[cap] AS INT) as CBACap"),
                                    DB::raw("
                            RTRIM(ISNULL(p.last_name,''))
                            + CASE WHEN LEN(ISNULL(p.last_name,''))=0 THEN '' ELSE ', ' END
                            + RTRIM(ISNULL(p.first_name,''))
                            + CASE WHEN ISNULL(p.middle_name,'') = '' THEN '' ELSE ' ' + RTRIM(p.middle_name) END
                            as CBAInstructors
                        "),
                    DB::raw("RTRIM(programs.code) as [CBA Program]"),
                    DB::raw("RTRIM(im.code)       as [CBA Mode]"),
                    DB::raw("RTRIM(f.code)        as [CBA Facility]"),
                    DB::raw("RTRIM(campuses.name) as CBACampus"),
                    DB::raw("RTRIM(s.[comment])   as Comments"),
                    DB::raw("RTRIM(s.[internal_note]) as Notes"),
                ]);

            // Search filter
            if (!empty($search)) {
                $search = strtolower($search);
                $like   = "%{$search}%";

                $query->where(function ($q) use ($like) {

                    $q->whereRaw("LOWER(ps.ps_Subject) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ps.ps_Catalog) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ps.ps_Subject + ps.ps_Catalog) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ps.ps_Department) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ps.ps_LastName) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ps.ps_FirstName) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ISNULL(p.last_name, '')) LIKE ?", [$like])
                        ->orWhereRaw("LOWER(ISNULL(p.first_name, '')) LIKE ?", [$like]);
                });
            }

            // Sorting
            if ($sortColumn) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // Paginate
            $results = $query->distinct()->paginate($perPage, ['*'], 'page', $page);

            return $results;

        } catch (Exception $e) {
            Log::error('Error in generateReport (PantherSoft vs CBASYS Report): ' . $e->getMessage());
            throw $e;
        }
    }
}
