<?php

namespace App\Repositories\v1\academic\reports;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Helpers\ScheduleUniqueSectionsReportHelper;

class ScheduleUniqueSectionsReportRepository
{
    /**
     * Generate a report for a specific term with pagination and search
     *
     * @param Request $request
     * @param int $termNumber
     * @return array
     * @throws ResourceNotFoundException|Exception
     */
    public function generateReport(Request $request, string $termNumber): LengthAwarePaginator
    {
        try {
            // Get term ID first
            $term = DB::table('ac.terms')
                ->where('number', $termNumber)
                ->first();

            if (!$term) {
                throw new ResourceNotFoundException(
                    trans('academic/reports.schedule_unique_sections_report.exceptionNotFound'),
                    Response::HTTP_NOT_FOUND
                );
            }

            // Extract pagination parameters
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn');
            $sortDirection = $request->query('sortDirection', 'desc');

            // Complete query with all joins
            $query = DB::table('ac.sections')
                ->join('ac.terms', 'ac.sections.term_id', '=', 'ac.terms.id')
                ->join('ac.courses', 'ac.sections.course_id', '=', 'ac.courses.id')

                //potential empty joins if ac.meeting_patterns is empty
                ->join('ac.meeting_patterns', 'ac.sections.id', '=', 'ac.meeting_patterns.section_id')
                ->join('ac.instructors', 'ac.meeting_patterns.instructor_id', '=', 'ac.instructors.id')
                ->join('hr.persons', 'ac.instructors.person_id', '=', 'hr.persons.id')
                ->leftJoin('hr.employee_types', 'ac.instructors.employee_type_id', '=', 'hr.employee_types.id')

                ->leftJoin('gn.departments', 'ac.courses.department_id', '=', 'gn.departments.id')
                ->leftJoin('ac.instructor_modes', 'ac.sections.instructor_mode_id', '=', 'ac.instructor_modes.id')

                //Empty fields if ac.workload_courses needs data
                ->leftJoin('ac.workload_courses', 'ac.sections.id', '=', 'ac.workload_courses.section_id')
                ->leftJoin('gn.facilities', 'ac.meeting_patterns.facility_id', '=', 'gn.facilities.id')

                ->leftJoin('gn.campuses', 'ac.sections.campus_id', '=', 'gn.campuses.id')
                ->leftJoin('ac.programs', 'ac.sections.program_id', '=', 'ac.programs.id')
                ->where('ac.terms.id', $term->id)
                ->select([
                    DB::raw('CAST(ac.terms.id AS VARCHAR(36)) as term_id'),
                    DB::raw('RTRIM(ac.terms.semester) + \' \' + RTRIM(ac.terms.year) as semester'),
                    DB::raw('RTRIM(ac.courses.code) as course'),
                    DB::raw('RTRIM(ac.sections.sec_code) + RTRIM(ac.sections.sec_number) as section'),
                    DB::raw('RTRIM(ac.sections.sec_sess) as session'),
                    DB::raw('RTRIM(ac.courses.name) as course_name'),
                    DB::raw('RTRIM(gn.departments.name) as department'),

                    // potential empty fields if ac.meeting_patterns is empty
                    DB::raw("RTRIM(hr.persons.first_name) + ' ' + ISNULL(RTRIM(hr.persons.middle_name) + ' ', '') + RTRIM(hr.persons.last_name) as instructor_name"),
                    DB::raw('RTRIM(hr.persons.panther_id) as instructor_pid'),


                    DB::raw('RTRIM(ac.instructor_modes.code) as instructional_mode'),
                    //need primary instructional mode
                    DB::raw('CAST(ac.sections.cap AS VARCHAR) as capacity'),
                    DB::raw('CAST(ac.sections.student_enrollment AS VARCHAR) as enrollment'),
                    DB::raw("CONVERT(VARCHAR, ac.sections.starting_date, 110) as start_date"),
                    DB::raw("CONVERT(VARCHAR, ac.sections.ending_date, 110) as end_date"),


                    // Fields that could be empty because of ac.meeting_patterns
                    DB::raw('RTRIM(ac.meeting_patterns.day) as days'),
                    DB::raw("CONCAT(
                        FORMAT(CAST(ac.meeting_patterns.start_time AS TIME), 'H:mm'),
                        '-',
                        FORMAT(CAST(ac.meeting_patterns.end_time AS TIME), 'H:mm')
                    ) as time"),
                    DB::raw('RTRIM(gn.facilities.code) as facility'),

                    DB::raw('RTRIM(gn.campuses.name) as campus'),
                    DB::raw('RTRIM(ac.programs.code) as primary_program'),
                    //need "combined programs"
                    DB::raw('RTRIM(ac.sections.cohorts) as cohort'),
                    //need "course level"
                    //need "class roster" which links to a table with the class roster
                ]);

            // Apply search if provided
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(ac.terms.academic_year) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.terms.semester + ' ' + CAST(ac.terms.year AS VARCHAR)) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.references_number_panther) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.sec_code + ac.sections.sec_number) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.sec_sess) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.courses.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.departments.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.instructor_modes.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.campuses.name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.programs.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.sections.cohorts) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.first_name + ' ' + hr.persons.last_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.persons.panther_id) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(hr.employee_types.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(gn.facilities.code) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(ac.meeting_patterns.day) LIKE ?", ["%$search%"]);
                });
            }

            // Apply sorting
            if ($sortColumn) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // Execute paginated query
            $results = $query->distinct()->paginate($perPage, ['*'], 'page', $page);

            // Reemplazar los items del paginador
            $results->setCollection(collect(ScheduleUniqueSectionsReportHelper::formatReport($results->items())));

            return $results;

        } catch (Exception $e) {
            Log::error('Error in generateReport: ' . $e->getMessage());
            throw $e;
        }
    }
}
