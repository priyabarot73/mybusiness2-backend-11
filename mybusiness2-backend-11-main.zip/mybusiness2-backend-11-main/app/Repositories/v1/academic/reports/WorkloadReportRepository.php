<?php

namespace App\Repositories\v1\academic\reports;

use RuntimeException;
use Illuminate\Support\Facades\DB;

use App\Models\academic\Workload;
use Carbon\Carbon;
use App\Models\academic\Term;
use App\Models\academic\Instructor;

class WorkloadReportRepository
{
    public function build(array $request): array
    {
        $termId = $request['term_id'] ?? null;

        if (!$termId) {
            throw new RuntimeException('term_id is required.');
        }

        $departmentId = $request['department_id'] ?? null;
        $workloadType = $request['workload_type'] ?? null;
        $instructorId = $request['instructor_id'] ?? null;
        $tenureType = $request['tenure_type'] ?? null;


        $term = Term::find($termId);
        
        $termStart = $term->begin_dt ? Carbon::parse($term->begin_dt) : null;
        $termEnd   = $term->end_dt ? Carbon::parse($term->end_dt) : null;

        $termIds = [$termId];

        if ($term) {

            if ($term->semester === 'Fall') {

                // find the next Spring after this Fall
                $spring = Term::where('semester', 'Spring')
                    ->where('begin_dt', '>', $term->begin_dt)
                    ->orderBy('begin_dt')
                    ->first();

                if ($spring) $termIds[] = $spring->id;
            }

            if ($term->semester === 'Spring') {

                // find the previous Fall before this Spring
                $fall = Term::where('semester', 'Fall')
                    ->where('begin_dt', '<', $term->begin_dt)
                    ->orderByDesc('begin_dt')
                    ->first();

                if ($fall) $termIds[] = $fall->id;
            }

            // Summer stays single
        }


        /*
        |--------------------------------------------------------------------------
        | Resolve instructor filter
        |--------------------------------------------------------------------------
        */

        $instructorIds = Instructor::query()
            ->when($departmentId, function ($q) use ($departmentId) {
                $q->whereHas('person', fn ($p) =>
                    $p->where('department_id', $departmentId)
                );
            })
            ->when($instructorId, fn ($q) =>
                $q->where('id', $instructorId)
            )
            ->when($tenureType, function ($q) use ($tenureType) {
                $q->where('tenure_type_id', $tenureType);
            })
            ->pluck('id');

        if ($instructorIds->isEmpty()) {
            throw new RuntimeException('No instructors found for filters.');
        }

        /*
        |--------------------------------------------------------------------------
        | Load workloads
        |--------------------------------------------------------------------------
        */

        $workloads = Workload::query()
            ->whereIn('instructor_id', $instructorIds)
            ->when($workloadType, fn ($q) =>
                $q->where('workload_type', $workloadType)
            )
            ->whereHas('workLoadCourses.section', function ($q) use ($termIds) {
                $q->whereIn('term_id', $termIds);
            })

            ->with([
                'instructor.person',

                'workLoadCourses.course',

                'instructor.tenureType',

                'workLoadCourses.section' => function ($q) {
                    $q->with([
                        'term',
                        'program',
                        'instructorMode',
                        'meetingPatterns',
                        'meetingPatternHybrids',
                        'workLoadCourses.course.program',
                    ])->withCount([
                        'meetingPatterns as instructor_number',
                        'meetingPatternHybrids as hybrid_instructor_number',
                    ]);
                },
            ])
            ->get();


        if ($workloads->isEmpty()) {
            throw new RuntimeException('No workload data found.');
        }

        /*
        |--------------------------------------------------------------------------
        | Group & Build Report
        |--------------------------------------------------------------------------
        */

        // Sort workloads by instructor first name
        $workloads = $workloads->sortBy(fn($w) => $w->instructor->person->first_name);
        $grouped = $workloads->groupBy('instructor_id');

        $report = [];

        foreach ($grouped as $instructorGroup) {

            $first = $instructorGroup->first();
            $instructor = $first->instructor;
            $assignment = $instructor->assignmentForTerm($termStart, $termEnd);
            $courses = $instructorGroup->flatMap->workLoadCourses;

            $adjusted = $courses->sum('adjusted');
            $overload = $courses->where('overload', true)->count();
            $release = $first->release ?? 0;
            $effective = $adjusted - $overload - $release;

            $totalWorkload = $instructorGroup->sum('workload');
            $error = abs($totalWorkload - $effective) > 0.01
                    ? "Error — check it out!"
                    : null;
            $report[] = [
                'instructor' => [
                    'id' => $instructor->id,
                    'name' => trim(
                        ($instructor->person->first_name ?? '') . ' ' .
                        ($instructor->person->last_name ?? '') 
                        
                    ),
                    'title' => $assignment?->jobTitle?->name,
                    'avatar' => $instructor->person?->avatar,
                    'panther_id' => $instructor->person?->panther_id,
                    'business_email' => $instructor->person?->business_email,
                    'tenure_type' => $instructor->tenureType?->name,
                    'workload_type' => $first->workload_type,
                    'release_type' => $first->release_type,
                ],

                'courses' => $courses->map(function ($c) use ($instructor) {
                    $section = $c->section;
                    $combinedSectionId = DB::table('ac.combined_sections')
                        ->where('section_id', $section->id)
                        ->value('section_id_combined');

                    $combinedRef = $combinedSectionId
                        ? DB::table('ac.sections')
                            ->where('id', $combinedSectionId)
                            ->value('references_number_panther')
                        : '';

                    $patterns = collect()
                        ->merge($section?->meetingPatterns ?? [])
                        ->merge($section?->meetingPatternHybrids ?? []);

                    $meeting = $patterns->first(fn($m) => $m->instructor_id == $instructor->id && $m->primary_instructor == 1);

                    $semesterYear = $section->term->year;

                    $location = $meeting && !empty($meeting->facility_id)
                        ? DB::table('gn.facilities')->where('id', $meeting->facility_id)->value('code')
                        : '';
                   
                    $time = '';
                   
                    if ($meeting && !empty($meeting->start_time) && !empty($meeting->end_time)) {
                        // Get first 8 chars to remove milliseconds
                        $startRaw = substr($meeting->start_time, 0, 8); // "HH:MM:SS"
                        $endRaw   = substr($meeting->end_time, 0, 8);   // "HH:MM:SS"

                        try {
                            $start = Carbon::createFromFormat('H:i:s', $startRaw)->format('H:i');
                            $end   = Carbon::createFromFormat('H:i:s', $endRaw)->format('H:i');

                            $time = "{$start} - {$end}";
                        } catch (\Exception $e) {
                            $time = ''; // fallback in case parsing fails
                        }
                    }

                    return [
                        'semester' => $section->term->semester . ' ' . $semesterYear,
                        'program' => $section?->program?->code,
                        'course' => $c->course?->code,
                        'course_name' => $c->course?->name,
                        'section' => $section?->sec_code . $section?->sec_number . $section?->sec_sess,
                        'adjusted' => $c->adjusted,
                        'overload' => $c->overload,
                        'on_contract' => $c->on_contract,
                        'instructor_mode' => $section?->instructorMode?->code,
                        'capacity' => $section?->cap,
                        'enrollment' => $section?->student_enrollment,
                        'credit' => $c->course?->credit,
                        'location' => $location,
                        'day' => $meeting?->day,
                        'time' => $time,
                        'comments' => $section?->comment ?? null,
                    ];
                })->values(),

                'summary' => [
                    'workload' => $totalWorkload,
                    'courses' => $courses->count(),
                    'adjusted' => $adjusted,
                    'overload' => $overload,
                    'effective' => $effective,
                    'release' => $release,
                    'release_type' => $first->release_type ?? null,
                    'error' => $error
                ],
            ];

        }

        return [
            'filters' => $request,
            'data' => $report,
        ];
    }
}
