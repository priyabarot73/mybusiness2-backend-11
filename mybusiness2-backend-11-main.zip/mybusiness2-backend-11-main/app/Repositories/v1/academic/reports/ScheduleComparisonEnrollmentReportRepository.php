<?php

namespace App\Repositories\v1\academic\reports;

// GLOBAL IMPORT
use RuntimeException;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\ModelNotFoundException;

// LOCAL IMPORT
use App\Models\academic\Term;
use App\Models\academic\Section;
use App\Models\academic\Offering;

class ScheduleComparisonEnrollmentReportRepository
{
    public function build(array $request): array
    {
        $termNumber = (int) ($request['termNumber'] ?? 0);

        $offeringCodes = $request['offeringCodes'] ?? [];
        if (!is_array($offeringCodes) || count($offeringCodes) === 0) {
            throw new RuntimeException('offeringCodes must be a non-empty array.');
        }

        // Normalize input offering codes -> lowercase + trim + unique
        $offeringCodes = array_values(array_unique(array_filter(array_map(
            fn ($c) => mb_strtolower(trim((string) $c)),
            $offeringCodes
        ), fn ($c) => $c !== '')));

        if (count($offeringCodes) === 0) {
            throw new RuntimeException('offeringCodes must contain at least one valid code.');
        }

        $term = Term::query()->where('number', $termNumber)->first();
        if (!$term) {
            throw (new ModelNotFoundException())->setModel(Term::class, [$termNumber]);
        }

        $previousTermNumber = $this->previousTermNumberByRule($termNumber);
        $previousTerm = Term::query()->where('number', $previousTermNumber)->first();

        /**
         * SQL Server safe: LOWER(LTRIM(RTRIM(code)))
         * - Evita problemas por espacios en DB (e.g. 'UP ').
         * - Evita problemas por mayúsculas/minúsculas.
         */
        $sqlLowerTrim = fn (string $col) => DB::raw("LOWER(LTRIM(RTRIM($col)))");

        // Load offerings (case-insensitive + trim) and validate missing codes
        $offerings = Offering::query()
            ->whereIn($sqlLowerTrim('code'), $offeringCodes)
            ->get()
            ->keyBy(fn ($o) => mb_strtolower(trim((string) $o->code)));

        $missing = array_values(array_diff($offeringCodes, $offerings->keys()->all()));
        if (!empty($missing)) {
            throw (new ModelNotFoundException())->setModel(Offering::class, $missing);
        }

        $rows = Section::query()
            ->from('ac.sections as s')
            ->join('ac.terms as t', 't.id', '=', 's.term_id')
            ->join('ac.courses as c', 'c.id', '=', 's.course_id')
            ->join('ac.programs as p', 'p.id', '=', 's.program_id')
            ->join('ac.offerings as o', 'o.id', '=', 'p.offering_id')
            ->leftJoin('gn.campuses as camp', 'camp.id', '=', 's.campus_id')
            ->leftJoin('ac.instructor_modes as im', 'im.id', '=', 's.instructor_mode_id')
            ->leftJoin('ac.program_groupings as pg', 'pg.id', '=', 'p.program_grouping_id')
            ->whereIn('t.number', array_values(array_filter([$previousTermNumber, $termNumber])))
            ->whereIn($sqlLowerTrim('o.code'), $offeringCodes)

            /**
             * IMPORTANTE:
             * Si s.status es NULL (como en tus CSV), un where('Active') mata todo.
             * Este filtro deja pasar NULL o 'Active' (cualquier casing, con espacios).
             *
             * Si quieres SOLO Active y excluir NULL, quita el whereNull().
             */
            ->where(function ($q) use ($sqlLowerTrim) {
                $q->whereNull('s.status')
                    ->orWhere($sqlLowerTrim('s.status'), 'active');
            })

            ->groupBy([
                'pg.name',
                'p.name',
                'p.code',
                'c.code',
                't.number',
                'camp.code',
                'im.name',
                'o.code',
            ])
            ->orderBy(DB::raw("COALESCE(pg.name, p.name)"))
            ->orderBy('c.code')
            ->select([
                DB::raw("COALESCE(pg.name, p.name) as program_grouping_name"),
                'p.code as program_code',
                'c.code as course_code',
                't.number as term_number',
                'camp.code as campus_code',
                'im.name as instructor_mode_name',
                'o.code as offering_code',
                DB::raw('COUNT(s.id) as sections_count'),
                DB::raw('COALESCE(SUM(COALESCE(s.student_enrollment,0)),0) as enrollment_sum'),
            ])
            ->get();

        $termsMeta = [
            [
                'number' => $previousTermNumber,
                'label'  => $previousTerm?->description_short ?? (string) $previousTermNumber,
            ],
            [
                'number' => $termNumber,
                'label'  => $term->description_short ?? (string) $termNumber,
            ],
        ];

        $data = [];

        foreach ($rows as $r) {
            $groupName = (string) $r->program_grouping_name;
            $course = (string) $r->course_code;
            $tNum = (int) $r->term_number;

            // Normalize offering code coming from DB
            $rowOfferingCode = mb_strtolower(trim((string) ($r->offering_code ?? '')));

            $campusColumn = $this->resolveCampusColumn(
                (string) ($r->campus_code ?? ''),
                (string) ($r->instructor_mode_name ?? ''),
                (string) ($r->program_code ?? ''),
                $rowOfferingCode
            );

            if (!isset($data[$groupName])) {
                $data[$groupName] = [
                    'program_grouping' => $groupName,
                    'courses' => [],
                    'totals' => [
                        $previousTermNumber => [],
                        $termNumber => [],
                    ],
                ];
            }

            if (!isset($data[$groupName]['courses'][$course])) {
                $data[$groupName]['courses'][$course] = [
                    'course_code' => $course,
                    'terms' => [
                        $previousTermNumber => [],
                        $termNumber => [],
                    ],
                    'totals' => [
                        $previousTermNumber => ['sections' => 0, 'enrollment' => 0],
                        $termNumber => ['sections' => 0, 'enrollment' => 0],
                    ],
                ];
            }

            if (!isset($data[$groupName]['courses'][$course]['terms'][$tNum][$campusColumn])) {
                $data[$groupName]['courses'][$course]['terms'][$tNum][$campusColumn] = [
                    'sections' => 0,
                    'enrollment' => 0,
                ];
            }

            $secCount = (int) $r->sections_count;
            $enrSum   = (int) $r->enrollment_sum;

            $data[$groupName]['courses'][$course]['terms'][$tNum][$campusColumn]['sections'] += $secCount;
            $data[$groupName]['courses'][$course]['terms'][$tNum][$campusColumn]['enrollment'] += $enrSum;

            $data[$groupName]['courses'][$course]['totals'][$tNum]['sections'] += $secCount;
            $data[$groupName]['courses'][$course]['totals'][$tNum]['enrollment'] += $enrSum;

            if (!isset($data[$groupName]['totals'][$tNum][$campusColumn])) {
                $data[$groupName]['totals'][$tNum][$campusColumn] = ['sections' => 0, 'enrollment' => 0];
            }

            $data[$groupName]['totals'][$tNum][$campusColumn]['sections'] += $secCount;
            $data[$groupName]['totals'][$tNum][$campusColumn]['enrollment'] += $enrSum;
        }

        $final = [];
        foreach ($data as $group) {
            $courses = array_values($group['courses']);
            usort($courses, fn ($a, $b) => strcmp($a['course_code'], $b['course_code']));

            $final[] = [
                'program_grouping' => $group['program_grouping'],
                'courses' => $courses,
                'totals' => $group['totals'],
            ];
        }

        usort($final, fn ($a, $b) => strcmp($a['program_grouping'], $b['program_grouping']));

        return [
            'meta' => [
                'offering_codes' => $offeringCodes,
                'offerings' => array_values(array_map(function ($code) use ($offerings) {
                    $o = $offerings->get($code);
                    return [
                        'code' => $o?->code,
                        'name' => $o?->name,
                    ];
                }, $offeringCodes)),
                'terms' => $termsMeta,
            ],
            'data' => $final,
        ];
    }

    private function previousTermNumberByRule(int $number): int
    {
        $s = (string) $number;

        if (strlen($s) !== 4 || !ctype_digit($s)) {
            throw new RuntimeException("Unexpected term number format: {$number}");
        }

        $third = (int) $s[2];
        $thirdMinus = $third - 1;

        if ($thirdMinus < 0) {
            throw new RuntimeException("No previous term number possible for: {$number}");
        }

        $prev = $s[0] . $s[1] . (string) $thirdMinus . $s[3];

        return (int) $prev;
    }

    private function resolveCampusColumn(
        string $campusCode,
        string $instructorModeName,
        string $programCode,
        string $offeringCode
    ): string {
        $campusCode = trim($campusCode);
        $programCode = trim($programCode);

        // offering is always in lowercase for comparison
        $offeringCode = mb_strtolower(trim($offeringCode));

        $mode = mb_strtolower(trim($instructorModeName));

        // MMC en tu catálogo es '1' (en SP era '01')
        $isMMC = in_array($campusCode, ['1', '01'], true);

        // Hybrid equivalente a InstMode in ('H','Q')
        $isHybrid = $mode !== '' && (
                str_contains($mode, 'hybrid') ||
                $mode === 'h' ||
                $mode === 'q'
            );

        if ($isMMC && $isHybrid) return 'Hybrid/MMC';
        if ($isMMC) return 'MMC';
        if (in_array($campusCode, ['10', '30', 'BBC'], true)) return 'BBC';
        if ($campusCode === '45') return 'FIU at I-75';
        if (in_array($campusCode, ['88', '99', 'DT'], true)) return 'Brickell';

        $onlineCampusCodes = ['96', '92', '90'];
        if (in_array($campusCode, $onlineCampusCodes, true)) {
            return $programCode === 'BBA-Online' ? 'Online 2.0' : 'Online';
        }

        if ($campusCode === '20' && $offeringCode === 'up') return 'Off Campus';

        return 'Other';
    }
}
