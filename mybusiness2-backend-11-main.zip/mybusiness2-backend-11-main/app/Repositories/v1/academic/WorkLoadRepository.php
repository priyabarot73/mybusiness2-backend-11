<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use App\Models\hr\Person;
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Str;
use App\Models\academic\Section;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Models\academic\Term;
use App\Models\academic\Workload;
use App\Models\academic\Instructor;
use App\Interfaces\UpdateInterface;
use App\Models\academic\WorkloadCourse;
use App\Repositories\v1\BaseRepository;
use App\Exceptions\ResourceNotFoundException;

class WorkLoadRepository extends BaseRepository implements UpdateInterface
{
    protected Carbon $currentDate;

    public function __construct()
    {
        $this->currentDate = Carbon::now();
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */

    /*public function viewAll($termId)
    {
        try {
            // Step 1: Get the selected or current term
            $term = $termId
                ? Term::find($termId)
                : Term::where('begin_dt', '<=', $this->currentDate)
                    ->where('end_dt', '>=', $this->currentDate)
                    ->first();

            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFoundTerm'));
            }

            $academicYear = $term->academic_year;
            $semester = $term->semester; // e.g. 'Fall', 'Spring', 'Summer'

            // Step 2: Determine which terms to include based on logic
            $semestersToInclude = [];

            if (in_array($semester, ['Fall', 'Spring'])) {
                $semestersToInclude = ['Fall', 'Spring'];
            } elseif ($semester === 'Summer') {
                $semestersToInclude = ['Summer'];
            }

            // Step 3: Get all term IDs for the academic year and desired term codes
            $termIds = Term::where('academic_year', $academicYear)
                ->whereIn('semester', $semestersToInclude)
                ->pluck('id');

            // Step 4: Get workloads for those terms
            $workload = Workload::whereIn('term_id', $termIds)
                ->with('term', 'instructor', 'workLoadCourses.course')
                ->get();

            if ($workload->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFound'));
            }

            // Step 5: Format floats
            return $workload->map(function ($item) {
                $item['workload'] = number_format($item['workload'], 2);
                $item['release'] = number_format($item['release'], 2);
                return $item;
            });

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }*/

    public function viewAll($termId)
    {
        try {
            // Step 1: Get the last term stored in the database
            $latestTerm = null;
            if ($termId !== null) {
                $latestTerm = Term::find($termId);
            } else {

                $latestTerm = Term::where('begin_dt', '<=', $this->currentDate)
                    ->where('end_dt', '>=', $this->currentDate)
                    ->first();
            }

            if (!$latestTerm) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFoundTerm'));
            }

            // Step 2: Get the workload associated with the last term
            $workload = Workload::where('term_id', $latestTerm->id)
                ->with('term', 'instructor', 'workLoadCourses.course')
                ->get();

            if ($workload->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFound'));
            }

            // Step 3: Format the floats and return the workload
            return $workload->map(function ($item) {
                $item['workload'] = number_format($item['workload'], 2);
                $item['release'] = number_format($item['release'], 2);
                return $item;
            });
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */

    public function viewById(string $ids): Collection
    {
        try {
            $idArray = array_filter(array_map('trim', explode(',', $ids)));

            $workloads = Workload::with([
                'instructor.person',
                'workloadCourses',
                'workloadCourses.course',
                'workloadCourses.section' => function ($query) {
                    $query->withCount([
                        'meetingPatterns as instructor_number',
                        'meetingPatternHybrids as hybrid_instructor_number'
                    ]);
                    $query->with([
                        'combinedSections.combinedSection',
                        'meetingPatterns',
                        'meetingPatternHybrids'
                    ]);
                },
                'workloadCourses.section.term',
                'workloadCourses.section.instructorMode',
                'workloadCourses.section.program',
            ])->whereIn('id', $idArray)->get();

            if ($workloads->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFoundTerm'));
            }

            // Calculation of the total number of instructor per section
            foreach ($workloads as $workload) {
                foreach ($workload->workloadCourses as $workloadCourse) {
                    $section = $workloadCourse->section;
                    if ($section) {
                        $section->total_instructors = ($section->instructor_number ?? 0) + ($section->hybrid_instructor_number ?? 0);
                    }
                }
            }

            // sort result
            $workloads->each(function ($workload) {
                $workload->workloadCourses = $workload->workloadCourses
                    ->sort(function ($a, $b) {
                        // Compare  course.code
                        $codeA = $a->course->code ?? '';
                        $codeB = $b->course->code ?? '';
                        $cmp = strcmp($codeA, $codeB);

                        if ($cmp === 0) {
                            // If the codes are the same, compare by sec_code + sec_number
                            $secA = ($a->section->sec_code ?? '') . ($a->section->sec_number ?? '');
                            $secB = ($b->section->sec_code ?? '') . ($b->section->sec_number ?? '');
                            return strcmp($secA, $secB);
                        }

                        return $cmp;
                    })->values();
            });


            return $workloads;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewIndex(array $request): array
    {
        try {
            $academicYear = $request['academic_year'];
            $semesters = $request['semesters'];
            $departmentId = trim($request['department_id']);
            $workloadType = $request['workload_type'];

            if (!empty($departmentId)) {
                $instructorIds = Instructor::whereHas('person', function ($query) use ($departmentId) {
                    $query->where('department_id', $departmentId);
                })->pluck('id');

            } else {
                $instructorIds = Instructor::pluck('id');
            }

            if (in_array('Fall', $semesters) || in_array('Spring', $semesters)) {
                $semesters = ['Fall', 'Spring'];
            }

            $workloads = Workload::whereIn('instructor_id', $instructorIds)
                ->where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->with(['instructor.person', 'workLoadCourses'])
                ->get();

            $grouped = $workloads
            ->sortBy(function ($item) {
                return strtolower($item->instructor->person->first_name ?? '');
            })
            ->groupBy('instructor_id');
            $data = [];

            foreach ($grouped as $instructorId => $workloadsGroup) {
                $firstWithData = $workloadsGroup->first(function ($w) {
                    return $w->workload || $w->release || $w->workLoadCourses->sum('adjusted') || $w->workLoadCourses->where('overload', true)->count();
                }) ?? $workloadsGroup->first();

                $allCourses = $workloadsGroup->flatMap(function ($w) {
                    return $w->workLoadCourses;
                });

                $adjusted = $allCourses->sum('adjusted');
                $overload = $allCourses->where('overload', true)->count();
                $release = $firstWithData->release ?? 0;
                $workloadTotal = $firstWithData->workload ?? 0;
                $releaseType = $firstWithData->release_type ?? '';
                $courseCount = $allCourses->count();

                $effective = abs($adjusted - $overload - $release);
                $error = abs((float)$workloadTotal - (float)$effective) > 0.01 ? 1 : 0;

                $data[] = [
                    'workload_id' => $workloadsGroup->pluck('id')->implode(','),
                    'instructor_id' => $firstWithData->instructor->id,
                    'academic_year' => trim($academicYear),
                    'workload' => $workloadTotal,
                    'courses' => $courseCount,
                    'adjusted' => $adjusted,
                    'overload' => $overload,
                    'effective' => $effective,
                    'release' => $release,
                    'releaseType' => $releaseType,
                    'error' => $error,
                    'user_data' => $firstWithData->instructor,
                ];
            }
            return $data;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function getWorkload($academicYear, $semester, $instructorId)
    {
        try {

            // Step 1: Get the workload using academic year, name and instructor_id
//            $workload = Workload::where('academic_year', $academicYear)
//                ->whereRaw('LOWER(semester) = ?', [strtolower($semester)])
//                ->where('instructor_id', $instructorId)
//                ->first();

//            DB::enableQueryLog();
//            dd($academicYear, $semester, $instructorId);
            $workload = Workload::where('academic_year', $academicYear)
                ->whereRaw('LTRIM(RTRIM(LOWER(semester))) = ?', [strtolower(trim($semester))])
                ->where('instructor_id', $instructorId)
                ->first();


            // Step 2: Format the floats if $workload is not null
            if ($workload) {
                $workload->workload = number_format($workload->workload, 2);
                $workload->release = number_format($workload->release, 2);
            }

            return $workload;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            DB::beginTransaction();

            // Step 1: Validate if workload already exists for the user in the given academic year and semester
            $workloadExist = Workload::where('instructor_id', $request['instructor_id'])
                ->where('academic_year', $request['academic_year'])
                ->where('semester', $request['semester'])
                ->exists();

            if ($workloadExist) {
                throw new Exception(trans('academic/workload.exceptionExist'), Response::HTTP_BAD_REQUEST);
            }

            // Step 2: Create a new workload
            $workload = new Workload();

            // Assign the values to the workload
            $newWorkload = $this->dataFormatWorkload($request, $workload);

            // Step 3: Save the new section
            $newWorkload->save();

            // Step 4: Assign the mating patterns to the new section
            if (isset($request['section_id'])) {
                $this->createWorkloadCourse($request, $newWorkload->id, $request['section_id']);
            }

            DB::commit();

            // Step 5: Return the new created section
            return $newWorkload;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        } finally {
            DB::rollBack();
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            DB::beginTransaction();

            // Step 1: Get the workload by id
            $workload = Workload::with('workLoadCourses.course')->find($id);
            if (!$workload) {
                throw new ResourceNotFoundException(trans('workload.exceptionNotFoundCourse'));
            }

            // Step 2: Format and update the rest of the data
            $updatedWorkload = $this->dataFormatWorkload($request, $workload);

            // Step 3: Save the updated workload
            $updatedWorkload->save();

            // Step 4: Replace old workload courses
            $updatedWorkload->workLoadCourses()->delete();
            $this->createWorkloadCourse($request, $updatedWorkload->id, null);

            DB::commit();

            // Step 5: Return updated workload
            return $updatedWorkload;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function sectionCreate($allMeetingPatterns, $request, $newSectionId): void
    {
        try {
            DB::beginTransaction();

            // Step 1: Get the request term
            $term = Term::find($request['term_id']);

            // Step 2: Get instructors from meeting patterns and hybrids
            $allInstructors = collect(array_merge(
                $request['meeting_patterns'] ?? [],
                $request['meeting_pattern_hybrids'] ?? []
            ))->pluck('instructor_id');

            // Step 3: Add instructors from combined sections
            foreach ($request['combined_sections'] ?? [] as $combinedSection) {
                $section = Section::with(['meetingPatterns', 'meetingPatternHybrids'])
                    ->find($combinedSection['section_id']);

                if ($section) {
                    $sectionInstructors = collect()
                        ->merge($section->meetingPatterns->pluck('instructor_id'))
                        ->merge($section->meetingPatternHybrids->pluck('instructor_id'));

                    $allInstructors = $allInstructors->merge($sectionInstructors);
                }
            }

            // Step 4: Remove duplicates and count
            $uniqueInstructors = $allInstructors->filter()->unique();
            $count = $uniqueInstructors->count();

            // Step 5: Calculate the value per instructor
            $value = $count > 0 ? number_format(1 / $count, 2) : 1;

            // Step 6: Create/Update workload and assign courses
            foreach ($uniqueInstructors as $instructorId) {

                // Get existing workload
                $workload = $this->getWorkload($term->academic_year, $term->semester, $instructorId);

                if ($workload) {
                    $requestForCreate = [
                        'workload_course' => [[
                            'course_id' => $request['course_id'],
                            'value' => $value,
                            'overload' => 0,
                            'adjusted' => 0,
                            'on_contract' => 0
                        ]]
                    ];

                    $this->createWorkloadCourse($requestForCreate, $workload->id, $newSectionId);
                } else {
                    $requestForCreate = [
                        'instructor_id' => $instructorId,
                        'section_id' => $newSectionId,
                        'academic_year' => $term->academic_year,
                        'semester' => $term->semester,
                        'workload' => 0,
                        'release' => 0,
                        'release_type' => null,
                        'on_sabbatical' => 0,
                        'on_sick_leave' => 0,
                        'on_paternity_leave' => 0,
                        'comment' => null,
                        'workload_course' => [[
                            'course_id' => $request['course_id'],
                            'value' => $value,
                            'overload' => 0,
                            'adjusted' => 0,
                            'on_contract' => 0
                        ]]
                    ];

                    // Create a new workload and delegate the calculation of workload_type
                    $newWorkload = $this->dataFormatWorkload($requestForCreate, new Workload());
                    $newWorkload->save();

                    $this->createWorkloadCourse($requestForCreate, $newWorkload->id, $newSectionId);
                }
            }

            DB::commit();
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**This is a function to determine the type of workload according to the logic:
     * I have a series of models that I need you to analyze to help me with the following:
     * I need to create a workload, that workload has a type, that type can be:
     * F-> if the instructor has an assignment where the salary admin plan is 220 or 290
     * P-> all others
     * The logic between the models is as follows:
     * I have the instructor's ID, with that ID we search the instructor table and find the ID of the person it is related to,
     * with that person's ID we go to the assignments table and look for the current assignment(s) (end_date=null) for that person,
     * then we take those current assignments and take the ID of the salary admin plan and look for the salary admin plan with which each assignment is related and when we have those salary admin plans we take their code,
     * if any of the codes are 220 or 229 then the type of the workload is F, otherwise it is P,
     */
    private function determineWorkloadType(string $instructorId): string
    {
        $instructor = Instructor::with('person.assignments.salaryAdminPlan')
            ->find($instructorId);

        if (!$instructor || !$instructor->person) {
            return 'P'; // Default fallback
        }

        $assignments = $instructor->person->assignments->whereNull('end_date');

        $codeToType = [
            '220' => 'F',
            '229' => 'F',
            '061' => 'A',
            '013' => 'A',
            '052' => 'P',
            '053' => 'P',
            '054' => 'P',
            '051' => 'P',
        ];

        foreach ($assignments as $assignment) {
            $salaryAdminPlan = $assignment->salaryAdminPlan;

            if ($salaryAdminPlan) {
                $code = trim($salaryAdminPlan->code);
                if (isset($codeToType[$code])) {
                    return $codeToType[$code];
                }
            }
        }

        return 'P';
    }


    /**
     * @throws Exception
     */
    public function dataFormatWorkload(array $request, $workload): object|null
    {
        try {
            $workload->academic_year = $request['academic_year'];
            $workload->semester = $request['semester'];
            $workload->workload = $request['workload'];
            $workload->release = $request['release'];
            $workload->release_type = $request['release_type'];
            $workload->on_sabbatical = $request['on_sabbatical'];
            $workload->on_sick_leave = $request['on_sick_leave'];
            $workload->on_paternity_leave = $request['on_paternity_leave'];
            $workload->workload_type = $this->determineWorkloadType($request['instructor_id']);
            $workload->comment = $request['comment'];
            $workload->instructor_id = $request['instructor_id'];
            return $workload;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function createWorkloadCourse($request, $id, $sectionId): void
    {
        try {
            foreach ($request['workload_course'] as $workload) {
                $workloadCourse = new WorkloadCourse();
                $workloadCourse->workload_id = $id;
                $workloadCourse->section_id = $sectionId ?: $workload['section_id'];
                $workloadCourse->course_id = $workload['course_id'];
                $workloadCourse->value = $workload['value'];
                $workloadCourse->overload = $workload['overload'];
                $workloadCourse->adjusted = $workload['adjusted'];
                $workloadCourse->on_contract = $workload['on_contract'];
                $workloadCourse->save();
            }
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage());
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function delete($workloadId)
    {
        try {
            DB::beginTransaction();
            $workload = Workload::findOrFail($workloadId);

            if (!$workload) {
                throw new ResourceNotFoundException(trans('academic/workload.exceptionNotFound'));
            }
            $workload->workLoadCourses()->delete();
            $workload->delete();

            DB::commit();
            return $workload;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('academic/workload.error'), Response::HTTP_INTERNAL_SERVER_ERROR);
        } finally {
            DB::rollBack();
        }
    }

    /**
     * @throws Exception
     */
    public function calculateWorkloadInfo(array $request): array
    {
        try {
            $academicYear = $request['academic_year'];
            $semesters = $request['semesters'];
            $workloadType = $request['workload_type'];

            $workloads = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->get();
            $errorCount = 0;

            foreach ($workloads as $workload) {
                $effective = abs($workload->release - $workload->workloadCourses->sum('adjusted') - $workload->workloadCourses->where('overload', true)->count());
                $error = ((float)$workload->workload !== (float)$effective) ? 1 : 0;
                $errorCount += $error;
            }

            $totalWorkload = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->count('workload');

            $totalWithRelease = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->where('release', '>', 0)->count('release');

            $totalAdjusted = WorkloadCourse::whereHas('workload', function ($query) use ($academicYear, $semesters, $workloadType) {
                $query->where('academic_year', $academicYear)
                    ->whereIn('semester', $semesters)
                    ->where('workload_type', $workloadType);
            })->where('adjusted', '>', 0)->count('adjusted');

            $totalSabbatical = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->where('on_sabbatical', true)
                ->count();

            $totalOnSickLeave = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->where('on_sick_leave', true)
                ->count();

            $totalOnPaternityLeave = Workload::where('academic_year', $academicYear)
                ->whereIn('semester', $semesters)
                ->where('workload_type', $workloadType)
                ->where('on_paternity_leave', true)
                ->count();

            $totalOverload = WorkloadCourse::whereHas('workload', function ($query) use ($academicYear, $semesters, $workloadType) {
                $query->where('academic_year', $academicYear)
                    ->whereIn('semester', $semesters)
                    ->where('workload_type', $workloadType);
            })->where('overload', true)->count();

            $totalOnContract = WorkloadCourse::whereHas('workload', function ($query) use ($academicYear, $semesters, $workloadType) {
                $query->where('academic_year', $academicYear)
                    ->whereIn('semester', $semesters)
                    ->where('workload_type', $workloadType);
            })->where('on_contract', true)->count();

            return [
                'totalWorkload' => number_format($totalWorkload, 0),
                'workloadInfo' => [
                    ['value' => number_format($errorCount, 0), 'title' => 'With error'],
                    ['value' => number_format($totalWithRelease, 0), 'title' => 'With release'],
                    ['value' => number_format($totalAdjusted, 0), 'title' => 'Adjusted'],
                    ['value' => number_format($totalSabbatical, 0), 'title' => 'Sabbatical'],
                    ['value' => number_format($totalOnSickLeave, 0), 'title' => 'On sick leave'],
                    ['value' => number_format($totalOnPaternityLeave, 0), 'title' => 'On paternity leave'],
                    ['value' => number_format($totalOverload, 0), 'title' => 'Overload'],
                    ['value' => number_format($totalOnContract, 0), 'title' => 'On contract'],
                ],
            ];
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
