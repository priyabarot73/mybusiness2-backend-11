<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Session;
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Exceptions\ResourceNotFoundException;

class SessionRepository implements CrudInterface,ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $sessions = Session::where('ac.sessions.active','=',$status)->get();
            if ($sessions->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFoundByStatus'));
            }
            return $sessions;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $sessions = Session::orderBy('code','desc')->get();
            if ($sessions->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFound'));
            }
            return $sessions;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllArray(): array
    {
        try {
            $sessions = Session::where('active', true)->get();

            if ($sessions->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFound'));
            }

            $result = [
                'secCode' => [],
                'secNumber' => [],
                'secSess' => [],
            ];

            foreach ($sessions as $session) {
                //Step 1: Store the code in secCode if it is not null
                $code = $session->code;
                if ($code !== null && !in_array(['code' => $code], $result['secCode'])) {
                    $result['secCode'][] = ['code' => $code, 'id' => $session->id];
                }

                //Step 2: Store the number in secNumber if it is not null
                $number = $session->number;
                if ($number !== null && !in_array(['number' => $number], $result['secNumber'])) {
                    $result['secNumber'][] = ['code' => $number, 'id' => $session->id];
                }

                //Step 3: Store the session in secSess if it is not null
                $sess = $session->sess;
                if ($sess !== null && !in_array(['sess' => $sess], $result['secSess'])) {
                    $result['secSess'][] = ['code' => $sess, 'id' => $session->id];
                }
            }

            // Sorting arrays
            usort($result['secCode'], function ($a, $b) {
                return $a['code'] <=> $b['code'];
            });

            usort($result['secNumber'], function ($a, $b) {
                return $a['code'] <=> $b['code'];
            });

            usort($result['secSess'], function ($a, $b) {
                return $a['code'] <=> $b['code'];
            });

            return $result;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $session = Session::find($id);
            if (!$session){
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFoundById'));
            }
            return $session;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $session = new Session();
            $newSession = $this->dataFormat($request,$session);
            $newSession->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSession->id,
                'created',
                'Session',
                'A new type of Session was created: ' . $newSession->code. ' ' .$newSession->number. ' '.$newSession->sess ,
            );

            return $newSession;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $session = $this->viewById($id);
            if (!$session){
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFoundById'));
            }
            $newSession = $this->dataFormat($request,$session);
            $newSession->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSession->id,
                'updated',
                'Session',
                'Session was updated: ' . $newSession->code. ' ' .$newSession->number. ' '.$newSession->sess ,
            );

            return $newSession;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $session = $this->viewById($id);
            if (!$session){
                throw new ResourceNotFoundException(trans('academic/session.exceptionNotFoundById'));
            }
            $session->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $session->id,
                'deleted',
                'Session',
                'Session was deleted: ' . $session->code. ' ' .$session->number. ' '.$session->sess ,
            );

            return $session;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Session $session):object|null
    {
        $session->code = $request['code'];
        $session->number = $request['number'];
        $session->sess = $request['sess'];
        $session->active = $request['active'];
        return $session;
    }
}
