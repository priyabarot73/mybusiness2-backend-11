<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Models\academic\InstructorMode;
use App\Exceptions\ResourceNotFoundException;

class InstructorModeRepository implements CrudInterface,ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $instructorModes = InstructorMode::orderBy('name','desc')->get();
            if ($instructorModes->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/instructor_mode.exceptionNotFound'));
            }
            return $instructorModes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $instructorModes = InstructorMode::where('active','=',$status)->get();
            if ($instructorModes->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/instructor_mode.exceptionNotFoundByStatus'));
            }
            return $instructorModes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $instructorMode = InstructorMode::find($id);
            if (!$instructorMode){
                throw new ResourceNotFoundException(trans('academic/instructor_mode.exceptionNotFoundById'));
            }
            return $instructorMode;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $instructorMode = new InstructorMode();
            $newIM = $this->dataFormat($request,$instructorMode);
            $newIM->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newIM->id,
                'created',
                'Instructor mode',
                'A new type of Instructor mode was created: ' . $newIM->name,
            );

            return $newIM;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $instructorMode = $this->viewById($id);
            if (!$instructorMode){
                throw new ResourceNotFoundException(trans('academic/instructor_mode.exceptionNotFoundById'));
            }
            $newIM = $this->dataFormat($request,$instructorMode);
            $newIM->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newIM->id,
                'updated',
                'Instructor mode',
                'Instructor mode was updated: ' . $newIM->name,
            );

            return $newIM;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $instructorMode = $this->viewById($id);
            if (!$instructorMode){
                throw new ResourceNotFoundException(trans('academic/instructor_mode.exceptionNotFoundById'));
            }
            $instructorMode->delete();
            return $instructorMode;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, InstructorMode $instructorMode):object|null
    {
        try {
            $instructorMode->code = $request['code'];
            $instructorMode->name = $request['name'];
            $instructorMode->active = $request['active'];
            return $instructorMode;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
