<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Degree;
use App\Exceptions\ResourceNotFoundException;

class DegreeRepository
{

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $degrees = Degree::where('ac.degrees.active','=',$status)->get();
            if ($degrees->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/degree.exceptionNotFoundByStatus'));
            }
            return $degrees;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $degrees = Degree::orderBy('name','desc')->get();
            if ($degrees->isEmpty()){
                throw new ResourceNotFoundException(trans('academic/degree.exceptionNotFound'));
            }
            return $degrees;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $degree = new Degree();
            $newDegree = $this->dataFormat($request,$degree);
            $newDegree->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newDegree->id,
                'created',
                'Degree',
                'A new type of Degree was created: ' . $newDegree->name,
            );

            return $newDegree;
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $degree =  Degree::find($id);
            if (!$degree){
                throw new ResourceNotFoundException(trans('academic/degree.exceptionNotFoundById'));
            }
            $newDegree = $this->dataFormat($request,$degree);
            $newDegree->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newDegree->id,
                'updated',
                'Degree',
                'Degree was updated: ' . $newDegree->name,
            );

            return $newDegree;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Degree $degree):object|null
    {
        $degree->code = $request['code'];
        $degree->name = $request['name'];
        $degree->active = $request['active'];
        return $degree;
    }

}
