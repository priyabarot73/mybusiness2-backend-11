<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Models\User;
use App\Models\hr\Person;
use App\Models\academic\ControlCloneSection;
use App\Exceptions\ResourceNotFoundException;

class ControlCloneSectionRepository
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            // Step 1: Get all clone sections entries
            $controls = ControlCloneSection::orderBy('created_at','desc')->get();
            if ($controls->isEmpty()){
                throw new ResourceNotFoundException(trans('control_clone_section.exceptionNotFound'));
            }

            // Step 2: Get users' unique IDs to upload their data in one go
            $userIds = $controls->pluck('user')->unique()->toArray();

            // Step 3: Get user data associated with controls
            $users = Person::whereIn('panther_id', $userIds)->get()->keyBy('panther_id');

            // Step 4: Combine user data with controls
            foreach ($controls as $control) {
                $control->user_data = $users[$control->user] ?? null;
            }

            // Step 5: Return
            return $controls;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function getUser(): ?User
    {
        try {
            // Step 1: Get user by panther id 0000000
            $user = User::where('panther_id', '9999999')->first();
            if (!$user){
                throw new ResourceNotFoundException(trans('control_clone_section.exceptionNotFoundById'));
            }

            // Step 2: Return
            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
