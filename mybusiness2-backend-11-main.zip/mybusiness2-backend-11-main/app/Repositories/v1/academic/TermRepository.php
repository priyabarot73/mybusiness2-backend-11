<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\academic\Term;
use App\Exceptions\ResourceNotFoundException;


class TermRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'number');
            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'desc')));

            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'desc';
            }

            // filters (can be array OR json string)
            $filterModel = $request->query('filters'); // array|string|null
            if (is_string($filterModel) && $filterModel !== '') {
                $decoded = json_decode($filterModel, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $filterModel = $decoded;
                }
            }

            $query = Term::query();

            // Search
            if (!empty($search)) {
                $searchLower = strtolower($search);

                $query->where(function ($q) use ($searchLower, $search) {
                    $q->whereRaw('LOWER(semester) LIKE ?', ["%{$searchLower}%"]);

                    if (is_numeric($search)) {
                        $q->orWhere('number', intval($search))
                            ->orWhere('year', intval($search));
                    }
                });
            }


            // Apply filter (DataGrid)
            $allowedFilterFields = ['number', 'name', 'semester', 'year', 'academicYear', 'p18StatusTermId'];

            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {

                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and|or

                $makeLike = function ($value, $operator) {
                    $v = strtolower(trim((string) $value));

                    return match ($operator) {
                        'equals', '=', 'is'       => $v,
                        'startsWith'              => $v . '%',
                        'endsWith'                => '%' . $v,
                        default                   => '%' . $v . '%', // contains
                    };
                };

                $query->where(function ($root) use ($filterModel, $logic, $allowedFilterFields, $makeLike) {

                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        if (!$field || !in_array($field, $allowedFilterFields, true)) {
                            continue;
                        }
                        if ($value === null || trim((string)$value) === '') {
                            continue;
                        }

                        $apply = function ($q) use ($field, $operator, $value, $makeLike) {
                            $pattern = $makeLike($value, $operator);

                            $columnMap = [
                                'number'         => 'number',
                                'semester'       => 'semester',
                                'year'           => 'year',
                                'academicYear'   => 'academic_year',
                                'p18StatusTermId'=> 'p18_status_term_id',
                            ];

                            // number/year: equals numérico o LIKE por CAST
                            if ($field === 'number' || $field === 'year') {
                                $col = $columnMap[$field];

                                if (in_array($operator, ['equals', '=', 'is'], true) && is_numeric($value)) {
                                    return $q->where($col, intval($value));
                                }

                                return $q->whereRaw("CAST({$col} AS VARCHAR(50)) LIKE ?", [$pattern]);
                            }

                            if ($field === 'name') {
                                return $q->where(function ($x) use ($pattern) {
                                    $x->whereRaw(
                                        "LOWER(CONCAT(ISNULL(semester,''),' ',CAST(year AS VARCHAR(10)))) LIKE ?",
                                        [$pattern]
                                    )->orWhereRaw(
                                        "LOWER(CONCAT(ISNULL(semester,''),CAST(year AS VARCHAR(10)))) LIKE ?",
                                        [$pattern]
                                    );
                                });
                            }

                            // semester / academicYear / p18StatusTermId: LIKE by CAST
                            if (in_array($field, ['semester', 'academicYear', 'p18StatusTermId'], true)) {
                                $col = $columnMap[$field] ?? $field;
                                return $q->whereRaw("LOWER(CAST({$col} AS VARCHAR(200))) LIKE ?", [$pattern]);
                            }

                            return null;
                        };

                        if ($logic === 'or') {
                            $root->orWhere(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        } else {
                            $root->where(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        }
                    }
                });
            }

            // Sorting
            $sortMap = [
                'academicYear'    => 'academic_year',
                'p18StatusTermId' => 'p18_status_term_id',
            ];

            $sortColumnDb = $sortMap[$sortColumn] ?? $sortColumn;

            $sortableColumns = ['year', 'number', 'semester', 'start_date', 'end_date', 'created_at', 'academic_year', 'p18_status_term_id'];

            if (in_array($sortColumnDb, $sortableColumns, true)) {
                $query->orderBy($sortColumnDb, $sortDirection);
            } else {
                $query->orderBy('number', 'desc');
            }

            $terms = $query->paginate($perPage, ['*'], 'page', $page);

            if ($terms->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFound'));
            }

            return $terms;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }




    /**
     * @throws Exception
     */
    public function viewAllByStatus(Request $request, $status): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'number');
            $sortDirection = $request->query('sortDirection', 'desc');

            // query base
            $query = Term::where('ac.terms.active', '=', $status);

            // apply search
            if (!empty($search)) {
                $searchLower = strtolower($search);

                $query->where(function ($q) use ($searchLower) {
                    $q->whereRaw('LOWER(semester) LIKE ?', ["%$searchLower%"]);
                });

                if (is_numeric($search)) {
                    $query->orWhere('number', intval($search));
                    $query->orWhere('year', intval($search));
                }
            }

            // columns to sort
            $sortableColumns = ['name', 'number', 'description', 'start_date', 'end_date', 'created_at'];

            // apply sorting
            if (in_array($sortColumn, $sortableColumns)) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('number', 'desc'); // default sort
            }

            // paginate
            $terms = $query->paginate($perPage, ['*'], 'page', $page);

            if ($terms->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundByStatus'));
            }

            return $terms;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function lastFiveTerms()
    {
        try {
            // Get the last 5 terms ordered from greatest to least by number
            return Term::orderByDesc('number')->take(5)->get();
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function getTerms($number)
    {
        try {
            // Get the number of terms ordered from greatest to least by number
            return Term::orderByDesc('number')->take($number)->get();
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $term = Term::find($id);
            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundById'));
            }
            return $term;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            // Step 1: Validate term
            $this->validateTerm($request);

            //Step 2: Create the term if there are no problems
            $term = new Term();
            $newTerm = $this->dataForTerm($request, $term);
            $newTerm->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newTerm->id,
                'created',
                'Term',
                'A new type of Term was created: ' . $newTerm->number,
            );

            //Step 3: Return new term
            return $newTerm;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {

            // Step 1: Find the term by id
            $term = $this->viewById($id);
            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundById'));
            }

            // Step 2: Check if a term with 'current' set to true already exists
            $this->validateTerm($request, $term);

            //Step 3: Update the term if there are no problems
            $newTerm = $this->dataForTerm($request, $term);
            $newTerm->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newTerm->id,
                'updated',
                'Term',
                'Term was updated: ' . $newTerm->number,
            );

            //Step 4: Return new term
            return $newTerm;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $term = $this->viewById($id);
            if (!$term) {
                throw new ResourceNotFoundException(trans('academic/term.exceptionNotFoundById'));
            }
            $term->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $term->id,
                'deleted',
                'Term',
                'Term was deleted: ' . $term->number,
            );

            return $term;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataForTerm(array $request, Term $term): object|null
    {
        try {
            $term->number = $request['number'];
            $term->semester = $request['semester'];
            $term->year = $request['year'];
            $term->academic_year = $request['academic_year'];
            $term->description = $request['description'];
            $term->fiu_academic_year = $request['fiu_academic_year'];
            $term->description_short = $request['description_short'];
            $term->begin_dt_for_apt = $request['begin_dt_for_apt'];
            $term->begin_dt = $request['begin_dt'];
            $term->end_dt = $request['end_dt'];
            $term->close_end_dt = $request['close_end_dt'];
            $term->fas_begin_dt = $request['fas_begin_dt'];
            $term->fas_end_dt = $request['fas_end_dt'];
            $term->session = $request['session'];
            $term->academic_year_full = $request['academic_year_full'];
            $term->fiu_grade_date = $request['fiu_grade_date'];
            $term->fiu_grade_date_a = $request['fiu_grade_date_a'];
            $term->fiu_grade_date_b = $request['fiu_grade_date_b'];
            $term->fiu_grade_date_c = $request['fiu_grade_date_c'];
            $term->p180_status_term_id = $request['p180_status_term_id'];
            $term->active = $request['active'];
            return $term;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws ResourceNotFoundException
     */
    private function validateTerm(array $request, ?Term $term = null): void
    {
        // Step 1: Check if a term with 'current' set to true already exists
        if (isset($request['current']) && $request['current'] === '1') {
            $existingTerm = Term::where('current', true)->first();
            if ($existingTerm && (!$term || $existingTerm->id !== $term->id)) {
                throw new ResourceNotFoundException(trans('academic/term.current_exists'));
            }
        }

        //Step 2: Check if a term with the same semester and year already exists
        $existingSemesterTerm = Term::where('semester', $request['semester'])
            ->where('year', $request['year'])
            ->first();
        if ($existingSemesterTerm && (!$term || $existingSemesterTerm->id !== $term->id)) {
            throw new ResourceNotFoundException(trans('academic/term.already_exists'));
        }
    }
}


