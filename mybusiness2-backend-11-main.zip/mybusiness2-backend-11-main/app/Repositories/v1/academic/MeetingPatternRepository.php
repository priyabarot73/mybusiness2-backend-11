<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Models\academic\MeetingPattern;

class MeetingPatternRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $meetingPatterns = MeetingPattern::all();
            if ($meetingPatterns->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/meeting_pattern.exceptionNotFound'));
            }
            return $meetingPatterns;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewByDayHourRoomId($day,$hour,$room_id)
    {
        try {
            $meetingPattern = MeetingPattern::where('day',$day)->where('hour',$hour)->where('room_id',$room_id)->first();
            if (!$meetingPattern){
                throw new ResourceNotFoundException(trans('hr/meeting_pattern.exceptionNotFoundByDayHourRoom'));
            }
            return $meetingPattern;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $meeting = new MeetingPattern();
            $newMeeting = $this->dataFormat($request,$meeting);
            $newMeeting->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newMeeting->id,
                'created',
                'Meeting pattern',
                'A new type of Meeting pattern was created: ' . $newMeeting->day,
            );

            return $newMeeting;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($day,$hour,$room_id,$request)
    {
        try {
            $meetingPattern = $this->viewById($day,$hour,$room_id);
            if (!$meetingPattern){
                throw new ResourceNotFoundException(trans('hr/meeting_pattern.exceptionNotFoundByDayHourRoom'));
            }
            $meetingAux = $this->dataFormat($request,$meetingPattern);
            $meetingAux->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $meetingAux->id,
                'updated',
                'Meeting pattern',
                'Meeting pattern was updated: ' . $meetingAux->day,
            );

            return $meetingAux;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($day,$hour,$room_id): object|null
    {
        try {

            $meetingPattern = $this->viewById($day,$hour,$room_id);
            if (!$meetingPattern){
                throw new ResourceNotFoundException(trans('hr/meeting_pattern.exceptionNotFoundByDayHourRoom'));
            }
            $meetingPattern->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $meetingPattern->id,
                'updated',
                'Meeting pattern',
                'Meeting pattern was delete: ' . $meetingPattern->day,
            );

            return $meetingPattern;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, MeetingPattern $meeting):object|null
    {
        $meeting->day=$request['day'];
        $meeting->hour=$request['hour'];
        $meeting->room_id=$request['room_id'];
        return $meeting;
    }
}
