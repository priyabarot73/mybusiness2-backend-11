<?php

namespace App\Repositories\v1\academic;

//GLOBAL IMPORT

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\academic\QualificationType;
use App\Exceptions\ResourceNotFoundException;

class QualificationTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $qualificationType = QualificationType::orderBy('name', 'desc')->get();
            if ($qualificationType->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/qualification_type.exceptionNotFound'));
            }
            return $qualificationType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $qualificationType = QualificationType::where('active', $status)->orderBy('name', 'desc')->get();
            if ($qualificationType->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/qualification_type.exceptionNotFoundByStatus'));
            }
            return $qualificationType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $qualificationType = new QualificationType();
            $newQualificationType = $this->dataFormat($request, $qualificationType);
            $newQualificationType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newQualificationType->id,
                'created',
                'Qualification type',
                'A new type of Qualification type was created: ' . $newQualificationType->name,
            );

            return $newQualificationType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $qualificationType = QualificationType::find($id);
            if (!$qualificationType) {
                throw new ResourceNotFoundException(trans('academic/qualification_type.exceptionNotFoundById'));
            }
            $newQualificationType = $this->dataFormat($request, $qualificationType);
            $newQualificationType->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newQualificationType->id,
                'updated',
                'Qualification type',
                'Qualification type was updated: ' . $newQualificationType->name,
            );

            return $newQualificationType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, QualificationType $qualificationType): object|null
    {
        $qualificationType->name = $request['name'];
        $qualificationType->code = $request['code'];
        $qualificationType->order = $request['order'];
        $qualificationType->active = $request['active'];
        return $qualificationType;
    }
}
