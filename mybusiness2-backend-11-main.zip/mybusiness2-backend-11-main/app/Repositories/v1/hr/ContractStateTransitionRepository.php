<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//Local Imports
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\ContractStateTransition;
use App\Exceptions\ResourceNotFoundException;

class ContractStateTransitionRepository implements UpdateInterface, ViewAllInterface, CreateInterface
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try
        {
            $contractStates = ContractStateTransition::with(['sourceState.contractOption', 'targetState.contractOption'])
                ->get();
            if ($contractStates->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_state_transition.exceptionNotFound'));
            }
            return $contractStates;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $contractStateTransition = new ContractStateTransition();

            $contractState = $this->dataFormat($request, $contractStateTransition);

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $contractState->id,
                'created',
                'Contract state transition',
                'A new type of Contract state transition was created: ' . $contractState->name,
            );

            return $contractState;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): array|object|null
    {
        try
        {
            $contractStateTransition = ContractStateTransition::find($id);
            if (!$contractStateTransition){
                throw new ResourceNotFoundException(trans('hr/contract_state_transition.exceptionNotFoundById'));
            }

            $contractState = $this->dataFormat($request, $contractStateTransition);

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $contractState->id,
                'updated',
                'Contract state transition',
                'Contract state transition was updated: ' . $contractState->name,
            );

            return $contractState;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ContractStateTransition $contractStateTransition):object|null
    {
        try {
            $contractStateTransition->source_state_id = $request['source_state_id'];
            $contractStateTransition->target_state_id = $request['target_state_id'];
            $contractStateTransition->name = $request['name'];
            $contractStateTransition->code = $request['code'];
            $contractStateTransition->message = $request['message'];
            $contractStateTransition->order = $request['order'];
            $contractStateTransition->active = $request['active'];
            $contractStateTransition->save();
            return $contractStateTransition;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }


    //    public function viewAll()
    //    {
    //        try {
    //            // Retrieve all contract state transitions, eager loading 'sourceState' and 'targetState' relationships
    //            $contractStateTransitions = ContractStateTransition::with(['sourceState', 'targetState']) // Eager load relationships
    //            ->get();
    //
    //            // If no transitions are found, throw a ResourceNotFoundException
    //            if ($contractStateTransitions->isEmpty()) {
    //                throw new ResourceNotFoundException(trans('contract_state_transition.exceptionNotFound'));
    //            }
    //
    //            // Group the transitions by 'source_state_id' (parent state)
    //            $groupedTransitions = $contractStateTransitions->groupBy('source_state_id');
    //
    //            // Format the data to create a tree and return result
    //            return $groupedTransitions->map(function ($transitions, $sourceStateId) {
    //                // Get the source state for the current group of transitions
    //                $sourceState = $transitions->first()->sourceState; // I assume all transitions in the group have the same source state
    //
    //                // Create the array for the parent state with its transitions
    //                return [
    //                    'id' => $sourceState->id,
    //                    'name' => $sourceState->name,
    //                    'message' => $sourceState->message,
    //                    'children' => $transitions->map(function ($transition) {
    //                        // Create the child items for each transition, linking to the target state
    //                        return [
    //                            'id' => $transition->targetState->id,
    //                            'name' => $transition->targetState->name,
    //                            'message' => $transition->targetState->message,
    //                        ];
    //                    })
    //                ];
    //            });
    //        } catch (ResourceNotFoundException $e) {
    //            Log::error($e);
    //            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
    //        } catch (Exception $e) {
    //            Log::error($e);
    //            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
    //        }
    //    }

    //ESte codigo es para asignar el correcto orden cuando proviene del arbol que voy a construir
//    public function assign(array $request): object|null|array
//    {
//        try {
//            // Start a database transaction
//            DB::beginTransaction();
//
//            // Array to store the results of the creation process
//            $result = [];
//
//            // Iterate over each state data in the provided input
//            foreach ($request['states'] as $stateData) {
//                // Search for the existing ContractState by its ID
//                $contractState = ContractState::find($stateData['id']);
//
//                // If the state does not exist, throw an exception or handle the case as needed
//                if (!$contractState) {
//                    throw new Exception("Contract State with ID {$stateData['id']} not found.");
//                }
//
//                // Add the updated state to the result array
//                $result[] = [
//                    'id' => $contractState->id,
//                    'name' => $contractState->name,
//                    'active' => $contractState->active,
//                ];
//
//                // Handle children recursively (passing the 'message' attribute)
//                $this->handleChildren($stateData, $contractState, $result);
//            }
//
//            // Commit the transaction if all operations are successful
//            DB::commit();
//
//            // Return the result as an array
//            return $result;
//
//        } catch (Exception $e) {
//            // Rollback the transaction in case of error
//            DB::rollBack();
//            Log::error($e);
//
//            // Return an error array instead of a JSON response
//            return [
//                'error' => 'Failed to create contract states and transitions.',
//                'message' => $e->getMessage(),
//            ];
//        }
//    }
//
//    private function handleChildren(array $stateData, ContractState $contractState, array &$result)
//    {
//        // Check if this state has children
//        if (isset($stateData['children']) && is_array($stateData['children'])) {
//            foreach ($stateData['children'] as $childData) {
//                // Check if the child state exists
//                $childState = ContractState::find($childData['id']);
//
//                dd($childState);
//
//                // If the child state exists, create or update the transition
//                if ($childState) {
//                    ContractStateTransition::updateOrCreate(
//                        [
//                            'source_state_id' => $contractState->id, // source is the current contract state
//                            'target_state_id' => $childState->id,   // target is the child contract state
//                        ],
//                        [
//                            'name' => $childData['name'],
//                            'message' => $childData['message'] ?? '', // Default message if not provided
//                        ]
//                    );
//
//                    // Add the child state to the result array
//                    $result[] = [
//                        'id' => $childState->id,
//                        'name' => $childState->name,
//                        'message' => $childData['message'] ?? '', // Add message to the result if it exists
//                    ];
//
//                    // Recursively handle any further children of this child state
//                    $this->handleChildren($childData, $childState, $result);
//                } else {
//                    // If the child state does not exist, you can log it or throw an exception
//                    Log::warning("Child Contract State with ID {$childData['id']} not found.");
//                }
//            }
//        }
//    }

}
