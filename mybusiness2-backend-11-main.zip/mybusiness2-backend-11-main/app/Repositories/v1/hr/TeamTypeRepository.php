<?php

namespace App\Repositories\v1\hr;

// Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// Helpers
use App\Helpers\ActivityTimeLineHelper;

// Local Imports
use App\Models\hr\TeamType;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Interfaces\ViewByIdInterface;
use App\Exceptions\ResourceNotFoundException;

class TeamTypeRepository implements ActiveInterface, UpdateInterface, ViewAllInterface, CreateInterface, ViewByIdInterface
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $teamTypes = TeamType::orderBy('name')->get();
            if ($teamTypes->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/team_type.exceptionNotFound'));
            }
            return $teamTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $teamType = TeamType::find($id);
            if (!$teamType) {
                throw new ResourceNotFoundException(trans('hr/team_type.exceptionNotFoundById'));
            }
            return $teamType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $teamTypes= TeamType::where('active', $status)->orderBy('name')->get();
            if ($teamTypes->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/team_type.exceptionNotFoundByStatus'));
            }
            return $teamTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $teamType = new TeamType();
            $newTeamType = $this->dataFormat($request, $teamType);
            $newTeamType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newTeamType->id,
                'created',
                'Team type',
                'A new team type was created: ' . $newTeamType->name,
            );

            return $newTeamType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $teamType = TeamType::find($id);
            if (!$teamType) {
                throw new ResourceNotFoundException(trans('hr/team_type.exceptionNotFoundById'));
            }

            $updatedTeamType = $this->dataFormat($request, $teamType);
            $updatedTeamType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $updatedTeamType->id,
                'updated',
                'Team type',
                'Team type was updated: ' . $updatedTeamType->name,
            );

            return $updatedTeamType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    private function dataFormat($data, TeamType $teamType): TeamType
    {
        try {
            $teamType->name = $data['name'];
            $teamType->active = $data['active'] ?? true;
            return $teamType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
