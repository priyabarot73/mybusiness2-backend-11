<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\CitizenshipType;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
class CitizenshipTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $ct = CitizenshipType::orderBy('name', 'desc')->get();
            if ($ct->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/citizenship_type.exceptionNotFound'));
            }
            return $ct;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $ct= CitizenshipType::where('active', $status)->orderBy('name','desc')->get();
            if ($ct->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/citizenship_type.exceptionNotFoundByStatus'));
            }
            return $ct;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $ct = new CitizenshipType();
            $newCt = $this->dataFormat($request,$ct);
            $newCt->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCt->id,
                'created',
                'Citizenship type',
                'A new Citizenship type was created: ' . $newCt->name,
            );

            return $newCt;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $ct = CitizenshipType::find($id);
            if (!$ct){
                throw new ResourceNotFoundException(trans('hr/citizenship_type.exceptionNotFoundById'));
            }
            $newCt = $this->dataFormat($request,$ct);
            $newCt->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCt->id,
                'Updated',
                'Citizenship type',
                'Citizenship type was Updated: ' . $newCt->name,
            );

            return $newCt;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, CitizenshipType $ct):object|null
    {
        try {
            $ct->name = $request['name'];
            $ct->active = $request['active'];
            return $ct;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
