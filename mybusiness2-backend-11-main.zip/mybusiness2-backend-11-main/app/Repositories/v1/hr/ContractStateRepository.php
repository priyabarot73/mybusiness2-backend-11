<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//Local Imports
use App\Models\hr\ContractState;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\ContractStateSupervisor;

class ContractStateRepository implements ActiveInterface, UpdateInterface, ViewAllInterface, CreateInterface
{
    /**
     * @throws Exception
     */
     public function viewAll()
     {
        try
        {
            $contractStates = ContractState::orderBy('name','desc')
                ->with(['contractOption','supervisors.person'])
                ->get();
            if ($contractStates->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_state.exceptionNotFound'));
            }
            return $contractStates;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
     }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
     {
        try{
            $contractStates = ContractState::where('active','=',$status)
                ->with(['contractOption','supervisors.person'])
                ->orderBy('name', 'asc')->get();
            if ($contractStates->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_state.exceptionNotFoundByStatus'));
            }
            return $contractStates;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
     }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
     {
         try {
             $contractState = new ContractState();
             $newContractState = $this->dataFormat($request, $contractState);
             $this->dataFormatSupervisor($request, $newContractState->id);

             // Store activity timeline
             ActivityTimeLineHelper::store(
                 $newContractState->id,
                 'created',
                 'Contract state',
                 'A new type of Contract state was created: ' . $newContractState->name,
             );

             return $newContractState;
         }catch (Exception $e) {
             Log::error($e);
             throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
         }
     }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): array|object|null
     {
        try
         {
             $contractState = ContractState::find($id);
             if (!$contractState){
                 throw new ResourceNotFoundException(trans('hr/contract_state.exceptionNotFoundById'));
             }
             $contractState = $this->dataFormat($request, $contractState);
             $contractState->supervisors()->delete();
             $this->dataFormatSupervisor($request, $contractState->id);

             // Store activity timeline
             ActivityTimeLineHelper::store(
                 $contractState->id,
                 'updated',
                 'Contract state',
                 'Contract state was update: ' . $contractState->name,
             );

             return $contractState;
         }catch (ResourceNotFoundException $e) {
             Log::error($e);
             throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
         }catch (Exception $e) {
             Log::error($e);
             throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
     }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ContractState $contractState):object|null
     {
         try {
             $contractState->name = $request['name'];
             $contractState->contract_option_id = $request['contract_option_id'];
             $contractState->action = $request['action'];
             $contractState->code = $request['code'];
             $contractState->active = $request['active'];
             $contractState->save();
             return $contractState;
         }catch (Exception $e) {
             Log::error($e);
             throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
         }

     }

    /**
     * @throws Exception
     */
    public function dataFormatSupervisor(array $request, $contractId): void
     {
         try {
             if (empty($request['supervisors'])) {
                 return;
             }
             foreach ($request['supervisors'] as $supervisor){
                 $contractSupervisor = new ContractStateSupervisor();
                 $contractSupervisor->person_id = $supervisor['person_id'];
                 $contractSupervisor->contract_state_id = $contractId;
                 $contractSupervisor->save();
             }
         }catch (Exception $e) {
             Log::error($e);
             throw new Exception($e->getMessage(),$e->getCode());
         }

     }
}
