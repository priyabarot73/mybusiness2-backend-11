<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\UnitStatus;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class UnitStatusRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $unit = UnitStatus::orderBy('name', 'desc')->get();
            if ($unit->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/unit_status.exceptionNotFound'));
            }
            return $unit;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $unit= UnitStatus::where('active', $status)->orderBy('name','desc')->get();
            if ($unit->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/unit_status.exceptionNotFoundByStatus'));
            }
            return $unit;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $unit = new UnitStatus();
            $newUnit = $this->dataFormat($request,$unit);
            $newUnit->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newUnit->id,
                'created',
                'Unit status',
                'A new type of Unit status was created: ' . $newUnit->name,
            );

            return $newUnit;
        } catch (Exception $e) {
             Log::error($e);
             throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $unit = UnitStatus::find($id);
            if (!$unit){
                throw new ResourceNotFoundException(trans('hr/unit_status.exceptionNotFoundById'));
            }
            $newUnit = $this->dataFormat($request,$unit);
            $newUnit->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newUnit->id,
                'updated',
                'Unit status',
                'Unit status was updated: ' . $newUnit->name,
            );

            return $newUnit;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, UnitStatus $unit):object|null
    {
        try {
            $unit->name = $request['name'];
            $unit->active = $request['active'];
            return $unit;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
