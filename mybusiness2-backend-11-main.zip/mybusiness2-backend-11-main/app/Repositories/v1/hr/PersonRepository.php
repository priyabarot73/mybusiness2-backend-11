<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use App\Models\academic\Instructor;
use Exception;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Person;
use App\Http\Requests\v1\hr\PersonRequest;
use App\Exceptions\ResourceNotFoundException;

class PersonRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = strtolower($request->query('sort', $request->query('sortDirection', 'desc')));

            // DataGrid filters (can be array OR json string)
            $filterModel = $request->query('filters'); // array|string|null
            if (is_string($filterModel) && $filterModel !== '') {
                $decoded = json_decode($filterModel, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $filterModel = $decoded;
                }
            }

            // sanitize sort direction
            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'desc';
            }

            $personNicknameCol = 'nickname';
            $personBusinessEmailCol = 'business_email';
            $personBusinessPhoneCol = 'business_phone_number';
            $personBusinessPhoneExtCol = 'business_phone_number_ext';

            $query = Person::with([
                'generationalTitle',
                'suffix',
                'maritalStatus',
                'citizenshipType',
                'visaType',
                'ethnic',
                'department',
                'instructor.employeeType',
                'instructor.qualificationType',
                'instructor.subQualification',
                'instructor.tenureType'
            ])->where('panther_id', '!=', '9999999');


            // Quick Search (global)
            if (!empty($search)) {
                $s = strtolower(trim((string) $search));

                $query->where(function ($q) use (
                    $s,
                    $personNicknameCol,
                    $personBusinessEmailCol,
                    $personBusinessPhoneCol,
                    $personBusinessPhoneExtCol
                ) {
                    // base fields (safe)
                    $q->whereRaw("LOWER(first_name) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(last_name) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(middle_name) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(panther_id) LIKE ?", ["%{$s}%"]);

                    // optional fields (match your UI concatenation)
                    $q->orWhereRaw("LOWER(COALESCE(CAST($personNicknameCol AS VARCHAR(200)), '')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(COALESCE(CAST($personBusinessEmailCol AS VARCHAR(200)), '')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(COALESCE(CAST($personBusinessPhoneCol AS VARCHAR(50)), '')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(COALESCE(CAST($personBusinessPhoneExtCol AS VARCHAR(50)), '')) LIKE ?", ["%{$s}%"]);

                    // department name
                    $q->orWhereHas('department', function ($d) use ($s) {
                        $d->whereRaw("LOWER(name) LIKE ?", ["%{$s}%"]);
                    });

                    // active quick search (active/inactive)
                    if (in_array($s, ['active', 'inactive', '1', '0', 'true', 'false'], true)) {
                        $q->orWhere('active', in_array($s, ['active', '1', 'true'], true) ? 1 : 0);
                    }
                });
            }

            // APPLY FILTER MODEL (DataGrid)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {
                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and|or

                $makeLike = function ($value, $operator) {
                    $v = strtolower(trim((string) $value));

                    return match ($operator) {
                        'equals', '=', 'is' => $v,
                        'startsWith' => $v . '%',
                        'endsWith' => '%' . $v,
                        default => '%' . $v . '%', // contains
                    };
                };

                $query->where(function ($q) use (
                    $filterModel,
                    $logic,
                    $makeLike,
                    $personNicknameCol,
                    $personBusinessEmailCol,
                    $personBusinessPhoneCol,
                    $personBusinessPhoneExtCol
                ) {
                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        // skip empty filters
                        if (!$field || $value === null || $value === '') {
                            continue;
                        }

                        $apply = function ($sub) use (
                            $field,
                            $operator,
                            $value,
                            $makeLike,
                            $personNicknameCol,
                            $personBusinessEmailCol,
                            $personBusinessPhoneCol,
                            $personBusinessPhoneExtCol
                        ) {
                            // active (boolean)
                            if ($field === 'active') {
                                $v = strtolower(trim((string) $value));
                                $bool = in_array($v, ['1', 'true', 'active', 'yes'], true) ? 1
                                    : (in_array($v, ['0', 'false', 'inactive', 'no'], true) ? 0 : null);

                                // si vino algo raro, no filtra
                                if ($bool === null) return null;

                                return $sub->where('active', $bool);
                            }

                            $pattern = $makeLike($value, $operator);

                            // panther_id
                            if ($field === 'panther_id') {
                                return $sub->whereRaw("LOWER(CAST(panther_id AS VARCHAR(50))) LIKE ?", [$pattern]);
                            }

                            // department (relation)
                            if ($field === 'department') {
                                return $sub->whereHas('department', function ($d) use ($pattern) {
                                    $d->whereRaw("LOWER(name) LIKE ?", [$pattern]);
                                });
                            }

                            // businessPhoneNumber
                            if ($field === 'businessPhoneNumber') {
                                return $sub->where(function ($x) use ($pattern, $personBusinessPhoneCol, $personBusinessPhoneExtCol) {
                                    $x->whereRaw("LOWER(COALESCE(CAST($personBusinessPhoneCol AS VARCHAR(50)), '')) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(COALESCE(CAST($personBusinessPhoneExtCol AS VARCHAR(50)), '')) LIKE ?", [$pattern]);
                                });
                            }

                            // first_name column in UI (fullName + nickname + businessEmail)
                            if ($field === 'first_name') {
                                return $sub->where(function ($x) use ($pattern, $personNicknameCol, $personBusinessEmailCol) {
                                    // name parts
                                    $x->whereRaw("LOWER(COALESCE(first_name,'')) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(COALESCE(last_name,'')) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(COALESCE(middle_name,'')) LIKE ?", [$pattern])

                                        // full name combos
                                        ->orWhereRaw("LOWER(CONCAT(COALESCE(first_name,''),' ',COALESCE(last_name,''))) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(CONCAT(COALESCE(last_name,''),' ',COALESCE(first_name,''))) LIKE ?", [$pattern])

                                        // also allow match by panther_id (your UI shows it en otras columnas, pero ayuda)
                                        ->orWhereRaw("LOWER(CAST(panther_id AS VARCHAR(50))) LIKE ?", [$pattern])

                                        // optional fields used in your concatenated valueGetter
                                        ->orWhereRaw("LOWER(COALESCE(CAST($personNicknameCol AS VARCHAR(200)), '')) LIKE ?", [$pattern])
                                        ->orWhereRaw("LOWER(COALESCE(CAST($personBusinessEmailCol AS VARCHAR(200)), '')) LIKE ?", [$pattern]);
                                });
                            }

                            return null;
                        };

                        if ($logic === 'or') {
                            $q->orWhere(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        } else {
                            $q->where(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        }
                    }
                });
            }

            //  Sorting
            $sortableColumns = ['created_at', 'first_name', 'last_name', 'panther_id', 'active'];

            if (in_array($sortColumn, $sortableColumns)) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('created_at', 'desc');
            }

            // paginate
            $persons = $query->paginate($perPage, ['*'], 'page', $page);

            if ($persons->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/person.exceptionNotFound'));
            }

            return $persons;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus(Request $request, $status): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = $request->query('sortDirection', 'desc');

            $query = Person::with([
                'generationalTitle',
                'suffix',
                'maritalStatus',
                'citizenshipType',
                'visaType',
                'ethnic',
                'department',
                'instructor.employeeType',
                'instructor.qualificationType',
                'instructor.subQualification',
                'instructor.tenureType'
            ])
                ->where('active', '=', $status)
                ->where('panther_id', '!=', '9999999');

            // apply search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($q) use ($search) {
                    $q->whereRaw("LOWER(first_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(last_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(middle_name) LIKE ?", ["%$search%"])
                        ->orWhereRaw("LOWER(panther_id) LIKE ?", ["%$search%"]);
                });
            }

            // apply sorting
            if (in_array($sortColumn, ['created_at', 'first_name', 'last_name', 'panther_id'])) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // paginate
            $persons = $query->paginate($perPage, ['*'], 'page', $page);

            if ($persons->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/person.exceptionNotFoundByStatus'));
            }

            return $persons;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id): Model|Collection|Builder|array
    {
        try {
            $person = Person::with('generationalTitle', 'suffix', 'maritalStatus', 'citizenshipType', 'visaType', 'ethnic', 'department')
                ->where('panther_id', '!=', '9999999')
                ->find($id);
            if (!$person) {
                throw new ResourceNotFoundException(trans('hr/person.exceptionNotFoundById'));
            }
            return $person;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(PersonRequest $request): array|Builder|Collection|Model
    {
        try {
            DB::beginTransaction();
            $person = new Person();
            $personNew = $this->dataFormat($request, $person);
            $personNew->save();
            DB::commit();

            // create a new instructor
            if ($request->boolean('is_instructor')) {
                $instructor = new Instructor();
                $instructorNew = $this->dataCreateInstructor($request, $personNew->id, $instructor);
                $instructorNew->save();

                // Store activity timeline
                ActivityTimeLineHelper::store(
                    $personNew->id,
                    'created',
                    'Instructor',
                    'A new instructor was created: ' . $instructorNew->panther_id,
                );
            }

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $personNew->id,
                'created',
                'Person',
                'A new type of Person was created: ' . $personNew->panther_id,
            );

            return $this->viewById($personNew->id);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, PersonRequest $request): object|null
    {
        try {
            DB::beginTransaction();
            $person = Person::find($id);
            if (!$person) {
                throw new ResourceNotFoundException(trans('hr/person.exceptionNotFoundById'));
            }
            $personNew = $this->dataFormat($request, $person);
            $personNew->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $personNew->id,
                'updated',
                'Person',
                'Person was updated: ' . $personNew->panther_id,
            );

            DB::commit();
            return $this->viewById($personNew->id);
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            DB::rollBack();
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            DB::rollBack();
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    function convertNull($value)
    {
        return $value === 'null' ? null : $value;
    }

    /**
     * @throws Exception
     */
    public function dataFormat(PersonRequest $request, Person $person): Person
    {
        try {
            $person->avatar = $this->uploadImage(
                $request,
                $person->avatar,
                'photos',
                'avatar' // key of input file
            );

            $person->high_res_avatar = $this->uploadImage(
                $request,
                $person->high_res_avatar,
                'HDPhotos',
                'high_res_avatar' // key of input file for high_resolution image
            );

            $person->panther_id = $this->convertNull($request->input('panther_id'));
            $person->prefix = $this->convertNull($request->input('prefix'));
            $person->first_name = $this->convertNull($request->input('first_name'));
            $person->middle_name = $this->convertNull($request->input('middle_name'));
            $person->last_name = $this->convertNull($request->input('last_name'));
            $person->second_last_name = $this->convertNull($request->input('second_last_name'));
            $person->generational_title_id = $this->convertNull($request->input('generational_title_id'));
            $person->suffix_id = $this->convertNull($request->input('suffix_id'));
            $person->nickname = $this->convertNull($request->input('nickname'));
            $person->birth_country = $this->convertNull($request->input('birth_country'));
            $person->birth_city = $this->convertNull($request->input('birth_city'));
            $person->gender = $this->convertNull($request->input('gender'));
            $person->marital_status_id = $this->convertNull($request->input('marital_status_id'));
            $person->as_of = $this->convertNull($request->input('as_of'));
            $person->disability = $this->convertNull($request->input('disability'));
            $person->citizenship_type_id = $this->convertNull($request->input('citizenship_type_id'));
            $person->citizenship_date = $this->convertNull($request->input('citizenship_date'));
            $person->visa_type_id = $this->convertNull($request->input('visa_type_id'));
            $person->visa_date = $this->convertNull($request->input('visa_date'));
            $person->driver_license = $this->convertNull($request->input('driver_license'));
            $person->country = $this->convertNull($request->input('country'));
            $person->city = $this->convertNull($request->input('city'));
            $person->military_status = $this->convertNull($request->input('military_status'));
            $person->ethnic_id = $this->convertNull($request->input('ethnic_id'));
            $person->address = $this->convertNull($request->input('address'));
            $person->address_country = $this->convertNull($request->input('address_country'));
            $person->address_city = $this->convertNull($request->input('address_city'));
            $person->address_postal = $this->convertNull($request->input('address_postal'));
            $person->business_phone_number = $this->convertNull($request->input('business_phone_number'));
            $person->business_phone_number_ext = $this->convertNull($request->input('business_phone_number_ext'));
            $person->business_phone_number_usa = $this->convertNull($request->input('business_phone_number_usa'));
            $person->business_phone_number_public = $this->convertNull($request->input('business_phone_number_public'));
            $person->personal_phone_number = $this->convertNull($request->input('personal_phone_number'));
            $person->personal_phone_number_ext = $this->convertNull($request->input('personal_phone_number_ext'));
            $person->personal_phone_number_usa = $this->convertNull($request->input('personal_phone_number_usa'));
            $person->personal_phone_number_public = $this->convertNull($request->input('personal_phone_number_public'));
            $person->business_email = $this->convertNull($request->input('business_email'));
            $person->business_email_public = $this->convertNull($request->input('business_email_public'));
            $person->personal_email = $this->convertNull($request->input('personal_email'));
            $person->personal_email_public = $this->convertNull($request->input('personal_email_public'));
            $person->active = $this->convertNull($request->input('active'));
            $person->department_id = $this->convertNull($request->input('department_id'));

            return $person;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    public function dataCreateInstructor($request, string $personId, Instructor $instructor):object|null
    {
        try {
            $instructor->person_id = $personId;
            $instructor->employee_type_id = $request->input('employee_type_id');
            $instructor->tenure_type_id = $request->input('tenure_type_id');
            $instructor->doctorate = $request->input('doctorate');
            $instructor->qualification = $request->input('qualification');
            $instructor->qualification_type_id = $request->input('qualification_type_id');
            $instructor->sub_qualification_id = $request->input('sub_qualification_id');
            $instructor->aacsb = $request->input('aacsb');
            $instructor->active = true;
            return $instructor;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function uploadImage(PersonRequest $request, ?string $previousAvatar, string $path, string $fileKey): ?string
    {
        try {
            if ($request->hasFile($fileKey)) {

                // Create directory if it does not exist
                if (!Storage::disk('public')->exists($path)) {
                    Storage::disk('public')->makeDirectory($path, 0775, true);
                }

                // Delete previous image if it exists
                if ($previousAvatar && Storage::disk('public')->exists($previousAvatar)) {
                    Storage::disk('public')->delete($previousAvatar);
                }

                // Save new image
                $image = $request->file($fileKey);
                $filename = Str::uuid() . '.' . $image->extension();
                $image->storeAs($path, $filename, 'public');

                return $path . '/' . $filename;
            }

            // If there is no new file, return the previous one
            return $previousAvatar;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), 500);
        }
    }

}
