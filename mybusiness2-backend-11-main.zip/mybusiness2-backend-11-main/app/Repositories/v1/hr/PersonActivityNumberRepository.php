<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//Local Imports
use App\Models\hr\Person;
use App\Models\hr\PersonActivityNumber;
use App\Exceptions\ResourceNotFoundException;

class PersonActivityNumberRepository
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try
        {
            // Step 1: Get the activity numbers with their relationships
            $personActivityNumbers = PersonActivityNumber::with(['person', 'activityNumber.department', 'activityNumber.program', 'activityNumber.responsible'])
                ->get();

            // Step 2: Check if it is empty
            if ($personActivityNumbers->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/person_activity_number.exceptionNotFound'));
            }

            // Step 3: Group activity numbers by person
            $groupedByPerson = $personActivityNumbers->groupBy('person.id')->map(function($group) {
                $person = $group->first()->person;
                $activityNumber = $group->pluck('activityNumber');

                return [
                    'person' => $person,
                    'activity_numbers' => $activityNumber,
                    'total_activity_numbers' => $activityNumber->count()
                ];
            });

            // Step 4: Return as a collection
            return $groupedByPerson->values();

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllPersonActivityNumbersById(string $personId): array
    {
        try {
            // Step 1: Find the person by the person_id
            $person = Person::where('id', $personId)
                ->first();

            if (!$person) {
                throw new ResourceNotFoundException(trans('hr/person_activity_number.exceptionNotFound'));
            }

            // Step 2: Get all activity numbers related to person_id
            $personActivityNumbers = PersonActivityNumber::with(['person', 'activityNumber.department', 'activityNumber.program', 'activityNumber.responsible'])
                ->where('person_id', $personId)
                ->get();

            if ($personActivityNumbers->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/person_activity_number.exceptionNotFound'));
            }

            // Step 3: Get the activity numbers
            $activityNumbers = $personActivityNumbers->pluck('activityNumber');

            // Step 4: Return the person with the associated activity numbers and the total count
            return [
                'person' => $person,
                'activity_numbers' => $activityNumbers,
                'total_activity_numbers' => $activityNumbers->count()
            ];

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function assignPersonActivityNumbers(array $request): object|null|array
    {
        try {
            // Step 1: Delete all previously associated activity numbers
            PersonActivityNumber::where('person_id', $request['person_id'])->delete();

            if (!empty($request['activity_numbers'])) {
                // Step 2: Re-create the activity numbers with the new data
                $this->saveActivityNumbers($request);
            }

            // Step 3: After saving the activity numbers, get the updated data to return it
            $personActivityNumbers = PersonActivityNumber::with(['person', 'activityNumber.department', 'activityNumber.program', 'activityNumber.responsible'])
                ->where('person_id', $request['person_id'])
                ->get();

            // Step 4: Group activity numbers by person
            $activityNumbers = $personActivityNumbers->groupBy('person.id')->map(function ($group) {
                $person = $group->first()->person;
                $activityNumbers = $group->pluck('activityNumber');

                return [
                    'person' => $person,
                    'activity_numbers' => $activityNumbers,
                    'total_activity_numbers' => $activityNumbers->count(),
                ];
            });

            // Step 5: Returns the updated person activity number with the activity numbers
            return $activityNumbers->values()->first();

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Helper method to save activity numbers for a person.
     * @throws Exception
     */
    private function saveActivityNumbers(array $request): void
    {
        try {
            foreach ($request['activity_numbers'] as $activityNumber) {
                $contract = new PersonActivityNumber();
                $contract->person_id = $request['person_id'];
                $contract->activity_number_id = $activityNumber;
                $contract->save();
            }
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
