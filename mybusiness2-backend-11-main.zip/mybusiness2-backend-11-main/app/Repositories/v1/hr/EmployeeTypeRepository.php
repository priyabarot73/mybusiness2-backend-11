<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\EmployeeType;
use App\Exceptions\ResourceNotFoundException;

class EmployeeTypeRepository
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $employeeType = EmployeeType::orderBy('name', 'asc')->get();
            if ($employeeType->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_type.exceptionNotFound'));
            }
            return $employeeType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $employeeType = EmployeeType::where('active', $status)->orderBy('name', 'asc')->get();
            if ($employeeType->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_type.exceptionNotFoundByStatus'));
            }
            return $employeeType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $employeeType = new EmployeeType();
            $newEmployeeType = $this->dataFormat($request, $employeeType);
            $newEmployeeType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployeeType->id,
                'created',
                'Employee type',
                'A new type of Employee type was created: ' . $newEmployeeType->name,
            );

            return $newEmployeeType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $employeeType = EmployeeType::find($id);
            if (!$employeeType) {
                throw new ResourceNotFoundException(trans('hr/employee_type.exceptionNotFoundById'));
            }
            $newEmployeeType = $this->dataFormat($request, $employeeType);
            $newEmployeeType->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployeeType->id,
                'updated',
                'Employee type',
                'Employee type was updated: ' . $newEmployeeType->name,
            );

            return $newEmployeeType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, EmployeeType $employeeType): object|null
    {
        try {
            $employeeType->name = $request['name'];
            $employeeType->code = $request['code'];
            $employeeType->active = $request['active'];
            return $employeeType;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
