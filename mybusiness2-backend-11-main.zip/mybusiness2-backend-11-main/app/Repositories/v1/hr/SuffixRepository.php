<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Suffix;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class SuffixRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $suffix = Suffix::orderBy('name', 'desc')->get();
            if ($suffix->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/suffix.exceptionNotFoundSuffix'));
            }
            return $suffix;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $suffix= Suffix::where('active', $status)->orderBy('name','desc')->get();
            if ($suffix->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/suffix.exceptionNotFoundByStatus'));
            }
            return $suffix;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $suffix = new Suffix();
            $newSuffix = $this->dataFormat($request,$suffix);
            $newSuffix->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSuffix->id,
                'created',
                'suffix',
                'A new type of suffix was created: ' . $newSuffix->name,
            );

            return $newSuffix;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $suffix = Suffix::find($id);
            if (!$suffix){
                throw new ResourceNotFoundException(trans('hr/suffix.exceptionNotFoundById'));
            }
            $newSuffix = $this->dataFormat($request,$suffix);
            $newSuffix->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSuffix->id,
                'Updated',
                'suffix',
                'suffix was Updated: ' . $newSuffix->name,
            );

            return $newSuffix;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Suffix $suffix):object|null
    {
        try {
            $suffix->name = $request['name'];
            $suffix->active = $request['active'];
            return $suffix;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
