<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\WorkingTitle;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
class WorkingTitleRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $workingTitle = WorkingTitle::orderBy('name', 'desc')->get();
            if ($workingTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/working_title.exceptionNotFound'));
            }
            return $workingTitle;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $workingTitle= WorkingTitle::where('active', $status)->orderBy('name','desc')->get();
            if ($workingTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/working_title.exceptionNotFoundByStatus'));
            }
            return $workingTitle;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $workingTitle = new WorkingTitle();
            $newWorkingTitle = $this->dataFormat($request,$workingTitle);
            $newWorkingTitle->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newWorkingTitle->id,
                'created',
                'Working title',
                'A new type of Working title was created: ' . $newWorkingTitle->name,
            );

            return $newWorkingTitle;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $workingTitle = WorkingTitle::find($id);
            if (!$workingTitle){
                throw new ResourceNotFoundException(trans('hr/working_title.exceptionNotFoundById'));
            }
            $newWorkingTitle = $this->dataFormat($request,$workingTitle);
            $newWorkingTitle->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newWorkingTitle->id,
                'updated',
                'Working title',
                'Working title was updated: ' . $newWorkingTitle->name,
            );

            return $newWorkingTitle;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, WorkingTitle $workingTitle):object|null
    {
        try {
            $workingTitle->name = $request['name'];
            $workingTitle->description = $request['description'];
            $workingTitle->active = $request['active'];
            return $workingTitle;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
