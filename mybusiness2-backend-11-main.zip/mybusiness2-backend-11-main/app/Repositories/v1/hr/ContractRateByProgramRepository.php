<?php

namespace App\Repositories\v1\hr;


// global import

use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

// local import
use App\Models\hr\ContractRateByProgram;
use App\Exceptions\ResourceNotFoundException;

class ContractRateByProgramRepository
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $contract = ContractRateByProgram::orderBy('contract_rate', 'asc')->with('program')->get();
            if ($contract->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_rate_by_program.exceptionNotFound'));
            }

            return $contract;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $contractRate = new ContractRateByProgram();
            $newContractRate = $this->dataFormat($request, $contractRate);
            $newContractRate->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractRate->id,
                'created',
                'Contract rate',
                'A new Contract rate was created: ' . $newContractRate->program->code,
            );

            return $newContractRate;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $contractRate = ContractRateByProgram::find($id);
            if (!$contractRate) {
                throw new ResourceNotFoundException(trans('hr/contract_rate_by_program.exceptionNotFoundById'));
            }
            $newContractRate = $this->dataFormat($request, $contractRate);
            $newContractRate->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractRate->id,
                'updated',
                'Contract rate',
                'Contract rate was updated: ' . $newContractRate->program->code,
            );

            return $newContractRate;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ContractRateByProgram $contractRate): object|null
    {
        try {
            $contractRate->program_id = $request['program_id'];
            $contractRate->contract_rate = $request['contract_rate'];
            $contractRate->active = $request['active'];
            return $contractRate;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }
}
