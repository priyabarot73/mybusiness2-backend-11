<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//Local Imports
use App\Models\hr\ContractType;
use App\Models\hr\ContractTypeQuestion;
use App\Exceptions\ResourceNotFoundException;

class ContractTypeQuestionRepository
{

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try
        {
            // Step 1: Get the questions with their relationships
            $contractTypeQuestions = ContractTypeQuestion::with(['question','contractType'])
                ->get();

            // Step 2: Check if it is empty
            if ($contractTypeQuestions->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_type_question.exceptionNotFound'));
            }

            // Step 3: Group questions by contract_type
            $groupedByContractType = $contractTypeQuestions->groupBy('contractType.id')->map(function($group) {
                $contractType = $group->first()->contractType;
                $questions = $group->pluck('question');

                return [
                    'contract_type' => $contractType,
                    'questions' => $questions,
                    'total_questions' => $questions->count()
                ];
            });

            // Step 4: Return as a collection
            return $groupedByContractType->values();

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllContractTypeQuestionById(string $contractTypeId): array
    {
        try {
            // Step 1: Find the contract_type by the contract_type_id
            $contractType = ContractType::where('id', $contractTypeId)
                ->first();

            if (!$contractType) {
                throw new ResourceNotFoundException(trans('hr/contract_type.exceptionNotFound'));
            }

            // Step 2: Get all questions related to contract_type_id
            $contractTypeQuestions = ContractTypeQuestion::with('question')
                ->where('contract_type_id', $contractTypeId)
                ->get();

            if ($contractTypeQuestions->isEmpty()) {
                throw new ResourceNotFoundException(trans('contract_type_question.exceptionNotFound'));
            }

            // Step 3: Get the questions
            $questions = $contractTypeQuestions->pluck('question');

            // Step 4: Return the contract_type with the associated questions and the total count
            return [
                'contract_type' => $contractType,
                'questions' => $questions,
                'total_questions' => $questions->count()
            ];

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function assignContractTypeQuestion(array $request): object|null|array
    {
        try {
            // Step 1: Delete all previously associated questions
            ContractTypeQuestion::where('contract_type_id', $request['contract_type_id'])->delete();

            if (!empty($request['questions'])) {
                // Step 2: Re-create the questions with the new data
                $this->saveQuestions($request);
            }

            // Step 3: After saving the questions, get the updated data to return it
            $contractTypeQuestions = ContractTypeQuestion::with(['question', 'contractType'])
                ->where('contract_type_id', $request['contract_type_id'])
                ->get();

            // Step 4: Group questions by contract_type
            $groupedByContractType = $contractTypeQuestions->groupBy('contractType.id')->map(function ($group) {
                $contractType = $group->first()->contractType;
                $questions = $group->pluck('question');

                return [
                    'contract_type' => $contractType,
                    'questions' => $questions,
                    'total_questions' => $questions->count(),
                ];
            });

            // Step 5: Returns the updated contract with the questions
            return $groupedByContractType->values()->first();

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Helper method to save questions for a contract type.
     * @throws Exception
     */
    private function saveQuestions(array $request): void
    {
        try {
            foreach ($request['questions'] as $question) {
                $contract = new ContractTypeQuestion();
                $contract->contract_type_id = $request['contract_type_id'];
                $contract->question_id = $question;
                $contract->save();
            }
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }
}
