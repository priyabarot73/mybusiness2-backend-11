<?php

namespace App\Repositories\v1\hr;

// Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// Helpers
use App\Helpers\ActivityTimeLineHelper;

// Local Imports
use App\Models\hr\Team;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Interfaces\ViewByIdInterface;
use App\Exceptions\ResourceNotFoundException;

class TeamRepository implements ActiveInterface, UpdateInterface, ViewAllInterface, CreateInterface, ViewByIdInterface
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $teams = Team::orderBy('name')->get();

            if ($teams->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/team.exceptionNotFound'));
            }

            return $teams;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $team = Team::find($id);

            if (!$team) {
                throw new ResourceNotFoundException(trans('hr/team.exceptionNotFoundById'));
            }

            return $team;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $teams= Team::where('active', $status)->orderBy('name')->get();

            if ($teams->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/team.exceptionNotFoundByStatus'));
            }

            return $teams;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $team = new Team();
            $newTeam = $this->dataFormat($request, $team);
            $newTeam->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newTeam->id,
                'created',
                'Team',
                'A new team was created: ' . $newTeam->name,
            );

            return $newTeam;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $team = Team::find($id);

            if (!$team) {
                throw new ResourceNotFoundException(trans('hr/team.exceptionNotFoundById'));
            }

            $updatedTeam = $this->dataFormat($request, $team);
            $updatedTeam->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $updatedTeam->id,
                'updated',
                'Team',
                'Team was updated: ' . $updatedTeam->name,
            );

            return $updatedTeam;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    private function dataFormat($data, Team $team): Team
    {
        try {
            $team->name = $data['name'];
            $team->active = $data['active'] ?? true;
            $team->team_type_id = $data['team_type_id'] ?? null;

            return $team;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
