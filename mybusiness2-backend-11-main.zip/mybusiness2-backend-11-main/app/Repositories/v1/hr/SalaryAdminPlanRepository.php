<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\SalaryAdminPlan;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class SalaryAdminPlanRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $salaryAP = SalaryAdminPlan::with('payGroup','employeeClassification','employeeType','personOrganizationRelationshipType')->orderBy('name','desc')->get();
            if ($salaryAP->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/salary_admin_plan.exceptionNotFound'));
            }
            return $salaryAP;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $salaryAP = SalaryAdminPlan::where('active', $status)->orderBy('name','desc')->get();
            if ($salaryAP->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/salary_admin_plan.exceptionNotFoundByStatus'));
            }
            return $salaryAP;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByUsedIn(array $request)
    {
        try {
            $salaryAP = SalaryAdminPlan::where('active', true)
                ->whereIn('used_in', $request['used_in'])
                ->orderBy('name','desc')->get();
            if ($salaryAP->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/salary_admin_plan.exceptionNotFoundUsedIn'));
            }
            return $salaryAP;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $salaryAP = new SalaryAdminPlan();
            $newSalaryAP = $this->dataFormat($request,$salaryAP);
            $newSalaryAP->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSalaryAP->id,
                'created',
                'Salary admin plan',
                'A new type of Salary admin plan was created: ' . $newSalaryAP->name,
            );

            return $newSalaryAP;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $salaryAP = SalaryAdminPlan::find($id);
            if (!$salaryAP){
                throw new ResourceNotFoundException(trans('hr/salary_admin_plan.exceptionNotFoundById'));
            }
            $newSalaryAP = $this->dataFormat($request,$salaryAP);
            $newSalaryAP->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSalaryAP->id,
                'updated',
                'Salary admin plan',
                'Salary admin plan was updated: ' . $newSalaryAP->name,
            );

            return $newSalaryAP;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, SalaryAdminPlan $salaryAP):object|null
    {
        try {
            $salaryAP->code = $request['code'];
            $salaryAP->name = $request['name'];
            $salaryAP->pay_group_id = $request['pay_group_id'];
            $salaryAP->employee_classification_id = $request['employee_classification_id'];
            $salaryAP->employee_type_id = $request['employee_type_id'];
            $salaryAP->person_organization_relationship_type_id = $request['person_organization_relationship_type_id'];
            $salaryAP->used_in = $request['used_in'];
            $salaryAP->active = $request['active'];
            return $salaryAP;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
