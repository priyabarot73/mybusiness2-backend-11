<?php

namespace App\Repositories\v1\hr;

// global import
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Builder;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\Relation;

// helper
use App\Helpers\ActivityTimeLineHelper;

// local import
use App\Models\hr\Person;
use App\Models\hr\Contract;
use App\Models\hr\Assignment;
use App\Models\hr\ContractType;
use App\Models\academic\Section;
use App\Models\hr\ContractState;
use App\Models\academic\Workload;
use App\Models\academic\Instructor;
use App\Models\academic\CombinedSection;
use App\Models\hr\ContractStateTransition;
use App\Http\Requests\v1\hr\ContractRequest;
use App\Models\hr\ContractRoleStateTransition;
use App\Http\Requests\v1\hr\ContractByIdRequest;
use App\Http\Requests\v1\hr\ContractTransitionRequest;
use App\Http\Requests\v1\hr\ContractStatusReportRequest;
use App\Http\Requests\v1\hr\ContractRequestReportRequest;

class ContractRepository
{
    /**
     * @throws Exception
     */

    public function getContracts(Request $request): array
    {
        try {
            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            // ---------- Pagination / sorting ----------
            $perPage       = (int) $request->query('pageSize', 10);
            $page          = max((int) $request->query('page', 1), 1);
            $search        = $request->query('search');
            $sortColumn    = $request->query('sortColumn', 'created_at');
            $sortDirection = strtolower($request->query('sort', 'desc')) === 'asc' ? 'asc' : 'desc';

            // ---------- Base query with useful relations ----------
            /** @var Builder $query */
            $query = Contract::query()->with([
                'person.department',
                'person.instructor',
                'department',
                'supervisor',
                'person.assignments' => function ($q) {
                    $q->with(['jobTitle', 'workingTitle', 'salaryAdminPlan', 'assignmentContract', 'supervisor'])
                        ->whereNull('end_date');
                },
                'course',
                'term',
                'contractState',
                'contractType',
                'secondaryTeachingAppointment',
                'contractActivities.activityNumber',
                'contractSecondaryEmploymentWorkSchedules',
                'contractQuestionAnswers.question',
                'contractHistories.person',
                'contractHistories.state',
                'contractAttachments',
                'contractCompensationDetails.activityNumber',
                'latestHistory.person',
            ]);

            // ---------- Visibility (same idea as getUserQuery) ----------
            if ($user->hasRole('Administrator')) {
                // Admin sees all contracts (no extra filter)
            } else {
                $department      = $user->person?->department;
                $activityNumbers = $user->person?->personActivityNumbers()->pluck('activity_number_id');

                // Contract must belong to a person visible to the user:
                $query->whereHas('person', function (Builder $q) use ($department, $activityNumbers) {
                    $q->where(function (Builder $x) use ($department, $activityNumbers) {
                        if ($department) {
                            $x->orWhere('department_id', $department->id);
                        }
                        if ($activityNumbers && $activityNumbers->isNotEmpty()) {
                            $x->orWhereHas('personActivityNumbers', function (Builder $sub) use ($activityNumbers) {
                                $sub->whereIn('activity_number_id', $activityNumbers);
                            });
                        }
                    })
                        // and must also have assignments or contracts (current counts)
                        ->where(function (Builder $y) {
                            $y->whereHas('assignments')
                                ->orWhereHas('contracts');
                        });
                });
            }

            // ---------- Specific filters (values from URL) ----------
            // term_ids: array
            $termIds = $request->query('term_ids');
            if (!empty($termIds)) {
                $ids = is_array($termIds) ? $termIds : array_filter(array_map('trim', explode(',', (string) $termIds)));
                if (!empty($ids)) {
                    $query->whereIn('term_id', $ids);
                }
            }

            if (($v = $request->query('panther_id')) !== null && $v !== '') {
                $needle = (string) $v;
                $query->whereHas('person', function (Builder $q) use ($needle) {
                    $this->whereLike($q, 'panther_id', $needle);
                });
            }


            // start_date / end_date (range overlap instead of only start_date)
            $startDate = $request->query('start_date');
            $endDate   = $request->query('end_date');

            if ($startDate && $endDate) {
                // Contracts that overlap the window: start_date <= endDate AND (end_date IS NULL OR end_date >= startDate)
                $query->where(function (Builder $q) use ($startDate, $endDate) {
                    $q->whereDate('start_date', '<=', $endDate)
                        ->where(function (Builder $qq) use ($startDate) {
                            $qq->whereNull('end_date')
                                ->orWhereDate('end_date', '>=', $startDate);
                        });
                });
            } elseif ($startDate) {
                // Active on/after startDate
                $query->where(function (Builder $q) use ($startDate) {
                    $q->whereDate('start_date', '<=', $startDate)
                        ->where(function (Builder $qq) use ($startDate) {
                            $qq->whereNull('end_date')
                                ->orWhereDate('end_date', '>=', $startDate);
                        });
                });
            } elseif ($endDate) {
                // Began before or on endDate
                $query->whereDate('start_date', '<=', $endDate);
            }

            // category
            if (($v = $request->query('category')) !== null && $v !== '') {
                $this->whereLike($query, 'category', (string)$v);
            }

            // activity_number: It can arrive as a comma-separated string or array
            $numbersRaw = $request->query('activity_number');
            $numbers = is_array($numbersRaw)
                ? array_filter(array_map('trim', $numbersRaw))
                : array_filter(array_map('trim', explode(',', (string) $numbersRaw)));

            if (!empty($numbers)) {
                $query->where(function (Builder $q) use ($numbers) {
                    // contract_activities -> activity_numbers.number
                    $q->whereHas('contractActivities.activityNumber', function (Builder $qa) use ($numbers) {
                        $qa->where(function (Builder $w) use ($numbers) {
                            foreach ($numbers as $n) {
                                // Prefix
                                $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                            }
                        });
                    })
                        // O contract_compensation_details -> activity_numbers.number
                        ->orWhereHas('contractCompensationDetails.activityNumber', function (Builder $qc) use ($numbers) {
                            $qc->where(function (Builder $w) use ($numbers) {
                                foreach ($numbers as $n) {
                                    $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                                }
                            });
                        });
                });
            }

            // amount
            if (($v = $request->query('amount_pay')) !== null && $v !== '') {
                $query->where('amount_pay', (float) $v);
            }

            // Direct filter by relationship between contract and department
            if ($v = $request->query('department_id')) {
                // Only one department id
                $ids = is_array($v) ? $v : array_filter(array_map('trim', explode(',', (string) $v)));
                if (!empty($ids)) {
                    // By department column in contracts
                    $query->whereIn('department_id', $ids);
                }
            }

            if (($v = $request->query('erac_number')) !== null && $v !== '') {
                $this->whereLike($query, 'erac_number', (string)$v);
            }

            if (($v = $request->query('contract_number')) !== null && $v !== '') {
                $this->whereLike($query, 'contract_number', (string)$v);
            }

            if (($v = $request->query('superseding_contract_number')) !== null && $v !== '') {
                $this->whereLike($query, 'superseding_contract_number', (string)$v);
            }

            if (($v = $request->query('hours_worked')) !== null && $v !== '') {
                $this->whereLike($query, 'hours_worked', (string)$v);
            }

            if (($v = $request->query('enrollment')) !== null && $v !== '') {
                $this->whereLike($query, 'enrollment', (string)$v);
            }

            if (($v = $request->query('contract_state_id')) !== null && $v !== '') {
                $needle = (string)$v;
                if (ctype_digit($needle)) {
                    $query->where('contract_state_id', (int)$needle);
                } else {
                    // buscar por nombre/código del estado
                    $query->whereHas('contractState', function (Builder $q) use ($needle) {
                        $this->whereLike($q, 'name', $needle)
                            ->orWhere(function (Builder $qq) use ($needle) {
                                $this->whereLike($qq, 'code', $needle);
                            });
                    });
                }
            }

            if (($v = $request->query('course')) !== null && $v !== '') {
                $needle = (string) $v;
                $query->whereHas('course', function (Builder $q) use ($needle) {
                    $q->where('code', 'like', "%{$needle}%")
                        ->orWhere('name', 'like', "%{$needle}%");
                });
            }

            if (($v = $request->query('contract_type_id')) !== null && $v !== '') {
                $needle = (string)$v;
                if (ctype_digit($needle)) {
                    $query->where('contract_type_id', (int)$needle);
                } else {
                    $query->whereHas('contractType', function (Builder $q) use ($needle) {
                        $this->whereLike($q, 'name', $needle);
                    });
                }
            }

            if (($v = $request->query('employee_type')) !== null && $v !== '') {
                $needle = (string)$v;
                $query->whereHas('person.instructor.employeeType', function (Builder $q) use ($needle) {
                    $this->whereLike($q, 'code', $needle)
                        ->orWhere(function (Builder $qq) use ($needle) {
                            $this->whereLike($qq, 'name', $needle);
                        });
                });
            }

            // ----------  action filter (I, C, A) on contractState.action ----------
            if (($a = $request->query('action')) !== null && $a !== '') {
                $act = strtoupper(trim((string) $a));
                if ($act === 'I' || $act === 'C') {
                    $query->whereHas('contractState', function (Builder $q) use ($act) {
                        $q->where('action', $act);
                    });
                }
            }

            // ---------- Free text search ----------
            if (!empty($search)) {
                $needle = (string) $search;
                $query->where(function (Builder $q) use ($needle) {
                    // Contract fields
                    $q->where('contract_number', 'like', "%{$needle}%")
                        ->orWhere('erac_number', 'like', "%{$needle}%")
                        ->orWhere('internal_comment', 'like', "%{$needle}%")
                        // Person
                        ->orWhereHas('person', function (Builder $p) use ($needle) {
                            $p->where('first_name', 'like', "%{$needle}%")
                                ->orWhere('last_name', 'like', "%{$needle}%")
                                ->orWhere('middle_name', 'like', "%{$needle}%")
                                ->orWhere('panther_id', 'like', "%{$needle}%");
                        })
                        // Course
                        ->orWhereHas('course', function (Builder $c) use ($needle) {
                            $c->where('code', 'like', "%{$needle}%")
                                ->orWhere('name', 'like', "%{$needle}%");
                        });
                });
            }

            // full name
            $fullName = $request->query('full_name');
            if (!empty($fullName)) {
                $needle = (string) $fullName;
                $query->where(function (Builder $q) use ($needle) {
                        // Person
                    $q->orWhereHas('person', function (Builder $p) use ($needle) {
                            $p->where('first_name', 'like', "%{$needle}%")
                                ->orWhere('last_name', 'like', "%{$needle}%")
                                ->orWhere('middle_name', 'like', "%{$needle}%")
                                ->orWhere('panther_id', 'like', "%{$needle}%");
                        });
                });
            }

            // ---------- Allowed sort columns (expanded whitelist) ----------
            $allowedColumns = [
                'created_at',
                'updated_at',
                'start_date',
                'end_date',
                'amount_pay',
                'hours_worked',
                'enrollment',
                'contract_number',
                'erac_number',
                'contract_state_id',
                'contract_type_id',
                'term_id',
            ];
            if (!in_array($sortColumn, $allowedColumns, true)) {
                $sortColumn = 'created_at';
            }
            $query->orderBy($sortColumn, $sortDirection);

            // ---------- Pagination via paginate() ----------
            $paginated = $query->paginate($perPage, ['*'], 'page', $page);

            // ---------- SORT IN-MEMORY (A→Z) by person.first_name, then person.last_name ----------
            // Note: reorders ONLY current page items (post-filter & pagination).
            $sorted = collect($paginated->items())
                ->sort(function (Contract $a, Contract $b) {
                    $pa = $a->person; $pb = $b->person;

                    $fa = mb_strtolower($pa->first_name ?? '');
                    $fb = mb_strtolower($pb->first_name ?? '');
                    if ($fa !== $fb) {
                        return $fa <=> $fb;
                    }

                    $la = mb_strtolower($pa->last_name ?? '');
                    $lb = mb_strtolower($pb->last_name ?? '');
                    return $la <=> $lb;
                })
                ->values();

            // ---------- Optional: extra fields for convenience ----------
            $items = $sorted->map(function (Contract $c) {
                $person = $c->person;
                $c->setAttribute('person_name', trim(implode(' ', array_filter([
                    $person->first_name ?? null,
                    $person->last_name ?? null,
                    $person->second_last_name ?? null,
                ]))));
                $c->setAttribute('panther_id', $person->panther_id ?? null);
                return $c;
            });

            return [
                'data' => $items,
                'pagination' => [
                    'total'        => $paginated->total(),
                    'current_page' => $paginated->currentPage(),
                    'last_page'    => $paginated->lastPage(),
                    'per_page'     => $paginated->perPage(),
                    'from'         => $paginated->firstItem() ?? 0,
                    'to'           => $paginated->lastItem() ?? 0,
                ],
            ];
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function getContractById(ContractByIdRequest $request): Contract
    {
        try {
            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            $contractId = $request->input('contract_id');

            /** @var Builder $query */
            $query = Contract::query()->with([
                'person.department',
                'person.instructor.employeeType',
                'department',
                'supervisor',
                'person.assignments' => function ($q) {
                    $q->with(['jobTitle', 'workingTitle', 'salaryAdminPlan', 'assignmentContract', 'supervisor'])
                        ->whereNull('end_date');
                },
                'course',
                'term',
                'contractState',
                'contractType',
                'secondaryTeachingAppointment',
                'contractActivities.activityNumber',
                'contractSecondaryEmploymentWorkSchedules',
                'contractQuestionAnswers.question',
                'contractHistories.person',
                'contractHistories.state',
                'contractAttachments',
                'contractCompensationDetails.activityNumber',
                'latestHistory.person',
            ]);

            // ---------- Visibility ----------
            if ($user->hasRole('Administrator')) {
                // Admin sees all
            } else {
                $department      = $user->person?->department;
                $activityNumbers = $user->person?->personActivityNumbers()->pluck('activity_number_id');

                $query->whereHas('person', function (Builder $q) use ($department, $activityNumbers) {
                    $q->where(function (Builder $x) use ($department, $activityNumbers) {
                        if ($department) {
                            $x->orWhere('department_id', $department->id);
                        }
                        if ($activityNumbers && $activityNumbers->isNotEmpty()) {
                            $x->orWhereHas('personActivityNumbers', function (Builder $sub) use ($activityNumbers) {
                                $sub->whereIn('activity_number_id', $activityNumbers);
                            });
                        }
                    })
                        ->where(function (Builder $y) {
                            $y->whereHas('assignments')
                                ->orWhereHas('contracts');
                        });
                });
            }

            /** @var Contract|null $contract */
            $contract = $query->whereRaw('LOWER(id) = ?', [mb_strtolower(trim((string) $contractId))])->first();

            if (!$contract) {
                throw new Exception(trans('hr/contract.contract_not_found'), Response::HTTP_NOT_FOUND);
            }

            $person = $contract->person;
            $contract->setAttribute('person_name', trim(implode(' ', array_filter([
                $person->first_name ?? null,
                $person->last_name ?? null,
                $person->second_last_name ?? null,
            ]))));
            $contract->setAttribute('panther_id', $person->panther_id ?? null);

            return $contract;
        } catch (Exception $e) {
            Log::error($e);
            $code = $e->getCode();
            if (is_int($code) && $code >= 400 && $code < 600) {
                throw $e;
            }
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * getInitialStateByPantherId → createContract → getAvailableTransitions → transitionContract → isFinalState
     * @throws Exception
     */
    public function createContract(ContractRequest $request): Contract
    {
        // Step 1: New instance
        $contract = new Contract();

        // Step 2: Resolve person
        $personId = $request->input('person_id');
        $person = Person::findOrFail($personId);

        // Step 3: Compute initial state and inject into the *Request* (not into an array)
        $initialId = $this->getInitialStateByPantherId($person->panther_id ?? null, $request->input('contract_type_id'));

        if (!$initialId) {
            throw new Exception(__('hr/contract.initial_state_not_found'));
        }

        // If it's a model, extract id
        $initialId = is_object($initialId) ? ($initialId->id ?? $initialId->getKey()) : $initialId;

        // keep files available by merging into the Request instance
        $request->merge(['contract_state_id' => $initialId]);

        // Step 4: Pass the Request (with files) to dataFormat
        $newContract = $this->dataFormat($request, $contract);

        // Step 5: Activity timeline (igual que ya tenías)
        $fullName = trim(implode(' ', array_filter([
            $person->first_name ?? null,
            $person->last_name ?? null,
            $person->second_last_name ?? null,
        ])));

        $message = sprintf(
            'A new Contract was created: (%s) %s',
            $person->panther_id ?? ($person->pantherId ?? 'N/A'),
            $fullName !== '' ? $fullName : 'N/A'
        );

        ActivityTimeLineHelper::store(
            $newContract->id,
            'created',
            'Contract',
            $message
        );

        return $newContract;
    }

    /**
     * Updates a contract using dataFormat (including contract_state_id and children)
     * and stores an 'updated' activity timeline entry.
     *
     * Note: contract_histories are NOT accepted from the payload; the repository
     * automatically appends a history entry using the current contract data.
     *
     * @param Request $request
     * @param int|string $id Contract primary key (UUID or int)
     * @return Contract
     * @throws Exception
     */
    public function updateContract(Request $request, $id): Contract
    {
        return DB::transaction(function () use ($request, $id) {
            // Load existing contract
            /** @var Contract $contract */
            $contract = Contract::findOrFail($id);

            // Keep track of old state (to log state changes if any)
            $oldStateId = $contract->contract_state_id;

            // Apply dataFormat: fills/saves contract (including contract_state_id) and syncs children;
            // histories are handled internally in the repository (no histories in the payload)
            $updated = $this->dataFormat($request, $contract);

            // Ensure we have fresh values from DB
            $updated->refresh();
            $newStateId = $updated->contract_state_id;

            // Build person's full name and panther id for the activity message
            $person = Person::findOrFail($updated->person_id);

            $fullName = trim(implode(' ', array_filter([
                $person->first_name ?? null,
                $person->last_name ?? null,
                $person->second_last_name ?? null,
            ])));

            // Compose message
            $panther = $person->panther_id ?? ($person->pantherId ?? 'N/A');

            // If state changed, include transition in the message
            if ($oldStateId !== $newStateId) {
                $message = sprintf(
                    'Contract updated: (%s) %s — state changed: %s → %s',
                    $panther,
                    $fullName !== '' ? $fullName : 'N/A',
                    $oldStateId ?? 'N/A',
                    $newStateId ?? 'N/A'
                );
            } else {
                $message = sprintf(
                    'Contract updated: (%s) %s',
                    $panther,
                    $fullName !== '' ? $fullName : 'N/A'
                );
            }

            // Store activity timeline (repository already stored the history entry)
            ActivityTimeLineHelper::store(
                $updated->id,   // entity_id
                'updated',      // action
                'Contract',     // entity_type
                $message        // description
            );

            return $updated;
        });
    }

    /**
     * Takes the data from the request + the contract (new or existing),
     * updates/saves the contract (including contract_state_id) and synchronizes ALL related tables,
     * including contract_histories. Histories' state_id is forced to the contract's contract_state_id.
     *
     * @param array|Request $request
     * @param Contract $contractType
     * @return Contract
     * @throws Exception
     */
    public function dataFormat(array|Request $request, Contract $contractType): Contract
    {
        // Support both Request and plain array payloads
        $input = $request instanceof Request ? $request->all() : (array)$request;

        // Allowed fields for Contract (includes contract_state_id for update flows)
        $contractFillable = [
            'contract_name',
            'lump_sum',
            'person_id',
            'job_title_id',
            'department_id',
            'supervisor_id',
            'contract_type_id',
            'secondary_teaching_appointment_id',
            'term_id',
            'course_id',
            'enrollment',
            'start_date',
            'end_date',
            'cost_pid',
            'cost_pid_value',
            'hours_worked',
            'amount_pay',
            'explanation_justification',
            'selection_justification',
            'why_cant',
            'erac_number',
            'contract_number',
            'internal_comment',
            'contract_state_id',
            'category',
            'employee_type',
            'superseding',
            'superseding_contract_number',
            'superseding_contract_enrollment',
            'superseding_contract_amount'
        ];

        try {
            return DB::transaction(function () use ($contractType, $input, $request, $contractFillable) {
                // 1) Save or update the base contract
                $contractData = Arr::only($input, $contractFillable);

                // Normalize booleans
                if (array_key_exists('lump_sum', $contractData)) {
                    $norm = filter_var($contractData['lump_sum'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                    if ($norm !== null) {
                        $contractData['lump_sum'] = $norm;
                    }
                }

                // Determine if this is a new contract (for history comment)
                $wasNew = !$contractType->exists;

                $contractType->fill($contractData);
                $contractType->save();

                $contractId = $contractType->getKey();

                // 2) Sync child relations (histories are handled automatically in step 4)
                // 2.a Secondary employment work schedules
                $this->syncHasMany(
                    relation: $contractType->contractSecondaryEmploymentWorkSchedules(),
                    rows: Arr::get($input, 'secondary_employment_work_schedules', []),
                    allowedKeys: ['day', 'from', 'to'],
                    contractId: $contractId
                );

                // 2.b Contract compensation details
                $this->syncHasMany(
                    relation: $contractType->contractCompensationDetails(),
                    rows: Arr::get($input, 'contract_compensation_details', []),
                    allowedKeys: [
                        'subject', 'catalog', 'section', 'program', 'activity_number',
                        'enrolled', 'hours', 'base', 'credits', 'overload', 'weight', 'amount',
                    ],
                    contractId: $contractId,
                    normalizer: function (array $row) {
                        if (array_key_exists('overload', $row)) {
                            $norm = filter_var($row['overload'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                            if ($norm !== null) {
                                $row['overload'] = $norm;
                            }
                        }
                        return $row;
                    }
                );

                // 2.c Contract question answers
                $this->syncHasMany(
                    relation: $contractType->contractQuestionAnswers(),
                    rows: Arr::get($input, 'contract_question_answers', []),
                    allowedKeys: ['question_id', 'answer'],
                    contractId: $contractId
                );

                // 2.d Contract attachments: handle uploaded files (multipart/form-data: attachments[])
                if ($request instanceof Request && $request->hasFile('attachments')) {
                    foreach ((array)$request->file('attachments') as $file) {
                        if (!$file || !$file->isValid()) {
                            continue; // skip invalid uploads
                        }

                        // Folder per instructor (person_id)
                        $personId = $contractType->person_id;

                        // Original name -> slug + same extension
                        $originalName = $file->getClientOriginalName();
                        $baseName = pathinfo($originalName, PATHINFO_FILENAME);
                        $extension = $file->getClientOriginalExtension(); // keeps original case
                        $slug = Str::slug($baseName);                // e.g., "project-brief-v2"
                        $finalName = $slug . ($extension ? '.' . strtolower($extension) : '');

                        // Build relative path: contracts/{personId}/{slug.ext}
                        $directory = "contracts/{$personId}";
                        $relativePath = "{$directory}/{$finalName}";

                        // Ensure uniqueness if the same slug already exists
                        $disk = 'public';
                        if (Storage::disk($disk)->exists($relativePath)) {
                            // append short unique suffix (timestamp or uniqid)
                            $suffix = '-' . substr((string)Str::uuid(), 0, 8);
                            $finalName = $slug . $suffix . ($extension ? '.' . strtolower($extension) : '');
                            $relativePath = "{$directory}/{$finalName}";
                        }

                        // Store file using the final slugified name
                        $file->storeAs($directory, $finalName, $disk);

                        // Save relative path in DB (matches Storage path)
                        $contractType->contractAttachments()->create([
                            'contract_id' => $contractType->id,
                            'attachment_filename' => $relativePath,
                        ]);
                    }
                }


                // 2.e Contract activities (includes amount)
                $this->syncHasMany(
                    relation: $contractType->contractActivities(),
                    rows: Arr::get($input, 'contract_activities', []),
                    allowedKeys: ['activity_number_id', 'amount'],
                    contractId: $contractId
                );

                // 3) Auto-create a contract history entry (payload does NOT provide histories)
                $actorPersonId = $this->currentSupervisorPersonId() ?? $contractType->supervisor_id;

                $contractType->contractHistories()->create([
                    'contract_id'        => $contractId,
                    'supervisor_id'      => $actorPersonId, // authenticated user persona
                    'state_id'           => $contractType->contract_state_id, // always synchronized with contract
                    'date'               => now(),
                    'notification_count' => 0,
                    'comment'            => $wasNew ? 'Contract created' : 'Contract updated',
                ]);

                return $contractType;
            });
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), (int)$e->getCode());
        }
    }

    /**
     * Retrieves a paginated list of persons based on user role and conditions.
     *
     * @throws Exception
     */
    public function getEmployees(Request $request): array
    {
        try {
            $query = $this->getUserQuery();
            $data = $this->applyFiltersAndPagination($query, $request);

            // Add initial_contract_state to each returned person
            $data['data']->transform(function ($person) {
                try {
                    $initialState = $this->getInitialStateByPantherId($person->panther_id);
                    $person->initial_contract_state = $initialState;
                } catch (Exception $e) {
                    Log::warning("Could not get initial state for panther_id {$person->panther_id}: " . $e->getMessage());
                    $person->initial_contract_state = null;
                }
                return $person;
            });

            return $data;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Base query of Persons visible to the logged user.
     * - If $includeInactive is false, filter active=1; otherwise include all.
     * - Admins: everyone (respecting the optional active filter).
     * - Non-admins: same dept OR share activity numbers, and must have assignments/contracts.
     * @throws Exception
     */
    private function getUserQuery(bool $includeInactive = true): Builder
    {
        try {
            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            // Base
            $query = Person::query(); // hr.persons

            // Apply active filter only when we do NOT want inactive persons
            if (!$includeInactive) {
                $query->where('active', true);
            }

            // Admins: done
            if ($user->hasRole('Administrator')) {
                return $query;
            }

            // Non-admins: restrict by dept or activity_numbers, and require assignments/contracts
            $department = $user->person?->department;
            $activityNumbers = $user->person?->personActivityNumbers()->pluck('activity_number_id');

            $query->where(function ($q) use ($department, $activityNumbers) {
                if ($department) {
                    $q->orWhere('department_id', $department->id);
                }
                if ($activityNumbers && $activityNumbers->isNotEmpty()) {
                    $q->orWhereHas('personActivityNumbers', function ($sub) use ($activityNumbers) {
                        $sub->whereIn('activity_number_id', $activityNumbers);
                    });
                }
            })->where(function ($q) {
                $q->whereHas('assignments')
                    ->orWhereHas('contracts');
            })->distinct();

            return $query;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Applies search filters, safe sorting, and manual pagination to a base Person query.
     * Enriches each person with:
     *  - employee_type and contract_type (based on Salary Admin Plan groups and title_id rules)
     *  - active_assignments / active_assignment_contracts (split by contract presence)
     *  - last_assignment (compact summary of job_title and working_title)
     *  - salary_admin_plan_codes (unique codes found across active assignments)
     *
     * @param Builder $query Base query (e.g., Person::query() with optional pre-filters)
     * @param Request $request Incoming request carrying page, pageSize, search, sortColumn, sort
     * @return array{data: Collection, pagination: array<string,int>}
     * @throws Exception
     */
    private function applyFiltersAndPagination(Builder $query, Request $request): array
    {
        try {
            // ---------------------------------------------------------
            // 1) Read pagination/sorting/search parameters
            // ---------------------------------------------------------
            $perPage = (int)$request->query('pageSize', 10);
            $page = max((int)$request->query('page', 1), 1);
            $search = trim((string)$request->query('search', ''));
            $sortColumn = $request->query('sortColumn', 'created_at');
            // Direction is read from "sort" (expected "asc" or "desc"); default to desc, guard invalid values.
            $sortDirection = strtolower((string)$request->query('sort', 'desc'));
            $sortDirection = in_array($sortDirection, ['asc', 'desc'], true) ? $sortDirection : 'desc';

            // ---------------------------------------------------------
            // 2) Case-insensitive LIKE search on key identity fields
            //    Uses LOWER() to normalize both sides of comparison
            // ---------------------------------------------------------
            if ($search !== '') {
                $query->where(function ($q) use ($search) {
                    $s = strtolower($search);
                    $q->whereRaw('LOWER(first_name) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(last_name) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(middle_name) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(panther_id) LIKE ?', ["%{$s}%"]);
                });
            }

            // ---------------------------------------------------------
            // 3) Count total BEFORE ordering/pagination
            // ---------------------------------------------------------
            $totalQuery = clone $query;
            $total = (int)$totalQuery->count();

            // ---------------------------------------------------------
            // 4) Safe sorting: only allow whitelisted columns
            // ---------------------------------------------------------
            $allowedColumns = [
                'first_name',
                'last_name',
                'panther_id',
                'created_at',
                'updated_at',
            ];
            if (in_array($sortColumn, $allowedColumns, true)) {
                $query->orderBy($sortColumn, $sortDirection);
            }

            // ---------------------------------------------------------
            // 5) Eager-load required relations and apply manual pagination
            //    Note: limit active assignments to those with end_date IS NULL
            // ---------------------------------------------------------
            $persons = $query
                ->with([
                    'department.person',
                    'instructor',
                    'assignments' => function ($q) {
                        $q->with([
                            'jobTitle',
                            'workingTitle',
                            'supervisor',
                            'salaryAdminPlan',
                            'assignmentContract.contractType',
                            'assignmentContract.contractCategory',
                        ])->whereNull('end_date'); // only active assignments
                    },
                ])
                ->skip(($page - 1) * $perPage)
                ->take($perPage)
                ->get()
                ->map(function ($person) {
                    // -------------------------------------------------
                    // 6) Per-person enrichment setup
                    // -------------------------------------------------
                    $assignments = $person->assignments;

                    // 6.1) Collect unique Salary Admin Plan codes across active assignments
                    $salaryAdminPlanCodes = collect();
                    foreach ($assignments as $assignment) {
                        if ($assignment->salaryAdminPlan && !empty($assignment->salaryAdminPlan->code)) {
                            $salaryAdminPlanCodes->push((string)$assignment->salaryAdminPlan->code);
                        }
                    }
                    $salaryAdminPlanCodes = $salaryAdminPlanCodes->unique()->values();

                    // -------------------------------------------------
                    // 7) Determine employee_type and contract_type
                    //
                    //    Rule sets:
                    //    - ADJ-qualifying title_ids: 9005, 9035 (with an ACTIVE contract: end_date NULL)
                    //
                    //    - GROUP A: ['012','22B','22A','229','220']
                    //        * contract_type = 'Additional Compensation'
                    //        * employee_type = 'ADJ' if has ADJ-like active title; else 'FAC'
                    //
                    //    - GROUP B: ['210','013']
                    //        * contract_type = 'Additional Compensation'
                    //        * employee_type = 'ADJ' if has ADJ-like active title; else 'ADM'
                    //
                    //    - Fallback: if codes don't match A or B, keep legacy 'Adjunct' and leave employee_type null
                    // -------------------------------------------------
                    $ADJ_TITLE_IDS = [9005, 9035];
                    $GROUP_A = ['012', '22B', '22A', '229', '220'];
                    $GROUP_B = ['210', '013'];

                    // Check if there's at least one ACTIVE contract (end_date NULL)
                    // AND a jobTitle with title_id in ADJ_TITLE_IDS
                    $hasAdjLikeTitle = $assignments->contains(function ($a) use ($ADJ_TITLE_IDS) {
                        $hasActiveContract = $a->assignmentContract && is_null($a->assignmentContract->end_date);

                        $titleId = optional($a->jobTitle)->title_id;
                        $titleIdInt = is_null($titleId) ? null : (int)$titleId;

                        $isAdjTitle = !is_null($titleIdInt) && in_array($titleIdInt, $ADJ_TITLE_IDS, true);

                        return $hasActiveContract && $isAdjTitle;
                    });

                    $inGroupA = $salaryAdminPlanCodes->intersect($GROUP_A)->isNotEmpty();
                    $inGroupB = $salaryAdminPlanCodes->intersect($GROUP_B)->isNotEmpty();

                    $contractType = 'Adjunct'; // legacy-compatible fallback
                    $employeeType = null;

                    if ($inGroupA) {
                        $contractType = 'Additional Compensation';
                        $employeeType = $hasAdjLikeTitle ? 'ADJ' : 'FAC';
                    } elseif ($inGroupB) {
                        $contractType = 'Additional Compensation';
                        $employeeType = $hasAdjLikeTitle ? 'ADJ' : 'ADM';
                    }
                    // If desired, enforce a default when not in A/B:
                    // else { $employeeType = 'FAC'; }

                    // -------------------------------------------------
                    // 8) Split assignments into with-contract vs without-contract
                    // -------------------------------------------------
                    [$withContract, $withoutContract] = $assignments->partition(function ($a) {
                        return !is_null($a->assignmentContract);
                    });

                    // Clean the ones without contract (remove null relation to keep payload tidy)
                    $cleanedWithoutContract = $withoutContract->map(function ($a) {
                        unset($a->assignment_contract);
                        return $a;
                    })->values();

                    // Keep the ones with valid contract
                    $cleanedWithContract = $withContract->filter(function ($a) {
                        return !is_null($a->assignmentContract);
                    })->values();

                    // -------------------------------------------------
                    // 9) Computed properties for API response
                    // -------------------------------------------------
                    $person->salary_admin_plan_codes = $salaryAdminPlanCodes;
                    $person->contract_type = $contractType;
                    $person->employee_type = $employeeType;
                    $person->active_assignments = $cleanedWithoutContract;
                    $person->active_assignment_contracts = $cleanedWithContract;

                    // -------------------------------------------------
                    // 10) Determine "last_assignment" by created_at DESC
                    //     Provide compact fields: job_title and working_title
                    // -------------------------------------------------
                    $combined = $cleanedWithContract->concat($cleanedWithoutContract)->values();
                    $lastAssignment = $combined->sortByDesc(function ($a) {
                        // If created_at is Carbon, prefer timestamp; else fall back to strtotime
                        if ($a->created_at instanceof Carbon) {
                            return $a->created_at->timestamp;
                        }
                        return $a->created_at ? strtotime((string)$a->created_at) : 0;
                    })->first();

                    $person->last_assignment = $lastAssignment ? [
                        'job_title' => optional($lastAssignment->jobTitle)->name . ' (' . optional($lastAssignment->jobTitle)->title_id . ')',
                        'working_title' => optional($lastAssignment->workingTitle)->name,
                    ] : null;

                    return $person;
                });

            // ---------------------------------------------------------
            // 11) Return data collection with manual pagination metadata
            // ---------------------------------------------------------
            return [
                'data' => $persons,
                'pagination' => [
                    'total' => $total,
                    'current_page' => $page,
                    'last_page' => (int)ceil($total / max($perPage, 1)),
                    'per_page' => $perPage,
                    'from' => $total ? (($page - 1) * $perPage + 1) : 0,
                    'to' => min($page * $perPage, $total),
                ],
            ];
        } catch (Exception $e) {
            // Log the exception and bubble up as HTTP 500
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get all responsible persons of any department.
     *
     * @throws Exception
     */
    public function getResponsiblePersons(): Collection
    {
        try {
            return Person::whereIn('id', function ($query) {
                $query->select('person_id')
                    ->from('gn.departments')
                    ->whereNotNull('person_id');
            })->with(['department'])->get();
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get all activity_number_id that the authenticated user is allowed to view.
     *
     * @return Collection
     * @throws Exception
     */
    public function getVisibleActivityNumbers(): Collection
    {
        try {
            $user = Auth::user();

            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }
            Log::info($user);

            // If you are an administrator, you get all the activity_number_id of active people
            if ($user->hasRole('Administrator')) {
                return DB::table('hr.person_activity_numbers')
                    ->join('hr.persons', 'hr.person_activity_numbers.person_id', '=', 'persons.id')
                    ->join('hr.activity_numbers', 'hr.person_activity_numbers.activity_number_id', '=', 'activity_numbers.id')
                    ->where('hr.persons.active', true)
                    ->select('activity_numbers.*')
                    ->distinct()
                    ->get();
            }

            // If not admin, only get the activity_numbers directly related to the user
            return $user->person?->personActivityNumbers()->with('activityNumber')->get()->pluck('activityNumber')->filter();

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Returns the available transitions for the current contract state based on the user's role.
     *
     * @throws Exception
     */
    public function getAvailableTransitions(string|Contract $contractOrId): Collection
    {
        try {
            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            /** @var Contract $contract */
            $contract = $contractOrId instanceof Contract
                ? $contractOrId
                : Contract::find($contractOrId);

            if (!$contract) {
                throw new Exception(trans('hr/contract.not_found'));
            }

            $currentStateId = (string) $contract->contract_state_id;

            $base = ContractStateTransition::query()
                ->where('source_state_id', $currentStateId)
                ->where('active', true)
                ->with(['targetState:id,name,code,action']);

            if (!$user->hasRole('Administrator')) {
                $roleIds   = $user->roles->pluck('id');
                $allowedIds = ContractRoleStateTransition::whereIn('role_id', $roleIds)
                    ->pluck('contract_state_transition_id')
                    ->unique();

                $base->whereIn('id', $allowedIds);
            }

            return $base->get()
                ->filter(fn ($t) => (string)$t->source_state_id !== (string)$t->target_state_id) // oculta "Stay in ..."
                ->sortBy(fn ($t) => [$t->order ?? 0, $t->id])
                ->values();

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * getInitialStateByPantherId → createContract → getAvailableTransitions → transitionContract → isFinalState
     * @throws Exception
     */
    /**
     * Determines the initial ContractState for a person based on their Panther ID and optional contract type.
     *
     * Business logic:
     * 1. Resolve the contract type name from the given contractTypeId (if provided).
     * 2. Retrieve all active assignments for the person with the given Panther ID,
     *    including job title, salary administration plan, and contract type.
     * 3. Apply the following rules to determine the state code:
     *    - Rule 1: If the job title ID is '9035', assign code '2000'.
     *    - Rule 2: If the salary plan code is in {210, 22B, 22A, 229, 220}:
     *        - If contract type is {administrative, other, other instructional, secondary instructor}, assign code '1000'.
     *        - If contract type is {primary instructor}, assign code '2000'.
     * 4. Default: If no rules match, assign code '3000'.
     *
     * @param string|null $pantherId The Panther ID of the person.
     * @param string|null $contractTypeId The optional contract type ID from the request.
     *
     * @return ContractState|null The resolved initial ContractState or null if it cannot be determined.
     */
    private function getInitialStateByPantherId(?string $pantherId, string $contractTypeId = null): ?ContractState
    {
        try {
            // 1) Resolve contract type of the request (if provided)
            $requestCt = null;

            if (!empty($contractTypeId)) {
                $requestCtName = ContractType::find($contractTypeId)?->name;
                $requestCt = $requestCtName ? strtolower(trim($requestCtName)) : null;
            }

            // 2) Get active assessments
            $assignments = Assignment::with([
                'jobTitle',
                'salaryAdminPlan',
                'assignmentContract.contractType',
            ])->whereHas('person', function ($q) use ($pantherId) {
                $q->where('panther_id', $pantherId);
            })->where(function ($q) {
                $q->whereNull('end_date')->orWhere('end_date', '');
            })->get();

            $code = null;
            foreach ($assignments as $assignment) {
                $titleId = (string)($assignment->jobTitle?->title_id);
                $salaryAdminPlanCode = $assignment->salaryAdminPlan?->code;

                $ct = $requestCt;

                // Rule 1
                if ($titleId === '9035') {
                    $code = '2000';
                    break;
                }

                // Rule 2
                if (in_array($salaryAdminPlanCode, ['210', '22B', '22A', '229', '220'], true)) {
                    $to1000 = ['administrative', 'other', 'other instructional', 'secondary instructor'];
                    if ($ct && in_array($ct, $to1000, true)) {
                        $code = '3000';
                        break;
                    }

                    // Rule 2: Primary → 2000
                    $to2000 = ['primary instructor'];
                    if ($ct && in_array($ct, $to2000, true)) {
                        $code = '1000';
                        break;
                    }
                }
            }

            // Default
            if ($code === null) {
                $code = '1000';
            }

            return ContractState::where('code', $code)->where('name', strtolower('Pending Revision'))->first();

        } catch (Exception $e) {
            Log::error("Error determining initial state for pantherId {$pantherId}: " . $e->getMessage());
            return null;
        }
    }


    /**
     * Applies a transition to the contract.
     * $transition can be:
     * - the id (int) of the ContractStateTransition
     * - the name (string) of the transition (unique per source_state)
     *
     * Returns the applied ContractStateTransition object (to take its id).
     * @throws Exception
     */
    public function transitionContractById(ContractTransitionRequest $request): ContractStateTransition
    {
        try {
            $contractId         = (string) $request->input('contract_id');
            $transitionIdOrName = (string) $request->input('transition_id');
            $userComment        = $request->input('comment'); // can be null

            return DB::transaction(function () use ($contractId, $transitionIdOrName, $userComment) {
                // 1) Logged user
                $user = Auth::user();
                if (!$user) {
                    throw new Exception(trans('auth.user_not_found'));
                }

                // 2) Contract
                /** @var Contract $contract */
                $contract = Contract::findOrFail($contractId);

                // 3) Current state
                $contract->refresh();
                $currentStateId = (string) $contract->contract_state_id;

                // 4) Available transitions (filtered by role/permissions)
                $available = $this->getAvailableTransitions($contract)->load('targetState:id,name,code');

                // 5) Resolve transition by UUID or by name (unique per source_state)
                /** @var ContractStateTransition|null $t */
                if (Str::isUuid($transitionIdOrName)) {
                    $t = $available->firstWhere('id', $transitionIdOrName);
                } else {
                    $t = $available->first(function ($row) use ($transitionIdOrName, $currentStateId) {
                        return (string)$row->name === (string)$transitionIdOrName
                            && (string)$row->source_state_id === $currentStateId;
                    });
                }

                if (!$t || (string)$t->source_state_id !== $currentStateId || !(bool)$t->active) {
                    throw new Exception(trans('hr/contract.transition_not_allowed'));
                }

                // 6) Optional business guards
                // $this->assertGuards($contract, $t);

                // 7) Apply status change
                $contract->contract_state_id = (string) $t->target_state_id;
                $contract->save();

                // 8) History + Timeline
                $target = $t->targetState ?: ContractState::find($t->target_state_id);

                // If comment comes I use it; If not, I use the default
                $defaultComment = "Transition: {$t->name} → " . ($target?->name ?? 'N/A');
                $finalComment   = $userComment !== null && $userComment !== '' ? (string) $userComment : $defaultComment;

                $actorPersonId = $this->currentSupervisorPersonId() ?? $contract->supervisor_id;

                $contract->contractHistories()->create([
                    'contract_id'        => $contract->id,
                    'supervisor_id'      => $actorPersonId,
                    'state_id'           => $t->target_state_id,
                    'date'               => now(),
                    'notification_count' => 0,
                    'comment'            => $finalComment,
                ]);

                $currentState = ContractState::find($currentStateId);
                $currentName  = $currentState?->name ?? 'N/A';
                $targetName   = $target?->name ?? 'N/A';

                ActivityTimeLineHelper::store(
                    $contract->id,
                    'state-transition',
                    'Contract',
                    "State changed: {$currentName} → {$targetName}"
                );


                return $t;
            });
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /*********************************************** Functions to calculate the contract amount *******************************************/
    // ---- Business constants ----
    /**
     * Single place to read params from config.
     * Central access to config params
     */
    private function params(): array
    {
        return config('compensation', []);
    }

    /** Feature flag: apply min-enrollment rules? */
    private function applyMinEnrollment(): bool
    {
        return (bool)data_get($this->params(), 'flags.apply_min_enrollment', true);
    }

    private function studyAbroadPerStudent(): float
    {
        return (float)data_get($this->params(), 'studyAbroad.perStudent', 560.72);
    }

    /** Derive a per-credit fallback from "per3cr" (role: FAC|ADJ; level currently 'graduate') */
    private function perCreditFallback(string $role, string $level = 'graduate'): float
    {
        $key = $role === 'FAC' ? 'faculty' : 'adjunct';
        $per3 = (float)data_get($this->params(), "{$level}.{$key}.per3cr", $role === 'FAC' ? 14000 : 10000);

        return round($per3 / 3, 2);
    }

    /** Graduate min enrollment rules */
    private function gradMinEnrollment(): int
    {
        return (int)data_get($this->params(), 'graduate.minEnrollment', 20);
    }

    private function gradPenaltyPerMissing(string $role): float
    {
        $key = $role === 'FAC' ? 'faculty' : 'adjunct';

        return (float)data_get($this->params(), "graduate.{$key}.perMissing", $role === 'FAC' ? 700 : 500);
    }

    private function gradMinAmount(string $role): float
    {
        $key = $role === 'FAC' ? 'faculty' : 'adjunct';

        return (float)data_get($this->params(), "graduate.{$key}.min", $role === 'FAC' ? 7000 : 5000);
    }

    /**
     * Apply min-enrollment penalty logic (if enabled).
     * Returns [newBase, basisExtraArray|null].
     */
    private function applyMinEnrollmentAdjustments(float $base, int $enrolled, string $role): array
    {
        if (!$this->applyMinEnrollment()) {
            return [$base, null];
        }

        $minEnroll = $this->gradMinEnrollment();

        if ($enrolled >= $minEnroll) {
            return [$base, [
                'minEnrollment' => $minEnroll,
                'enrolled' => $enrolled,
                'penalty' => 0,
            ]];
        }

        $missing = $minEnroll - $enrolled;
        $penalty = $this->gradPenaltyPerMissing($role) * $missing;
        $newBase = max($this->gradMinAmount($role), $base - $penalty);

        return [$newBase, [
            'minEnrollment' => $minEnroll,
            'enrolled' => $enrolled,
            'penalty' => $penalty,
        ]];
    }

    /**
     * Compute compensation grouped by course (one contract per course)
     * and flatten all rows into a single "activities" table.
     *
     * Rules:
     * - ADJ: uses ALL sections of the instructor.
     * - FAC: uses ONLY sections with overload=true (in workloadCourses)
     *        AND also include sections combined with those overload sections.
     *
     * Each activity row now includes:
     * - base, credits (from the group/basis actually used to calculate)
     * - overload (bool), activity_numbers (program.activityNumber[])
     * - weight, amount (allocation share for the activity's program)
     */
    public function computeForTermAndInstructor(Request $request): array
    {
        $termId = $request['term_id'];
        $instructorId = $request['instructor_id'];
        $courseId = $request['course_id'] ?? $request['courseId'] ?? null;

        $instructor = Instructor::with('employeeType')->findOrFail($instructorId);
        $roleCode = strtoupper((string)optional($instructor->employeeType)->code); // 'FAC'|'ADJ'|...
        $role = $roleCode === 'FAC' ? 'FAC' : 'ADJ';

        // Centralize the relations list so we can reuse it for the re-hydration step
        $withRelations = [
            'term',
            'course',
            'instructorMode',
            'program.contractRates',
            'program.programLevel',
            'program.activityNumber',
            'meetingPatterns.facility',
            'meetingPatterns.instructor.person',
            'meetingPatterns.instructor.activeAssignment.salaryAdminPlan',
            'meetingPatterns.instructor.activeAssignment.jobTitle',
            'meetingPatterns.instructor.activeAssignment.assignmentContract',
            'meetingPatterns.instructor.activeAssignmentContract',
            'meetingPatternHybrids.facility.facilityType',
            'meetingPatternHybrids.instructor.person',
            'meetingPatternHybrids.instructor.activeAssignment.salaryAdminPlan',
            'meetingPatternHybrids.instructor.activeAssignment.jobTitle',
            'meetingPatternHybrids.instructor.activeAssignment.assignmentContract',
            'meetingPatternHybrids.instructor.activeAssignmentContract',
            'combinedSections.combinedSection.course',
            'combinedSections.combinedSection.program.contractRates',
            'combinedSections.combinedSection.program.activityNumber',
            'workloadCourses.workload',
        ];

        // ===== Base dataset: sections in the given term (optionally filtered by course)
        // ===== Instructor association checked via meetingPatterns, meetingPatternHybrids, or workload
        $baseQuery = Section::with($withRelations)
            ->where('term_id', $termId)
            ->when($courseId, fn($q) => $q->where('course_id', $courseId))
            ->where(function ($q) use ($instructorId) {
                $q->whereHas('meetingPatterns.instructor', fn($qq) => $qq->where('id', $instructorId))
                    ->orWhereHas('meetingPatternHybrids.instructor', fn($qq) => $qq->where('id', $instructorId))
                    ->orWhereHas('workloadCourses.workload', fn($qw) => $qw->where('instructor_id', $instructorId));
            })
            ->orderBy('sec_code')
            ->orderBy('sec_number');

        $sections = $baseQuery->get();

        // (Optional) debug pre-checks...
        try {
            $countAllForTerm = Section::where('term_id', $termId)
                ->where(function ($q) use ($instructorId) {
                    $q->whereHas('meetingPatterns.instructor', fn($qq) => $qq->where('id', $instructorId))
                        ->orWhereHas('meetingPatternHybrids.instructor', fn($qq) => $qq->where('id', $instructorId))
                        ->orWhereHas('workloadCourses.workload', fn($qw) => $qw->where('instructor_id', $instructorId));
                })->count();

            $countForTermAndCourse = null;
            if ($courseId) {
                $countForTermAndCourse = Section::where('term_id', $termId)
                    ->where('course_id', $courseId)
                    ->where(function ($q) use ($instructorId) {
                        $q->whereHas('meetingPatterns.instructor', fn($qq) => $qq->where('id', $instructorId))
                            ->orWhereHas('meetingPatternHybrids.instructor', fn($qq) => $qq->where('id', $instructorId))
                            ->orWhereHas('workloadCourses.workload', fn($qw) => $qw->where('instructor_id', $instructorId));
                    })->count();
            }

            $validCourses = $this->listValidCoursesForTermAndInstructor($termId, $instructorId);

            Log::debug('computeForTermAndInstructor: precheck', [
                'role' => $role,
                'term_id' => $termId,
                'course_id_requested' => $courseId,
                'count_all_for_term' => $countAllForTerm,
                'count_for_term_and_course' => $countForTermAndCourse,
                'valid_courses_for_term' => $validCourses,
                'snapshot' => $sections->map(fn($s) => [
                    'section_id' => (string)$s->id,
                    'course_id' => (string)$s->course_id,
                    'course_code' => optional($s->course)->code,
                    'sec' => ($s->sec_code ?? '') . ($s->sec_number ?? '') . ($s->sec_sess ?? ''),
                    'overload' => $this->isSectionOverload($s),
                    'enrolled' => (int)($s->student_enrollment ?? 0),
                ])->values()->toArray(),
            ]);
        } catch (\Throwable $e) {
            Log::warning('computeForTermAndInstructor: precheck logging failed', ['err' => $e->getMessage()]);
        }

        if ($sections->isEmpty()) {
            return ['activities' => [], 'grandTotal' => 0, 'paramsUsed' => $this->params()];
        }

        // ===== Selection rules (same business logic):
        // - FAC: must have at least one overload section
        // - ADJ: can use all sections
        // - When course_id is provided, be strict to that course (do not expand beyond it)
        if ($role === 'FAC') {
            if ($courseId) {
                // Sections already filtered by course_id in $sections (by ->when($courseId))
                $courseSections = $sections->filter(fn($s) => (string)$s->course_id === (string)$courseId)->values();

                // Is any section of the course marked overload in workload_courses?
                $hasOverload = $courseSections->contains(fn($s) => $this->isSectionOverload($s));

                if (!$hasOverload) {
                    // There is no overload in the course → NO activities are calculated (FAC rule)
                    Log::info('FAC course without overload; returning empty set', [
                        'term_id' => $termId,
                        'course_id' => $courseId,
                        'instructor_id' => $instructorId,
                    ]);
                    return ['activities' => [], 'grandTotal' => 0, 'paramsUsed' => $this->params()];
                }

                // There is at least one overload → include ALL course sections
                $selected = $courseSections->values();
            } else {
                // FAC without courseId: original behavior (use seeds overload + combined)
                $seedSections = $sections->filter(fn($s) => $this->isSectionOverload($s))->values();
                if ($seedSections->isEmpty()) {
                    return ['activities' => [], 'grandTotal' => 0, 'paramsUsed' => $this->params()];
                }
                $selected = $this->expandCombinedFromSeeds($sections, $seedSections)->values();
            }
        } else { // ADJ
            if ($courseId) {
                $selected = $this->expandCombinedSections($sections)->filter(
                    fn($s) => (string)$s->course_id === (string)$courseId
                )->values();
            } else {
                $selected = $this->expandCombinedSections($sections)->values();
            }
        }

        if ($selected->isEmpty()) {
            if ($role === 'FAC' && $courseId) {
                Log::warning('computeForTermAndInstructor: empty after FAC course selection', [
                    'term_id' => $termId,
                    'course_id' => $courseId,
                    'instructor_id' => $instructorId,
                ]);
            }
            return ['activities' => [], 'grandTotal' => 0, 'paramsUsed' => $this->params()];
        }

        // ===== IMPORTANT FIX =====
        // Re-hydrate the selected sections with FULL relations to guarantee schedules are available.
        // When expandCombined* pulls partner sections via combinedSections, those instances may not
        // have meetingPatterns/meetingPatternHybrids eager-loaded. Reload ensures they do.
        $selectedIds = $selected->pluck('id')->unique()->values();
        $selected = Section::with($withRelations)
            ->whereIn('id', $selectedIds)
            ->orderBy('sec_code')
            ->orderBy('sec_number')
            ->get();

        // ===== Calculation (unchanged)
        $groups = $selected->groupBy('course_id');
        $activities = [];
        $grandTotal = 0.0;
        $grandHoursWorked = 0.0;

        foreach ($groups as $courseIdKey => $group) {
            $course = optional($group->first())->course;
            $code = optional($course)->code ?? 'COURSE';
            $credits = (int)(optional($course)->credit ?? 0);

            // Extract subject (letters) and catalog (numbers) from code
            $subject = '';
            $catalog = '';
            if (is_string($code) && $code !== '') {
                if (preg_match('/^[A-Za-z]+/', $code, $m)) $subject = $m[0];
                if (preg_match('/(\d+)/', $code, $m)) $catalog = $m[0];
            }

            $groupRef = sprintf('%s (%d %s)', $code, $group->count(), $group->count() === 1 ? 'activity' : 'activities');

            $uniquePrograms = $group->pluck('program')->filter()->unique('id')->values();
            $splitCount = max(1, $uniquePrograms->count());
            $splitWeight = 1.0 / $splitCount;
            $levelKey = 'graduate';

            $isStudyAbroad = $uniquePrograms->contains(function ($p) {
                return strtoupper((string)optional($p)->code) === 'STUDY-ABROAD';
            });

            $basis = [];
            if ($isStudyAbroad) {
                $headcount = (int)$group->sum(fn($s) => (int)($s->student_enrollment ?? $s->studentEnrollment ?? 0));
                $perStudent = $this->studyAbroadPerStudent();
                $base = round($headcount * $perStudent, 2);
                $basis = ['perStudent' => $perStudent, 'headcount' => $headcount];
            } elseif ($role === 'FAC') {
                $contract = $this->pickContractRate($uniquePrograms);
                if ($contract !== null) {
                    $base = (float)$contract;
                    $basis = ['base' => $base, 'credits' => $credits];
                } else {
                    $perCredit = $this->perCreditFallback('FAC', $levelKey);
                    $base = round($perCredit * $credits, 2);
                    $basis = ['credits' => $credits, 'perCredit' => $perCredit];
                }
                $enrolledSum = (int)$group->sum(fn($s) => (int)($s->student_enrollment ?? $s->studentEnrollment ?? 0));
                [$base, $extra] = $this->applyMinEnrollmentAdjustments($base, $enrolledSum, 'FAC');
                if ($extra) $basis = array_merge($basis, $extra);
            } else {
                $perCredit = $this->perCreditFallback('ADJ', $levelKey);
                $base = round($perCredit * $credits, 2);
                $basis = ['credits' => $credits, 'perCredit' => $perCredit];

                $enrolledSum = (int)$group->sum(fn($s) => (int)($s->student_enrollment ?? $s->studentEnrollment ?? 0));
                [$base, $extra] = $this->applyMinEnrollmentAdjustments($base, $enrolledSum, 'ADJ');
                if ($extra) $basis = array_merge($basis, $extra);
            }

            $allocations = $uniquePrograms->map(function ($p) use ($base, $splitWeight) {
                return [
                    'programId' => (string)optional($p)->id,
                    'label' => $this->programLabel($p),
                    'weight' => $splitWeight,
                    'amount' => round($base * $splitWeight, 2),
                ];
            })->values();

            $allocIndex = [];
            foreach ($allocations as $a) {
                $allocIndex[(string)$a['programId']] = ['weight' => $a['weight'], 'amount' => $a['amount']];
            }

            foreach ($group as $s) {
                $program = $s->program;
                $pid = (string)optional($program)->id;

                $weight = Arr::get($allocIndex, "{$pid}.weight", 0.0);
                $amount = Arr::get($allocIndex, "{$pid}.amount", 0.0);

                $sectionCode = (string)($s->sec_code ?? '');
                $sectionNumber = (string)($s->sec_number ?? '');
                $sectionSess = (string)($s->sec_sess ?? '');
                $sectionOnly = "{$sectionCode}{$sectionNumber}{$sectionSess}";

                // Now schedules are guaranteed to be available because we reloaded the relations
                $schedules = $this->buildSchedules($s);

                // hours worked for THIS section
                $hoursWorked = $this->computeHoursWorkedForSection($s);
                $grandHoursWorked += $hoursWorked;

                $activities[] = [
                    'groupRef' => $groupRef,
                    'sectionId' => (string)$s->id,
                    'sectionRef' => $this->sectionRef($s),
                    'programId' => $pid,
                    'programLabel' => $this->programLabel($program),
                    'enrolled' => (int)($s->student_enrollment ?? $s->studentEnrollment ?? 0),
                    'activity_numbers' => $this->activityNumbersForProgram($program),
                    'weight' => (float)$weight,
                    'amount' => (float)$amount,
                    'base' => isset($basis['base']) ? (float)$basis['base'] : (float)$base,
                    'credits' => (int)$credits,
                    'overload' => $this->isSectionOverload($s),
                    'subject' => $subject,
                    'catalog' => $catalog,
                    'section' => $sectionOnly,
                    'workSchedule' => $schedules,

                    // hours worked
                    'hoursWorked' => (float)$hoursWorked,
                ];
            }

            $grandTotal += (float)$base; // one contract per course
        }

        return [
            'activities' => $activities,
            'grandTotal' => (float)$grandTotal,
            'paramsUsed' => $this->params(),
            'grandHoursWorked' => (float)round($grandHoursWorked, 2) // hours worked
        ];
    }

    /**
     * Helper (IMPROVEMENT #3): list valid courses in the term for the instructor.
     * Useful for UI dropdowns or debugging. Returns a simple array for logging.
     */
    private function listValidCoursesForTermAndInstructor(string $termId, string $instructorId): array
    {
        return Section::with('course:id,code,name')
            ->where('term_id', $termId)
            ->where(function ($q) use ($instructorId) {
                $q->whereHas('meetingPatterns.instructor', fn($qq) => $qq->where('id', $instructorId))
                    ->orWhereHas('meetingPatternHybrids.instructor', fn($qq) => $qq->where('id', $instructorId))
                    ->orWhereHas('workloadCourses.workload', fn($qw) => $qw->where('instructor_id', $instructorId));
            })
            ->get()
            ->unique('course_id')
            ->map(fn($s) => [
                'course_id' => (string)$s->course_id,
                'code' => $s->course?->code,
                'name' => $s->course?->name,
            ])
            ->values()
            ->toArray();
    }

    /** Normalizes 'day' to MON..SUN if it comes in as an integer 1–7 or 0–6; leaves string as it comes in if it's already text */
    /** Map many "day" formats to full English names: Monday..Sunday.
     *  Returns null for non-meeting tokens (ONLINE/WEB/TBA/etc.). */
    private function normalizeDay($v): ?string
    {
        if ($v === null || $v === '') {
            return null;
        }

        // Ignore non-meeting tokens
        the_token:
        $token = strtoupper(trim((string)$v));
        $nonMeeting = ['ONLINE', 'WEB', 'REMOTE', 'ASYNC', 'ASYNCHRONOUS', 'TBA', 'TBD', 'ARR', 'ARRANGED', 'NA', 'N/A'];
        if (in_array($token, $nonMeeting, true)) {
            return null;
        }

        // Numeric forms: 1–7 (Mon=1) or 0–6 (Sun=0)
        if (is_numeric($v)) {
            $n = (int)$v;
            $map17 = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
            $map06 = [0 => 'Sunday', 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday'];
            if (isset($map17[$n])) return $map17[$n];
            if (isset($map06[$n])) return $map06[$n];
        }

        // English-only aliases (single letter, two-letter, three-letter, full)
        $aliases = [
            // Monday
            'M' => 'Monday', 'MO' => 'Monday', 'MON' => 'Monday', 'MONDAY' => 'Monday',
            // Tuesday
            'T' => 'Tuesday', 'TU' => 'Tuesday', 'TUE' => 'Tuesday', 'TUESDAY' => 'Tuesday',
            // Wednesday
            'W' => 'Wednesday', 'WE' => 'Wednesday', 'WED' => 'Wednesday', 'WEDNESDAY' => 'Wednesday',
            // Thursday
            'R' => 'Thursday', 'TH' => 'Thursday', 'THU' => 'Thursday', 'THURSDAY' => 'Thursday',
            // Friday
            'F' => 'Friday', 'FR' => 'Friday', 'FRI' => 'Friday', 'FRIDAY' => 'Friday',
            // Saturday
            'S' => 'Saturday', 'SA' => 'Saturday', 'SAT' => 'Saturday', 'SATURDAY' => 'Saturday',
            // Sunday
            'U' => 'Sunday', 'SU' => 'Sunday', 'SUN' => 'Sunday', 'SUNDAY' => 'Sunday',
        ];

        return $aliases[$token] ?? null;
    }

    /** Derive MON..SUN from a date string like 'YYYY-MM-DD' (or any Carbon-parseable). */
    private function dayOfWeekFromDate(?string $date): ?string
    {
        if (!$date) return null;
        try {
            $c = Carbon::parse($date);
            $d = strtoupper($c->format('D')); // Mon/Tue/... -> MON/TUE/...
            $map = ['MON' => 'MON', 'TUE' => 'TUE', 'WED' => 'WED', 'THU' => 'THU', 'FRI' => 'FRI', 'SAT' => 'SAT', 'SUN' => 'SUN'];
            return $map[$d] ?? null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Normalize time strings:
     *  - 'HH:MM:SS' or 'HH:MM:SS.ffffff' -> 'HH:MM'
     *  - '900' / '0930' -> '09:00' / '09:30'
     */
    private function normalizeTime($t)
    {
        if (!$t) return $t;
        $s = trim((string)$t);

        // Already HH:MM
        if (preg_match('/^\d{1,2}:\d{2}$/', $s)) {
            return $s;
        }

        // HH:MM:SS or HH:MM:SS.fffffffff (SQL Server)
        if (preg_match('/^\d{1,2}:\d{2}:\d{2}(\.\d+)?$/', $s)) {
            return substr($s, 0, 5); // keep HH:MM
        }

        // 900 / 0930 / 1305 -> 09:00 / 09:30 / 13:05
        if (preg_match('/^\d{3,4}$/', $s)) {
            $s = str_pad($s, 4, '0', STR_PAD_LEFT);
            return substr($s, 0, 2) . ':' . substr($s, 2, 2);
        }

        return $s;
    }

    /** Build a unified schedule array mixing MeetingPattern (recurring) and MeetingPatternHybrid (dated).
     *  - MP rows: use 'day' + start/end times; no 'date'.
     *  - MPH rows: use 'date' (or 'meeting_date'); if 'day' missing, derive from 'date'.
     *  - Include location if facility is available (facility.name) and facility_type (facility.facilityType.name).
     *  - When no usable rows exist, synthesize a fallback (ONLINE/TBA) with section date range.
     */
    private function buildSchedules($section): array
    {
        $out = [];
        $push = function ($src, string $kind) use (&$out) {
            // Times (common)
            $start = Arr::get($src, 'start_time')
                ?? Arr::get($src, 'start')
                ?? Arr::get($src, 'time_start');
            $end = Arr::get($src, 'end_time')
                ?? Arr::get($src, 'end')
                ?? Arr::get($src, 'time_end');

            $start = $this->normalizeTime($start);
            $end = $this->normalizeTime($end);

            // Facility / location (use data_get to traverse models)
            $facilityName = data_get($src, 'facility.name');
            $facilityType = data_get($src, 'facility.facilityType.name');

            if ($kind === 'mp') {
                // Recurring pattern: 'day' from multiple possible keys
                $dayRaw = Arr::get($src, 'day')
                    ?? Arr::get($src, 'dow')
                    ?? Arr::get($src, 'day_of_week')
                    ?? Arr::get($src, 'weekday')
                    ?? Arr::get($src, 'week_day');

                $day = $this->normalizeDay($dayRaw);

                // Skip if totally empty
                if (!$day && !$start && !$end) return;

                $row = [
                    'day' => $day,      // MON..SUN
                    'start_time' => $start,    // HH:MM
                    'end_time' => $end,      // HH:MM
                ];
                if ($facilityName) $row['location'] = $facilityName;
                if ($facilityType) $row['facility_type'] = $facilityType;

                $out[] = $row;
                return;
            }

            // Hybrid (dated)
            $date = Arr::get($src, 'date')
                ?? Arr::get($src, 'meeting_date')
                ?? Arr::get($src, 'scheduled_date');

            // If day is not present, derive it from date
            $dayRaw = Arr::get($src, 'day')
                ?? Arr::get($src, 'dow')
                ?? Arr::get($src, 'day_of_week');

            $day = $this->normalizeDay($dayRaw);
            if (!$day && $date) {
                $day = $this->dayOfWeekFromDate((string)$date);
            }

            // Skip only if everything is missing (day, times AND date)
            if (!$day && !$start && !$end && !$date) return;

            $row = [
                'day' => $day,
                'start_time' => $start,
                'end_time' => $end,
            ];
            if ($date) {
                // Keep YYYY-MM-DD if a full datetime string is present
                $row['date'] = substr((string)$date, 0, 10);
            }
            if ($facilityName) $row['location'] = $facilityName;
            if ($facilityType) $row['facility_type'] = $facilityType;

            $out[] = $row;
        };

        // Merge MeetingPattern (recurring)
        foreach (collect($section->meetingPatterns ?? []) as $mp) {
            $push($mp, 'mp');
        }

        // Merge MeetingPatternHybrid (dated)
        foreach (collect($section->meetingPatternHybrids ?? []) as $mph) {
            $push($mph, 'mph');
        }

        // Deduplicate identical rows
        $out = collect($out)->unique(function ($r) {
            return
                ($r['day'] ?? '') . '|' .
                ($r['start_time'] ?? '') . '|' .
                ($r['end_time'] ?? '') . '|' .
                ($r['date'] ?? '') . '|' .
                ($r['location'] ?? '') . '|' .
                ($r['facility_type'] ?? '');
        })->values()->all();

        // Fallback when empty: synthesize a meaningful row
        if (empty($out)) {
            $mode = strtoupper((string)optional($section->instructorMode)->code); // 'I' = Internet
            $label = $mode === 'I' ? 'ONLINE' : 'TBA';

            $startDate = $section->starting_date ? substr((string)$section->starting_date, 0, 10) : null;
            $endDate = $section->ending_date ? substr((string)$section->ending_date, 0, 10) : null;

            $row = [
                'day' => $label,  // conveys delivery mode to the UI
                'start_time' => null,
                'end_time' => null,
            ];
            if ($startDate || $endDate) {
                $row['date'] = $startDate && $endDate ? "{$startDate}–{$endDate}" : ($startDate ?? $endDate);
            }

            $out[] = $row;
        }

        return $out;
    }

    // ----------------- Helpers -----------------

    /** Small helper to expose program.activityNumber[] as [{name, number}, ...] */
    private function activityNumbersForProgram($program): array
    {
        if (!$program || !isset($program->activityNumber)) return [];
        $out = [];
        foreach ($program->activityNumber as $an) {
            $out[] = [
                'name' => (string)($an->name ?? ''),
                'number' => (string)($an->number ?? ''),
                'id' => (string)($an->id ?? ''),
            ];
        }
        return $out;
    }

    private function sectionRef($s): string
    {
        $code = Arr::get($s, 'course.code', '');
        $c = Arr::get($s, 'sec_code', '');
        $n = Arr::get($s, 'sec_number', '');
        $ss = Arr::get($s, 'sec_sess', '');

        return trim("{$code}{$c}{$n}{$ss}");
    }

    private function programLabel($program): string
    {
        if (!$program) return '';
        return $program->name ?: ($program->code ?: (string)$program->id);
    }

    /** First active contract_rate among programs (if any) */
    private function pickContractRate(Collection $programs): ?float
    {
        foreach ($programs as $p) {
            $rates = optional($p->contractRates)->filter(function ($cr) {
                return (int)($cr->active ?? 0) === 1 && $cr->contract_rate !== null;
            });

            if ($rates && $rates->count() > 0) {
                $rate = (float)$rates->first()->contract_rate;
                if ($rate > 0) return $rate;
            }
        }
        return null;
    }

    /** Is this section marked as overload (from workloadCourses)? */
    private function isSectionOverload($section): bool
    {
        $list = collect($section->workloadCourses ?? []);
        foreach ($list as $wc) {
            if ((bool)($wc->overload ?? false)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Expand only from a set of "seed" sections: include each seed and any section
     * combined with it (both directions).
     */
    private function expandCombinedFromSeeds(Collection $all, Collection $seeds): Collection
    {
        $byId = $all->keyBy('id');
        $wanted = collect();

        $enqueue = function ($s) use (&$wanted) {
            if ($s && !empty($s->id) && !$wanted->has($s->id)) {
                $wanted->put($s->id, $s);
            }
        };

        // Add seeds
        foreach ($seeds as $s) {
            $enqueue($s);

            // Forward partners from seed
            foreach (collect($s->combinedSections ?? []) as $cs) {
                $partner = $cs->combinedSection ?? null;
                if ($partner) {
                    $enqueue($byId->get($partner->id, $partner));
                }
            }
        }

        // Reverse: any section that references one of the seeds as its combined partner
        foreach ($all as $opt) {
            foreach (collect($opt->combinedSections ?? []) as $cs) {
                $partnerId = optional($cs->combinedSection)->id;
                if ($partnerId && $seeds->contains(fn($s) => (string)$s->id === (string)$partnerId)) {
                    $enqueue($opt);
                }
            }
        }

        return $wanted->values();
    }

    /** Include combined partners for ALL sections (unused in FAC filter path, kept for reuse) */
    private function expandCombinedSections(Collection $sections): Collection
    {
        $byId = $sections->keyBy('id');
        $wanted = collect();

        foreach ($sections as $s) {
            $wanted->put($s->id, $s);
            $list = collect($s->combinedSections ?? []);
            foreach ($list as $cs) {
                $partner = $cs->combinedSection ?? null;
                if ($partner && !$wanted->has($partner->id)) {
                    $wanted->put($partner->id, $partner);
                }
            }
        }

        foreach ($sections as $opt) {
            $list = collect($opt->combinedSections ?? []);
            foreach ($list as $cs) {
                $combinedId = optional($cs->combinedSection)->id;
                if ($combinedId && $byId->has($combinedId) && !$wanted->has($opt->id)) {
                    $wanted->put($opt->id, $opt);
                }
            }
        }

        return $wanted->values();
    }

    /** Gather unique activity numbers for a given program (for allocations table) */
    private function collectProgramActivities(Collection $group, string $programId): array
    {
        $map = [];
        foreach ($group as $s) {
            $p = $s->program;
            if (!$p || (string)$p->id !== (string)$programId) continue;

            $list = optional($p->activityNumber) ?: collect();
            foreach ($list as $an) {
                $key = ($an->id ?? ($an->number . '-' . $an->name));
                if (!isset($map[$key])) {
                    $map[$key] = [
                        'name' => (string)($an->name ?? ''),
                        'number' => (string)($an->number ?? ''),
                        'id' => (string)($an->id ?? ''),
                    ];
                }
            }
        }
        return array_values($map);
    }

    /**
     * Converts 'Monday'..'Sunday' to a Carbon number (0=Sun..6=Sat).
     */
    private function dayNameToCarbonDow(?string $dayName): ?int
    {
        if (!$dayName) return null;
        $map = [
            'Sunday' => 0,
            'Monday' => 1,
            'Tuesday' => 2,
            'Wednesday' => 3,
            'Thursday' => 4,
            'Friday' => 5,
            'Saturday' => 6,
        ];
        return $map[$dayName] ?? null;
    }

    /**
     * Difference in minutes between two 'HH:MM' times.
     * If end < start, assumes midnight (+24h).
     */
    private function timeDiffMinutes(?string $start, ?string $end): int
    {
        if (!$start || !$end) return 0;

        if (!preg_match('/^(\d{1,2}):(\d{2})$/', $start, $a)) return 0;
        if (!preg_match('/^(\d{1,2}):(\d{2})$/', $end, $b)) return 0;

        $sm = ((int)$a[1]) * 60 + (int)$a[2];
        $em = ((int)$b[1]) * 60 + (int)$b[2];

        $diff = $em - $sm;
        if ($diff < 0) $diff += 24 * 60; // por si cruza medianoche
        return $diff;
    }

    /**
     * Counts occurrences of a weekday between two (inclusive) dates.
     * $weekday: 0=Sun..6=Sat (Carbon format).
     */
    private function countWeekdayBetweenDates(Carbon $start, Carbon $end, int $weekday): int
    {
        if ($end->lt($start)) return 0;

        $first = $start->copy();
        $delta = ($weekday - $first->dayOfWeek + 7) % 7;
        $first->addDays($delta);

        if ($first->gt($end)) return 0;

        $diffDays = $first->diffInDays($end);
        return intdiv($diffDays, 7) + 1;
    }

    /**
     * Calculate hours worked (double) for a section:
     * - MeetingPattern: Repeats for each week within the term.
     * - MeetingPatternHybrid: Uses the current date if it falls within the term.
     */
    private function computeHoursWorkedForSection($section): float
    {
        $term = $section->term ?? null;
        $begin = $term?->begin_dt;
        $end = $term?->end_dt;

        if (!$begin || !$end) {
            return 0.0;
        }

        $startDate = Carbon::parse($begin)->startOfDay();
        $endDate = Carbon::parse($end)->startOfDay();

        $mpMinutes = 0;
        $mphMinutes = 0;

        // ---- MeetingPattern (recurring)
        foreach (collect($section->meetingPatterns ?? []) as $mp) {
            $dayRaw = Arr::get($mp, 'day')
                ?? Arr::get($mp, 'dow')
                ?? Arr::get($mp, 'day_of_week')
                ?? Arr::get($mp, 'weekday')
                ?? Arr::get($mp, 'week_day');

            $dayName = $this->normalizeDay($dayRaw);
            $weekday = $this->dayNameToCarbonDow($dayName);
            if ($weekday === null) continue;

            $start = $this->normalizeTime(
                Arr::get($mp, 'start_time')
                ?? Arr::get($mp, 'start')
                ?? Arr::get($mp, 'time_start')
            );
            $endT = $this->normalizeTime(
                Arr::get($mp, 'end_time')
                ?? Arr::get($mp, 'end')
                ?? Arr::get($mp, 'time_end')
            );

            $minutesPerMeeting = $this->timeDiffMinutes($start, $endT);
            if ($minutesPerMeeting <= 0) continue;

            $occ = $this->countWeekdayBetweenDates($startDate, $endDate, $weekday);
            $mpMinutes += $occ * $minutesPerMeeting;
        }

        // ---- MeetingPatternHybrid (with dated)
        foreach (collect($section->meetingPatternHybrids ?? []) as $mph) {
            $date = Arr::get($mph, 'date')
                ?? Arr::get($mph, 'meeting_date')
                ?? Arr::get($mph, 'scheduled_date');

            if (!$date) continue;

            try {
                $d = Carbon::parse($date)->startOfDay();
            } catch (\Throwable $e) {
                continue;
            }

            if ($d->lt($startDate) || $d->gt($endDate)) {
                continue; // out of range of the term
            }

            $start = $this->normalizeTime(
                Arr::get($mph, 'start_time')
                ?? Arr::get($mph, 'start')
                ?? Arr::get($mph, 'time_start')
            );
            $endT = $this->normalizeTime(
                Arr::get($mph, 'end_time')
                ?? Arr::get($mph, 'end')
                ?? Arr::get($mph, 'time_end')
            );

            $minutes = $this->timeDiffMinutes($start, $endT);
            if ($minutes > 0) {
                $mphMinutes += $minutes;
            }
        }

        return round(($mpMinutes + $mphMinutes) / 60, 2); // in hours, 2 decimal places
    }

    /**
     * Replaces a hasMany relation set with provided rows (delete + createMany).
     * If you prefer upsert-by-id, we can adapt this method.
     *
     * @param HasMany $relation
     * @param array $rows
     * @param array $allowedKeys
     * @param string|int $contractId
     * @param callable|null $normalizer function (array $row): array
     * @return void
     */
    protected function syncHasMany($relation, array $rows, array $allowedKeys, $contractId, callable $normalizer = null): void
    {
        // Remove all existing related rows
        $relation->delete();

        if (empty($rows)) {
            return;
        }

        $prepared = collect($rows)
            ->filter(fn($r) => is_array($r) && !empty($r))
            ->map(function ($row) use ($allowedKeys, $contractId, $normalizer) {
                $row = Arr::only($row, $allowedKeys);

                // Optional per-row normalization hook
                if ($normalizer) {
                    $row = $normalizer($row);
                }

                // Always enforce contract_id
                $row['contract_id'] = $contractId;

                return $row;
            })
            ->values()
            ->all();

        if (!empty($prepared)) {
            $relation->createMany($prepared);
        }
    }

    /** Returns the SQL expression to cast a column to text based on the driver */
    private function castToText(string $column): string
    {
        $driver = DB::getDriverName();
        return match ($driver) {
            'pgsql'  => "CAST({$column} AS TEXT)",
            'sqlsrv' => "CAST({$column} AS NVARCHAR(MAX))",
            default  => "CAST({$column} AS CHAR)" // mysql/mariadb
        };
    }

    /** WHERE LIKE case-insensitive and null-safe (simple columns) */
    private function whereLike(Builder $q, string $column, string $needle): Builder
    {
        $expr = $this->castToText($column);
        return $q->whereRaw("LOWER({$expr}) LIKE ?", ['%' . mb_strtolower($needle) . '%']);
    }

    /** WHERE LIKE within whereHas (relationship) */
    private function whereHasLike(Builder $q, string $relation, string $column, string $needle): Builder
    {
        return $q->whereHas($relation, function (Builder $qq) use ($column, $needle) {
            $this->whereLike($qq, $column, $needle);
        });
    }

    // Function is to get the person related to the logged user
    private function currentSupervisorPersonId(): ?string
    {
        $user = Auth::user();
        return $user?->person?->getKey();
    }

    /*********************************************** Functions related to reports *******************************************/
    /**
     * Report dataset: rows ready for PDF/Excel rendering (1 row = 1 line like the PDF).
     *
     * Required:
     * - $termIds: array of term UUIDs
     *
     * Optional filters:
     * - $departmentId: UUID
     * - $employeeId: UUID (person_id)
     * - $activityNumbers: array of strings (prefix match against activity_numbers.number)
     *
     * @throws Exception
     */
    public function getContractRequestReport(ContractRequestReportRequest $request): array
    {
        try {
            $termIds         = array_values(array_filter(array_map('trim', (array) $request->input('term_ids', []))));
            $departmentId    = $request->input('department_id');
            $employeeId      = $request->input('employee_id');
            $activityNumbers = $request->input('activity_numbers', []);

            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            if (empty($termIds)) {
                throw new Exception('term_ids is required and must have at least one value.');
            }

            $numbers = is_array($activityNumbers)
                ? array_values(array_filter(array_map('trim', $activityNumbers)))
                : [];

            /** @var Builder $query */
            $query = Contract::query()->with([
                'person.department',
                'person.instructor.employeeType',
                'course.department.academicOrganization', // The Department in the report comes from academic_organizations.name related to the COURSE
                'department.academicOrganization',
                'course',
                'term',
                'contractState',
                'contractActivities.activityNumber',
                'contractCompensationDetails.activityNumber',

                // Fallback schedule if there are no meeting patterns
                'contractSecondaryEmploymentWorkSchedules',
            ]);


            // Visibility
            if (!$user->hasRole('Administrator')) {
                $department     = $user->person?->department;
                $visibleActNums = $user->person?->personActivityNumbers()->pluck('activity_number_id');

                $query->whereHas('person', function (Builder $q) use ($department, $visibleActNums) {
                    $q->where(function (Builder $x) use ($department, $visibleActNums) {
                        if ($department) {
                            $x->orWhere('department_id', $department->id);
                        }

                        if ($visibleActNums && $visibleActNums->isNotEmpty()) {
                            $x->orWhereHas('personActivityNumbers', function (Builder $sub) use ($visibleActNums) {
                                $sub->whereIn('activity_number_id', $visibleActNums);
                            });
                        }
                    })
                        ->where(function (Builder $y) {
                            $y->whereHas('assignments')
                                ->orWhereHas('contracts');
                        });
                });
            }

            // REQUIRED filter: term_ids (case-insensitive UUID compare)
            $termIdsLower = array_map('mb_strtolower', $termIds);
            $query->whereRaw(
                'LOWER(term_id) IN (' . implode(',', array_fill(0, count($termIdsLower), '?')) . ')',
                $termIdsLower
            );

            // OPTIONAL filter: department_id (case-insensitive UUID compare) (dejo tu lógica original)
            if (!empty($departmentId)) {
                $query->whereRaw('LOWER(department_id) = ?', [mb_strtolower(trim((string) $departmentId))]);
            }

            // OPTIONAL filter: employee_id (person_id) (case-insensitive UUID compare)
            if (!empty($employeeId)) {
                $query->whereRaw('LOWER(person_id) = ?', [mb_strtolower(trim((string) $employeeId))]);
            }

            // OPTIONAL filter: activity_numbers (prefix match)
            if (!empty($numbers)) {
                $query->where(function (Builder $q) use ($numbers) {
                    $q->whereHas('contractActivities.activityNumber', function (Builder $qa) use ($numbers) {
                        $qa->where(function (Builder $w) use ($numbers) {
                            foreach ($numbers as $n) {
                                $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                            }
                        });
                    })
                        ->orWhereHas('contractCompensationDetails.activityNumber', function (Builder $qc) use ($numbers) {
                            $qc->where(function (Builder $w) use ($numbers) {
                                foreach ($numbers as $n) {
                                    $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                                }
                            });
                        });
                });
            }

            $contracts = $query->get();

            // Stable sort (como lo tenías)
            $contracts = $contracts->sort(function (Contract $a, Contract $b) {
                $pa = $a->person;
                $pb = $b->person;

                $fa = mb_strtolower($pa->first_name ?? '');
                $fb = mb_strtolower($pb->first_name ?? '');
                if ($fa !== $fb) return $fa <=> $fb;

                $la = mb_strtolower($pa->last_name ?? '');
                $lb = mb_strtolower($pb->last_name ?? '');
                if ($la !== $lb) return $la <=> $lb;

                return strcmp((string) $a->id, (string) $b->id);
            })->values();

            // Caches
            $combinedMapCache = null; // section_id => [other_section_id => true]
            $workloadCache    = [];   // workloadKey => [SECTION_ID => aggregated WC data]

            $rows = [];

            foreach ($contracts as $c) {
                $person       = $c->person;
                $instructorId = (string) data_get($c, 'person.instructor.id'); // UUID string

                // Instructor name "Last, First"
                $instructorName = trim(implode(' ', array_filter([
                    $person->last_name ?? null,
                    $person->second_last_name ?? null,
                ])));
                if ($instructorName !== '') {
                    $instructorName .= ', ';
                }
                $instructorName .= trim(implode(' ', array_filter([
                    $person->first_name ?? null,
                    $person->middle_name ?? null,
                ])));

                // Department: academic_organizations.name related to the COURSE of the contract
                $deptName =
                    $c->course?->department?->academicOrganization?->name
                    ?? $c->course?->department?->name
                    ?? $c->department?->academicOrganization?->name
                    ?? $c->department?->name
                    ?? null;

                // Employee type
                $type =
                    data_get($c, 'person.instructor.employeeType.code')
                    ?? data_get($c, 'person.instructor.employeeType.name')
                    ?? $c->employee_type
                    ?? null;

                // Dates
                $startDate = $this->fmtDateForReport($c->start_date);
                $endDate   = $this->fmtDateForReport($c->end_date);

                // Contract status
                $contractStatus =
                    $c->contractState?->name
                    ?? $c->contractState?->code
                    ?? null;

                // Parse semester / academicYear (to find the correct Workload)
                [$semesterName, $academicYear] = $this->parseSemesterYear($c);

                // Combined map (once)
                if ($combinedMapCache === null) {
                    $combinedMapCache = $this->buildCombinedSectionBidirectionalMap();
                }

                // Workload aggregated map (robust) + cached by instructor/semester/year
                $workloadKey = $instructorId . '|' . ($semesterName ?? 'null') . '|' . ($academicYear ?? 'null');
                if (!isset($workloadCache[$workloadKey])) {
                    $workloadCache[$workloadKey] = $this->loadWorkloadCoursesMap($instructorId, $semesterName, $academicYear);
                }
                $wlBySection = $workloadCache[$workloadKey];

                // Resolve sections (tu método)
                $sections = $this->resolveSectionsForContract($c, $instructorId, $semesterName, $academicYear, $wlBySection);

                // Contract activities (merge)
                $activities = [];
                foreach (($c->contractActivities ?? []) as $a) {
                    $activities[] = [
                        'activity_number' => data_get($a, 'activityNumber.number'),
                        'amount'          => (string) ($a->amount ?? $c->amount_pay ?? ''),
                    ];
                }
                foreach (($c->contractCompensationDetails ?? []) as $d) {
                    $activities[] = [
                        'activity_number' => data_get($d, 'activityNumber.number'),
                        'amount'          => (string) ($d->amount ?? $d->amount_pay ?? $c->amount_pay ?? ''),
                    ];
                }

                // Sections payload + summaries
                $sectionPayloads   = [];
                $sectionsSummary   = [];
                $referenceSummary  = [];
                $enrollmentSummary = [];
                $cohortSummary     = [];

                foreach ($sections as $sec) {
                    $sectCode = $this->buildSectionDisplay($sec);

                    // Combined (bidirectional)
                    $combinedCodes = $this->resolveCombinedCodes($sec, $combinedMapCache);

                    // Meeting patterns with fallback to contract schedules
                    $meetingPayload = $this->buildMeetingPatternsPayload(
                        $sec,
                        $instructorId,
                        $c->contractSecondaryEmploymentWorkSchedules ?? []
                    );

                    // WorkloadCourse aggregated fields por SECTION_ID
                    $secKey = strtoupper((string) $sec->id);
                    $wcAgg  = $wlBySection[$secKey] ?? null;

                    $valueSum     = $wcAgg ? (float) ($wcAgg['value_sum'] ?? 0) : 0.0;
                    $adjustedSum  = $wcAgg ? (float) ($wcAgg['adjusted_sum'] ?? 0) : 0.0;
                    $overloadFlag = $wcAgg ? (int) ($wcAgg['overload'] ?? 0) : 0;
                    $onContractF  = $wcAgg ? (int) ($wcAgg['on_contract'] ?? 0) : 0;

                    $value    = $wcAgg ? (string) $valueSum : null;
                    $adjusted = (string) $adjustedSum;

                    // overload_value = SUM(value) si overload=1
                    $overloadValue = ($overloadFlag === 1) ? (string) $valueSum : null;

                    // on_contract (Y/N, para no romper front)
                    $onContract = ($onContractF === 1) ? 'Y' : 'N';

                    $sectionPayloads[] = [
                        'section_id'       => (string) $sec->id,
                        'reference_number' => $sec->references_number_panther ?? null,
                        'enrollment'       => $sec->student_enrollment ?? null,
                        'cohort'           => $sec->cohorts ?? '',
                        'course'           => $sec->course?->code ?? null,
                        'course_name'      => $sec->course?->name ?? null,
                        'section'          => $sectCode,
                        'combined'         => $combinedCodes,
                        'cap'              => $sec->cap ?? null,
                        'program'          => $sec->program?->code ?? $sec->program?->name ?? null,
                        'instructional_mode' => $sec->instructorMode?->code ?? $sec->instructorMode?->name ?? null,
                        'value'          => $value,
                        'overload'       => $overloadFlag,
                        'overload_value' => $overloadValue,
                        'adjusted'       => $adjusted,
                        'on_contract'    => $onContract,
                        'time'                  => $meetingPayload['meeting_patterns_text'],
                        'meeting_patterns'      => $meetingPayload['meeting_patterns'],
                        'meeting_patterns_text' => $meetingPayload['meeting_patterns_text'],
                        'schedule_source'       => $meetingPayload['schedule_source'],
                    ];

                    $sectionsSummary[] = $sectCode;

                    if (!empty($sec->references_number_panther)) {
                        $referenceSummary[] = $sec->references_number_panther;
                    }

                    // (lo dejo como venía: si quieres que incluya 0, lo ajustamos luego)
                    if ($sec->student_enrollment !== null && $sec->student_enrollment !== '') {
                        $enrollmentSummary[] = (string) $sec->student_enrollment;
                    }

                    if (!empty($sec->cohorts)) {
                        $cohortSummary[] = (string) $sec->cohorts;
                    }
                }

                $rows[] = [
                    'contract_id' => (string) $c->id,
                    'person_id'   => (string) $c->person_id,
                    'course_id'   => $c->course_id ? (string) $c->course_id : null,
                    'term_id'     => (string) $c->term_id,
                    'semester' => trim(($c->term?->semester ?? '') . ' ' . ($c->term?->year ?? $c->term?->academic_year ?? '')),
                    'instructor' => $instructorName,
                    'panther_id' => $person?->panther_id,
                    'type'       => $type,
                    'department' => $deptName,
                    'start_date' => $startDate,
                    'end_date'   => $endDate,
                    'contract_status'             => $contractStatus,
                    'erac_number'                 => $c->erac_number,
                    'contract_number'             => $c->contract_number,
                    'superseding_contract_number' => $c->superseding_contract_number,
                    'superseding_contract_enrollment' => $c->superseding_contract_enrollment,
                    'superseding_contract_amount' => $c->superseding_contract_amount,
                    'lump_sum'                    => $c->lump_sum,
                    'sections'   => $sectionPayloads,
                    'activities' => $activities,
                    'sections_summary'          => implode(' | ', array_values(array_filter($sectionsSummary))),
                    'reference_numbers_summary' => implode(' | ', array_values(array_unique(array_filter($referenceSummary)))),
                    // NOTE: array_filter removes "0"
                    'enrollment_summary'        => implode(' | ', array_values(array_unique(array_filter($enrollmentSummary)))),
                    'cohort_summary'            => implode(' | ', array_values(array_unique(array_filter($cohortSummary)))),
                ];
            }

            return [
                'filters' => [
                    'term_ids'         => $termIds,
                    'department_id'    => $departmentId,
                    'employee_id'      => $employeeId,
                    'activity_numbers' => $numbers,
                ],
                'count' => count($rows),
                'rows'  => $rows,
            ];
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Report dataset with extended filters: rows ready for PDF/Excel rendering (1 row = 1 line like the PDF).
     *
     * Required:
     * - $termIds: array of term UUIDs
     *
     * Optional filters:
     * - $departmentId: UUID
     * - $employeeId: UUID (person_id)
     * - $employeeTypeId: UUID (person.instructor.employee_type_id)
     * - $programIds: array of UUIDs (filters by course program)
     * - $status: string (Pending, In Progress, Completed, All)
     * - $activityNumbers: array of strings (prefix match against activity_numbers.number)
     *
     * Notes:
     * - Applies the same visibility rules as getContractsReportData().
     * - Returns the same payload structure (filters, count, rows).
     *
     * @throws Exception
     */

    function getContractStatusReport(ContractStatusReportRequest $request): array
    {
        try {
            $termIds         = array_values(array_filter(array_map('trim', (array) $request->input('term_ids', []))));
            $departmentId    = $request->input('department_id');
            $employeeId      = $request->input('employee_id');
            $employeeTypeId  = $request->input('employee_type_id');

            // program_ids (UUIDs) — normalized to uppercase to match DB UUID casing
            $programIdsRaw = (array) $request->input('program_ids', []);
            $programIds    = array_values(array_filter(array_map(function ($v) {
                $v = strtoupper(trim((string) $v));
                return $v !== '' ? $v : null;
            }, $programIdsRaw)));

            $status          = trim((string) $request->input('status', 'All'));
            $activityNumbers = $request->input('activity_numbers', []);

            $user = Auth::user();
            if (!$user) {
                throw new Exception(trans('auth.user_not_found'));
            }

            if (empty($termIds)) {
                throw new Exception('term_ids is required and must have at least one value.');
            }

            $numbers = is_array($activityNumbers)
                ? array_values(array_filter(array_map('trim', $activityNumbers)))
                : [];

            /** @var Builder $query */
            $query = Contract::query()->with([
                'person.department',
                'person.instructor.employeeType',
                'course.department.academicOrganization',
                'department.academicOrganization',
                'course',
                'term',
                'contractState',
                'contractActivities.activityNumber',
                'contractCompensationDetails.activityNumber',
                'contractSecondaryEmploymentWorkSchedules',
            ]);

            // ===================== VISIBILITY =====================
            if (!$user->hasRole('Administrator')) {
                $department     = $user->person?->department;
                $visibleActNums = $user->person?->personActivityNumbers()->pluck('activity_number_id');

                $query->whereHas('person', function (Builder $q) use ($department, $visibleActNums) {
                    $q->where(function (Builder $x) use ($department, $visibleActNums) {
                        if ($department) {
                            $x->orWhere('department_id', $department->id);
                        }

                        if ($visibleActNums && $visibleActNums->isNotEmpty()) {
                            $x->orWhereHas('personActivityNumbers', function (Builder $sub) use ($visibleActNums) {
                                $sub->whereIn('activity_number_id', $visibleActNums);
                            });
                        }
                    })
                        ->where(function (Builder $y) {
                            $y->whereHas('assignments')
                                ->orWhereHas('contracts');
                        });
                });
            }

            // ===================== REQUIRED filter: term_ids =====================
            // Case-insensitive comparison against UUID strings
            $termIdsLower = array_map('mb_strtolower', $termIds);
            $query->whereRaw(
                'LOWER(term_id) IN (' . implode(',', array_fill(0, count($termIdsLower), '?')) . ')',
                $termIdsLower
            );

            // ===================== OPTIONAL filter: department_id =====================
            if (!empty($departmentId)) {
                $query->whereRaw('LOWER(department_id) = ?', [mb_strtolower(trim((string) $departmentId))]);
            }

            // ===================== OPTIONAL filter: employee_id (person_id) =====================
            if (!empty($employeeId)) {
                $query->whereRaw('LOWER(person_id) = ?', [mb_strtolower(trim((string) $employeeId))]);
            }

            // ===================== OPTIONAL filter: activity_numbers (prefix match) =====================
            if (!empty($numbers)) {
                $query->where(function (Builder $q) use ($numbers) {
                    $q->whereHas('contractActivities.activityNumber', function (Builder $qa) use ($numbers) {
                        $qa->where(function (Builder $w) use ($numbers) {
                            foreach ($numbers as $n) {
                                $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                            }
                        });
                    })
                        ->orWhereHas('contractCompensationDetails.activityNumber', function (Builder $qc) use ($numbers) {
                            $qc->where(function (Builder $w) use ($numbers) {
                                foreach ($numbers as $n) {
                                    $w->orWhere('activity_numbers.number', 'LIKE', $n . '%');
                                }
                            });
                        });
                });
            }

            // ===================== OPTIONAL filter: employee_type_id =====================
            if (!empty($employeeTypeId)) {
                $query->whereHas('person.instructor', function (Builder $q) use ($employeeTypeId) {
                    $q->whereRaw('LOWER(employee_type_id) = ?', [mb_strtolower(trim((string) $employeeTypeId))]);
                });
            }

            // ===================== OPTIONAL filter: status (C / I / A / P) =====================
            $st = strtoupper(trim((string) $status));
            if ($st === 'ALL') $st = 'A';

            // apply Pending AFTER get() (in-memory)
            $applyPendingPostFilter = false;

            if ($st !== '' && $st !== 'A') {
                if ($st === 'C' || $st === 'I') {
                    $query->whereHas('contractState', function (Builder $q) use ($st) {
                        $q->where('action', $st);
                    });
                } elseif ($st === 'P') {
                    $applyPendingPostFilter = true;
                }
            }

            $contracts = $query->get();

            // Pending bucket filter (in-memory, reliable)
            if ($applyPendingPostFilter) {
                $contracts = $contracts
                    ->filter(function (Contract $c) {
                        $name = (string) ($c->contractState?->name ?? '');
                        $n    = mb_strtolower(trim($name));

                        // Pending bucket: before starting approval process / revision / submit
                        return str_contains($n, 'pending')
                            || str_contains($n, 'revision')
                            || str_contains($n, 'ready to submit')
                            || str_contains($n, 'submit');
                    })
                    ->values();
            }

            // ===================== Stable sort =====================
            $contracts = $contracts->sort(function (Contract $a, Contract $b) {
                $pa = $a->person;
                $pb = $b->person;

                $fa = mb_strtolower($pa->first_name ?? '');
                $fb = mb_strtolower($pb->first_name ?? '');
                if ($fa !== $fb) return $fa <=> $fb;

                $la = mb_strtolower($pa->last_name ?? '');
                $lb = mb_strtolower($pb->last_name ?? '');
                if ($la !== $lb) return $la <=> $lb;

                return strcmp((string) $a->id, (string) $b->id);
            })->values();

            // ===================== Caches =====================
            $combinedMapCache = null;
            $workloadCache    = [];

            // program_ids Set for O(1) lookup
            $programIdsSet = !empty($programIds)
                ? array_fill_keys($programIds, true)
                : [];

            $rows = [];

            foreach ($contracts as $c) {
                $person       = $c->person;
                $instructorId = (string) data_get($c, 'person.instructor.id'); // UUID string

                // Instructor name "Last, First"
                $instructorName = trim(implode(' ', array_filter([
                    $person->last_name ?? null,
                    $person->second_last_name ?? null,
                ])));
                if ($instructorName !== '') {
                    $instructorName .= ', ';
                }
                $instructorName .= trim(implode(' ', array_filter([
                    $person->first_name ?? null,
                    $person->middle_name ?? null,
                ])));

                // Department: academic_organizations.name related to the COURSE of the contract
                $deptName =
                    $c->course?->department?->academicOrganization?->name
                    ?? $c->course?->department?->name
                    ?? $c->department?->academicOrganization?->name
                    ?? $c->department?->name
                    ?? null;

                // Employee type
                $type =
                    data_get($c, 'person.instructor.employeeType.code')
                    ?? data_get($c, 'person.instructor.employeeType.name')
                    ?? $c->employee_type
                    ?? null;

                // Dates
                $startDate = $this->fmtDateForReport($c->start_date);
                $endDate   = $this->fmtDateForReport($c->end_date);

                // Contract status
                $contractStatus =
                    $c->contractState?->name
                    ?? $c->contractState?->code
                    ?? null;

                // Parse semester / academicYear (to find the correct Workload)
                [$semesterName, $academicYear] = $this->parseSemesterYear($c);

                // Combined map (once)
                if ($combinedMapCache === null) {
                    $combinedMapCache = $this->buildCombinedSectionBidirectionalMap();
                }

                // Workload aggregated map + cached by instructor/semester/year
                $workloadKey = $instructorId . '|' . ($semesterName ?? 'null') . '|' . ($academicYear ?? 'null');
                if (!isset($workloadCache[$workloadKey])) {
                    $workloadCache[$workloadKey] = $this->loadWorkloadCoursesMap($instructorId, $semesterName, $academicYear);
                }
                $wlBySection = $workloadCache[$workloadKey];

                // Resolve sections
                $sections = $this->resolveSectionsForContract($c, $instructorId, $semesterName, $academicYear, $wlBySection);

                // ===================== OPTIONAL filter: program_ids (SECTION-based) =====================
                if (!empty($programIdsSet)) {
                    $sections = $sections
                        ->filter(function ($sec) use ($programIdsSet) {
                            $pid = strtoupper(trim((string) ($sec->program_id ?? $sec->program?->id ?? '')));
                            if ($pid === '') return false;
                            return isset($programIdsSet[$pid]);
                        })
                        ->values();

                    if ($sections->isEmpty()) {
                        continue;
                    }
                }

                // Contract activities (merge)
                $activities = [];
                foreach (($c->contractActivities ?? []) as $a) {
                    $activities[] = [
                        'activity_number' => data_get($a, 'activityNumber.number'),
                        'amount'          => (string) ($a->amount ?? $c->amount_pay ?? ''),
                    ];
                }
                foreach (($c->contractCompensationDetails ?? []) as $d) {
                    $activities[] = [
                        'activity_number' => data_get($d, 'activityNumber.number'),
                        'amount'          => (string) ($d->amount ?? $d->amount_pay ?? $c->amount_pay ?? ''),
                    ];
                }

                // Sections payload + summaries
                $sectionPayloads   = [];
                $sectionsSummary   = [];
                $referenceSummary  = [];
                $enrollmentSummary = [];
                $cohortSummary     = [];

                foreach ($sections as $sec) {
                    $sectCode = $this->buildSectionDisplay($sec);

                    // Combined (bidirectional)
                    $combinedCodes = $this->resolveCombinedCodes($sec, $combinedMapCache);

                    // Meeting patterns with fallback to contract schedules
                    $meetingPayload = $this->buildMeetingPatternsPayload(
                        $sec,
                        $instructorId,
                        $c->contractSecondaryEmploymentWorkSchedules ?? []
                    );

                    // WorkloadCourse aggregated fields per SECTION_ID
                    $secKey = strtoupper((string) $sec->id);
                    $wcAgg  = $wlBySection[$secKey] ?? null;

                    $valueSum     = $wcAgg ? (float) ($wcAgg['value_sum'] ?? 0) : 0.0;
                    $adjustedSum  = $wcAgg ? (float) ($wcAgg['adjusted_sum'] ?? 0) : 0.0;
                    $overloadFlag = $wcAgg ? (int) ($wcAgg['overload'] ?? 0) : 0;
                    $onContractF  = $wcAgg ? (int) ($wcAgg['on_contract'] ?? 0) : 0;

                    $value    = $wcAgg ? (string) $valueSum : null;
                    $adjusted = (string) $adjustedSum;

                    // overload_value = SUM(value) if overload=1
                    $overloadValue = ($overloadFlag === 1) ? (string) $valueSum : null;

                    // on_contract as Y/N (keep front stable)
                    $onContract = ($onContractF === 1) ? 'Y' : 'N';

                    $sectionPayloads[] = [
                        'section_id'         => (string) $sec->id,
                        'reference_number'   => $sec->references_number_panther ?? null,
                        'enrollment'         => $sec->student_enrollment ?? null,
                        'cohort'             => $sec->cohorts ?? '',
                        'course'             => $sec->course?->code ?? null,
                        'course_name'        => $sec->course?->name ?? null,
                        'section'            => $sectCode,
                        'combined'           => $combinedCodes,
                        'cap'                => $sec->cap ?? null,
                        'program'            => $sec->program?->code ?? $sec->program?->name ?? null,
                        'instructional_mode' => $sec->instructorMode?->code ?? $sec->instructorMode?->name ?? null,
                        'value'          => $value,
                        'overload'       => $overloadFlag,
                        'overload_value' => $overloadValue,
                        'adjusted'       => $adjusted,
                        'on_contract'    => $onContract,
                        'time'                  => $meetingPayload['meeting_patterns_text'],
                        'meeting_patterns'      => $meetingPayload['meeting_patterns'],
                        'meeting_patterns_text' => $meetingPayload['meeting_patterns_text'],
                        'schedule_source'       => $meetingPayload['schedule_source'],
                    ];

                    $sectionsSummary[] = $sectCode;

                    if (!empty($sec->references_number_panther)) {
                        $referenceSummary[] = $sec->references_number_panther;
                    }

                    if ($sec->student_enrollment !== null && $sec->student_enrollment !== '') {
                        $enrollmentSummary[] = (string) $sec->student_enrollment;
                    }

                    if (!empty($sec->cohorts)) {
                        $cohortSummary[] = (string) $sec->cohorts;
                    }
                }

                $rows[] = [
                    'contract_id' => (string) $c->id,
                    'person_id'   => (string) $c->person_id,
                    'course_id'   => $c->course_id ? (string) $c->course_id : null,
                    'term_id'     => (string) $c->term_id,
                    'semester' => trim(($c->term?->semester ?? '') . ' ' . ($c->term?->year ?? $c->term?->academic_year ?? '')),
                    'instructor' => $instructorName,
                    'panther_id' => $person?->panther_id,
                    'type'       => $type,
                    'department' => $deptName,
                    'start_date' => $startDate,
                    'end_date'   => $endDate,
                    'contract_status'             => $contractStatus,
                    'erac_number'                 => $c->erac_number,
                    'contract_number'             => $c->contract_number,
                    'superseding_contract_number' => $c->superseding_contract_number,
                    'superseding_contract_enrollment' => $c->superseding_contract_enrollment,
                    'superseding_contract_amount'=> $c->superseding_contract_amount,
                    'lump_sum'=> $c->lump_sum,
                    'sections'   => $sectionPayloads,
                    'activities' => $activities,
                    'sections_summary'          => implode(' | ', array_values(array_filter($sectionsSummary))),
                    'reference_numbers_summary' => implode(' | ', array_values(array_unique(array_filter($referenceSummary)))),
                    // NOTE: array_filter removes "0"
                    'enrollment_summary'        => implode(' | ', array_values(array_unique(array_filter($enrollmentSummary)))),
                    'cohort_summary'            => implode(' | ', array_values(array_unique(array_filter($cohortSummary)))),
                ];
            }

            return [
                // plus extra filters from this report (doesn't break consumers that ignore unknown keys).
                'filters' => [
                    'term_ids'         => $termIds,
                    'department_id'    => $departmentId,
                    'employee_id'      => $employeeId,
                    'activity_numbers' => $numbers,

                    // extras (status report)
                    'employee_type_id' => $employeeTypeId,
                    'program_ids'      => $programIds,
                    'status'           => $status,
                ],
                'count' => count($rows),
                'rows'  => $rows,
            ];
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('hr/contract.error_fetching_data'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Build the section code displayed in UI: sec_code + sec_number + sec_sess
     */
    private function buildSectionDisplay(Section $sec): string
    {
        $code = (string) ($sec->sec_code ?? '');
        $num  = (string) ($sec->sec_number ?? '');
        $sess = (string) ($sec->sec_sess ?? '');

        $out = $code . $num;
        if ($sess !== '' && $sess !== '0') {
            $out .= $sess;
        }

        return trim($out);
    }

    /**
     * Parse semester/year from term label (used by workloads).
     * Returns: [semesterName|null, year|null]
     */
    private function parseSemesterYear(Contract $c): array
    {
        $semester = $c->term?->semester ? ucfirst(strtolower((string) $c->term->semester)) : null;
        $academicYear = $c->term?->academic_year ? (string) $c->term->academic_year : null;

        // If there is no academic_year, use the numeric year of the term
        if (!$academicYear && $c->term?->year) {
            $academicYear = (string) $c->term->year;
        }

        $label = (string) (
            $c->term?->name
            ?? $c->term?->term_name
            ?? $c->term?->code
            ?? ''
        );

        if (!$semester && preg_match('/(?:^|\s)(Spring|Summer|Fall|Winter)(?:\s|$)/i', $label, $m)) {
            $semester = ucfirst(strtolower($m[1]));
        }

        if (!$academicYear && preg_match('/(20\d{2}(?:\s*-\s*20\d{2})?)/', $label, $m)) {
            $academicYear = preg_replace('/\s+/', '', $m[1]); // "2025 - 2026" -> "2025-2026"
        }

        return [$semester, $academicYear];
    }

    private function fmtDateForReport($v): ?string
    {
        if (!$v) return null;

        try {
            return Carbon::parse($v)->format('m/d/y');
        } catch (\Throwable $e) {
            return substr((string) $v, 0, 10);
        }
    }

    private function normTime($t): ?string
    {
        if (!$t) return null;

        $s = trim((string) $t);
        if ($s === '') return null;

        // 14:00:00.0000000 -> 14:00
        if (preg_match('/^\d{1,2}:\d{2}/', $s)) {
            return substr($s, 0, 5);
        }

        // 1400 -> 14:00
        if (preg_match('/^\d{3,4}$/', $s)) {
            $s = str_pad($s, 4, '0', STR_PAD_LEFT);
            return substr($s, 0, 2) . ':' . substr($s, 2, 2);
        }

        return $s;
    }


    private function dayAbbrev(?string $day): ?string
    {
        if (!$day) return null;
        $d = trim($day);
        if ($d === '') return null;

        $map = [
            'MONDAY'    => 'M',
            'TUESDAY'   => 'T',
            'WEDNESDAY' => 'W',
            'THURSDAY'  => 'R',
            'FRIDAY'    => 'F',
            'SATURDAY'  => 'S',
            'SUNDAY'    => 'U',
        ];

        $k = strtoupper($d);
        if (isset($map[$k])) return $map[$k];

        // already like "M"
        if (preg_match('/^[A-Z]$/', $k)) return $k;

        return strtoupper(substr($k, 0, 1));
    }

    /**
     * Meeting patterns:
     * - Prefer ac.meeting_patterns for the instructor, else any patterns on section.
     * - If none, fallback to ac.meeting_pattern_hybrids (same logic).
     * Returns meeting_patterns + meeting_patterns_text + schedule_source
     */
    private function buildMeetingPatternsPayload(Section $section, ?string $instructorId, $fallbackSchedules = null): array
    {
        $patterns = collect($section->meetingPatterns ?? []);
        $hybrids  = collect($section->meetingPatternHybrids ?? []);

        // Prefer filtering by instructor
        $patternsForInstructor = $instructorId ? $patterns->where('instructor_id', $instructorId)->values() : collect();
        $hybridsForInstructor  = $instructorId ? $hybrids->where('instructor_id', $instructorId)->values() : collect();

        $source = null;
        $items  = collect();

        if ($patternsForInstructor->isNotEmpty()) {
            $source = 'meeting_patterns.filtered';
            $items = $patternsForInstructor->map(function ($p) {
                $from = $this->normTime($p->start_time ?? null);
                $to   = $this->normTime($p->end_time ?? null);
                $day  = $this->dayAbbrev($p->day ?? null);

                return [
                    'day'  => $day,
                    'from' => $from,
                    'to'   => $to,
                    'time' => ($from && $to) ? ($from . '-' . $to) : null,
                ];
            });
        } elseif ($patterns->isNotEmpty()) {
            $source = 'meeting_patterns.all';
            $items = $patterns->map(function ($p) {
                $from = $this->normTime($p->start_time ?? null);
                $to   = $this->normTime($p->end_time ?? null);
                $day  = $this->dayAbbrev($p->day ?? null);

                return [
                    'day'  => $day,
                    'from' => $from,
                    'to'   => $to,
                    'time' => ($from && $to) ? ($from . '-' . $to) : null,
                ];
            });
        } elseif ($hybridsForInstructor->isNotEmpty()) {
            $source = 'meeting_pattern_hybrids.filtered';
            $items = $hybridsForInstructor->map(function ($h) {
                $from = $this->normTime($h->start_time ?? null);
                $to   = $this->normTime($h->end_time ?? null);
                $day  = $this->dayAbbrev($h->day ?? null);

                return [
                    'day'  => $day,
                    'from' => $from,
                    'to'   => $to,
                    'time' => ($from && $to) ? ($from . '-' . $to) : null,
                ];
            });
        } elseif ($hybrids->isNotEmpty()) {
            $source = 'meeting_pattern_hybrids.all';
            $items = $hybrids->map(function ($h) {
                $from = $this->normTime($h->start_time ?? null);
                $to   = $this->normTime($h->end_time ?? null);
                $day  = $this->dayAbbrev($h->day ?? null);

                return [
                    'day'  => $day,
                    'from' => $from,
                    'to'   => $to,
                    'time' => ($from && $to) ? ($from . '-' . $to) : null,
                ];
            });
        } else {
            // Fallback: hr.contract_secondary_employment_work_schedules
            $fallback = collect($fallbackSchedules ?? []);
            if ($fallback->isNotEmpty()) {
                $source = 'contract_secondary_employment_work_schedules';
                $items = $fallback->map(function ($s) {
                    $from = $this->normTime($s->from ?? null);
                    $to   = $this->normTime($s->to ?? null);
                    $day  = $this->dayAbbrev($s->day ?? null);

                    return [
                        'day'  => $day,
                        'from' => $from,
                        'to'   => $to,
                        'time' => ($from && $to) ? ($from . '-' . $to) : null,
                    ];
                });
            }
        }

        $items = $items
            ->filter(fn ($x) => !empty($x['day']) || !empty($x['time']))
            ->unique(fn ($x) => ($x['day'] ?? '') . '|' . ($x['time'] ?? ''))
            ->values();

        $text = $items
            ->map(fn ($x) => trim(implode(' ', array_filter([$x['day'] ?? null, $x['time'] ?? null]))))
            ->filter()
            ->implode(' | ');

        return [
            'meeting_patterns'      => $items->all(),
            'meeting_patterns_text' => $text !== '' ? $text : null,
            'schedule_source'       => $source,
        ];
    }
    /**
     * Build a bidirectional combined-sections map:
     * - Excludes self-links (section_id == section_id_combined)
     * - Maps both directions so UI can show main<->child
     * Returns: array<section_id, array<other_section_id => true>>
     */
    private function buildCombinedSectionBidirectionalMap(): array
    {
        $rows = CombinedSection::query()
            ->select(['section_id', 'section_id_combined'])
            ->get();

        $map = [];

        foreach ($rows as $r) {
            $a = (string) $r->section_id;
            $b = (string) $r->section_id_combined;

            if ($a === '' || $b === '') continue;
            if (strcasecmp($a, $b) === 0) continue; // prevent self-combined

            $map[$a][$b] = true;
            $map[$b][$a] = true;
        }

        return $map;
    }

    private function resolveCombinedCodes(Section $sec, array $combinedMap): ?string
    {
        $id = (string) $sec->id;
        if (!isset($combinedMap[$id])) return null;

        $otherIds = array_keys($combinedMap[$id]);
        if (empty($otherIds)) return null;

        $others = Section::query()
            ->select(['id', 'sec_code', 'sec_number', 'sec_sess'])
            ->whereIn('id', $otherIds)
            ->get()
            ->map(fn (Section $s) => $this->buildSectionDisplay($s))
            ->filter()
            ->unique()
            ->values()
            ->all();

        if (empty($others)) return null;

        return implode(', ', $others);
    }

    /**
     * Load workload_courses for this instructor+semester+year and return map by section_id.
     */
    private function loadWorkloadCoursesMap(string $instructorId, ?string $semesterName, ?string $academicYear): array
    {
        if ($instructorId === '') return [];

        $base = Workload::query()
            ->with(['workLoadCourses'])
            ->where('instructor_id', $instructorId);

        $candidates = [];

        // 1) semester + academic_year
        if (!empty($semesterName) && !empty($academicYear)) {
            $candidates[] = (clone $base)
                ->where('semester', $semesterName)
                ->where('academic_year', $academicYear);
        }

        // 2) only academic_year
        if (!empty($academicYear)) {
            $candidates[] = (clone $base)
                ->where('academic_year', $academicYear);
        }

        // 3) only semester
        if (!empty($semesterName)) {
            $candidates[] = (clone $base)
                ->where('semester', $semesterName);
        }

        // 4) Fallback: Any (per instructor)
        $candidates[] = (clone $base);

        $wl = null;
        foreach ($candidates as $q) {
            $wl = $q->orderByDesc('created_at')->first();
            if ($wl) break;
        }

        if (!$wl) return [];

        // section_id => aggregated data
        $map = [];

        foreach (($wl->workLoadCourses ?? []) as $wc) {
            if (empty($wc->section_id)) continue;

            $sid = strtoupper((string) $wc->section_id);

            if (!isset($map[$sid])) {
                $map[$sid] = [
                    'value_sum'    => 0.0,
                    'adjusted_sum' => 0.0,
                    'overload'     => 0,
                    'on_contract'  => 0,
                ];
            }

            $map[$sid]['value_sum']    += (float) ($wc->value ?? 0);
            $map[$sid]['adjusted_sum'] += (float) ($wc->adjusted ?? 0);
            $map[$sid]['overload']      = max($map[$sid]['overload'], (int) ((bool) ($wc->overload ?? false)));
            $map[$sid]['on_contract']   = max($map[$sid]['on_contract'], (int) ((bool) ($wc->on_contract ?? false)));
        }

        return $map;
    }
    /**
     * Resolve sections for the contract:
     * - If contract.course_id exists: sections in that term/course (filtered by instructor when possible)
     * - Else: sections from workload_courses map (so one contract can show many courses/sections)
     */
    private function resolveSectionsForContract(Contract $c, string $instructorId, ?string $semesterName, ?string $year, array $wlBySection): Collection
    {
        $termId   = (string) $c->term_id;
        $courseId = $c->course_id ? (string) $c->course_id : null;

        if ($courseId) {
            $q = Section::query()
                ->with([
                    'course',
                    'program',
                    'instructorMode',
                    'meetingPatterns',
                    'meetingPatternHybrids',
                ])
                ->where('term_id', $termId)
                ->where('course_id', $courseId);

            // Prefer sections that actually belong to this instructor (schedule/workload)
            if (!empty($instructorId)) {
                $q->where(function (Builder $w) use ($instructorId, $semesterName, $year) {
                    $w->whereHas('meetingPatterns', fn (Builder $mp) => $mp->where('instructor_id', $instructorId))
                        ->orWhereHas('meetingPatternHybrids', fn (Builder $mh) => $mh->where('instructor_id', $instructorId))
                        ->orWhereHas('workloadCourses.workload', function (Builder $wl) use ($instructorId, $semesterName, $year) {
                            $wl->where('instructor_id', $instructorId);
                            if (!empty($semesterName)) $wl->where('semester', $semesterName);
                            if (!empty($year)) $wl->where('academic_year', $year);
                        });
                });
            }

            return $q->get();
        }

        // No course_id on contract => take all section_ids from workload_courses
        $sectionIds = array_keys($wlBySection);
        if (empty($sectionIds)) {
            return collect();
        }

        return Section::query()
            ->with([
                'course',
                'program',
                'instructorMode',
                'meetingPatterns',
                'meetingPatternHybrids',
            ])
            ->where('term_id', $termId)
            ->whereIn('id', $sectionIds)
            ->get();
    }

}
