<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\EmployeeClassification;
use App\Exceptions\ResourceNotFoundException;

class EmployeeClassificationRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $employeeClassification = EmployeeClassification::orderBy('name', 'desc')->get();
            if ($employeeClassification->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/employee_classifications.exceptionNotFound'));
            }
            return $employeeClassification;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $employeeClassification= EmployeeClassification::where('active', $status)->orderBy('name','desc')->get();
            if ($employeeClassification->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/employee_classifications.exceptionNotFoundByStatus'));
            }
            return $employeeClassification;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $employeeClassification = new EmployeeClassification();
            $newEmployeeClassification = $this->dataFormat($request,$employeeClassification);
            $newEmployeeClassification->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployeeClassification->id,
                'created',
                'Employee classification',
                'A new type of Employee classification was created: ' . $newEmployeeClassification->name,
            );

            return $newEmployeeClassification;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $employeeClassification = EmployeeClassification::find($id);
            if (!$employeeClassification){
                throw new ResourceNotFoundException(trans('hr/employee_classifications.exceptionNotFoundById'));
            }
            $newEmployeeClassification = $this->dataFormat($request,$employeeClassification);
            $newEmployeeClassification->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployeeClassification->id,
                'updated',
                'Employee classification',
                'Employee classification was updated: ' . $newEmployeeClassification->name,
            );

            return $newEmployeeClassification;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, EmployeeClassification $employeeClassification):object|null
    {
        try {
            $employeeClassification->name = $request['name'];
            $employeeClassification->active = $request['active'];
            return $employeeClassification;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
