<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\PersonOrganizationRelationshipType;

class PersonOrganizationRelationshipTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $person = PersonOrganizationRelationshipType::orderBy('name', 'desc')->get();
            if ($person->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/person_org_rel_type.exceptionNotFound'));
            }
            return $person;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $person = PersonOrganizationRelationshipType::where('active', $status)->orderBy('name', 'desc')->get();
            if ($person->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/person_org_rel_type.exceptionNotFoundByStatus'));
            }
            return $person;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $person = new PersonOrganizationRelationshipType();
            $newPerson = $this->dataFormat($request, $person);
            $newPerson->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPerson->id,
                'created',
                'Person organization relationship type',
                'A new type of Person organization relationship type was created: ' . $newPerson->name,
            );

            return $newPerson;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $person = PersonOrganizationRelationshipType::find($id);
            if (!$person) {
                throw new ResourceNotFoundException(trans('hr/person_org_rel_type.exceptionNotFoundById'));
            }
            $newPerson = $this->dataFormat($request, $person);
            $newPerson->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPerson->id,
                'updated',
                'Person organization relationship type',
                'A new type of Person organization relationship type was updated: ' . $newPerson->name,
            );

            return $newPerson;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, PersonOrganizationRelationshipType $person): object|null
    {
        try {
            $person->name = $request['name'];
            $person->code = $request['code'];
            $person->active = $request['active'];
            return $person;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
