<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\VisaType;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
class VisaTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $vt = VisaType::orderBy('name', 'desc')->get();
            if ($vt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/visa_type.exceptionNotFound'));
            }
            return $vt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $vt= VisaType::where('active', $status)->orderBy('name','desc')->get();
            if ($vt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/visa_type.exceptionNotFoundByStatus'));
            }
            return $vt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $vt = new VisaType();
            $newVt = $this->dataFormat($request,$vt);
            $newVt->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newVt->id,
                'created',
                'Visa type',
                'A new type of Visa type was created: ' . $newVt->name,
            );

            return $newVt;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $vt = VisaType::find($id);
            if (!$vt){
                throw new ResourceNotFoundException(trans('hr/visa_type.exceptionNotFoundById'));
            }
            $newVt = $this->dataFormat($request,$vt);
            $newVt->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newVt->id,
                'updated',
                'Visa type',
                'Visa type was updated: ' . $newVt->name,
            );

            return $newVt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, VisaType $vt):object|null
    {
        try {
            $vt->name = $request['name'];
            $vt->type_desc = $request['type_desc'];
            $vt->active = $request['active'];
            return $vt;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}

