<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Action;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class ActionRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $action = Action::orderBy('name', 'desc')->get();
            if ($action->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/action.exceptionNotFound'));
            }
            return $action;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $action= Action::where('active', $status)->orderBy('name','desc')->get();
            if ($action->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/action.exceptionNotFoundByStatus'));
            }
            return $action;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $action = new Action();
            $newAction = $this->dataFormat($request,$action);
            $newAction->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAction->id,
                'created',
                'Action',
                'A new type of Action was created: ' . $newAction->name,
            );

            return $newAction;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $action = Action::find($id);
            if (!$action){
                throw new ResourceNotFoundException(trans('hr/action.exceptionNotFoundById'));
            }
            $newAction = $this->dataFormat($request,$action);
            $newAction->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAction->id,
                'updated',
                'Action',
                'Action was updated: ' . $newAction->name,
            );

            return $newAction;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Action $action):object|null
    {
        try {
            $action->name = $request['name'];
            $action->job_status = $request['job_status'];
            $action->active = $request['active'];
            return $action;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
