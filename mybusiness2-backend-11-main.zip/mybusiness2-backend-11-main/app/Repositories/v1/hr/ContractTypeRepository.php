<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//Local Imports
use App\Models\hr\ContractType;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Interfaces\ViewByIdInterface;
use App\Exceptions\ResourceNotFoundException;


class ContractTypeRepository implements ActiveInterface, UpdateInterface, ViewAllInterface, CreateInterface, ViewByIdInterface
{

    /**
     * @throws Exception
     * */
    public function viewAll()
    {
        try{
        $contractTypes = ContractType::orderBy('name')->get();
        if (!$contractTypes){
            throw new ResourceNotFoundException(trans('hr/contract_type.exceptionNotFound'));
        }
        return $contractTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewById($id)
    {
        try
        {
            $contractType = ContractType::find($id);
            if (!$contractType){
                throw new ResourceNotFoundException(trans('hr/contract_type.exceptionNotFoundById'));
            }
            return $contractType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try
        {
            $contractTypes = ContractType::where('active', '=', $status)->get();
            if (!$contractTypes){
                throw new ResourceNotFoundException(trans('hr/contract_type.exceptionNotFoundByStatus'));
            }
            return $contractTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request):object|null|array
    {
        try
        {
            $contractType = new ContractType();
            $newContractType = $this->dataFormat($request, $contractType);
            $newContractType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractType->id,
                'created',
                'Contract type',
                'A new type of Contract type was created: ' . $newContractType->name,
            );

            return $newContractType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request):object|null|array
    {
        try
        {
            $contractType = ContractType::find($id);
            if (!$contractType){
                throw new ResourceNotFoundException(trans('hr/contract_type.exceptionNotFoundById'));
            }
            $newContractType = $this->dataFormat($request, $contractType);
            $newContractType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractType->id,
                'updated',
                'Contract type',
                'Contract type was updated: ' . $newContractType->name,
            );

            return $newContractType;
        }  catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat($data, ContractType $contractType): ContractType
    {
        try {
            $contractType->name = $data['name'];
            $contractType->description = $data['description'];
            $contractType->teaching_duties = $data['teaching_duties'];
            $contractType->teaching_credit_courses = $data['teaching_credit_courses'];
            $contractType->contract_type_level = $data['contract_type_level'];
            $contractType->sec_employee_type_level = $data['sec_employee_type_level'];
            $contractType->active = $data['active'];
            return $contractType;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
