<?php

namespace App\Repositories\v1\hr;

// Global Imports
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// Helpers
use App\Helpers\ActivityTimeLineHelper;

// Local Imports
use App\Models\hr\EmployeeDirectory;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Interfaces\ViewByIdInterface;
use App\Exceptions\ResourceNotFoundException;

class EmployeeDirectoryRepository implements ViewAllInterface, ViewByIdInterface, CreateInterface, UpdateInterface
{
    /**
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $directories = EmployeeDirectory::with(['persons', 'teams.teamType'])
                ->orderBy('start_date', 'desc')
                ->get();

            if ($directories->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_directory.exceptionNotFound'));
            }

            return $directories;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw $e;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException|Exception
     */
    public function viewById($id)
    {
        try {
            $directory = EmployeeDirectory::with(['persons', 'teams.teamType'])->find($id);

            if (!$directory) {
                throw new ResourceNotFoundException(trans('hr/employee_directory.exceptionNotFoundById'));
            }

            return $directory;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw $e;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $directory = new EmployeeDirectory();
            $newDirectory = $this->dataFormat($request, $directory);
            $newDirectory->save();

            ActivityTimeLineHelper::store(
                $newDirectory->id,
                'created',
                'Employee Directory',
                'A new employee directory record was created for person ID: ' . $newDirectory->person_id,
            );

            return $newDirectory;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
            //throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException|Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $directory = EmployeeDirectory::find($id);

            if (!$directory) {
                throw new ResourceNotFoundException(trans('hr/employee_directory.exceptionNotFoundById'));
            }

            $updatedDirectory = $this->dataFormat($request, $directory);
            $updatedDirectory->save();

            ActivityTimeLineHelper::store(
                $updatedDirectory->id,
                'updated',
                'Employee Directory',
                'Employee directory record updated for person ID: ' . $updatedDirectory->person_id,
            );

            return $updatedDirectory;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw $e;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): bool
    {
        try {
            $record = EmployeeDirectory::find($id);

            if (!$record) {
                throw new ResourceNotFoundException(trans('hr/employee_directory.exceptionNotFoundById'));
            }

            $record->delete();

            // Optionally store in activity timeline
            ActivityTimeLineHelper::store(
                $id,
                'deleted',
                'Employee Directory',
                'Employee Directory record was deleted.'
            );

            return true;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }


    /**
     * Formats and fills the model attributes.
     *
     * @throws Exception
     */
    private function dataFormat($data, EmployeeDirectory $directory): EmployeeDirectory
    {
        try {
            $directory->person_id   = $data['person_id'] ?? $directory->person_id;
            $directory->team_id     = $data['team_id'] ?? $directory->team_id;
            $directory->appearance  = $data['appearance'] ?? $directory->appearance;
            $directory->role        = $data['role'] ?? $directory->role;
            $directory->locked      = $data['locked'] ?? $directory->locked ?? false;
            $directory->start_date  = $data['start_date'] ?? $directory->start_date;
            $directory->end_date    = $data['end_date'] ?? $directory->end_date;

            return $directory;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
