<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\EmployeeResponsibilityAssignment;

class EmployeeResponsibilityAssignmentRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $employee = EmployeeResponsibilityAssignment::orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_responsibility_assignment.not_found'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $employee = EmployeeResponsibilityAssignment::where('active', $status)->orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_responsibility_assignment.status'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $employee = new EmployeeResponsibilityAssignment();
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'created',
                'Employee RA',
                'A new type of Employee RA was created: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $employee = EmployeeResponsibilityAssignment::find($id);
            if (!$employee) {
                throw new ResourceNotFoundException(trans('hr/employee_responsibility_assignment.id'));
            }
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'updated',
                'Employee RA',
                'Employee RA was updated: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, EmployeeResponsibilityAssignment $employee): object|null
    {
        try {
            $employee->code = $request['code'];
            $employee->name = $request['name'];
            $employee->active = $request['active'];
            return $employee;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}

