<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\PayGroup;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class PayGroupRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $payGroup = PayGroup::orderBy('name', 'desc')->get();
            if ($payGroup->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/pay_group.exceptionNotFound'));
            }
            return $payGroup;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $payGroup = PayGroup::where('active', $status)->orderBy('name', 'desc')->get();
            if ($payGroup->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/pay_group.exceptionNotFoundByStatus'));
            }
            return $payGroup;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $payGroup = new PayGroup();
            $newPayGroup = $this->dataFormat($request, $payGroup);
            $newPayGroup->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPayGroup->id,
                'created',
                'Pay group',
                'A new type of Pay group was created: ' . $newPayGroup->name,
            );

            return $newPayGroup;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $payGroup = PayGroup::find($id);
            if (!$payGroup) {
                throw new ResourceNotFoundException(trans('hr/pay_group.exceptionNotFoundById'));
            }
            $newPayGroup = $this->dataFormat($request, $payGroup);
            $newPayGroup->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPayGroup->id,
                'updated',
                'Pay group',
                'Pay group was updated: ' . $newPayGroup->name,
            );

            return $newPayGroup;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, PayGroup $payGroup): object|null
    {
        try {
            $payGroup->name = $request['name'];
            $payGroup->code = $request['code'];
            $payGroup->active = $request['active'];
            return $payGroup;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
