<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\JobTitleClassification;
use App\Exceptions\ResourceNotFoundException;

class JobTitleClassificationRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $jobTitle = JobTitleClassification::orderBy('name', 'desc')->get();
            if ($jobTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/job_title_classification.exceptionNotFound'));
            }
            return $jobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $jobTitle= JobTitleClassification::where('active', $status)->orderBy('name','desc')->get();
            if ($jobTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/job_title_classification.exceptionNotFoundByStatus'));
            }
            return $jobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $jobTitle = new JobTitleClassification();
            $newJobTitle = $this->dataFormat($request,$jobTitle);
            $newJobTitle->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newJobTitle->id,
                'created',
                'Job title classification',
                'A new type of Job title classification was created: ' . $newJobTitle->name,
            );

            return $newJobTitle;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $jobTitle = JobTitleClassification::find($id);
            if (!$jobTitle){
                throw new ResourceNotFoundException(trans('hr/job_title_classification.exceptionNotFoundById'));
            }
            $newJobTitle = $this->dataFormat($request,$jobTitle);
            $newJobTitle->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newJobTitle->id,
                'updated',
                'Job title classification',
                'Job title classification was updated: ' . $newJobTitle->name,
            );

            return $newJobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, JobTitleClassification $jobTitle):object|null
    {
        try {
            $jobTitle->name = $request['name'];
            $jobTitle->active = $request['active'];
            return $jobTitle;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }
}
