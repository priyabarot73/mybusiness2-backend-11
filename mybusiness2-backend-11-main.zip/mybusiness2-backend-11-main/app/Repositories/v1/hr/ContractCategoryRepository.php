<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\ContractCategory;
use App\Exceptions\ResourceNotFoundException;

class ContractCategoryRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $contractCategories = ContractCategory::orderBy('name', 'asc')->get();
            if ($contractCategories->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_category.exceptionNotFound'));
            }
            return $contractCategories;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $contractCategories = ContractCategory::where('active', $status)->orderBy('name', 'asc')->get();
            if ($contractCategories->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_category.exceptionNotFoundByStatus'));
            }
            return $contractCategories;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $contractCategory = new ContractCategory();
            $newContractCategory = $this->dataFormat($request, $contractCategory);
            $newContractCategory->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractCategory->id,
                'created',
                'Contract category',
                'A new type of Contract category was created: ' . $newContractCategory->name,
            );

            return $newContractCategory;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $contractCategory = ContractCategory::find($id);
            if (!$contractCategory) {
                throw new ResourceNotFoundException(trans('hr/contract_category.exceptionNotFoundById'));
            }
            $newContractCategory = $this->dataFormat($request, $contractCategory);
            $newContractCategory->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractCategory->id,
                'updated',
                'Contract category',
                'Contract category was updated: ' . $newContractCategory->name,
            );

            return $newContractCategory;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ContractCategory $contractCategory): object|null
    {
        try {
            $contractCategory->name = $request['name'];
            $contractCategory->description = $request['description'];
            $contractCategory->active = $request['active'];
            return $contractCategory;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }
}
