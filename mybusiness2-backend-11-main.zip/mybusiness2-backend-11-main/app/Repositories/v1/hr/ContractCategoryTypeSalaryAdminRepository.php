<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\ContractCategoryTypeSalaryAdmin;

class ContractCategoryTypeSalaryAdminRepository implements ViewAllInterface, CreateInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $contract = ContractCategoryTypeSalaryAdmin::with(['contractCategory','contractType','salaryAdminPlant'])->get();
            if ($contract->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_category_type_salary_admin.exceptionNotFound'));
            }
            return $contract;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByContractCategoryId(string $id): array
    {
        try {
            // Filter records by contract_category_id and load relationships
            $contracts = ContractCategoryTypeSalaryAdmin::with(['contractType', 'salaryAdminPlant'])
                ->where('contract_category_id', $id)
                ->get();

            if ($contracts->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_category_type_salary_admin.exceptionNotFound'));
            }

            // Get the unique salaryAdminPlant and contractType objects
            $salaryAdminPlans = $contracts->map(fn($contract) => $contract->salaryAdminPlant)
                ->filter()
                ->unique('id')
                ->values();

            $contractTypes = $contracts->map(fn($contract) => $contract->contractType)
                ->filter()
                ->unique('id')
                ->values();

            return [
                'salary_admin_plans' => $salaryAdminPlans,
                'contract_types' => $contractTypes,
            ];
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $contract = new ContractCategoryTypeSalaryAdmin();
            $newContract = $this->dataFormat($request, $contract);
            $newContract->save();

            return $newContract;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $contract = ContractCategoryTypeSalaryAdmin::find($id);
            if (!$contract) {
                throw new ResourceNotFoundException(trans('hr/contract_category_type_salary_admin.exceptionNotFoundById'));
            }
            $newContract = $this->dataFormat($request, $contract);
            $newContract->update();

            return $newContract;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ContractCategoryTypeSalaryAdmin $contract): object|null
    {
        try {
            $contract->contract_category_id = $request['contract_category_id'];
            $contract->contract_type_id = $request['contract_type_id'];
            $contract->salary_admin_plan_id = $request['salary_admin_plan_id'];
            return $contract;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
