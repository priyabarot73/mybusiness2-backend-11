<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Question;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class QuestionRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $questions = Question::orderBy('text', 'asc')->get();
            if ($questions->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/question.exceptionNotFound'));
            }
            return $questions;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $questions= Question::where('active', $status)->orderBy('text','asc')->get();
            if ($questions->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/question.exceptionNotFoundByStatus'));
            }
            return $questions;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $question = new Question();
            $newQuestion = $this->dataFormat($request,$question);
            $newQuestion->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newQuestion->id,
                'created',
                'Question',
                'A new type of Question was created: ' . $newQuestion->text,
            );

            return $newQuestion;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $question = Question::find($id);
            if (!$question){
                throw new ResourceNotFoundException(trans('hr/question.exceptionNotFoundById'));
            }
            $newQuestion = $this->dataFormat($request,$question);
            $newQuestion->update();

            ActivityTimeLineHelper::store(
                $newQuestion->id,
                'updated',
                'Question',
                'Question was updated: ' . $newQuestion->text,
            );

            return $newQuestion;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Question $action):object|null
    {
        try {
            $action->text = $request['text'];
            $action->active = $request['active'];
            return $action;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }

}
