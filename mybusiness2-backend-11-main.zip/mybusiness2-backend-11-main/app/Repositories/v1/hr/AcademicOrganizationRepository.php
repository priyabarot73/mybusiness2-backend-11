<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\AcademicOrganization;
use App\Exceptions\ResourceNotFoundException;

class AcademicOrganizationRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $academic = AcademicOrganization::orderBy('name', 'desc')->get();
            if ($academic->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/academic_organization.not_found'));
            }
            return $academic;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $academic= AcademicOrganization::where('active', $status)->orderBy('name','desc')->get();
            if ($academic->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/academic_organization.status'));
            }
            return $academic;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $academic = new AcademicOrganization();
            $newAcademic = $this->dataFormat($request,$academic);
            $newAcademic->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAcademic->id,
                'created',
                'Academic Organization',
                'A new type of Academic Organization was created: ' . $newAcademic->name,
            );

            return $newAcademic;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $academic = AcademicOrganization::find($id);
            if (!$academic){
                throw new ResourceNotFoundException(trans('hr/academic_organization.id'));
            }
            $newAcademic = $this->dataFormat($request,$academic);
            $newAcademic->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAcademic->id,
                'updated',
                'Academic Organization',
                'Academic Organization was updated: ' . $newAcademic->name,
            );

            return $newAcademic;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, AcademicOrganization $academic):object|null
    {
        try {
            $academic->name = $request['name'];
            $academic->description = $request['description'];
            $academic->active = $request['active'];
            return $academic;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}




