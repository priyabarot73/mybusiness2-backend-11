<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\GenerationalTitle;
use App\Exceptions\ResourceNotFoundException;
class GenerationalTitleRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $gt = GenerationalTitle::orderBy('name', 'desc')->get();
            if ($gt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/generational_title.exceptionNotFoundGT'));
            }
            return $gt;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $gt= GenerationalTitle::where('active', $status)->orderBy('name','desc')->get();
            if ($gt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/generational_title.exceptionNotFoundByStatus'));
            }
            return $gt;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $gt = new GenerationalTitle();
            $newGT = $this->dataFormat($request,$gt);
            $newGT->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newGT->id,
                'created',
                'Generational title',
                'A new type of Generational title was created: ' . $newGT->name,
            );

            return $newGT;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $gt = GenerationalTitle::find($id);
            if (!$gt){
                throw new ResourceNotFoundException(trans('hr/generational_title.exceptionNotFoundById'));
            }
            $newGT = $this->dataFormat($request,$gt);
            $newGT->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newGT->id,
                'updated',
                'Generational title',
                'Generational title was updated: ' . $newGT->name,
            );

            return $newGT;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, GenerationalTitle $gt):object|null
    {
        try {
            $gt->name = $request['name'];
            $gt->active = $request['active'];
            return $gt;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
