<?php

namespace App\Repositories\v1\hr;

// global import
use App\Models\Role;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

// local import
use App\Models\hr\ContractRoleStatus;
use App\Exceptions\ResourceNotFoundException;

class ContractRoleStatusRepository
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $contracts = ContractRoleStatus::with('role', 'contractState')->get();

            if ($contracts->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_role_status.exceptionNotFound'));
            }

            // Group by role_id
            $grouped = $contracts->groupBy('role_id')->map(function ($items) {
                $role = $items->first()->role;
                $firstItem = $items->first();

                return [
                    'role' => $role,
                    'states' => $items->map(function ($item) {
                        return $item->contractState;
                    })->unique('id')->values(), // // avoid repetitions
                    'id' => $firstItem->id,
                    'created_at' => $firstItem->created_at,
                    'updated_at' => $firstItem->updated_at,
                ];
            })->values();

            return $grouped;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewByRoleId($roleId): Collection
    {
        try
        {
            $contract = ContractRoleStatus::where('role_id', $roleId)->with(['role','contractState'])
                ->get();
            if ($contract->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_role_status.exceptionNotFoundById'));
            }
            return $contract;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public static function create(array $request): string
    {
        // Check if any role with this id exists
        $role = Role::find($request['role']);
        if (!$role) {
            throw new ResourceNotFoundException(trans('hr/contract_role_status.exceptionNotFoundById'));
        }

        // Delete all records with this role
        ContractRoleStatus::where('role_id', $request['role'])->delete();

        // I go through the received states array, creating a new ContractRoleStatus, assigning the values and then saving it to the database
        foreach ($request['states'] as $states) {
            $newContract = new ContractRoleStatus();
            $newContract->role_id = $request['role'];
            $newContract->contract_states_id = $states;
            $newContract->active = $request['active'];
            $newContract->save();
        }

        // return message
        return trans('hr/contract_role_status.syncTransitions');
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
//    public function update($id, array $request): object|null|array
//    {
//        try {
//            $contract = ContractRoleStatus::find($id);
//            if (!$contract) {
//                throw new ResourceNotFoundException(trans('hr/contract_role_status.exceptionNotFoundById'));
//            }
//            $newContract = $this->dataFormat($request, $contract);
//            $newContract->update();
//
//            // Store activity timeline
//            ActivityTimeLineHelper::store(
//                $newContract->id,
//                'updated',
//                'Contract option',
//                'A new type of Contract role status was updated',
//            );
//
//            return $newContract;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
//            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    public function dataFormat(array $request, ContractRoleStatus $contract): object|null
//    {
//        $contract->role_id = $request['role_id'];
//        $contract->contract_states_id = $request['contract_states_id'];
//        $contract->active = $request['active'];
//        return $contract;
//    }

}
