<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\MaritalStatus;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
class MaritalStatusRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $mt = MaritalStatus::orderBy('name', 'desc')->get();
            if ($mt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/marital_status.exceptionNotFound'));
            }
            return $mt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $mt= MaritalStatus::where('active', $status)->orderBy('name','desc')->get();
            if ($mt->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/marital_status.exceptionNotFoundByStatus'));
            }
            return $mt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $mt = new MaritalStatus();
            $newMt = $this->dataFormat($request,$mt);
            $newMt->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newMt->id,
                'created',
                'Marital status',
                'A new type of Marital status was created: ' . $newMt->name,
            );

            return $newMt;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $mt = MaritalStatus::find($id);
            if (!$mt){
                throw new ResourceNotFoundException(trans('hr/marital_status.exceptionNotFoundById'));
            }
            $newMt = $this->dataFormat($request,$mt);
            $newMt->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newMt->id,
                'updated',
                'Marital status',
                'Marital status was updated: ' . $newMt->name,
            );

            return $newMt;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, MaritalStatus $mt):object|null
    {
        try {
            $mt->name = $request['name'];
            $mt->active = $request['active'];
            return $mt;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }
}
