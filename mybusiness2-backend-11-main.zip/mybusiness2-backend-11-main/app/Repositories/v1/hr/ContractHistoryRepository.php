<?php

namespace App\Repositories\v1\hr;

//Global Imports
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//Local Imports
use App\Models\hr\ContractHistory;
use App\Interfaces\CreateInterface;
use App\Interfaces\ViewAllInterface;
use App\Interfaces\ViewByIdInterface;
use App\Exceptions\ResourceNotFoundException;

class ContractHistoryRepository implements  ViewAllInterface, ViewByIdInterface, CreateInterface
{

    /**
     * @throws Exception
     */

    public function viewAll()
    {
        try
        {
            $contractHistories = ContractHistory::orderBy('date')->get();
            if (!$contractHistories){
                throw new ResourceNotFoundException(trans('contract_history.exceptionNotFound'));
            }
            return $contractHistories;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    public function viewById($id)
    {
        try
        {
            $contractHistory = ContractHistory::find($id);
            if (!$contractHistory){
                throw new ResourceNotFoundException(trans('contract_history.exceptionNotFoundById'));
            }
            return $contractHistory;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }
    }

    public function viewByContractID($id)
    {
        try
        {
            $contractHistories = ContractHistory::where('contract_id','=',$id)->orderBy('date')->get();
            if (!$contractHistories){
                throw new ResourceNotFoundException(trans('contract_history.exceptionNotFoundByContractID'));
            }
            return $contractHistories;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }
    }

    public function create(array $data): array|object|null
    {
        try
        {
            DB::beginTransaction();
            $activeHistory = new ContractHistory();
            $contractHistory = new ContractHistory();
            $activeHistory = $this->getActiveHistory($data['contract_id']);
            if ($activeHistory===null){
                $newContractHistory = $this->dataFormat($data, $contractHistory);
                //When a new contract history is created, a notification is automatically sent to the supervisor.
                $newContractHistory->current_active = 1;
                $newContractHistory->notification_count = 1;
                $newContractHistory->save();
                DB::commit();
                return $newContractHistory;
            }else{
                $activeHistory->current_active = 0;
                $contractHistory = new ContractHistory;
                $newContractHistory = $this->dataFormat($data, $contractHistory);
                //When a new contract history is created, a notification is automatically sent to the supervisor.
                $newContractHistory->current_active = 1;
                $newContractHistory->notification_count = 1;
                $newContractHistory->save();
                $activeHistory->save();
                DB::commit();
            }

            return $contractHistory;
        }catch (ResourceNotFoundException $e) {
            DB::rollback();
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            DB::rollback();
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    public function incrementNotifCount($id)
    {
        try
        {
            $contractHistory = ContractHistory::where('contract_id','=',$id)->where('current_active', '=', 1)->first();
            if (!$contractHistory){
                return throw new ResourceNotFoundException(trans('contract.exceptionNotFoundById'));
            }
            $contractHistory->notification_count = $contractHistory->notification_count + 1;
            $contractHistory->save();
            return $contractHistory;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat($data, $contractHistory) : object | null
    {
        $contractHistory->contract_id = $data['contract_id'];
        $contractHistory->state_id = $data['state_id'];
        $contractHistory->date = $data['date'];
        $contractHistory->notification_count = $data['notification_count'];
        $contractHistory->supervisor_id = $data['supervisor_id'];
        $contractHistory->current_active = 1;
        return $contractHistory;
    }
    public function getActiveHistory($id): object | null
    {
        try
        {
            $contractHistory = new ContractHistory();
            $contractHistory = ContractHistory::where('contract_id','=',$id)->where('current_active','=',1)->first();
            if (!$contractHistory){
                return null;
            }
            return $contractHistory;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }

}
