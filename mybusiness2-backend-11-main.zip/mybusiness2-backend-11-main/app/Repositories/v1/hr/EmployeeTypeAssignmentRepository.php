<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\hr\EmployeeTypeAssignment;
use App\Exceptions\ResourceNotFoundException;

class EmployeeTypeAssignmentRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $employee = EmployeeTypeAssignment::orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_type_assignment.exceptionNotFound'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $employee = EmployeeTypeAssignment::where('active', $status)->orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_type_assignment.exceptionNotFoundByStatus'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $employee = new EmployeeTypeAssignment();
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'created',
                'Employee type assignment',
                'A new type of Employee type assignment was created: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $employee = EmployeeTypeAssignment::find($id);
            if (!$employee) {
                throw new ResourceNotFoundException(trans('hr/employee_type_assignment.exceptionNotFoundById'));
            }
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'created',
                'Employee type assignment',
                'Employee type assignment was created: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, EmployeeTypeAssignment $employee): object|null
    {
        try {
            $employee->name = $request['name'];
            $employee->active = $request['active'];
            return $employee;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
