<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\EmployeeClass;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class EmployeeClassRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $employee = EmployeeClass::orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_class.exceptionNotFound'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $employee = EmployeeClass::where('active', $status)->orderBy('name', 'desc')->get();
            if ($employee->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/employee_class.exceptionNotFoundByStatus'));
            }
            return $employee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $employee = new EmployeeClass();
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'created',
                'Employee class',
                'A new type of Employee class was created: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $employee = EmployeeClass::find($id);
            if (!$employee) {
                throw new ResourceNotFoundException(trans('hr/employee_class.exceptionNotFoundById'));
            }
            $newEmployee = $this->dataFormat($request, $employee);
            $newEmployee->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEmployee->id,
                'updated',
                'Employee class',
                'Employee class was updated: ' . $newEmployee->name,
            );

            return $newEmployee;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, EmployeeClass $employee): object|null
    {
        try {
            $employee->code = $request['code'];
            $employee->name = $request['name'];
            $employee->set_id = $request['set_id'];
            $employee->active = $request['active'];
            return $employee;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}

