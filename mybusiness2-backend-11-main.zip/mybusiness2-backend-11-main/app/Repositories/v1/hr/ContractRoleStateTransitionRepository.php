<?php

namespace App\Repositories\v1\hr;

//Global Imports
use App\Helpers\ActivityTimeLineHelper;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

//Local Imports
use App\Models\Role;
use App\Models\hr\ContractStateTransition;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\ContractRoleStateTransition;

class ContractRoleStateTransitionRepository
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $transitions = ContractRoleStateTransition::with(['role', 'contractStateTransition'])->get();

            if ($transitions->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_role_state_transition.exceptionNotFound'));
            }

            // Group by role_id
            $grouped = $transitions->groupBy('role_id')->map(function ($items) {
                $role = $items->first()->role;
                $firstItem = $items->first();

                return [
                    'role' => $role,
                    'transitions' => $items->map(function ($item) {
                        return $item->contractStateTransition;
                    })->unique('id')->values(), // Avoid duplicated
                    'id' => $firstItem->id,
                    'created_at' => $firstItem->created_at,
                    'updated_at' => $firstItem->updated_at,
                ];
            })->values();

            return $grouped;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function viewByRoleId($roleId): Collection
    {
        try
        {
            $roleContractStates = ContractRoleStateTransition::where('role_id', $roleId)->with(['role','contractStateTransition'])
                ->get();
            if ($roleContractStates->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/contract_role_state_transition.exceptionNotFoundById'));
            }
            return $roleContractStates;
        }catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public static function create(array $request): string
    {
        // Check if any role with this id exists
        $role = Role::find($request['role']);
        if (!$role) {
            throw new ResourceNotFoundException(trans('hr/contract_role_state_transition.exceptionNotFoundById'));
        }

        // Delete all records with this role
        ContractRoleStateTransition::where('role_id', $request['role'])->delete();

        // I go through the received transition array, creating a new RoleContractStateTransition , assigning the values and then saving it to the database
        foreach ($request['transitions'] as $transition) {
            $newRoleContractStateTransition = new ContractRoleStateTransition();
            $newRoleContractStateTransition->role_id = $request['role'];
            $newRoleContractStateTransition->contract_state_transition_id = $transition;
            $newRoleContractStateTransition->save();
        }

        // return message
        return trans('hr/contract_role_state_transition.syncTransitions');
    }
}
