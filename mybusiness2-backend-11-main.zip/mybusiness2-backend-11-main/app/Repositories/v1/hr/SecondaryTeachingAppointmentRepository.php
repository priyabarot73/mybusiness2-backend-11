<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\hr\SecondaryTeachingAppointment;

class SecondaryTeachingAppointmentRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $secondary = SecondaryTeachingAppointment::orderBy('name', 'desc')->get();
            if ($secondary->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/secondary_teaching_appointment.not_found'));
            }
            return $secondary;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $secondary= SecondaryTeachingAppointment::where('active', $status)->orderBy('name','desc')->get();
            if ($secondary->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/secondary_teaching_appointment.status'));
            }
            return $secondary;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $secondary = new SecondaryTeachingAppointment();
            $newSecondary = $this->dataFormat($request,$secondary);
            $newSecondary->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSecondary->id,
                'created',
                'Secondary teaching A',
                'A new type of Secondary teaching A was created: ' . $newSecondary->name,
            );

            return $newSecondary;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $secondary = SecondaryTeachingAppointment::find($id);
            if (!$secondary){
                throw new ResourceNotFoundException(trans('hr/secondary_teaching_appointment.id'));
            }
            $newSecondary = $this->dataFormat($request,$secondary);
            $newSecondary->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newSecondary->id,
                'updated',
                'Secondary teaching A',
                'Secondary teaching A was updated: ' . $newSecondary->name,
            );

            return $newSecondary;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, SecondaryTeachingAppointment $secondary):object|null
    {
        try {
            $secondary->name = $request['name'];
            $secondary->description = $request['description'];
            $secondary->active = $request['active'];
            return $secondary;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}

