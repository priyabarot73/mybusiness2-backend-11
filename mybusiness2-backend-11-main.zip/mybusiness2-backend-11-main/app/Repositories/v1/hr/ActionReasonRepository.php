<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\ActionReason;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class ActionReasonRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $action = ActionReason::orderBy('name', 'desc')->with('action')->get();
            if ($action->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/action_reason.exceptionNotFound'));
            }
            return $action;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $action= ActionReason::where('active', $status)->orderBy('name','desc')->get();
            if ($action->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/action_reason.exceptionNotFoundByStatus'));
            }
            return $action;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $action = new ActionReason();
            $newAction = $this->dataFormat($request,$action);
            $newAction->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAction->id,
                'created',
                'Action reason',
                'A new type of Action reason was created: ' . $newAction->name,
            );

            return $newAction;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $action = ActionReason::find($id);
            if (!$action){
                throw new ResourceNotFoundException(trans('hr/action_reason.exceptionNotFoundById'));
            }
            $newAction = $this->dataFormat($request,$action);
            $newAction->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAction->id,
                'updated',
                'Action reason',
                'Action reason was updated: ' . $newAction->name,
            );

            return $newAction;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ActionReason $action):object|null
    {
        try {
            $action->code = $request['code'];
            $action->name = $request['name'];
            $action->action_id = $request['action_id'];
            $action->active = $request['active'];
            return $action;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
