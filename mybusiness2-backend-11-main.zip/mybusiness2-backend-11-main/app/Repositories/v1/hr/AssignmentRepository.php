<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Assignment;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Models\hr\AssignmentContract;
use App\Exceptions\ResourceNotFoundException;

class AssignmentRepository implements CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = $request->query('sort', 'desc');

            // filters (array)
            $filterModel = $request->query('filters'); // array|null

            $query = Assignment::with([
                'person', 'salaryAdminPlan', 'jobTitle', 'businessUnit', 'department',
                'employeeClass', 'employeeType', 'employeeResponsibility',
                'unitStatus', 'workingTitle', 'action', 'actionReason',
                'subDepartment', 'academicGroup', 'academicOrganization', 'physicalLocation',
                'facility', 'publicEstablishment', 'publicFacility',
                'supervisor', 'assignmentContract.contractCategory', 'assignmentContract.contractType'
            ])->select([
                'hr.assignments.*',
                DB::raw('(CASE WHEN EXISTS (SELECT 1 FROM hr.assignment_contracts WHERE assignment_contracts.assignment_id = assignments.id) THEN 1 ELSE 0 END) AS is_contract')
            ]);

            // Search
            if (!empty($search)) {
                $search = strtolower($search);
                $query->where(function ($query) use ($search) {
                    $query->whereHas('person', function ($q) use ($search) {
                        $q->whereRaw("LOWER(first_name) LIKE ?", ["%$search%"])
                            ->orWhereRaw("LOWER(last_name) LIKE ?", ["%$search%"])
                            ->orWhereRaw("LOWER(middle_name) LIKE ?", ["%$search%"])
                            ->orWhereRaw("LOWER(panther_id) LIKE ?", ["%$search%"]);
                    })->orWhereHas('department', function ($q) use ($search) {
                        $q->whereRaw("LOWER(name) LIKE ?", ["%$search%"]);
                    })->orWhereHas('jobTitle', function ($q) use ($search) {
                        $q->whereRaw("LOWER(name) LIKE ?", ["%$search%"]);
                    })->orWhereHas('businessUnit', function ($q) use ($search) {
                        $q->whereRaw("LOWER(name) LIKE ?", ["%$search%"]);
                    })->orWhere(function ($q) use ($search) {
                        if (in_array($search, ['active', 'inactive'])) {
                            $q->where('assignments.active', $search === 'active' ? 1 : 0);
                        }
                    })->orWhere(function ($q) use ($search) {
                        if (in_array($search, ['yes', 'no'])) {
                            $q->havingRaw('is_contract = ?', [$search === 'yes' ? 1 : 0]);
                        }
                    });
                });
            }

            // Apply filters (server-side)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {

                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and | or

                $query->where(function ($q) use ($filterModel, $logic) {
                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        // ignore empty filters
                        if (!$field || $value === null || $value === '') {
                            continue;
                        }

                        $applyFilter = function ($subQ) use ($field, $operator, $value) {

                            // helper para LIKE
                            $buildLike = function ($v, $op) {
                                $v = strtolower(trim((string) $v));
                                return match ($op) {
                                    'equals', '=' => [$v],
                                    'startsWith' => [$v . '%'],
                                    'endsWith' => ['%' . $v],
                                    default => ['%' . $v . '%'], // contains
                                };
                            };

                            // PERSON (person.first_name)
                            if (str_starts_with($field, 'person.')) {
                                $col = str_replace('person.', '', $field);
                                [$pattern] = $buildLike($value, $operator);

                                return $subQ->whereHas('person', function ($p) use ($col, $pattern) {
                                    $p->whereRaw("LOWER($col) LIKE ?", [$pattern]);
                                });
                            }

                            // department.name / departments.name
                            if ($field === 'department.name' || $field === 'departments.name') {
                                [$pattern] = $buildLike($value, $operator);

                                return $subQ->whereHas('department', function ($d) use ($pattern) {
                                    $d->whereRaw("LOWER(name) LIKE ?", [$pattern]);
                                });
                            }

                            // jobTitle.name / job_titles.name
                            if ($field === 'jobTitle.name' || $field === 'job_titles.name') {
                                [$pattern] = $buildLike($value, $operator);

                                return $subQ->whereHas('jobTitle', function ($jt) use ($pattern) {
                                    $jt->whereRaw("LOWER(name) LIKE ?", [$pattern]);
                                });
                            }

                            // business_units.name
                            if ($field === 'business_units.name') {
                                [$pattern] = $buildLike($value, $operator);

                                return $subQ->whereHas('businessUnit', function ($bu) use ($pattern) {
                                    $bu->whereRaw("LOWER(name) LIKE ?", [$pattern]);
                                });
                            }

                            // salary_admin_plans.name
                            if ($field === 'salary_admin_plans.name') {
                                [$pattern] = $buildLike($value, $operator);

                                return $subQ->whereHas('salaryAdminPlan', function ($sap) use ($pattern) {
                                    $sap->whereRaw("LOWER(name) LIKE ?", [$pattern]);
                                });
                            }

                            // active (boolean)
                            if ($field === 'active') {
                                $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                                return $subQ->where('assignments.active', $bool ? 1 : 0);
                            }

                            // is_contract (boolean) -> HAVING
                            if ($field === 'is_contract') {
                                $bool = filter_var($value, FILTER_VALIDATE_BOOLEAN);
                                return $subQ->havingRaw('is_contract = ?', [$bool ? 1 : 0]);
                            }

                            // start_date / end_date
                            if ($field === 'assignments.start_date' || $field === 'assignment.start_date') {
                                return $subQ->whereDate('assignments.start_date', $value);
                            }
                            if ($field === 'assignments.end_date' || $field === 'assignment.end_date') {
                                return $subQ->whereDate('assignments.end_date', $value);
                            }

                            // If an illegal field arrives, it does nothing.
                            return null;
                        };

                        if ($logic === 'or') {
                            $q->orWhere(function ($sub) use ($applyFilter) {
                                $applyFilter($sub);
                            });
                        } else {
                            $q->where(function ($sub) use ($applyFilter) {
                                $applyFilter($sub);
                            });
                        }
                    }
                });
            }

            // sorting
            if (in_array($sortColumn, [
                'created_at',
                'person.first_name',
                'person.last_name',
                'department.name',
                'jobTitle.name',
                'assignment.start_date',
                'assignment.end_date',
                'salary_admin_plans.name',
                'job_titles.name',
                'business_units.name',
                'departments.name',
                'active',
                'is_contract'
            ])) {
                if (str_starts_with($sortColumn, 'person.')) {
                    $query->join('hr.persons', 'assignments.person_id', '=', 'hr.persons.id');
                    $column = str_replace('person.', '', $sortColumn);
                    $query->orderBy("hr.persons.$column", $sortDirection);
                } elseif ($sortColumn === 'department.name' || $sortColumn === 'departments.name') {
                    $query->join('gn.departments', 'assignments.department_id', '=', 'gn.departments.id')
                        ->orderBy('gn.departments.name', $sortDirection);
                } elseif ($sortColumn === 'jobTitle.name' || $sortColumn === 'job_titles.name') {
                    $query->join('hr.job_titles', 'assignments.job_title_id', '=', 'hr.job_titles.id')
                        ->orderBy('hr.job_titles.name', $sortDirection);
                } elseif ($sortColumn === 'business_units.name') {
                    $query->join('hr.business_units', 'assignments.business_unit_id', '=', 'hr.business_units.id')
                        ->orderBy('hr.business_units.name', $sortDirection);
                } elseif ($sortColumn === 'salary_admin_plans.name') {
                    $query->join('hr.salary_admin_plans', 'assignments.salary_admin_plan_id', '=', 'hr.salary_admin_plans.id')
                        ->orderBy('hr.salary_admin_plans.name', $sortDirection);
                } elseif ($sortColumn === 'assignment.start_date') {
                    $query->orderBy('assignments.start_date', $sortDirection);
                } elseif ($sortColumn === 'assignment.end_date') {
                    $query->orderBy('assignments.end_date', $sortDirection);
                } elseif ($sortColumn === 'is_contract') {
                    $query->orderBy('is_contract', $sortDirection);
                } else {
                    $query->orderBy($sortColumn, $sortDirection);
                }
            }

            // pagination
            $assignments = $query->paginate($perPage, ['*'], 'page', $page);

            if ($assignments->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/assignment.not_found'));
            }

            return $assignments;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAssignmentById($id)
    {
        try {
            $assignment = Assignment::where('id', $id)
                ->select([
                    'hr.assignments.*',
                    DB::raw('(CASE WHEN EXISTS (SELECT 1 FROM hr.assignment_contracts WHERE assignment_contracts.assignment_id = assignments.id) THEN 1 ELSE 0 END) AS is_contract')
                ])
                ->with([
                    'person', 'salaryAdminPlan', 'jobTitle', 'businessUnit', 'department',
                    'employeeClass', 'employeeType', 'employeeResponsibility',
                    'unitStatus', 'workingTitle', 'action', 'actionReason',
                    'subDepartment', 'academicGroup', 'academicOrganization', 'physicalLocation',
                    'facility', 'publicEstablishment', 'publicFacility',
                    'supervisor', 'assignmentContract.contractCategory', 'assignmentContract.contractType'
                ])->first();

            if (!$assignment) {
                throw new ResourceNotFoundException(trans('hr/assignment.not_found'));
            }
            return $assignment;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAssignmentByPersonId($personId)
    {
        try {
            $assignments = Assignment::where('person_id', $personId)
                ->select([
                    'hr.assignments.*',
                    DB::raw('(CASE WHEN EXISTS (SELECT 1 FROM hr.assignment_contracts WHERE assignment_contracts.assignment_id = assignments.id) THEN 1 ELSE 0 END) AS is_contract')
                ])
                ->with([
                    'person', 'salaryAdminPlan', 'jobTitle', 'businessUnit', 'department',
                    'employeeClass', 'employeeType', 'employeeResponsibility',
                    'unitStatus', 'workingTitle', 'action', 'actionReason',
                    'subDepartment', 'academicGroup', 'academicOrganization', 'physicalLocation',
                    'facility', 'publicEstablishment', 'publicFacility',
                    'supervisor', 'assignmentContract.contractCategory', 'assignmentContract.contractType'
                ])
                ->get();

            if ($assignments->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/assignment.not_found'));
            }
            return $assignments;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $assigment = Assignment::where('active', $status)
                ->with(
                    [
                        'person', 'salaryAdminPlan', 'jobTitle', 'businessUnit', 'department',
                        'employeeClass', 'employeeType', 'employeeResponsibility',
                        'unitStatus', 'workingTitle', 'action', 'actionReason',
                        'subDepartment', 'academicGroup', 'academicOrganization', 'physicalLocation',
                        'facility', 'publicEstablishment', 'publicFacility',
                        'supervisor', 'assignmentContract.contractCategory', 'assignmentContract.contractType'
                    ]
                )
                ->orderBy('created_at', 'desc')
                ->get();
            if ($assigment->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/assignment.status'));
            }
            return $assigment;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        DB::beginTransaction();
        try {
            $assignment = new Assignment();
            $newAssignment = $this->dataFormat($request, $assignment);
            $newAssignment->save();

            // Load the person relationship
            $newAssignment->load('person');

            $person = $newAssignment->person;
            $description = sprintf(
                'Assignment created for %s %s (Panther ID: %s)',
                $person->first_name ?? '',
                $person->last_name ?? '',
                $person->panther_id ?? ''
            );

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAssignment->id,
                'created',
                'Assignment',
                $description
            );

            // Create AssignmentContract if present in the request
            if (!empty($request['assignment_contract'])) {
                $this->createAssignmentContract($request, $newAssignment->id);
            }
            DB::commit();

            return $newAssignment;
        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        DB::beginTransaction();
        try {
            $assignment = Assignment::find($id);
            if (!$assignment) {
                throw new ResourceNotFoundException(trans('hr/assignment.id'));
            }
            $newAssignment = $this->dataFormat($request, $assignment);
            $newAssignment->update();

            // Update or create Assignment Contract if present in the request
            if (!empty($request['assignment_contract'])) {
                $this->createAssignmentContract($request, $newAssignment->id);
            }
            DB::commit();

            // Load the person relationship
            $newAssignment->load('person');

            $person = $newAssignment->person;
            $description = sprintf(
                'Assignment updated for %s %s (Panther ID: %s)',
                $person->first_name ?? '',
                $person->last_name ?? '',
                $person->panther_id ?? ''
            );

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newAssignment->id,
                'updated',
                'Assignment',
                $description
            );

            return $newAssignment;
        } catch (ResourceNotFoundException $e) {
            DB::rollBack();
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function getAssignmentsWithAndWithoutContracts($personId): array
    {
        try {
            // Retrieve assignments for the given person_id, including necessary relationships
            $assignments = Assignment::with([
                'salaryAdminPlan',
                'employeeClass',
                'jobTitle',
                'assignmentContract.contractCategory',
                'assignmentContract.contractType'
            ])->where('person_id', $personId)->get();

            // Filter assignments without a contract
            $assignmentsWithoutContracts = $assignments->filter(function ($assignment) {
                return $assignment->assignmentContract === null;
            })->map(function ($assignment) {
                return [
                    'id' => $assignment->id,
                    'original_hire_date' => Carbon::parse($assignment->original_hire_date)->format('d/m/Y'),
                    'salary_admin_plan' => $assignment->salaryAdminPlan->name ?? null,
                    'employee_class' => $assignment->employeeClass->name ?? null,
                    'job_title' => $assignment->jobTitle->name ?? null,
                    'created_at' => Carbon::parse($assignment->created_at)->format('d/m/Y'),
                    'updated_at' => $assignment->updated_at ? Carbon::parse($assignment->updated_at)->format('d/m/Y') : null,
                ];
            });

            // Filter assignments with a contract
            $assignmentsWithContracts = $assignments->filter(function ($assignment) {
                return $assignment->assignmentContract !== null;
            })->map(function ($assignment) {
                return [
                    'id' => $assignment->id,
                    'original_hire_date' => Carbon::parse($assignment->original_hire_date)->format('d/m/Y'),
                    'salary_admin_plan' => $assignment->salaryAdminPlan->name ?? null,
                    'employee_class' => $assignment->employeeClass->name ?? null,
                    'job_title' => $assignment->jobTitle->name ?? null,
                    'contract_number' => $assignment->assignmentContract->contract_number ?? null,
                    'contract_category' => $assignment->assignmentContract->contractCategory->name ?? null,
                    'contract_type' => $assignment->assignmentContract->contractType->name ?? null,
                    'created_at' => Carbon::parse($assignment->created_at)->format('d/m/Y'),
                    'updated_at' => $assignment->updated_at ? Carbon::parse($assignment->updated_at)->format('d/m/Y') : null,
                ];
            });

            // Return the result as an array with counts and assignment details
            return [
                'assignments_without_contracts' => [
                    'count' => $assignmentsWithoutContracts->count(),
                    'assignments' => $assignmentsWithoutContracts->values(),
                ],
                'assignments_with_contracts' => [
                    'count' => $assignmentsWithContracts->count(),
                    'assignments' => $assignmentsWithContracts->values(),
                ],
            ];
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Assignment $assignment): object|null
    {
        try {
            $assignment->person_id = $request['person_id'];
            $assignment->original_hire_date = $request['original_hire_date'];
            $assignment->salary_admin_plan_id = $request['salary_admin_plan_id'];
            $assignment->employee_class_id = $request['employee_class_id'];
            $assignment->employee_type_id = $request['employee_type_id'];
            $assignment->employee_responsibility_id = $request['employee_responsibility_id'];
            $assignment->unit_status_id = $request['unit_status_id'];
            $assignment->position_number = $request['position_number'];
            $assignment->fte = $request['fte'];
            $assignment->job_title_id = $request['job_title_id'];
            $assignment->working_title_id = $request['working_title_id'];
            $assignment->action_id = $request['action_id'];
            $assignment->action_reason_id = $request['action_reason_id'];
            $assignment->start_date = $request['start_date'];
            $assignment->end_date = $request['end_date'];
            $assignment->business_unit_id = $request['business_unit_id'];
            $assignment->department_id = $request['department_id'];
            $assignment->sub_department_id = $request['sub_department_id'];
            $assignment->academic_group_id = $request['academic_group_id'];
            $assignment->academic_organization_id = $request['academic_organization_id'];
            $assignment->physical_location_id = $request['physical_location_id'];
            $assignment->facility_id = $request['facility_id'];
            $assignment->physical_public_establishment = $request['physical_public_establishment'];
            $assignment->public_establishment_id = $request['public_establishment_id'];
            $assignment->public_facility_id = $request['public_facility_id'];
            $assignment->supervisor_id = $request['supervisor_id'];
            $assignment->active = $request['active'];
            return $assignment;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    public function createAssignmentContract($request, $id): void
    {
        try {
            // handle an object
            $assignmentContract = new AssignmentContract();
            $assignmentContract->assignment_id = $id;
            $assignmentContract->contract_number = $request['assignment_contract']['contract_number'];
            $assignmentContract->contract_category_id = $request['assignment_contract']['contract_category_id'];
            $assignmentContract->contract_type_id = $request['assignment_contract']['contract_type_id'];
            $assignmentContract->save();

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }

}


