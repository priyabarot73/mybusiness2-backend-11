<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\ActivityNumber;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class ActivityNumberRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $activity = ActivityNumber::orderBy('number','desc')
                ->with(['department','program','responsible'])
                ->get();
            if ($activity->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/activity_number.not_found'));
            }
            return $activity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $activity= ActivityNumber::where('active', $status)
                ->with(['department','program','responsible'])
                ->orderBy('number','desc')
                ->get();
            if ($activity->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/activity_number.status'));
            }
            return $activity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $activity = new ActivityNumber();
            $newActivity = $this->dataFormat($request,$activity);
            $newActivity->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newActivity->id,
                'created',
                'Activity number',
                'A new type of Activity number was created: ' . $newActivity->name,
            );

            return $newActivity;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $activity = ActivityNumber::find($id);
            if (!$activity){
                throw new ResourceNotFoundException(trans('hr/activity_number.id'));
            }
            $newActivity = $this->dataFormat($request,$activity);
            $newActivity->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newActivity->id,
                'updated',
                'Activity number',
                'Activity number was updated: ' . $newActivity->name,
            );

            return $newActivity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('activity_number.error'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, ActivityNumber $activity):object|null
    {
        try {
            $activity->number = $request['number'];
            $activity->name = $request['name'];
            $activity->department_id = $request['department_id'];
            $activity->program_id = $request['program_id'];
            $activity->responsible_id = $request['responsible_id'];
            $activity->active = $request['active'];
            return $activity;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }
    }
}






