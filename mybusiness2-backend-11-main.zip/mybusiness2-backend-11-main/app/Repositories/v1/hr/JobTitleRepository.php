<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\JobTitle;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class JobTitleRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $jobTitle = JobTitle::orderBy('name', 'desc')->get();
            if ($jobTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/job_title.exceptionNotFound'));
            }
            return $jobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $jobTitle= JobTitle::where('active', $status)->orderBy('name','desc')->get();
            if ($jobTitle->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/job_title.exceptionNotFoundByStatus'));
            }
            return $jobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $jobTitle = new JobTitle();
            $newJobTitle = $this->dataFormat($request,$jobTitle);
            $newJobTitle->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newJobTitle->id,
                'created',
                'Job title',
                'A new type of Job title was created: ' . $newJobTitle->name,
            );

            return $newJobTitle;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $jobTitle = JobTitle::find($id);
            if (!$jobTitle){
                throw new ResourceNotFoundException(trans('hr/job_title.exceptionNotFoundById'));
            }
            $newJobTitle = $this->dataFormat($request,$jobTitle);
            $newJobTitle->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newJobTitle->id,
                'updated',
                'Job title',
                'Job title was updated: ' . $newJobTitle->name,
            );

            return $newJobTitle;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, JobTitle $jobTitle):object|null
    {
        try {
            $jobTitle->title_id = $request['title_id'];
            $jobTitle->name = $request['name'];
            $jobTitle->active = $request['active'];
            return $jobTitle;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
