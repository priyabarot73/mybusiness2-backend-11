<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\ContractOption;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class ContractOptionRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $contractOption = ContractOption::orderBy('name', 'asc')->get();
            if ($contractOption->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_option.exceptionNotFound'));
            }
            return $contractOption;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $contractOption = ContractOption::where('active', $status)->orderBy('name', 'asc')->get();
            if ($contractOption->isEmpty()) {
                throw new ResourceNotFoundException(trans('hr/contract_option.exceptionNotFoundByStatus'));
            }
            return $contractOption;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $contractOption = new ContractOption();
            $newContractOption = $this->dataFormat($request, $contractOption);
            $newContractOption->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractOption->id,
                'created',
                'Contract option',
                'A new type of Contract option was created: ' . $newContractOption->name,
            );

            return $newContractOption;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $contractOption = ContractOption::find($id);
            if (!$contractOption) {
                throw new ResourceNotFoundException(trans('contract_option.exceptionNotFoundById'));
            }
            $newContractOption = $this->dataFormat($request, $contractOption);
            $newContractOption->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newContractOption->id,
                'updated',
                'Contract option',
                'A new type of Contract option was updated: ' . $newContractOption->name,
            );

            return $newContractOption;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, ContractOption $contractOption): object|null
    {
        $contractOption->name = $request['name'];
        $contractOption->code = $request['code'];
        $contractOption->active = $request['active'];
        return $contractOption;
    }
}
