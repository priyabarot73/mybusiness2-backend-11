<?php

namespace App\Repositories\v1\hr;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\hr\Ethnicity;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;

class EthnicityRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $ethnicity = Ethnicity::orderBy('name', 'desc')->get();
            if ($ethnicity->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/ethnicity.exceptionNotFound'));
            }
            return $ethnicity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $ethnicity= Ethnicity::where('active', $status)->orderBy('name','desc')->get();
            if ($ethnicity->isEmpty()){
                throw new ResourceNotFoundException(trans('hr/ethnicity.exceptionNotFoundByStatus'));
            }
            return $ethnicity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $ethnicity = new Ethnicity();
            $newEthnicity = $this->dataFormat($request,$ethnicity);
            $newEthnicity->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEthnicity->id,
                'created',
                'Ethnicity',
                'A new type of Ethnicity was created: ' . $newEthnicity->name,
            );

            return $newEthnicity;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $ethnicity = Ethnicity::find($id);
            if (!$ethnicity){
                throw new ResourceNotFoundException(trans('hr/ethnicity.exceptionNotFoundById'));
            }
            $newEthnicity = $this->dataFormat($request,$ethnicity);
            $newEthnicity->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newEthnicity->id,
                'updated',
                'Ethnicity',
                'Ethnicity was updated: ' . $newEthnicity->name,
            );

            return $newEthnicity;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Ethnicity $ethnicity):object|null
    {
        try {
            $ethnicity->name = $request['name'];
            $ethnicity->active = $request['active'];
            return $ethnicity;
        }catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(),$e->getCode());
        }

    }
}
