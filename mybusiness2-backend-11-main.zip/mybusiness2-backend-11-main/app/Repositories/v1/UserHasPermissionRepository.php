<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Http\Requests\v1\UserHasPermissionRequest;
use App\Models\Permission;
use App\Models\User;

class UserHasPermissionRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(): JsonResponse
    {
        try {
            $users = User::all();
            $permissions = Permission::all();
            if (!$users || !$permissions) {
                throw new ResourceNotFoundException(trans('user_has_permission.exceptionNotFound'));
            }
            return response()->json([$users, $permissions]);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * @throws Exception
     */
    public function viewById($id): JsonResponse
    {
        try {
            $permissions = $this->viewUserById($id)->getDirectPermissions();
            if (!$permissions){
                throw new ResourceNotFoundException(trans('user_has_permission.exceptionNotFoundById'));
            }
            return response()->json($permissions);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function assignPermissions(UserHasPermissionRequest $request, string $id): string
    {
        try {
            if(!$this->viewUserById($id)->syncPermissions($request['permissions'])){
                throw new ResourceNotFoundException(trans('user_has_permission.syncPermissionsWrong'));
            }
            return trans('user_has_permission.syncPermissionsOk');
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function deletePermissions(UserHasPermissionRequest $request, string $id): string
    {
        try {
            $value = "";
            foreach ($request['permissions'] as $role) {
                if(!$this->viewUserById($id)->revokePermissionTo($role)){
                    throw new ResourceNotFoundException(trans('user_has_permission.revokePermissionsWrong'));
                }
                $value =trans('user_has_permission.revokePermissionsOk');
            }
            return $value;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewUserById(string $id):?object
    {
        try {
            $user = User::find($id);
            if (!$user) {
                throw new ResourceNotFoundException(trans('user_has_permission.exceptionNotFoundById'));
            }
            return $user;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
