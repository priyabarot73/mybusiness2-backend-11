<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\Role;
use App\Interfaces\CrudInterface;
use App\Exceptions\ResourceNotFoundException;


class RoleRepository implements CrudInterface
{

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $roles =  Role::orderBy('name', 'desc')->get();
            if ($roles->isEmpty()){
                throw new ResourceNotFoundException(trans('role.exceptionNotFound'));
            }
            return $roles;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $role = Role::find($id);
            if (!$role){
                throw new ResourceNotFoundException(trans('role.exceptionNotFoundById'));
            }
            return $role;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null
    {
        try {
            $newRole = Role::create($this->dataFormat($request,"create"));

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newRole->id,
                'created',
                'Role',
                'A new role was created: ' . $newRole->name,
            );

            return $newRole;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function update($id, array $request): object|null
    {
        try {
            $role = $this->viewById($id);
            if (!$role){
                throw new ResourceNotFoundException(trans('role.exceptionNotFoundById'));
            }

            $role->update($this->dataFormat($request));

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $role->id,
                'updated',
                'Role',
                'Role was updated: ' . $role->name,
            );

            return $role;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $role = $this->viewById($id);
            if(!$role){
                throw new ResourceNotFoundException(trans('role.exceptionNotFoundById'));
            }
            $role->delete();
            return $role;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function totalUserRoleAvatars(): array
    {
        try {
            $rolesWithUsers = Role::with('users')->get();
           return $cardData = $rolesWithUsers->map(function ($role) {
                return [
                    'totalUsers' => $role->users->count(),
                    'rol' => $role->name,
                    'avatars' => $role->users->pluck('avatar')->toArray(),
                ];
            })->toArray();
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $data,string $type = null): array
    {
        if ($type){
            return [
                'name'=>$data['name'],
                'guard_name'=>$data['guard_name'],
                'created_at'=>Carbon::now()->format('m/d/y h:i:s'),
                'updated_at'=>null,
            ];
        }
        return [
            'name'=>$data['name'],
            'guard_name'=>$data['guard_name'],
            'created_at'=>$data['created_at'],
            'updated_at'=>Carbon::now()->format('m/d/y h:i:s'),
        ];
    }

}
