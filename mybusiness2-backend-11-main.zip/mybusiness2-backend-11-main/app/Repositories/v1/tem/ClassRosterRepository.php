<?php

namespace App\Repositories\v1\tem;

// GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Illuminate\Support\Facades\DB;

// LOCAL IMPORT
use App\Models\academic\Term;
use App\Models\academic\Course;
use App\Models\temp\PsSchedule;
use App\Models\academic\Section;
use App\Models\academic\Program;
use Illuminate\Support\Collection;
use App\Models\academic\WorkloadCourse;

// DTO
use App\DTOs\hr\CourseSectionDTO;


class ClassRosterRepository
{

    /**
     * @throws Exception
     *This method uses the following flow:
     * WorkloadCourse → section → meetingPatterns / meetingPatternHybrids → instructor → person.panther_id → combinedSections (combined_sections) → combined_with_id → other Section(s) combined
     *
     * To retrieve the courses with their section, given a term number (1255) and a panther_id (6447398),
     * based on the courses in meetingPatterns and meetingPatternHybrids that have an instructor whose workload is overloaded(overload = true).
     * Also, search for the sections that are combined with the section with overload set to true.
     * Once all these sections are obtained, the courses are obtained by taking the course_id, sec_code, and sec_number,
     * joining them with the course, and returning a result like the following: "ISM6128 RG8B,U01A",
     * which shows the course and section codes, grouped by course.
     *
     * Then, with this result, the getCourseSections method is called, which will take "ISM6128 RG8B,U01A" and perform a lookup
     * in the temp.PS_SCHEDULE table to obtain the details of the sections that should be used for the class roster.
     */
    public function getCourseSectionsSummary(Request $request): Collection
    {
        try {
            $term = $request->input('term');
            $pantherId = $request->input('panther_id');
            $termId = Term::where('number', $term)->value('id');
            if (!$termId) return collect();

            // 1. Find sections with overload=true
            $workloadCourses = WorkloadCourse::where('overload', true)
                ->whereHas('section', function ($q) use ($termId, $pantherId) {
                    $q->where('term_id', $termId)
                        ->where(function ($sub) use ($pantherId) {
                            $sub->whereHas('meetingPatterns.instructor.person', fn($q) => $q->where('panther_id', $pantherId))
                                ->orWhereHas('meetingPatternHybrids.instructor.person', fn($q) => $q->where('panther_id', $pantherId));
                        });
                })
                ->with('section.course')
                ->get();

            $allSectionCombos = collect();

            foreach ($workloadCourses as $wc) {
                $section = $wc->section;
                $course = $section?->course;
                if (!$section || !$course) continue;

                // Get the original section
                $mainCode = strtoupper(($section->sec_code ?? '') . ($section->sec_number ?? '') . ($section->sec_sess ?? ''));
                $courseCode = strtoupper($course->code);

                // Get all related sections (combined)
                $sectionIds = DB::table('ac.combined_sections')
                    ->where('section_id', $section->id)
                    ->orWhere('section_id_combined', $section->id)
                    ->pluck('section_id', 'section_id_combined')
                    ->flatMap(fn($value, $key) => [$key, $value])
                    ->filter() // Eliminate possibles nulls
                    ->unique()
                    ->values();

                // Also include the original ID in case there are no combinations
                $sectionIds->push($section->id)->unique();

                $relatedSections = collect([$section])->merge(
                    Section::whereIn('id', $sectionIds)->with('course')->get()
                );

                $sectionCodes = $relatedSections
                    ->map(function ($s) {
                        return strtoupper(($s->sec_code ?? '') . ($s->sec_number ?? '') . ($s->sec_sess ?? ''));
                    })
                    ->unique()
                    ->values();

                $allSectionCombos->push([
                    'course_code' => $courseCode,
                    'section_codes' => $sectionCodes,
                ]);
            }

            // 2. Search PsSchedule to filter
            $psRecords = PsSchedule::where('Term', $term)
                ->where('Instructor ID', $pantherId)
                ->get();

            $filteredRecords = collect();

            foreach ($allSectionCombos as $combo) {
                $filtered = $psRecords->filter(function ($row) use ($combo) {
                    $code = strtoupper($row->Subject . $row->Catalog);
                    $section = strtoupper(trim($row->Section));
                    return $code === $combo['course_code'] && $combo['section_codes']->contains($section);
                });
                $filteredRecords = $filteredRecords->merge($filtered);
            }

            // 3. Return
            return $filteredRecords
                ->groupBy(fn($row) => $row->Subject . $row->Catalog)
                ->map(function ($group, $courseCode) {
                    $course = Course::where('code', $courseCode)->first();
                    $sections = $group->pluck('Section')
                        ->map(fn($s) => strtoupper(trim($s)))
                        ->unique()
                        ->sort()
                        ->implode(',');

                    return [
                        'course_code' => "{$courseCode} {$sections}",
                        'course_id' => $course?->id
                    ];
                })
                ->values();

        } catch (Exception $e) {
            throw new Exception(trans('temp/class_roster.summary_error') . $e->getMessage());
        }
    }

    /**
     * @throws Exception
     *
     * Get details of the sections of a specific course in a given term, based on data from the PsSchedule temporary table.
     */

    public function getCourseSections(Request $request): Collection
    {
        try {
            $term = $request->input('term');
            $courseSection = $request->input('course_section');

            // Expected format: "ISM6128 RG8B" or "ISM6128 RG8B,RG9A"
            [$courseCode, $sectionPart] = explode(' ', $courseSection);

            // Extract subject and catalog from the courseCode (ex: ISM6128)
            preg_match('/^([A-Z]+)(\d+)/', $courseCode, $matches);
            if (count($matches) !== 3) {
                throw new InvalidArgumentException(trans('temp/class_roster.format'));
            }

            [$__, $subject, $catalog] = $matches;

            // Sections to search (can be separated by commas or spaces)
            $sections = collect(preg_split('/[,\s]+/', $sectionPart))
                ->map(fn($s) => strtoupper(trim($s)))
                ->filter()
                ->unique();

            $psRecords = PsSchedule::where('Term', $term)
                ->where('Subject', $subject)
                ->where('Catalog', $catalog)
                ->whereIn('Section', $sections)
                ->get();

            $schedule = [];
            $daysMap = [
                'M' => 'Monday',
                'T' => 'Tuesday',
                'W' => 'Wednesday',
                'R' => 'Thursday',
                'F' => 'Friday',
                'S' => 'Saturday',
                'U' => 'Sunday',
            ];

            $courseSectionDTOs = $psRecords->map(function ($ps) use (&$schedule, $daysMap) {
                $course = Course::where('code', $ps->Subject . $ps->Catalog)->first();
                $program = $this->getProgramFromCourseAndTerm($ps->Subject, $ps->Catalog, $ps->Term, $ps->Notes);

                // Schedule (this is global; it can be overwritten by duplicates)
                if (!empty($ps->{'Meeting Time'}) && !empty($ps->{'Meeting Days'})) {
                    $times = explode('-', $ps->{'Meeting Time'});

                    if (count($times) === 2 && preg_match('/^\d{4}$/', $times[0]) && preg_match('/^\d{4}$/', $times[1])) {
                        try {
                            $from = Carbon::createFromFormat('Hi', $times[0])->format('H:i');
                            $to = Carbon::createFromFormat('Hi', $times[1])->format('H:i');

                            foreach (str_split($ps->{'Meeting Days'}) as $char) {
                                if (isset($daysMap[$char]) && !isset($schedule[$daysMap[$char]])) {
                                    $schedule[$daysMap[$char]] = [
                                        'from' => $from,
                                        'to' => $to
                                    ];
                                }
                            }
                        } catch (Exception $e) {
                            throw new Exception(trans('temp/class_roster.summary_error') . $e->getMessage());
                        }
                    }
                }

                return new CourseSectionDTO(
                    course: $ps->Subject . $ps->Catalog,
                    section: $ps->Section,
                    courseName: $ps->Title ?? $course?->name ?? '',
                    creditsMin: $this->parseCredit($ps->Units, 'min') ?? $course?->credits_min ?? 0.0,
                    creditsMax: $this->parseCredit($ps->Units, 'max') ?? $course?->credits_max ?? 0.0,
                    enrollment: (int)$ps->Enrl ?? 0,
                    career: $ps->Level ?? 'GRAD',
                    mode: $ps->Mode ?? 'Other',
                    program: $program?->code ?? '',
                    cohort: $program?->cohort ?? 0,
                    overload: $this->getOverloadFlag($ps->Subject, $ps->Catalog, $ps->Term),
                    startDate: $ps->{'Start Date'} ?? null,
                    endDate: $ps->{'End Date'} ?? null,
                );
            })->unique(fn($dto) => $dto->course . $dto->section);


            return collect([
                'sections' => $courseSectionDTOs,
                'schedule' => (object)$schedule
            ]);
        } catch (Exception $e) {
            throw new Exception(trans('tem/class_roster.section_error'), $e->getCode());
        }
    }

    /**
     * @throws Exception
     *
     * It is responsible for extracting the number of credits (minimum or maximum) from a text string that
     * represents the credits of a course in a field such as "3 3" or "1 12".
     */
    private function parseCredit(?string $unitField, string $type = 'min'): ?float
    {
        try {
            if (!$unitField) return null;
            $parts = preg_split('/\s+/', trim($unitField));
            if (count($parts) >= 2) {
                return $type === 'min' ? floatval($parts[0]) : floatval($parts[1]);
            }
            return floatval($parts[0]);
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }

    }

    /**
     * @throws Exception
     *
     * It is used to determine which academic program (Program) a course belongs to in a specific term,
     * based mainly on real data from WorkloadCourse and its relationship with Section.
     */
    private function getProgramFromCourseAndTerm(string $subject, string $catalog, string $term, ?string $notes = null): ?Program
    {
        try {
            $courseCode = $subject . $catalog;
            $course = Course::where('code', $courseCode)->first();

            if ($course) {
                $termId = Term::where('number', $term)->value('id');

                $workloadCourse = WorkloadCourse::where('course_id', $course->id)
                    ->whereHas('section', fn($q) => $q->where('term_id', $termId))
                    ->with('section.program')
                    ->first();

                if ($workloadCourse?->section?->program) {
                    return $workloadCourse->section->program;
                }
            }

            // Fallback: search by name if there is no direct association
            if ($notes) {
                return Program::where('name', 'LIKE', "%{$notes}%")->first();
            }

            return null;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     *
     * Used to determine whether a course in a specific term has at least one section marked with overload = true.
     */
    private function getOverloadFlag(string $subject, string $catalog, string $term): float
    {
        try {
            $courseCode = $subject . $catalog;

            $course = Course::where('code', $courseCode)->first();
            if (!$course) return 0.0;

            // Get the term ID from the number
            $termId = Term::where('number', $term)->value('id');
            if (!$termId) return 0.0;

            $hasOverload = WorkloadCourse::where('course_id', $course->id)
                ->where('overload', true)
                ->whereHas('section', fn($query) => $query->where('term_id', $termId))
                ->exists();

            return $hasOverload ? 1.0 : 0.0;
        } catch (Exception $e) {
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }
}
