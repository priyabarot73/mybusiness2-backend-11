<?php

namespace App\Repositories\v1\dashboard;

// GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// LOCAL IMPORT
use App\Models\User;
use App\Models\hr\Person;
use App\Models\academic\Term;
use App\Models\academic\Course;
use App\Models\academic\Program;
use App\Models\academic\Section;
use App\Models\general\Department;
use App\Models\academic\Instructor;
use App\Models\academic\MeetingPattern;
use App\Models\academic\CombinedSection;
use App\Models\academic\MeetingPatternHybrid;
use App\Exceptions\ResourceNotFoundException;

// DTO
use App\DTOs\Dashboard\CarouselDTO;
use App\DTOs\Dashboard\ChartDataDTO;
use App\DTOs\Dashboard\DashboardDataCardDTO;
use App\DTOs\Dashboard\GraphTermInstructorCombinedDTO;
use App\DTOs\Dashboard\TermInstructorsChartDataDTO;

// HELPER
use App\Helpers\CurrentTermHelper;

class DashboardRepository
{

    /**
     * @throws Exception
     *
     * This is the function we use to show the amounts in the cards we have in the CRM
     */
    public function cardDataQuantity(): DashboardDataCardDTO
    {
        try {
            return new DashboardDataCardDTO(
                userCount: User::count(),
                personCount: Person::count(),
                sectionCount: $this->sectionsCountCurrentTerm(),
                programCount: Program::count(),
                departmentCount: Department::count(),
                instructorCount: Instructor::count(),
                courseCount: Course::count(),
                termCount: Term::count(),
            );
        } catch (Exception $e){
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     *
     * This is the function we used to display the graph with the number of instructors by terms in the CRM.
     */
    public function graphInstructorTerm(): TermInstructorsChartDataDTO
    {
        try {
            // Step 1: Get the last 6 terms
            $latestTerms = Term::orderByDesc('number')->take(6)->get();

            if ($latestTerms->isEmpty()) {
                throw new ResourceNotFoundException(trans('section.exceptionNotFound'));
            }

            $termIds = $latestTerms->pluck('id');

            // Step 2: Get the sections of those terms
            $sections = Section::whereIn('term_id', $termIds)->select(['id', 'term_id'])->get();

            // Step 3: Load the meetingPatterns from those sections into chunks
            $meetingPatterns = collect();
            $sections->pluck('id')->chunk(1000)->each(function ($chunk) use (&$meetingPatterns) {
                $meetingPatterns = $meetingPatterns->merge(
                    MeetingPattern::whereIn('section_id', $chunk)
                        ->select(['section_id', 'instructor_id'])
                        ->get()
                );
            });

            // Step 4: Group the data by term
            $totals = [];
            $semesters = [];

            foreach ($latestTerms as $term) {
                $semester = Str::upper(Str::substr($term->semester, 0, 2)) . $term->year;

                $sectionIds = $sections->where('term_id', $term->id)->pluck('id');
                $instructors = $meetingPatterns->whereIn('section_id', $sectionIds)->pluck('instructor_id')->unique();

                $semesters[] = $semester;
                $totals[] = $instructors->count();
            }

            return TermInstructorsChartDataDTO::fromTotals($totals, $semesters);

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     *
     * This function is the one we use to determine the number of combined sections in the last 6 terms
     */
    public function graphCombinedSectionsLastTerms(): TermInstructorsChartDataDTO
    {
        try {
            // Step 1: Bring the last 6 terms sorted by descending number
            $latestTerms = Term::orderByDesc('number')
                ->take(6)
                ->get();

            if ($latestTerms->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.termNotFound'));
            }

            $termIds = $latestTerms->pluck('id');

            // Step 2: Search for combined sections of those terms
            $sections = Section::whereIn('term_id', $termIds)
                ->where('combined', true)
                ->select('id', 'term_id')
                ->get();

            // Step 3: Group and count
            $totals = [];
            $semesters = [];

            foreach ($latestTerms as $term) {
                $semester = strtoupper(substr($term->semester, 0, 2)) . $term->year;

                $combinedCount = $sections->where('term_id', $term->id)->count();

                $semesters[] = $semester;
                $totals[] = $combinedCount;
            }

            // Step 4: Return the DTO
            return new TermInstructorsChartDataDTO(
                series: [
                    [
                        'name' => trans('dashboard/dashboard.graphic_combined_section'),
                        'data' => array_reverse($totals), // from oldest to newest
                    ]
                ],
                categories: array_reverse($semesters)
            );

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     *
     * This is the function we use to display the carousel in the CRM
     */
    public function termCarousel(): GraphTermInstructorCombinedDTO
    {
        try {
            $latestTerms = Term::with([
                'sections' => function ($q) {
                    $q->select('id', 'term_id', 'status');
                }
            ])
                ->orderBy('number', 'desc')
                ->limit(7)
                ->get()
                ->reverse()
                ->values();

            if ($latestTerms->isEmpty()) {
                throw new ResourceNotFoundException(trans('academic/section.exceptionNotFound'));
            }

            $currentTermData = CurrentTermHelper::getCurrentTermWithProgress($latestTerms);
            $currentTerm = $currentTermData['term'];

            $termsDTO = [];

            foreach ($latestTerms as $key => $term) {
                $sectionIds = $term->sections->pluck('id');

                // Eager load relations only for sections of this term
                $meetingPatterns = MeetingPattern::with(['facility', 'instructor.person'])
                    ->whereIn('section_id', $sectionIds)
                    ->get()
                    ->groupBy('section_id');

                $meetingPatternHybrids = MeetingPatternHybrid::with(['facility.facilityType', 'instructor.person'])
                    ->whereIn('section_id', $sectionIds)
                    ->get()
                    ->groupBy('section_id');

                $combinedSections = CombinedSection::with('combinedSection.course')
                    ->whereIn('section_id', $sectionIds)
                    ->get()
                    ->groupBy('section_id');

                $statesCount = [];
                $instructorIds = collect();

                foreach ($term->sections as $section) {
                    // Count states
                    $statesCount[$section->status] = ($statesCount[$section->status] ?? 0) + 1;

                    // Associate relationships to the section
                    $patterns = $meetingPatterns->get($section->id, collect());
                    $hybrids = $meetingPatternHybrids->get($section->id, collect());

                    // Get unique instructors
                    $instructorIds = $instructorIds
                        ->merge($patterns->pluck('instructor.person.id')->filter())
                        ->merge($hybrids->pluck('instructor.person.id')->filter());
                }

                $instructorCount = $instructorIds->unique()->count();

                // DTO data
                $termName = ucfirst($term->semester) . $term->year;
                $termStartDate = date('m/d/y', strtotime($term->begin_dt));
                $termEndDate = date('m/d/y', strtotime($term->end_dt));
                $isCurrentTerm = $currentTerm && $term->id === $currentTerm->id;

                $previousTerm = $latestTerms->get($key - 1);
                $sectionsIncrease = 0;
                $sectionsDecrease = 0;
                $increase = false;

                if ($previousTerm) {
                    $prevCount = $previousTerm->sections->count();
                    $diff = $term->sections->count() - $prevCount;
                    $increase = $diff > 0;
                    $sectionsIncrease = $increase ? $diff : 0;
                    $sectionsDecrease = !$increase ? abs($diff) : 0;
                }

                $statesArray = collect($statesCount)
                    ->map(fn($c, $s) => ['name' => $s, 'value' => $c])
                    ->values()
                    ->toArray();

                $termsDTO[] = new CarouselDTO(
                    name: $termName,
                    semester: strtolower(substr($term->semester, 0, 2)),
                    startDate: $termStartDate,
                    endDate: $termEndDate,
                    daysPassed: $isCurrentTerm ? $currentTermData['daysPassed'] : 0,
                    totalDays: $isCurrentTerm ? $currentTermData['totalDays'] : 0,
                    current: $isCurrentTerm,
                    sections: $term->sections->count(),
                    instructors: $instructorCount,
                    states: $statesArray,
                    remainingDays: $isCurrentTerm ? $currentTermData['remainingDays'] : 0,
                    progressValue: $isCurrentTerm ? $currentTermData['progress'] : 0,
                    quantity: [
                        'value' => $sectionsIncrease,
                        'increase' => $increase,
                        'decreaseValue' => $sectionsDecrease,
                    ],
                    sess: strtolower(trim($term->semester)) === 'summer'
                );
            }

            return new GraphTermInstructorCombinedDTO(terms: $termsDTO);

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function sectionsCountCurrentTerm(): array
    {
        $now = Carbon::now();

        $currentTerm = Term::where('begin_dt', '<=', $now)
            ->where('end_dt', '>=', $now)
            ->first();

        if (!$currentTerm) {
            return [
                'total' => 0,
                'graduate' => 0,
                'undergraduate' => 0,
            ];
        }

        $sectionsQuery = $currentTerm->sections();

        $total = $sectionsQuery->count();

        $graduate = $sectionsQuery
            ->whereHas('program.offering', function ($query) {
                $query->whereIn('code', ['GP', 'DP']);
            })
            ->count();

        $undergraduate = $sectionsQuery
            ->whereHas('program.offering', function ($query) {
                $query->whereIn('code', ['UP', 'UCA']);
            })
            ->count();

        return [
            'total' => $total,
            'graduate' => $graduate,
            'undergraduate' => $undergraduate,
        ];
    }

}
