<?php
//
//namespace App\Repositories\v1\support;
//
//// GLOBAL IMPORT
//use Exception;
//use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Log;
//use Symfony\Component\HttpFoundation\Response;
//use Illuminate\Contracts\Pagination\LengthAwarePaginator;
//
//// HELPER
//use App\Helpers\ActivityTimeLineHelper;
//
//// LOCAL IMPORT
//use App\Models\support\Ticket;
//use App\Exceptions\ResourceNotFoundException;
//
//class TicketRepository
//{
//    /**
//     * @throws Exception
//     */
//    public function viewAll(Request $request): LengthAwarePaginator
//    {
//        try {
//            $perPage = (int) $request->query('pageSize', 10);
//            $page = (int) $request->query('page', 1);
//
//            $search = $request->query('search');
//            $sortColumn = $request->query('sortColumn', 'created_at');
//            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'desc')));
//
//            if (!in_array($sortDirection, ['asc', 'desc'], true)) {
//                $sortDirection = 'desc';
//            }
//
//            $user = auth()->user();
//
//            $query = Ticket::query()
//                ->with(['user', 'assignee'])
//                ->withCount('messages');
//
//            // Security: non-admin user only sees their own tickets
//            if (!$this->isAdmin($user)) {
//                $query->where('user_id', $user->id);
//            }
//
//            // Optional filters
//            if ($request->filled('status')) {
//                $query->where('status', $request->query('status'));
//            }
//            if ($request->filled('priority')) {
//                $query->where('priority', $request->query('priority'));
//            }
//            if ($request->filled('category')) {
//                $query->where('category', $request->query('category'));
//            }
//            if ($request->filled('assigned_to')) {
//                $query->where('assigned_to', $request->query('assigned_to'));
//            }
//
//            // Search
//            if (!empty($search)) {
//                $s = strtolower($search);
//                $query->where(function ($q) use ($s) {
//                    $q->whereRaw('LOWER(subject) LIKE ?', ["%{$s}%"])
//                        ->orWhereRaw('LOWER(description) LIKE ?', ["%{$s}%"])
//                        ->orWhereRaw('LOWER(code) LIKE ?', ["%{$s}%"]);
//                });
//            }
//
//            // Sorting safe list
//            $sortable = ['code', 'subject', 'status', 'priority', 'category', 'created_at', 'updated_at', 'closed_at'];
//            if (!in_array($sortColumn, $sortable, true)) {
//                $sortColumn = 'created_at';
//                $sortDirection = 'desc';
//            }
//
//            $tickets = $query
//                ->orderBy($sortColumn, $sortDirection)
//                ->paginate($perPage, ['*'], 'page', $page);
//
//            if ($tickets->isEmpty()) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFound'));
//            }
//
//            return $tickets;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    /**
//     * @throws Exception
//     */
//    public function viewById(string $id): Ticket
//    {
//        try {
//            $ticket = Ticket::query()
//                ->with(['user', 'assignee', 'messages.user'])
//                ->withCount('messages')
//                ->find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $user = auth()->user();
//
//            // Security: non-admin cannot view tickets from another user
//            if (!$this->isAdmin($user) && $ticket->user_id !== $user->id) {
//                // Return as "not found" for better security
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            return $ticket;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    /**
//     * @throws Exception
//     */
//    public function create(array $request): ?object
//    {
//        try {
//            $ticket = new Ticket();
//            $newTicket = $this->dataFormat($request, $ticket);
//            $newTicket->save();
//
//            ActivityTimeLineHelper::store(
//                $newTicket->id,
//                'created',
//                'Ticket',
//                'Ticket created: ' . ($newTicket->code ?? $newTicket->id) . ' - ' . $newTicket->subject
//            );
//
//            return $newTicket;
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//
//    /**
//     * @throws Exception
//     */
//    public function update(string $id, array $request): ?object
//    {
//        try {
//            $ticket = Ticket::find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $ticket = $this->dataFormat($request, $ticket);
//            $ticket->update();
//
//            ActivityTimeLineHelper::store(
//                $ticket->id,
//                'updated',
//                'Ticket',
//                'Ticket updated: ' . ($ticket->code ?? $ticket->id) . ' - ' . $ticket->subject
//            );
//
//            return $ticket;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//
//    }
//
//
//    /**
//     * @throws Exception
//     */
//    public function assign(string $id, ?string $assignedTo): ?object
//    {
//        try {
//            $ticket = Ticket::find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $ticket->assigned_to = $assignedTo;
//            $ticket->save();
//
//            $assigneeLabel = $assignedTo ? $assignedTo : 'null';
//
//            ActivityTimeLineHelper::store(
//                $ticket->id,
//                'assigned',
//                'Ticket',
//                'Ticket assigned: ' . ($ticket->code ?? $ticket->id) . ' -> assigned_to: ' . $assigneeLabel
//            );
//
//            return $ticket;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//
//    /**
//     * @throws Exception
//     */
//    public function close(string $id, string $finalStatus = 'closed'): ?object
//    {
//        try {
//            $ticket = Ticket::find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $ticket->status = $finalStatus;
//            $ticket->closed_at = now();
//            $ticket->save();
//
//            ActivityTimeLineHelper::store(
//                $ticket->id,
//                'closed',
//                'Ticket',
//                'Ticket closed: ' . ($ticket->code ?? $ticket->id) . ' (status: ' . $finalStatus . ')'
//            );
//
//            return $ticket;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//
//    /**
//     * @throws Exception
//     */
//    public function reopen(string $id): ?object
//    {
//        try {
//            $ticket = Ticket::find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $ticket->status = 'open';
//            $ticket->closed_at = null;
//            $ticket->save();
//
//            ActivityTimeLineHelper::store(
//                $ticket->id,
//                'reopened',
//                'Ticket',
//                'Ticket reopened: ' . ($ticket->code ?? $ticket->id)
//            );
//
//            return $ticket;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//
//    /**
//     * @throws Exception
//     */
//    public function delete(string $id): bool
//    {
//        try {
//            $ticket = Ticket::find($id);
//
//            if (!$ticket) {
//                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
//            }
//
//            $code = $ticket->code ?? $ticket->id;
//            $subject = $ticket->subject;
//
//            $deleted = (bool) $ticket->delete();
//
//            if ($deleted) {
//                ActivityTimeLineHelper::store(
//                    $id,
//                    'deleted',
//                    'Ticket',
//                    'Ticket deleted: ' . $code . ' - ' . $subject
//                );
//            }
//
//            return $deleted;
//        } catch (ResourceNotFoundException $e) {
//            Log::error($e);
//            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
//        } catch (Exception $e) {
//            Log::error($e);
////            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    /**
//     * @throws Exception
//     */
//    public function dataFormat(array $request, Ticket $ticket): Ticket
//    {
//        try {
//            $ticket->code = $request['code'] ?? $ticket->code;
//            $ticket->subject = $request['subject'] ?? $ticket->subject;
//            $ticket->description = $request['description'] ?? $ticket->description;
//
//            $ticket->status = $request['status'] ?? $ticket->status ?? 'open';
//            $ticket->priority = $request['priority'] ?? $ticket->priority ?? 'medium';
//            $ticket->category = $request['category'] ?? $ticket->category;
//
//            $ticket->user_id = $request['user_id'] ?? $ticket->user_id ?? auth()->id();
//            $ticket->assigned_to = $request['assigned_to'] ?? $ticket->assigned_to;
//
//            if (array_key_exists('closed_at', $request)) {
//                $ticket->closed_at = $request['closed_at'];
//            }
//
//            return $ticket;
//        } catch (Exception $e) {
//            Log::error($e);
//            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }
//
//    private function isAdmin($user): bool
//    {
//        if (!$user) return false;
//
//        // Spatie roles
//        if (method_exists($user, 'hasRole')) {
//            return $user->hasRole('Administrator');
//        }
//
//        // Campo role simple
//        return ($user->role ?? null) === 'Administrator';
//    }
//
//}

//-----------------------------------------------


namespace App\Repositories\v1\support;

// GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// HELPER
use App\Helpers\ActivityTimeLineHelper;

// LOCAL IMPORT
use App\Models\support\Ticket;
use App\Models\support\DistributionList;
use App\Exceptions\ResourceNotFoundException;

// MAILER (listas de distribución)
use App\Services\Support\DistributionListMailer;

class TicketRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            $perPage = (int)$request->query('pageSize', 10);
            $page = (int)$request->query('page', 1);

            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'desc')));

            if (!in_array($sortDirection, ['asc', 'desc'], true)) {
                $sortDirection = 'desc';
            }

            $user = auth()->user();

            $query = Ticket::query()
                ->with(['user', 'assignee'])
                ->withCount('messages');

            // Security: non-admin user only sees their own tickets
            if (!$this->isAdmin($user)) {
                $query->where('user_id', $user->id);
            }

            // Optional filters
            if ($request->filled('status')) {
                $query->where('status', $request->query('status'));
            }
            if ($request->filled('priority')) {
                $query->where('priority', $request->query('priority'));
            }
            if ($request->filled('category')) {
                $query->where('category', $request->query('category'));
            }
            if ($request->filled('assigned_to')) {
                $query->where('assigned_to', $request->query('assigned_to'));
            }

            // Search
            if (!empty($search)) {
                $s = strtolower($search);
                $query->where(function ($q) use ($s) {
                    $q->whereRaw('LOWER(subject) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(description) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(code) LIKE ?', ["%{$s}%"]);
                });
            }

            // Sorting safe list
            $sortable = ['code', 'subject', 'status', 'priority', 'category', 'created_at', 'updated_at', 'closed_at'];
            if (!in_array($sortColumn, $sortable, true)) {
                $sortColumn = 'created_at';
                $sortDirection = 'desc';
            }

            $tickets = $query
                ->orderBy($sortColumn, $sortDirection)
                ->paginate($perPage, ['*'], 'page', $page);

            if ($tickets->isEmpty()) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFound'));
            }

            return $tickets;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById(string $id): Ticket
    {
        try {
            $ticket = Ticket::query()
                ->with(['user', 'assignee', 'messages.user'])
                ->withCount('messages')
                ->find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $user = auth()->user();

            // Security: non-admin cannot view tickets from another user
            if (!$this->isAdmin($user) && $ticket->user_id !== $user->id) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            return $ticket;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $ticket = new Ticket();
            $newTicket = $this->dataFormat($request, $ticket);
            $newTicket->save();

            ActivityTimeLineHelper::store(
                $newTicket->id,
                'created',
                'Ticket',
                'Ticket created: ' . ($newTicket->code ?? $newTicket->id) . ' - ' . $newTicket->subject
            );

            Log::info('TICKET MAIL: about to notify', [
                'ticket_id' => $newTicket->id,
                'category' => $newTicket->category,
            ]);

            $this->notifyDistributionListsByCategory($newTicket, 'created');

            Log::info('TICKET MAIL: notify finished', [
                'ticket_id' => $newTicket->id,
            ]);


//            // ✅ Notificación por lista de distribución (por categoría)
//            $this->notifyDistributionListsByCategory($newTicket, 'created');

            return $newTicket;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update(string $id, array $request): ?object
    {
        try {
            $ticket = Ticket::find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            // Guarda valores anteriores para comparar
            $old = [
                'subject' => $ticket->subject,
                'description' => $ticket->description,
                'status' => $ticket->status,
                'priority' => $ticket->priority,
                'category' => $ticket->category,
                'assigned_to' => $ticket->assigned_to,
            ];

            $ticket = $this->dataFormat($request, $ticket);

            // Detecta cambios importantes antes de guardar
            $dirty = $ticket->getDirty(); // campos cambiados
            $ticket->update();

            ActivityTimeLineHelper::store(
                $ticket->id,
                'updated',
                'Ticket',
                'Ticket updated: ' . ($ticket->code ?? $ticket->id) . ' - ' . $ticket->subject
            );

            // ✅ Notificación solo si cambió algo relevante
            $relevantKeys = ['subject', 'description', 'status', 'priority', 'category', 'assigned_to'];
            $relevantChanges = [];

            foreach ($relevantKeys as $k) {
                if (array_key_exists($k, $dirty)) {
                    $relevantChanges[$k] = [
                        'from' => $old[$k] ?? null,
                        'to' => $ticket->{$k},
                    ];
                }
            }

            if (!empty($relevantChanges)) {
                // Si cambió la categoría, notificamos a la NUEVA categoría
                $this->notifyDistributionListsByCategory($ticket, 'updated', $relevantChanges);
            }

            return $ticket;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Envia correo a TODAS las listas activas que coincidan con la categoría del ticket.
     * No rompe el flujo si el mail falla.
     */
    private function notifyDistributionListsByCategory(Ticket $ticket, string $event, array $changes = []): void
    {
        try {
            $category = (string)($ticket->category ?? '');

            if ($category === '') {
                return;
            }

            // Busca listas activas por categoría (pueden existir varias)
            $listIds = DistributionList::query()
                ->where('category', $category)
                ->where('is_active', true)
                ->pluck('id')
                ->all();

            if (empty($listIds)) {
                return;
            }

            /** @var DistributionListMailer $mailer */
            $mailer = app(DistributionListMailer::class);

            $code = $ticket->code ?? $ticket->id;

            // Payload para tu blade
            $meta = [
                'Code' => $code,
                'Subject' => $ticket->subject ?? '-',
                'Priority' => $ticket->priority ?? '-',
                'Status' => $ticket->status ?? '-',
                'Category' => $ticket->category ?? '-',
                'Created By' => $ticket->user?->name ?? $ticket->user?->email ?? '-',
                'Assigned To' => $ticket->assignee?->name ?? $ticket->assignee?->email ?? '-',
            ];

            // si es update, agrega cambios
            if (!empty($changes)) {
                foreach ($changes as $field => $delta) {
                    $meta['Changed: ' . $field] = ($delta['from'] ?? '-') . ' -> ' . ($delta['to'] ?? '-');
                }
            }

            // URL al frontend (ajusta a tu ruta real)
            $frontendUrl = config('app.frontend_url') ?: config('app.url');
            $ctaUrl = $frontendUrl ? rtrim($frontendUrl, '/') . '/support/ticket' : null;

            $subject = $event === 'created'
                ? "New Ticket: #{$code} - " . ($ticket->subject ?? '')
                : "Ticket Updated: #{$code} - " . ($ticket->subject ?? '');

            $payload = [
                'appName' => config('app.name'),
                'subtitle' => 'Support Notification',
                'title' => $event === 'created' ? 'New ticket created' : 'Ticket updated',
                'messageLine' => $event === 'created'
                    ? 'A new ticket has been created and requires attention.'
                    : 'A ticket has been updated. Please review the changes.',
                'meta' => $meta,
                'ctaUrl' => $ctaUrl,
                'ctaText' => 'View Tickets',
                'footerNote' => 'This email was sent automatically based on the ticket category distribution list.'
            ];

            foreach ($listIds as $listId) {
                $mailer->sendToList((string)$listId, $subject, $payload);
            }
        } catch (\Throwable $e) {
            // Importante: NO romper create/update si falla el mail
            Log::error('DistributionList email failed: ' . $e->getMessage(), [
                'ticket_id' => $ticket->id ?? null,
                'category' => $ticket->category ?? null,
                'event' => $event,
            ]);
        }
    }

    /**
     * @throws Exception
     */
    public function assign(string $id, ?string $assignedTo): ?object
    {
        try {
            $ticket = Ticket::find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $ticket->assigned_to = $assignedTo;
            $ticket->save();

            $assigneeLabel = $assignedTo ? $assignedTo : 'null';

            ActivityTimeLineHelper::store(
                $ticket->id,
                'assigned',
                'Ticket',
                'Ticket assigned: ' . ($ticket->code ?? $ticket->id) . ' -> assigned_to: ' . $assigneeLabel
            );

            return $ticket;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function close(string $id, string $finalStatus = 'closed'): ?object
    {
        try {
            $ticket = Ticket::find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $ticket->status = $finalStatus;
            $ticket->closed_at = now();
            $ticket->save();

            ActivityTimeLineHelper::store(
                $ticket->id,
                'closed',
                'Ticket',
                'Ticket closed: ' . ($ticket->code ?? $ticket->id) . ' (status: ' . $finalStatus . ')'
            );

            return $ticket;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function reopen(string $id): ?object
    {
        try {
            $ticket = Ticket::find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $ticket->status = 'open';
            $ticket->closed_at = null;
            $ticket->save();

            ActivityTimeLineHelper::store(
                $ticket->id,
                'reopened',
                'Ticket',
                'Ticket reopened: ' . ($ticket->code ?? $ticket->id)
            );

            return $ticket;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete(string $id): bool
    {
        try {
            $ticket = Ticket::find($id);

            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $code = $ticket->code ?? $ticket->id;
            $subject = $ticket->subject;

            $deleted = (bool)$ticket->delete();

            if ($deleted) {
                ActivityTimeLineHelper::store(
                    $id,
                    'deleted',
                    'Ticket',
                    'Ticket deleted: ' . $code . ' - ' . $subject
                );
            }

            return $deleted;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int)$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, Ticket $ticket): Ticket
    {
        try {
            $ticket->code = $request['code'] ?? $ticket->code;
            $ticket->subject = $request['subject'] ?? $ticket->subject;
            $ticket->description = $request['description'] ?? $ticket->description;

            $ticket->status = $request['status'] ?? $ticket->status ?? 'open';
            $ticket->priority = $request['priority'] ?? $ticket->priority ?? 'medium';
            $ticket->category = $request['category'] ?? $ticket->category;

            $ticket->user_id = $request['user_id'] ?? $ticket->user_id ?? auth()->id();
            $ticket->assigned_to = $request['assigned_to'] ?? $ticket->assigned_to;

            if (array_key_exists('closed_at', $request)) {
                $ticket->closed_at = $request['closed_at'];
            }

            return $ticket;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    private function isAdmin($user): bool
    {
        if (!$user) return false;

        // Spatie roles
        if (method_exists($user, 'hasRole')) {
            return $user->hasRole('Administrator');
        }

        // Campo role simple
        return ($user->role ?? null) === 'Administrator';
    }
}
