<?php

namespace App\Repositories\v1\support;

// GLOBAL IMPORT
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// HELPER
use App\Helpers\ActivityTimeLineHelper;

// LOCAL IMPORT
use App\Models\support\Ticket;
use App\Models\support\TicketMessage;
use App\Exceptions\ResourceNotFoundException;

class TicketMessageRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);

            $query = TicketMessage::query()
                ->with(['ticket', 'user'])
                ->orderBy('created_at', 'desc');

            if ($request->filled('ticket_id')) {
                $query->where('ticket_id', $request->query('ticket_id'));
            }
            if ($request->filled('user_id')) {
                $query->where('user_id', $request->query('user_id'));
            }

            $messages = $query->paginate($perPage, ['*'], 'page', $page);

            if ($messages->isEmpty()) {
                throw new ResourceNotFoundException(trans('support/ticket_message.exceptionNotFound'));
            }

            return $messages;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByTicket(Request $request, string $ticketId): LengthAwarePaginator
    {
        try {
            $perPage = (int) $request->query('pageSize', 20);
            $page = (int) $request->query('page', 1);

            $ticket = Ticket::find($ticketId);
            if (!$ticket) {
                throw new ResourceNotFoundException(trans('support/ticket.exceptionNotFoundById'));
            }

            $messages = TicketMessage::query()
                ->where('ticket_id', $ticketId)
                ->with(['user'])
                ->orderBy('created_at', 'asc')
                ->paginate($perPage, ['*'], 'page', $page);

            if ($messages->isEmpty()) {
                throw new ResourceNotFoundException(trans('support/ticket_message.exceptionNotFoundByTicket'));
            }

            return $messages;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById(string $id): TicketMessage
    {
        try {
            $message = TicketMessage::query()
                ->with(['ticket', 'user'])
                ->find($id);

            if (!$message) {
                throw new ResourceNotFoundException(trans('support/ticket_message.exceptionNotFoundById'));
            }

            return $message;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $message = new TicketMessage();
            $message = $this->dataFormat($request, $message);
            $message->save();

            ActivityTimeLineHelper::store(
                $message->id,
                'message_created',
                'TicketMessage',
                'Message created for ticket: ' . ($message->ticket_id ?? 'N/A')
            );

            return $message;
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function update(string $id, array $request): ?object
    {
        try {
            $message = TicketMessage::find($id);

            if (!$message) {
                throw new ResourceNotFoundException(trans('support/ticket_message.exceptionNotFoundById'));
            }

            $message = $this->dataFormat($request, $message);
            $message->update();

            ActivityTimeLineHelper::store(
                $message->id,
                'message_updated',
                'TicketMessage',
                'Message updated for ticket: ' . ($message->ticket_id ?? 'N/A')
            );

            return $message;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete(string $id): bool
    {
        try {
            $message = TicketMessage::find($id);

            if (!$message) {
                throw new ResourceNotFoundException(trans('support/ticket_message.exceptionNotFoundById'));
            }

            $ticketId = $message->ticket_id;

            $deleted = (bool) $message->delete();

            if ($deleted) {
                ActivityTimeLineHelper::store(
                    $id,
                    'message_deleted',
                    'TicketMessage',
                    'Message deleted for ticket: ' . ($ticketId ?? 'N/A')
                );
            }

            return $deleted;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function dataFormat(array $request, TicketMessage $message): TicketMessage
    {
        try {
            $message->ticket_id = $request['ticket_id'] ?? $message->ticket_id;
            $message->user_id = $request['user_id'] ?? $message->user_id ?? auth()->id();
            $message->message = $request['message'] ?? $message->message;

            if (array_key_exists('is_internal', $request)) {
                $message->is_internal = (bool) $request['is_internal'];
            }

            return $message;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
