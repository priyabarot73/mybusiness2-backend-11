<?php

namespace App\Repositories\v1\support;

// GLOBAL IMPORT
use App\Models\support\DistributionListRole;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// LOCAL IMPORT
use App\Models\User;
use App\Models\support\DistributionList;
use App\Models\support\DistributionListMember;
use App\Exceptions\ResourceNotFoundException;

class DistributionListRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);

            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = strtolower($request->query('sortDirection', $request->query('sort', 'desc')));

            if (!in_array($sortDirection, ['asc', 'desc'], true)) {
                $sortDirection = 'desc';
            }

            $query = DistributionList::query()
                ->withCount(['members', 'roles'])
                ->with(['members.user', 'roles.role']);


            if ($request->filled('category')) {
                $query->where('category', $request->query('category'));
            }
            if ($request->filled('is_active')) {
                $query->where('is_active', filter_var($request->query('is_active'), FILTER_VALIDATE_BOOLEAN));
            }

            if (!empty($search)) {
                $s = strtolower($search);
                $query->where(function ($q) use ($s) {
                    $q->whereRaw('LOWER(name) LIKE ?', ["%{$s}%"])
                        ->orWhereRaw('LOWER(category) LIKE ?', ["%{$s}%"]);
                });
            }

            $sortable = ['name', 'category', 'is_active', 'created_at', 'updated_at'];
            if (!in_array($sortColumn, $sortable, true)) {
                $sortColumn = 'created_at';
                $sortDirection = 'desc';
            }

            $lists = $query
                ->orderBy($sortColumn, $sortDirection)
                ->paginate($perPage, ['*'], 'page', $page);

            if ($lists->isEmpty()) {
                throw new ResourceNotFoundException(trans('support/distribution_list.exceptionNotFound'));
            }

            return $lists;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById(string $id): DistributionList
    {
        try {
            $list = DistributionList::query()
                ->with(['members.user', 'roles.role'])
                ->withCount(['members', 'roles'])
                ->find($id);

            if (!$list) {
                throw new ResourceNotFoundException(trans('support/distribution_list.exceptionNotFoundById'));
            }

            return $list;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        DB::beginTransaction();
        try {
            $list = new DistributionList();
            $list = $this->dataFormat($request, $list);
            $list->save();

            if (!empty($request['members']) && is_array($request['members'])) {
                $this->syncMembers($list->id, $request['members']);
            }

            if (!empty($request['roles']) && is_array($request['roles'])) {
                $this->syncRoles($list->id, $request['roles']);
            }

            DB::commit();
            return $this->viewById($list->id);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update(string $id, array $request): ?object
    {
        DB::beginTransaction();
        try {
            $list = DistributionList::find($id);

            if (!$list) {
                throw new ResourceNotFoundException(trans('support/distribution_list.exceptionNotFoundById'));
            }

            $list = $this->dataFormat($request, $list);
            $list->update();

            if (array_key_exists('members', $request) && is_array($request['members'])) {
                $this->syncMembers($id, $request['members']);
            }

            if (array_key_exists('roles', $request) && is_array($request['roles'])) {
                $this->syncRoles($id, $request['roles']);
            }


            DB::commit();
            return $this->viewById($id);
        } catch (ResourceNotFoundException $e) {
            DB::rollBack();
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            DB::rollBack();
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete(string $id): bool
    {
        try {
            $list = DistributionList::find($id);

            if (!$list) {
                throw new ResourceNotFoundException(trans('support/distribution_list.exceptionNotFoundById'));
            }

            return (bool) $list->delete();
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), (int) $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Total sync: leaves EXACTLY the members sent.
     * Expected structure:
     * members = [{ user_id: "...", is_active: true }, ...]
     *
     * @throws Exception
     */
    public function syncMembers(string $listId, array $members): void
    {
        // Normalize (unique by user_id)
        $unique = [];
        foreach ($members as $m) {
            $uid = $m['user_id'] ?? null;
            if ($uid) $unique[$uid] = $m;
        }
        $members = array_values($unique);

        // It brings in users to resolve email/name issues.
        $userIds = array_map(fn($m) => $m['user_id'], $members);
        $users = User::query()->whereIn('id', $userIds)->get()->keyBy('id');

        // Delete those that are no longer there.
        DistributionListMember::query()
            ->where('distribution_list_id', $listId)
            ->whereNotIn('user_id', $userIds)
            ->delete();

        foreach ($members as $m) {
            $uid = $m['user_id'];
            $user = $users->get($uid);

            $payload = [
                'distribution_list_id' => $listId,
                'user_id' => $uid,
                'email' => $user?->email,
                'full_name' => $user?->name ?? $user?->full_name ?? null,
                'is_active' => array_key_exists('is_active', $m) ? (bool)$m['is_active'] : true,
            ];

            DistributionListMember::query()->updateOrCreate(
                ['distribution_list_id' => $listId, 'user_id' => $uid],
                $payload
            );
        }
    }


    // Sync roles
    public function syncRoles(string $listId, array $roles): void
    {
        // Normaliza unique por role_id (string)
        $unique = [];
        foreach ($roles as $r) {
            $rid = $r['role_id'] ?? null;
            if (!empty($rid)) {
                $unique[(string) $rid] = $r;
            }
        }
        $roles = array_values($unique);

        // roleIds como UUID strings (NO int)
        $roleIds = array_map(fn($r) => (string) $r['role_id'], $roles);

        // Borra los que ya no están
        DistributionListRole::query()
            ->where('distribution_list_id', $listId)
            ->when(!empty($roleIds), function ($q) use ($roleIds) {
                $q->whereNotIn('role_id', $roleIds);
            }, function ($q) {
                // si viene vacío, borra todo
                $q->whereRaw('1=1');
            })
            ->delete();

        foreach ($roles as $r) {
            $rid = (string) $r['role_id'];

            DistributionListRole::query()->updateOrCreate(
                ['distribution_list_id' => $listId, 'role_id' => $rid],
                [
                    'distribution_list_id' => $listId,
                    'role_id' => $rid,
                    'is_active' => array_key_exists('is_active', $r) ? (bool) $r['is_active'] : true,
                ]
            );
        }
    }


    // Get active email addresses by category (for sending notifications)
    public function getActiveEmailsByCategory(string $category): array
    {
        // 1) Emails from direct members
        $memberEmails = DistributionListMember::query()
            ->whereHas('list', function ($q) use ($category) {
                $q->where('category', $category)->where('is_active', true);
            })
            ->where('is_active', true)
            ->whereNotNull('email')
            ->pluck('email')
            ->toArray();

        // 2) Active Role IDs linked to the list(s) in that category.
        $roleIds = DistributionListRole::query()
            ->whereHas('list', function ($q) use ($category) {
                $q->where('category', $category)->where('is_active', true);
            })
            ->where('is_active', true)
            ->pluck('role_id')
            ->unique()
            ->values()
            ->toArray();

        // 3) Emails of users who have any of those roles.
        $roleEmails = [];
        if (!empty($roleIds)) {
            $roleEmails = User::query()
                ->whereHas('roles', function ($q) use ($roleIds) {
                    $q->whereIn('id', $roleIds);
                })
                ->whereNotNull('email')
                ->pluck('email')
                ->toArray();
        }

        // 4) Merge + unique + limpiar
        return collect(array_merge($memberEmails, $roleEmails))
            ->filter()
            ->map(fn($e) => strtolower(trim($e)))
            ->unique()
            ->values()
            ->toArray();
    }


    /**
     * @throws Exception
     */
    private function dataFormat(array $request, DistributionList $list): DistributionList
    {
        try {
            $list->name = $request['name'] ?? $list->name;
            $list->category = $request['category'] ?? $list->category;
            $list->description = $request['description'] ?? $list->description;

            if (array_key_exists('is_active', $request)) {
                $list->is_active = (bool) $request['is_active'];
            } elseif ($list->is_active === null) {
                $list->is_active = true;
            }

            $list->created_by = $request['created_by'] ?? $list->created_by ?? auth()->id();

            return $list;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
