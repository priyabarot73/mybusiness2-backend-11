<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\Permission;
use App\Interfaces\CrudInterface;
use App\Exceptions\ResourceNotFoundException;

class PermissionRepository implements CrudInterface
{
    /**
     * @throws Exception
     */
    public function viewAll(): array
    {
        try {
            $permissions = Permission::with('roles.users')->get();
            if ($permissions->isEmpty()){
                throw new ResourceNotFoundException(trans('permission.exceptionNotFound'));
            }
            $permissionsArray = [];
            foreach ($permissions as $permission) {
                $roles = $permission->roles;
                $users = $roles->flatMap(function ($role) {
                    return $role->users;
                })->unique('id');
                $mappedUsers = $users->map(function ($user) {
                    return [
                        'user_name' => $user->name,
                        'avatar' => $user->avatar,
                        'panther_id' => $user->panther_id,
                    ];
                });

                $permissionObject = [
                    'id' => $permission->id,
                    'name' => $permission->name,
                    'created_at' => $permission? $permission->created_at->format('m/d/y'): null,
                    'updated_at' => $permission? $permission->updated_at->format('m/d/y'): null ,
                    'roles' => $roles->pluck('name')->toArray(),
                    'users' => $mappedUsers->toArray(),
                ];
                $permissionsArray[] = $permissionObject;
            }
            return $permissionsArray;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $permission = Permission::find($id);
            if (!$permission){
                throw new ResourceNotFoundException(trans('permission.exceptionNotFoundById'));
            }
            return $permission;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null
    {
        try {
            $newPermission = Permission::create($this->dataFormat($request, "create"));

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPermission->id,
                'created',
                'Permission',
                'A new permission was created: ' . $newPermission->name,
            );

            return $newPermission;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, array $request): object|null
    {
        try {
            $permission = $this->viewById($id);
            if (!$permission){
                throw new ResourceNotFoundException(trans('permission.exceptionNotFoundById'));
            }

            $permission->update($this->dataFormat($request));

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $permission->id,
                'updated',
                'Permission',
                'Permission was updated: ' . $permission->name,
            );

            return $permission;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $permission = $this->viewById($id);
            if (!$permission){
                throw new ResourceNotFoundException(trans('permission.exceptionNotFoundById'));
            }
            $permission->delete();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $permission->id,
                'deleted',
                'Permission',
                'A new permission was deleted: ' . $permission->name,
            );

            return $permission;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $data,string $type = null): array
    {
        if ($type){
            return [
                'name'=>$data['name'],
                'guard_name'=>$data['guard_name'],
                'created_at'=>Carbon::now()->format('m/d/y h:i:s'),
                'updated_at'=>Carbon::now()->format('m/d/y h:i:s'),
            ];
        }
        return [
            'name'=>$data['name'],
            'guard_name'=>$data['guard_name'],
            'created_at'=>$data['created_at'],
            'updated_at'=>Carbon::now()->format('m/d/y h:i:s'),
        ];
    }
}
