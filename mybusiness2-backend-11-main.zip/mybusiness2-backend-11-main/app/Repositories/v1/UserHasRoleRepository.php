<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Http\Requests\v1\UserHasRoleRequest;
use App\Models\Role;
use App\Models\User;

class UserHasRoleRepository
{
    /**
     * @throws Exception
     */
    public function viewAll(): JsonResponse
    {
        try {
            $users = User::all();
            $roles = Role::all();
            if (!$users || !$roles) {
                throw new ResourceNotFoundException(trans('user_has_role.exceptionNotFound'));
            }
            return response()->json([$users, $roles]);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById(string $id): JsonResponse
    {
        try {
            $roles = $this->viewUserById($id)->getRoleNames();
            if (!$roles){
                throw new ResourceNotFoundException(trans('user_has_role.exceptionNotFoundById'));
            }
            return response()->json($roles);
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function assignRoles(UserHasRoleRequest $request, string $id): string
    {
        try {
            if(!$this->viewUserById($id)->syncRoles($request['roles'])){
                throw new ResourceNotFoundException(trans('user_has_role.syncRolesWrong'));
            }
            return trans('user_has_role.syncRolesOk');
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function deleteRoles(UserHasRoleRequest $request, string $id): string
    {
        try {
            $value = "";
            foreach ($request['roles'] as $role) {
                if(!$this->viewUserById($id)->removeRole($role)){
                    throw new ResourceNotFoundException(trans('user_has_role.revokeRolesWrong'));
                }
                $value = trans('user_has_role.revokeRolesOk');
            }
            return $value;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


    /**
     * @throws Exception
     */
    public function viewUserById(string $id):?object
    {
        try {
            $user = User::find($id);
            if (!$user) {
                throw new ResourceNotFoundException(trans('user_has_role.exceptionNotFoundById'));
            }
            return $user;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}
