<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\general\Campus;
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Exceptions\ResourceNotFoundException;

class CampusRepository implements CrudInterface,ActiveInterface
{
    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $campus = Campus::where('gn.campuses.active','=',$status)->get();
            if ($campus->isEmpty()){
                throw new ResourceNotFoundException(trans('general/campus.exceptionNotFoundByStatus'));
            }
            return $campus;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $campus = Campus::orderBy('name', 'desc')->get();
            if ($campus->isEmpty()){
                throw new ResourceNotFoundException(trans('general/campus.exceptionNotFound'));
            }
            return $campus;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $campus = Campus::find($id);
            if (!$campus){
                throw new ResourceNotFoundException(trans('general/campus.exceptionNotFoundById'));
            }
            return $campus;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $campus = new Campus();
            $newCampus = $this->dataFormat($request,$campus);
            $newCampus->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCampus->id,
                'created',
                'Campus',
                'A new type of campus was created: ' . $newCampus->name,
            );

            return $newCampus;
        }  catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $campus = $this->viewById($id);
            if (!$campus){
                throw new ResourceNotFoundException(trans('general/campus.exceptionNotFoundById'));
            }
            $newCampus = $this->dataFormat($request,$campus);
            $newCampus->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCampus->id,
                'updated',
                'Campus',
                'Campus was updated: ' . $newCampus->name,
            );
            return $newCampus;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $campus = $this->viewById($id);
            if (!$campus){
                throw new ResourceNotFoundException(trans('general/campus.exceptionNotFoundById'));
            }
            $campus->delete();
            return $campus;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     */
    public function dataFormat(array $request, Campus $campus):object|null
    {
        $campus->code = $request['code'];
        $campus->name = $request['name'];
        $campus->active = $request['active'];
        return $campus;
    }
}
