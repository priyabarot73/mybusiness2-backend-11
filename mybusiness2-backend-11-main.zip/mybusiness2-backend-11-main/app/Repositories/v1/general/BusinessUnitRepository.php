<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\BusinessUnit;
use App\Exceptions\ResourceNotFoundException;

class BusinessUnitRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $businessUnit = BusinessUnit::orderBy('name', 'desc')
                ->with(['businessUnitType','academicGroup','jobTitle','person'])
                ->get();
            if ($businessUnit->isEmpty()){
                throw new ResourceNotFoundException(trans('general/business_unit.exceptionNotFound'));
            }
            return $businessUnit;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $businessUnit= BusinessUnit::where('active', $status)->orderBy('name','desc')
                ->get();
            if ($businessUnit->isEmpty()){
                throw new ResourceNotFoundException(trans('general/business_unit.exceptionNotFoundByStatus'));
            }
            return $businessUnit;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $businessUnit = new BusinessUnit();
            $newBusinessUnit = $this->dataFormat($request,$businessUnit);
            $newBusinessUnit->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newBusinessUnit->id,
                'created',
                'Business unit',
                'A new type of business unit was created: ' . $newBusinessUnit->name,
            );
            return $newBusinessUnit;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $businessUnit = BusinessUnit::find($id);
            if (!$businessUnit){
                throw new ResourceNotFoundException(trans('general/business_unit.exceptionNotFoundById'));
            }
            $newBusinessUnit = $this->dataFormat($request,$businessUnit);
            $newBusinessUnit->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newBusinessUnit->id,
                'updated',
                'Business unit',
                'Business unit was updated: ' . $newBusinessUnit->name,
            );
            return $newBusinessUnit;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, BusinessUnit $businessUnit):object|null
    {
        $businessUnit->code = $request['code'];
        $businessUnit->name = $request['name'];
        $businessUnit->business_unit_type_id = $request['business_unit_type_id'];
        $businessUnit->academic_group_id = $request['academic_group_id'];
        $businessUnit->job_title_id = $request['job_title_id'];
        $businessUnit->person_id = $request['person_id'];
        $businessUnit->active = $request['active'];
        return $businessUnit;
    }
}



