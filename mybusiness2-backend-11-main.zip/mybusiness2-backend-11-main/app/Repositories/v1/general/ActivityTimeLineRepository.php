<?php

namespace App\Repositories\v1\general;

// GLOBAL IMPORT
use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Log as LaravelLog;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

// LOCAL IMPORT
use App\Models\general\ActivityTimeLine;

class ActivityTimeLineRepository
{
    /**
     * @throws Exception
     */
    public function all(Request $request): LengthAwarePaginator
    {
        try {
            // pagination values
            $perPage = (int) $request->query('pageSize', 10);
            $page = (int) $request->query('page', 1);
            $search = $request->query('search');

            // FRONTEND sends sortColumn like: createdAt | category | action | description | fullName
            $sortColumn = $request->query('sortColumn', 'createdAt');
            $sortDirection = strtolower($request->query('sort', $request->query('sortDirection', 'desc')));

            if (!in_array($sortDirection, ['asc', 'desc'])) {
                $sortDirection = 'desc';
            }

            // filters (can be array OR json string)
            $filterModel = $request->query('filters'); // array|string|null
            if (is_string($filterModel) && $filterModel !== '') {
                $decoded = json_decode($filterModel, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $filterModel = $decoded;
                }
            }

            $query = ActivityTimeLine::query()->with('person');

            //  apply "search" (global)
            if (!empty($search)) {
                $s = strtolower(trim((string) $search));

                $query->where(function ($q) use ($s) {
                    // Direct fields in ActivityTimeLine
                    $q->whereRaw("LOWER(ISNULL(panther_id,'')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(ISNULL(action,'')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(ISNULL(category,'')) LIKE ?", ["%{$s}%"])
                        ->orWhereRaw("LOWER(ISNULL(description,'')) LIKE ?", ["%{$s}%"]);

                    // search by employee data (fullName column of the grid)
                    $q->orWhereHas('person', function ($p) use ($s) {
                        $p->whereRaw("LOWER(ISNULL(first_name,'')) LIKE ?", ["%{$s}%"])
                            ->orWhereRaw("LOWER(ISNULL(last_name,'')) LIKE ?", ["%{$s}%"])
                            ->orWhereRaw("LOWER(CONCAT(ISNULL(first_name,''), ' ', ISNULL(last_name,''))) LIKE ?", ["%{$s}%"])
                            ->orWhereRaw("LOWER(CONCAT(ISNULL(last_name,''), ' ', ISNULL(first_name,''))) LIKE ?", ["%{$s}%"])
                            ->orWhereRaw("LOWER(ISNULL(panther_id,'')) LIKE ?", ["%{$s}%"]);
                    });
                });
            }

            // apply filters (DataGrid)
            if (is_array($filterModel) && !empty($filterModel['items']) && is_array($filterModel['items'])) {

                $logic = strtolower($filterModel['logicOperator'] ?? 'and'); // and|or

                $makeLike = function ($v, $op) {
                    $v = strtolower(trim((string) $v));
                    return match ($op) {
                        'equals', '=', 'is' => $v,
                        'startsWith' => $v . '%',
                        'endsWith' => '%' . $v,
                        default => '%' . $v . '%', // contains
                    };
                };

                $query->where(function ($outer) use ($filterModel, $logic, $makeLike) {

                    foreach ($filterModel['items'] as $item) {
                        $field = $item['field'] ?? null;
                        $operator = $item['operator'] ?? 'contains';
                        $value = $item['value'] ?? null;

                        if (!$field) {
                            continue;
                        }

                        $noValueOps = ['isEmpty', 'isNotEmpty', 'isNull', 'isNotNull'];
                        if (!in_array($operator, $noValueOps) && ($value === null || $value === '')) {
                            continue;
                        }

                        $apply = function ($q) use ($field, $operator, $value, $makeLike) {

                            // map fields coming from frontend -> real backend columns/logic
                            // fullName = person fields (first_name, last_name, panther_id)
                            if ($field === 'fullName') {
                                if (in_array($operator, ['isEmpty', 'isNull'])) {
                                    return $q->whereDoesntHave('person');
                                }

                                if (in_array($operator, ['isNotEmpty', 'isNotNull'])) {
                                    return $q->whereHas('person');
                                }

                                $pattern = $makeLike($value, $operator);

                                return $q->whereHas('person', function ($p) use ($pattern, $value, $operator) {

                                    // equals exact (case-insensitive) vs like
                                    if (in_array($operator, ['equals', '=', 'is'])) {
                                        $exact = strtolower(trim((string) $value));
                                        $p->where(function ($x) use ($exact) {
                                            $x->whereRaw("LOWER(ISNULL(first_name,'')) = ?", [$exact])
                                                ->orWhereRaw("LOWER(ISNULL(last_name,'')) = ?", [$exact])
                                                ->orWhereRaw("LOWER(ISNULL(panther_id,'')) = ?", [$exact]);
                                        });
                                        return;
                                    }

                                    $p->where(function ($x) use ($pattern) {
                                        $x->whereRaw("LOWER(ISNULL(first_name,'')) LIKE ?", [$pattern])
                                            ->orWhereRaw("LOWER(ISNULL(last_name,'')) LIKE ?", [$pattern])
                                            ->orWhereRaw("LOWER(CONCAT(ISNULL(first_name,''), ' ', ISNULL(last_name,''))) LIKE ?", [$pattern])
                                            ->orWhereRaw("LOWER(CONCAT(ISNULL(last_name,''), ' ', ISNULL(first_name,''))) LIKE ?", [$pattern])
                                            ->orWhereRaw("LOWER(ISNULL(panther_id,'')) LIKE ?", [$pattern]);
                                    });
                                });
                            }

                            // createdAt (frontend) -> created_at (db)
                            if ($field === 'createdAt') {
                                if (in_array($operator, ['isEmpty', 'isNull'])) {
                                    return $q->whereNull('created_at');
                                }

                                if (in_array($operator, ['isNotEmpty', 'isNotNull'])) {
                                    return $q->whereNotNull('created_at');
                                }

                                if ($operator === 'equals') {
                                    return $q->whereDate('created_at', $value);
                                }

                                // fallback: contains sobre string
                                return $q->whereRaw("CAST(created_at AS VARCHAR(30)) LIKE ?", ["%{$value}%"]);
                            }

                            // fields in ActivityTimeLine: category, action, description
                            $directColumns = [
                                'category' => 'category',
                                'action' => 'action',
                                'description' => 'description',
                                'panther_id' => 'panther_id',
                            ];

                            if (isset($directColumns[$field])) {
                                $col = $directColumns[$field];

                                if (in_array($operator, ['isEmpty', 'isNull'])) {
                                    return $q->where(function ($z) use ($col) {
                                        $z->whereNull($col)->orWhere($col, '=', '');
                                    });
                                }

                                if (in_array($operator, ['isNotEmpty', 'isNotNull'])) {
                                    return $q->where(function ($z) use ($col) {
                                        $z->whereNotNull($col)->where($col, '!=', '');
                                    });
                                }

                                if (in_array($operator, ['equals', '=', 'is'])) {
                                    return $q->whereRaw("LOWER(ISNULL($col,'')) = ?", [strtolower(trim((string) $value))]);
                                }

                                $pattern = $makeLike($value, $operator);
                                return $q->whereRaw("LOWER(ISNULL($col,'')) LIKE ?", [$pattern]);
                            }

                            return $q;
                        };

                        if ($logic === 'or') {
                            $outer->orWhere(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        } else {
                            $outer->where(function ($sub) use ($apply) {
                                $apply($sub);
                            });
                        }
                    }
                });
            }

            // apply sorting
            $sortMap = [
                'createdAt' => 'created_at',
                'category' => 'category',
                'action' => 'action',
                'description' => 'description',
            ];

            $dbSort = $sortMap[$sortColumn] ?? 'created_at';
            $query->orderBy($dbSort, $sortDirection);

            return $query->paginate($perPage, ['*'], 'page', $page);

        } catch (Exception $e) {
            LaravelLog::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */

    public function getAllByActionRange(Request $request, string $actionId): Collection
    {
        try {
            $dateRange = $request->query('range');

            // Allowed range values
            $allowedRanges = ['Last 28 Days', 'Last Month', 'Last Year'];

            // Validate received range
            if ($dateRange && !in_array($dateRange, $allowedRanges)) {
                throw new Exception(trans('general/activity_time_line.range') . " $dateRange");
            }

            // Base query with relationship
            $queryBase = ActivityTimeLine::with('person')
                ->where('action_id', $actionId);

            // If no range is provided, return the 4 most recent records
            if (!$dateRange) {
                return $queryBase->latest()->take(4)->get();
            }

            // ------------------------------------------
            // 1) Apply the selected range
            // ------------------------------------------
            $query = clone $queryBase;

            switch ($dateRange) {
                case 'Last 28 Days':
                    // Records from the past 28 days
                    $query->whereBetween('created_at', [
                        Carbon::now()->subDays(28),
                        Carbon::now()
                    ]);
                    break;

                case 'Last Month':
                    // Records from the previous full calendar month
                    $query->whereBetween('created_at', [
                        Carbon::now()->subMonthNoOverflow()->startOfMonth(),
                        Carbon::now()->subMonthNoOverflow()->endOfMonth()
                    ]);
                    break;

                case 'Last Year':
                    // Records from the previous full calendar year
                    $query->whereBetween('created_at', [
                        Carbon::now()->subYear()->startOfYear(),
                        Carbon::now()->subYear()->endOfYear()
                    ]);
                    break;
            }

            // Execute the initial range query
            $results = $query->orderBy('created_at', 'desc')->get();

            // ------------------------------------------
            // 2) If no records found in the two first ranges,
            //    fallback to "Last Year"
            // ------------------------------------------
            if ($results->isEmpty() && in_array($dateRange, ['Last 28 Days', 'Last Month'])) {

                // Build fallback query
                $fallbackQuery = clone $queryBase;
                $fallbackQuery->whereBetween('created_at', [
                    Carbon::now()->subYear()->startOfYear(),
                    Carbon::now()->subYear()->endOfYear()
                ]);

                // Return fallback results
                return $fallbackQuery->orderBy('created_at', 'desc')->get();
            }

            // Return results from the requested range
            return $results;

        } catch (Exception $e) {
            // Throw generic exception message
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }


//    public function getAllByActionRange(Request $request, string $actionId)
//    {
//        try {
//            $dateRange = $request->query('range');
//
//            // Define allowed range values
//            $allowedRanges = ['Last 28 Days', 'Last Month', 'Last Year'];
//
//            // Validate range if provided
//            if ($dateRange && !in_array($dateRange, $allowedRanges)) {
//                throw new Exception(trans('general/activity_time_line.range') . " $dateRange");
//            }
//
//            $query = ActivityTimeLine::with('person')
//                ->where('action_id', $actionId);
//
//            // Apply range filter if valid
//            if ($dateRange) {
//                switch ($dateRange) {
//                    case 'Last 28 Days':
//                        $query->whereBetween('created_at', [
//                            Carbon::now()->subDays(28),
//                            Carbon::now()
//                        ]);
//                        break;
//
//                    case 'Last Month':
//                        $query->whereBetween('created_at', [
//                            Carbon::now()->subMonthNoOverflow()->startOfMonth(),
//                            Carbon::now()->subMonthNoOverflow()->endOfMonth()
//                        ]);
//                        break;
//
//                    case 'Last Year':
//                        $query->whereBetween('created_at', [
//                            Carbon::now()->subYear()->startOfYear(),
//                            Carbon::now()->subYear()->endOfYear()
//                        ]);
//                        break;
//                }
//
//                return $query->orderBy('created_at', 'desc')->get();
//            }
//
//            // Default: return the 4 most recent records
//            return $query->latest()->take(4)->get();
//
//        } catch (Exception $e) {
//            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
//        }
//    }

}
