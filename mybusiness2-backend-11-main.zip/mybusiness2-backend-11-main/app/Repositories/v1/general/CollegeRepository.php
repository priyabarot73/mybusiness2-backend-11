<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use App\Http\Requests\v1\general\CollegeRequest;
use App\Http\Requests\v1\hr\PersonRequest;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\general\College;
use App\Interfaces\ActiveInterface;
use App\Exceptions\ResourceNotFoundException;

class CollegeRepository implements ActiveInterface
{

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $colleges = College::where('gn.colleges.active','=',$status)->get();
            if ($colleges->isEmpty()){
                throw new ResourceNotFoundException(trans('general/college.exceptionNotFoundByStatus'));
            }
            return $colleges;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $colleges = College::orderBy('name','desc')->get();
            if ($colleges->isEmpty()){
                throw new ResourceNotFoundException(trans('general/college.exceptionNotFound'));
            }
            return $colleges;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $college = College::find($id);
            if (!$college){
                throw new ResourceNotFoundException(trans('general/college.exceptionNotFoundById'));
            }
            return $college;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(CollegeRequest $request): ?object
    {
        try {
            $college = new College();
            $newCollege = $this->dataFormat($request,$college);
            $newCollege->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCollege->id,
                'created',
                'College',
                'A new type of College was created: ' . $newCollege->name,
            );

            return $newCollege;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $college = $this->viewById($id);
            if (!$college){
                throw new ResourceNotFoundException(trans('general/college.exceptionNotFoundById'));
            }
            $newCollege = $this->dataFormat($request,$college);
            $newCollege->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newCollege->id,
                'updated',
                'College',
                'College was updated: ' . $newCollege->name,
            );

            return $newCollege;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $college = $this->viewById($id);
            if (!$college){
                throw new ResourceNotFoundException(trans('general/college.exceptionNotFoundById'));
            }
            $college->delete();
            return $college;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    function convertNull($value)
    {
        return $value === 'null' ? null : $value;
    }

    /**
     * @throws Exception
     */
    public function dataFormat($request, $college): College
    {
        try {
            // Upload logo LEFT
            $college->logo_left = $this->uploadImage(
                $request,
                $college->logo_left,
                'collegeLogos/left',   // folder
                'logo_left'            // input key (multipart)
            );

            // Upload logo RIGHT
            $college->logo_right = $this->uploadImage(
                $request,
                $college->logo_right,
                'collegeLogos/right',  // folder
                'logo_right'           // input key (multipart)
            );

            // campos normales
            $college->code   = $this->convertNull($request->input('code'));
            $college->name   = $this->convertNull($request->input('name'));
            $college->university_name   = $this->convertNull($request->input('university_name'));
            $college->state   = $this->convertNull($request->input('state'));
            $college->country   = $this->convertNull($request->input('country'));
            $college->email   = $this->convertNull($request->input('email'));
            $college->phone   = $this->convertNull($request->input('phone'));
            $college->address   = $this->convertNull($request->input('address'));
            $college->url    = $this->convertNull($request->input('url'));
            $college->active = $this->convertNull($request->input('active'));

            return $college;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @throws Exception
     */
    public function uploadImage(CollegeRequest $request, ?string $previousAvatar, string $path, string $fileKey): ?string
    {
        try {
            if ($request->hasFile($fileKey)) {

                // Create directory if it does not exist
                if (!Storage::disk('public')->exists($path)) {
                    Storage::disk('public')->makeDirectory($path, 0775, true);
                }

                // Delete previous image if it exists
                if ($previousAvatar && Storage::disk('public')->exists($previousAvatar)) {
                    Storage::disk('public')->delete($previousAvatar);
                }

                // Save new image
                $image = $request->file($fileKey);
                $filename = Str::uuid() . '.' . $image->extension();
                $image->storeAs($path, $filename, 'public');

                return $path . '/' . $filename;
            }

            // If there is no new file, return the previous one
            return $previousAvatar;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), 500);
        }
    }
}
