<?php

namespace App\Repositories\v1\general;

// GLOBAL IMPORT
use Exception;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Pagination\LengthAwarePaginator;

// LOCAL IMPORT
use App\Models\general\ImportJob;
use App\Exceptions\ResourceNotFoundException;

class ImportJobRepository
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(Request $request): LengthAwarePaginator
    {
        try {
            // Get pagination values
            $perPage = $request->query('pageSize', 10);
            $page = $request->query('page', 1);
            $search = $request->query('search');
            $sortColumn = $request->query('sortColumn', 'created_at');
            $sortDirection = $request->query('sortDirection', 'desc');

            $query = ImportJob::query();

            // Search filter
            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where('file_name', 'like', "%$search%")
                        ->orWhere('file_path', 'like', "%$search%");
                });
            }

            // Ordering
            if (in_array($sortColumn, ['file_name', 'file_path', 'scheduled_time', 'created_at'])) {
                $query->orderBy($sortColumn, $sortDirection);
            } else {
                $query->orderBy('created_at', 'desc');
            }

            $results = $query->paginate($perPage, ['*'], 'page', $page);

            if ($results->isEmpty()) {
                throw new ResourceNotFoundException(trans('general/import_job.not_found'));
            }

            // Format scheduled_time as "H:i" (e.g. "23:00")
            $results->getCollection()->transform(function ($item) {
                $item->scheduled_time = Carbon::parse($item->scheduled_time)->format('H:i');
                return $item;
            });

            return $results;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $importJob = new ImportJob();
            $newImportJob = $this->dataFormat($request, $importJob);
            $newImportJob->save();
            return $newImportJob;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('general/import_jobs.error'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $importJob = ImportJob::find($id);
            if (!$importJob) {
                throw new ResourceNotFoundException(trans('general/import_job.not_found'));
            }
            $newImportJob = $this->dataFormat($request, $importJob);
            $newImportJob->update();
            return $newImportJob;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, ImportJob $importJob): object|null
    {
        $importJob->file_path = $request['file_path'];
        $importJob->file_name = $request['file_name'];
        $importJob->scheduled_time = $request['scheduled_time'];
        return $importJob;
    }
}
