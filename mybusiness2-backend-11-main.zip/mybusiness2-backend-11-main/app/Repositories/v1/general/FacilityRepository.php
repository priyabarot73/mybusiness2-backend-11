<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\general\Facility;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
class FacilityRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{


    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $facilities = Facility::with(['building','academicGroup','facilityType'])
                ->orderBy('code','desc')->get();
            if ($facilities->isEmpty()){
                throw new ResourceNotFoundException(trans('general/facility.exceptionNotFound'));
            }
            return $facilities;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $facilities = Facility::where('gn.facilities.active','=',$status)->get();
            if ($facilities->isEmpty()){
                throw new ResourceNotFoundException(trans('general/facility.exceptionNotFoundByStatus'));
            }
            return $facilities;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $facility = Facility::find($id);
            if (!$facility){
                throw new ResourceNotFoundException(trans('general/facility.exceptionNotFoundById'));
            }
            return $facility;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $facility = new Facility();
            $newFacility = $this->dataFormat($request,$facility);
            $newFacility->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newFacility->id,
                'created',
                'Facility',
                'A new type of Facility was created: ' . $newFacility->name,
            );

            return $newFacility;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $facility = $this->viewById($id);
            if (!$facility){
                throw new ResourceNotFoundException(trans('general/facility.exceptionNotFoundById'));
            }
            $newFacility = $this->dataFormat($request,$facility);
            $newFacility->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newFacility->id,
                'updated',
                'Facility',
                'Facility was updated: ' . $newFacility->name,
            );

            return $newFacility;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Facility $facility):object|null
    {
        $facility->code = $request['code'];
        $facility->floor = $request['floor'];
        $facility->room = $request['room'];
        $facility->capacity = $request['capacity'];
        $facility->address = $request['address'];
        $facility->description = $request['description'];
        $facility->academic_group_id = $request['academic_group_id'];
        $facility->facility_type_id = $request['facility_type_id'];
        $facility->building_id = $request['building_id'];
        $facility->active = $request['active'];
        return $facility;
    }
}
