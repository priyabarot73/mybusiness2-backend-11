<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Exceptions\ResourceNotFoundException;
use App\Models\general\Country;

class CountryRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $countries = Country::orderBy('country_desc', 'asc')->get();

            if ($countries->isEmpty()) {
                throw new ResourceNotFoundException(trans('general/country.exceptionNotFound'));
            }

            return $countries;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $countries = Country::where('active', $status)
                ->orderBy('country_desc', 'asc')
                ->get();

            if ($countries->isEmpty()) {
                throw new ResourceNotFoundException(trans('general/country.exceptionNotFoundByStatus'));
            }

            return $countries;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Used by your controller's showCountry(id)
     *
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewById($id): object
    {
        try {
            $country = Country::find($id);

            if (!$country) {
                throw new ResourceNotFoundException(trans('general/country.exceptionNotFoundById'));
            }

            return $country;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $country = new Country();
            $newCountry = $this->dataFormat($request, $country);
            $newCountry->save();

            ActivityTimeLineHelper::store(
                $newCountry->id,
                'created',
                'Country',
                'A new Country was created: ' . $newCountry->country_desc,
            );

            return $newCountry;

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $country = Country::find($id);

            if (!$country) {
                throw new ResourceNotFoundException(trans('general/country.exceptionNotFoundById'));
            }

            $newCountry = $this->dataFormat($request, $country);
            $newCountry->update();

            ActivityTimeLineHelper::store(
                $newCountry->id,
                'updated',
                'Country',
                'Country was updated: ' . $newCountry->country_desc,
            );

            return $newCountry;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Used by your controller's deleteCountry(id)
     *
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $country = Country::find($id);

            if (!$country) {
                throw new ResourceNotFoundException(trans('general/country.exceptionNotFoundById'));
            }

            $country->delete();
            return $country;

        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(), $e->getCode());

        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Country $country): object|null
    {
        $country->country_code       = $request['country_code'] ?? $country->country_code;
        $country->country_short_code = $request['country_short_code'] ?? $country->country_short_code;
        $country->country_desc       = $request['country_desc'] ?? $country->country_desc;
        $country->country_short_desc = $request['country_short_desc'] ?? $country->country_short_desc;
        $country->active             = $request['active'] ?? $country->active;

        return $country;
    }
}
