<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\FacilityType;
use App\Exceptions\ResourceNotFoundException;

class FacilityTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $facility = FacilityType::orderBy('name', 'desc')->get();
            if ($facility->isEmpty()){
                throw new ResourceNotFoundException(trans('general/facility_type.exceptionNotFound'));
            }
            return $facility;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $facility= FacilityType::where('active', $status)->orderBy('name','desc')->get();
            if ($facility->isEmpty()){
                throw new ResourceNotFoundException(trans('general/facility_type.exceptionNotFoundByStatus'));
            }
            return $facility;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $facility = new FacilityType();
            $newFacility = $this->dataFormat($request,$facility);
            $newFacility->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newFacility->id,
                'created',
                'Facility type',
                'A new type of Facility type was created: ' . $newFacility->name,
            );

            return $newFacility;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $facility = FacilityType::find($id);
            if (!$facility){
                throw new ResourceNotFoundException(trans('general/facility_type.exceptionNotFoundById'));
            }
            $newFacility = $this->dataFormat($request,$facility);
            $newFacility->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newFacility->id,
                'updated',
                'Facility type',
                'Facility type was updated: ' . $newFacility->name,
            );

            return $newFacility;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, FacilityType $facility):object|null
    {
        $facility->code = $request['code'];
        $facility->name = $request['name'];
        $facility->active = $request['active'];
        return $facility;
    }
}
