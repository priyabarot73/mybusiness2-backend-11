<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT

use Exception;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\BusinessUnitType;
use App\Exceptions\ResourceNotFoundException;

class BusinessUnitTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $unitType = BusinessUnitType::orderBy('name', 'desc')->get();
            if ($unitType->isEmpty()){
                throw new ResourceNotFoundException(trans('general/business_unit_type.exceptionNotFound'));
            }
            return $unitType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $unitType= BusinessUnitType::where('active', $status)->orderBy('name','desc')->get();
            if ($unitType->isEmpty()){
                throw new ResourceNotFoundException(trans('general/business_unit_type.exceptionNotFoundByStatus'));
            }
            return $unitType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $unitType = new BusinessUnitType();
            $newUnitType = $this->dataFormat($request,$unitType);
            $newUnitType->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newUnitType->id,
                'created',
                'Business unit type',
                'A new type of business unit was created: ' . $newUnitType->name,
            );

            return $newUnitType;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $unitType = BusinessUnitType::find($id);
            if (!$unitType){
                throw new ResourceNotFoundException(trans('general/business_unit_type.exceptionNotFoundById'));
            }
            $newUnitType = $this->dataFormat($request,$unitType);
            $newUnitType->update();

            // Store log
            ActivityTimeLineHelper::store(
                $newUnitType->id,
                'updated',
                'Business unit type',
                'Business unit was updated: ' . $newUnitType->name,
            );
            return $newUnitType;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, BusinessUnitType $unitType):object|null
    {
        $unitType->level = $request['level'];
        $unitType->code = $request['code'];
        $unitType->name = $request['name'];
        $unitType->active = $request['active'];
        return $unitType;
    }
}

