<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\general\Building;
use App\Interfaces\CrudInterface;
use App\Interfaces\ActiveInterface;
use App\Exceptions\ResourceNotFoundException;

class BuildingRepository implements CrudInterface,ActiveInterface
{

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $buildings = Building::where('gn.buildings.active','=',$status)->get();
            if ($buildings->isEmpty()){
                throw new ResourceNotFoundException(trans('general/building.exceptionNotFoundByStatus'));
            }
            return $buildings;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $buildings = Building::with('campus')->orderBy('name','desc')->get();
            if ($buildings->isEmpty()){
                throw new ResourceNotFoundException(trans('general/building.exceptionNotFound'));
            }
            return $buildings;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $building = Building::find($id);
            if (!$building){
                throw new ResourceNotFoundException(trans('general/building.exceptionNotFoundById'));
            }
            return $building;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $building = new Building();
            $newBuilding = $this->dataFormat($request,$building);
            $newBuilding->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newBuilding->id,
                'created',
                'Building',
                'A new type of Building was created: ' . $newBuilding->name,
            );

            return $newBuilding;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $building = $this->viewById($id);
            if (!$building){
                throw new ResourceNotFoundException(trans('general/building.exceptionNotFoundById'));
            }
            $newBuilding = $this->dataFormat($request,$building);
            $newBuilding->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newBuilding->id,
                'updated',
                'Building',
                'Building was updated: ' . $newBuilding->name,
            );

            return $newBuilding;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $building = $this->viewById($id);
            if (!$building){
                throw new ResourceNotFoundException(trans('general/building.exceptionNotFoundById'));
            }
            $building->delete();
            return $building;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('message.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Building $building):object|null
    {
        $building->code = $request['code'];
        $building->name = $request['name'];
        $building->campus_id = $request['campus_id'];
        $building->active = $request['active'];
        return $building;
    }
}
