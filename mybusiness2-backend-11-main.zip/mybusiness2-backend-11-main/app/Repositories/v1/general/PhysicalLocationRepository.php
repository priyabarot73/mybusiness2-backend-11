<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\PhysicalLocation;
use App\Exceptions\ResourceNotFoundException;
class PhysicalLocationRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $physicalLocation = PhysicalLocation::orderBy('name', 'desc')->get();
            if ($physicalLocation->isEmpty()){
                throw new ResourceNotFoundException(trans('general/physical_location.not_found'));
            }
            return $physicalLocation;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $physicalLocation= PhysicalLocation::where('active', $status)->orderBy('name','desc')->get();
            if ($physicalLocation->isEmpty()){
                throw new ResourceNotFoundException(trans('general/physical_location.status'));
            }
            return $physicalLocation;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $physicalLocation = new PhysicalLocation();
            $newPhysicalLocation  = $this->dataFormat($request,$physicalLocation);
            $newPhysicalLocation ->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPhysicalLocation ->id,
                'created',
                'Physical location',
                'A new type of Physical location was created: ' . $newPhysicalLocation ->name,
            );

            return $newPhysicalLocation ;
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $physicalLocation = PhysicalLocation::find($id);
            if (!$physicalLocation){
                throw new ResourceNotFoundException(trans('general/physical_location.id'));
            }
            $newPhysicalLocation = $this->dataFormat($request,$physicalLocation);
            $newPhysicalLocation->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newPhysicalLocation ->id,
                'updated',
                'Physical location',
                'Physical location was updated: ' . $newPhysicalLocation ->name,
            );

            return $newPhysicalLocation;
        } catch (ResourceNotFoundException $e) {
             Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
             Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, PhysicalLocation $physicalLocation):object|null
    {
        $physicalLocation->name = $request['name'];
        $physicalLocation->description = $request['description'];
        $physicalLocation->short_description = $request['short_description'];
        $physicalLocation->address = $request['address'];
        $physicalLocation->city = $request['city'];
        $physicalLocation->zip_code = $request['zip_code'];
        $physicalLocation->active = $request['active'];
        return $physicalLocation;
    }
}
