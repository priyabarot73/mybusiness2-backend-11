<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\Department;
use App\Exceptions\ResourceNotFoundException;
class DepartmentRepository  implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws Exception
     */
    public function viewAll()
    {
        try {
            $departments = Department::with(['businessUnit','person','jobTitle','parentDepartment','childDepartments','academicOrganization','academicGroup'])->orderBy('name','desc')->get();
            if ($departments->isEmpty()){
                throw new ResourceNotFoundException(trans('general/department.exceptionNotFound'));
            }
            return $departments;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $departments = Department::where('gn.departments.active','=',$status)
                ->with(['parentDepartment','childDepartments'])
                ->get();
            if ($departments->isEmpty()){
                throw new ResourceNotFoundException(trans('general/department.exceptionNotFoundByStatus'));
            }
            return $departments;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function viewById($id)
    {
        try {
            $department = Department::find($id);
            if (!$department){
                throw new ResourceNotFoundException(trans('general/department.exceptionNotFoundById'));
            }
            return $department;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): ?object
    {
        try {
            $department = new Department();
            $newDepartment = $this->dataFormat($request,$department);
            $newDepartment->save();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newDepartment->id,
                'created',
                'Department',
                'A new type of Department was created: ' . $newDepartment->name,
            );

            return $newDepartment;
        } catch (Exception $e){
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function update($id, $request): object|null
    {
        try {
            $department = $this->viewById($id);
            if (!$department){
                throw new ResourceNotFoundException(trans('general/department.exceptionNotFoundById'));
            }
            $newDepartment = $this->dataFormat($request,$department);
            $newDepartment->update();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $newDepartment->id,
                'updated',
                'Department',
                'Department was updated: ' . $newDepartment->name,
            );

            return $newDepartment;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
//            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function delete($id): object|null
    {
        try {
            $department = $this->viewById($id);
            if (!$department){
                throw new ResourceNotFoundException(trans('general/department.exceptionNotFoundById'));
            }
            $department->delete();
            return $department;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, Department $department):object|null
    {
        $department->number = $request['number'];
        $department->name = $request['name'];
        $department->description = $request['description'];
        $department->business_unit_id = $request['business_unit_id'];
        $department->person_id = $request['person_id'];
        $department->job_title_id = $request['job_title_id'];
        $department->academic_organization_id = $request['academic_organization_id'];
        $department->academic_group_id = $request['academic_group_id'];
        $department->parent_department_id = $request['parent_department_id'];
        $department->active = $request['active'];
        return $department;
    }
}
