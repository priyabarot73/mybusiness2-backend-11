<?php

namespace App\Repositories\v1\general;

//GLOBAL IMPORT
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\general\AcademicGroup;
use App\Exceptions\ResourceNotFoundException;

class AcademicGroupRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{
    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAll(): Collection
    {
        try {
            $academicGroup = AcademicGroup::orderBy('name', 'desc')->get();
            if ($academicGroup->isEmpty()){
                throw new ResourceNotFoundException(trans('general/academic_group.not_found'));
            }
            return $academicGroup;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function viewAllByStatus($status)
    {
        try {
            $academicGroup= AcademicGroup::where('active', $status)->orderBy('name','desc')->get();
            if ($academicGroup->isEmpty()){
                throw new ResourceNotFoundException(trans('general/academic_group.status'));
            }
            return $academicGroup;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function create(array $request): object|null|array
    {
        try {
            $academicGroup = new AcademicGroup();
            $newAcademicGroup = $this->dataFormat($request,$academicGroup);
            $newAcademicGroup->save();

            ActivityTimeLineHelper::store(
                $newAcademicGroup->id,
                'created',
                'Academic Group',
                'A new type of academic group was created: ' . $newAcademicGroup->name,
            );
            return $newAcademicGroup;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function update($id, array $request): object|null|array
    {
        try {
            $academicGroup = AcademicGroup::find($id);
            if (!$academicGroup){
                throw new ResourceNotFoundException(trans('general/academic_group.id'));
            }
            $newAcademicGroup = $this->dataFormat($request,$academicGroup);
            $newAcademicGroup->update();

            ActivityTimeLineHelper::store(
                $newAcademicGroup->id,
                'updated',
                'Academic Group',
                'Academic group was updated: ' . $newAcademicGroup->name,
            );
            return $newAcademicGroup;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function dataFormat(array $request, AcademicGroup $academicGroup):object|null
    {
        $academicGroup->code = $request['code'];
        $academicGroup->name = $request['name'];
        $academicGroup->description = $request['description'];
        $academicGroup->active = $request['active'];
        return $academicGroup;
    }
}


