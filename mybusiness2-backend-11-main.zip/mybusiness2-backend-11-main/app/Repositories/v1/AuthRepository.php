<?php

namespace  App\Repositories\v1;

//GLOBAL IMPORT
use DOMXPath;
use Exception;
use DOMDocument;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\QueryException;
use Laravel\Passport\PersonalAccessTokenResult;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;

// helper
use App\Helpers\ActivityTimeLineHelper;

//LOCAL IMPORT
use App\Models\User;
use App\Exceptions\ResourceNotFoundException;

class AuthRepository
{
    /**
     * @throws Exception
     */
    public function login(array $data): ?User
    {
        try {
            $user =  User::where('panther_id', $data['panther_id'])
                ->where('active','=', true)
                ->with(['roles.permissions', 'permissions'])
                ->first();

            // Store activity timeline
            ActivityTimeLineHelper::store(
                $user->id,
                'login',
                'User',
                'User was login-in: ' . $user->panther_id,
            );

            if (!$user) {
                throw new Exception(trans('auth.user'), response::HTTP_NOT_FOUND);
            }
            $user->accessToken = $this->createAuthToken($user)->accessToken;
            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (QueryException $e){
            Log::error($e);
            throw new HttpException($e->getMessage(),response::HTTP_INTERNAL_SERVER_ERROR);
        }
        catch (Exception $e){
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws ResourceNotFoundException
     * @throws Exception
     */
    public function loginDemo(array $data): ?User
    {
        try {

            $user =  User::where('panther_id', $data['panther_id'])
                ->where('active','=', true)
                ->with(['roles.permissions', 'permissions'])
                ->first();

            if (!$user || !Hash::check($data['password'], $user->password)) {
                throw new Exception(trans('auth.user'), response::HTTP_NOT_FOUND);
            }

            $user->accessToken = $this->createAuthToken($user)->accessToken;

            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (QueryException $e){
            Log::error($e);
            throw new HttpException($e->getMessage(),response::HTTP_INTERNAL_SERVER_ERROR);
        }
        catch (Exception $e){
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function register(array $data): array
    {
        $user = User::create($this->dataForRegister($data));
        if (!$user) {
            throw new Exception("Sorry, user does not registered. Please try again.", response::HTTP_INTERNAL_SERVER_ERROR);
        }
        $tokenInstance = $this->createAuthToken($user);

        // Store activity timeline
        ActivityTimeLineHelper::store(
            $user->id,
            'created',
            'User',
            'User was created: ' . $user->panther_id,
        );

        return $this->getAuthData($user, $tokenInstance,null,null);
    }

    /**
     * @throws Exception
     */
    public function profile():?Object
    {
        $data = Auth::guard()->user();
        if (!$data){
            throw new Exception("asasas", response::HTTP_INTERNAL_SERVER_ERROR);
        }
        return $data;
    }

    public function createAuthToken(User $user): PersonalAccessTokenResult
    {
        return $user->createToken('authToken');
    }

    public function getAuthData(User $user, PersonalAccessTokenResult $tokenInstance, $roles, $permission): array
    {
        return [
            'user'         => $user,
            'roles'        => $roles,
            'permissions'  => $permission,
            'access_token' => $tokenInstance->accessToken,
            'token_type'   => 'Bearer',
            'expires_at'   => Carbon::parse($tokenInstance->token->expires_at)->toDateTimeString()
        ];
    }
    public function dataForRegister(array $data): array
    {
        return [
            'name'=>$data['name'],
            'email'=>$data['email'],
            'password'=>Hash::make($data['password']),
            'panther_id'=>$data['panther_id'],
            'avatar'=>$data['avatar'],
            'active'=>$data['active']
        ];
    }

    /**
     * @throws Exception
     */
    public function verifyAuthenticatedToken($request): ?User
    {
        try {
            $user = User::with(['roles.permissions', 'permissions'])
                ->where('id', optional(Auth::guard('api')->user())->id)
                ->first();

            if (!$user) {
                throw new Exception("Sorry, user does not exist.", response::HTTP_NOT_FOUND);
            }
            $user->accessToken = str_replace('Bearer ', '', $request->header('Authorization'));

            return $user;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e){
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @throws Exception
     */
    public function validateCasTicket(Request $request): User|string|array|null
    {
        $user=null;
        $casServerPath = config('auth.urlValidateTicketCas');
        $ticket = $request->input('ticket');
        $service = $request->input('service');

        if (empty($ticket) || empty($service)) {
            throw new Exception(trans('auth.required'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
        $validateUrl = $casServerPath . '?service=' . urlencode($service) . '&ticket=' . urlencode($ticket);

        try {
            $response = Http::get($validateUrl);
            if ($response->ok()){

                // Create a new DOMDocument and load the XML response
                $dom = new DOMDocument();
                $dom->loadXML($response->body());

                // Create a new XPath and register the namespace
                $xpath = new DOMXPath($dom);
                $xpath->registerNamespace('cas', 'http://www.yale.edu/tp/cas');

                // Extract the data using XPath
                $userData = [
                    'user' => $xpath->query('//cas:user')->item(0)->nodeValue ?? null,
                    'firstname' => $xpath->query('//cas:firstname')->item(0)->nodeValue ?? null,
                    'department_number' => $xpath->query('//cas:department_number')->item(0)->nodeValue ?? null,
                    'lastname' => $xpath->query('//cas:lastname')->item(0)->nodeValue ?? null,
                    'panther_id' => $xpath->query('//cas:pantherid')->item(0)->nodeValue ?? null,
                    'organization' => $xpath->query('//cas:organization')->item(0)->nodeValue ?? null,
                    'department' => $xpath->query('//cas:department')->item(0)->nodeValue ?? null,
                    'email' => $xpath->query('//cas:email')->item(0)->nodeValue ?? null,
                    'username' => $xpath->query('//cas:username')->item(0)->nodeValue ?? null,
                ];
                Log::info($userData['firstname'].' '.$userData['panther_id'].' '.$userData['lastname'].' '.$userData['email']);
                $user = $this->login($userData);

            }
            return $user;
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception($e->getMessage(), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
}

