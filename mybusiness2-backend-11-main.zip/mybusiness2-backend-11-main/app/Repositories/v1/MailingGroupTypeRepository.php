<?php

namespace App\Repositories\v1;

//GLOBAL IMPORT
use App\Exceptions\ResourceNotFoundException;
use App\Interfaces\ActiveInterface;
use App\Interfaces\CreateInterface;
use App\Interfaces\UpdateInterface;
use App\Interfaces\ViewAllInterface;
use App\Models\MailingGroupType;
use Exception;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

//LOCAL IMPORT


class MailingGroupTypeRepository implements ViewAllInterface, CreateInterface, ActiveInterface, UpdateInterface
{

    public function viewAll()
    {
        try {
            $mailingGroupTypes = MailingGroupType::orderBy('name')->get();
            if ($mailingGroupTypes->isEmpty()){
                throw new ResourceNotFoundException(trans('mailing_group_type.exceptionNotFound'));
            }
            return $mailingGroupTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    public function viewAllByStatus($status)
    {
        try {
            $mailingGroupTypes = MailingGroupType::where('active', $status)->orderBy('name')->get();
            if ($mailingGroupTypes->isEmpty()){
                throw new ResourceNotFoundException(trans('mailing_group_type.exceptionNotFound'));
            }
            return $mailingGroupTypes;
        } catch (ResourceNotFoundException $e) {
            Log::error($e);
            throw new ResourceNotFoundException($e->getMessage(),$e->getCode());
        } catch (Exception $e) {
            Log::error($e);
            throw new Exception(trans('messages.exception'), response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }
    public function create(MailingGroupTypeRequest $request): Array|Object|Null
    {

    }

    public function update():Array|Object|Null
    {

    }

    public function dataFormat($request, MailingGroupType $mailingGroupType):object|null
    {
        $mailingGroupType->name = $request['name'];
        $mailingGroupType->reference_contract_id = $request['reference_contract_id'];
        $mailingGroupType->contract_state_id = $request['contract_state_id'];
        $mailingGroupType->active = $request['active'];
        return $mailingGroupType;
    }

}
