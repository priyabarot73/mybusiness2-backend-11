<?php

namespace App\Repositories\v1\cobapi;

use App\Repositories\v1\cobapi\clients\Faculty180Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class AllFacultyByKeywordRepository
{
    public function __construct(
        protected Faculty180Client $faculty180
    ) {}

    public function fetchFacultyByKeyword(string $firstName, string $lastName, string $keyword): array
    {
        $firstName = trim($firstName);
        $lastName  = trim($lastName);
        $keyword   = trim($keyword);

        $cacheKey = 'cobapi.faculty_by_keyword.'
            . md5(mb_strtolower($firstName . '|' . $lastName . '|' . $keyword));

        return Cache::remember($cacheKey, now()->addMinutes(10), function () use ($firstName, $lastName, $keyword) {

            // 1) Pull users + activities (areas)
            $usersByUserid = $this->faculty180->usersByUseridDetailed();        // keyed by userid
            $areasByUserid = $this->faculty180->expertiseAreasByUserid();      // userid => ["Financial Reporting", ...]

            if (empty($usersByUserid)) {
                return ['rows' => [], 'interestsByEmployeeId' => []];
            }

            $firstNeedle = mb_strtolower($firstName);
            $lastNeedle  = mb_strtolower($lastName);
            $kwNeedle    = mb_strtolower($keyword);

            $pids = [];
            $areasByPid = []; // pid(string) => areas[]

            foreach ($usersByUserid as $userid => $u) {
                $uFirst = mb_strtolower((string)($u['firstname'] ?? ''));
                $uLast  = mb_strtolower((string)($u['lastname'] ?? ''));

                // old API wildcard behavior: empty means match all
                if ($firstNeedle !== '' && !str_contains($uFirst, $firstNeedle)) continue;
                if ($lastNeedle  !== '' && !str_contains($uLast,  $lastNeedle))  continue;

                // keyword filter: empty => match all
                $userAreas = $areasByUserid[$userid] ?? [];
                $matchesKeyword = true;

                if ($kwNeedle !== '') {
                    $matchesKeyword = false;

                    // match against areas
                    foreach ($userAreas as $a) {
                        if (str_contains(mb_strtolower($a), $kwNeedle)) {
                            $matchesKeyword = true;
                            break;
                        }
                    }

                    // TODO: biography match (if you identify the right Faculty180 field/activity)
                    // Example if Faculty180 user payload contains a biography-ish field:
                    // $bio = mb_strtolower((string)($u['biography'] ?? ''));
                    // if (!$matchesKeyword && $bio !== '' && str_contains($bio, $kwNeedle)) $matchesKeyword = true;
                }

                if (!$matchesKeyword) continue;

                // map to pid (this is what matches mybusiness2 persons.panther_id per your note)
                $pid = $this->normalizePid($u['pid'] ?? null);
                if ($pid === '') continue;

                $pids[] = $pid;
                if (!empty($userAreas)) {
                    $areasByPid[$pid] = $userAreas;
                }
            }

            $pids = array_values(array_unique($pids));
            if (empty($pids)) {
                return ['rows' => [], 'interestsByEmployeeId' => []];
            }

            // 2) Fetch directory rows from mybusiness2.0 using panther_id IN (pids...)
            $rows = $this->fetchDirectoryStyleRowsByPids($pids);

            // 3) Build interests keyed by employeeID (nickname) in legacy shape [{interest:"..."}]
            $interestsByEmployeeId = [];

            foreach ($rows as $r) {
                $employeeId = (string)($r->employeeID ?? '');
                $pid = $this->normalizePid($r->_pid_internal ?? null);

                if ($employeeId === '' || $pid === '') continue;
                if (empty($areasByPid[$pid])) continue;

                $dedup = [];
                foreach ($areasByPid[$pid] as $a) {
                    $a = trim((string)$a);
                    if ($a === '') continue;
                    $dedup[mb_strtolower($a)] = $a;
                }

                $interestsByEmployeeId[$employeeId] = array_map(
                    fn ($val) => ['interest' => $val],
                    array_values($dedup)
                );
            }

            return [
                'rows' => $rows,
                'interestsByEmployeeId' => $interestsByEmployeeId,
            ];
        });
    }

    private function normalizePid(mixed $pid): string
    {
        // Faculty180 pid sometimes comes as int, sometimes string.
        // Keep digits only; trim; DO NOT expose pid in response.
        $s = trim((string)($pid ?? ''));
        if ($s === '') return '';
        $s = preg_replace('/\D+/', '', $s) ?? '';
        return trim($s);
    }

    private function fetchDirectoryStyleRowsByPids(array $pids): array
    {
        $placeholders = implode(',', array_fill(0, count($pids), '?'));

        $sql = "
        SELECT
            -- INTERNAL ONLY: pid for joining interests (do not expose)
            p.panther_id AS _pid_internal,

            ISNULL(p.nickname, '') AS employeeID,
            ISNULL(p.last_name, '') AS last_name,
            ISNULL(p.first_name, '') AS first_name,
            ISNULL(d.name, '') AS department_desc,
            ISNULL(p.business_email, '') AS email,
            CASE
                WHEN p.business_phone_number IS NULL OR LTRIM(RTRIM(p.business_phone_number)) = '' THEN ''
                WHEN p.business_phone_number_ext IS NULL OR LTRIM(RTRIM(p.business_phone_number_ext)) = '' THEN p.business_phone_number
                ELSE p.business_phone_number + ' x' + p.business_phone_number_ext
            END AS phone,
            ISNULL(p.avatar, '') AS profile_picture,
            ISNULL(COALESCE(wt.name, jt.name), '') AS title,
            ISNULL(pl.description, '') AS location,
            CASE
                WHEN fac.id IS NULL THEN ''
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                     AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                     AND (
                          fac.description LIKE '%' + LTRIM(RTRIM(fac.room)) + '%'
                          OR RIGHT(LTRIM(RTRIM(fac.description)), LEN(LTRIM(RTRIM(fac.room)))) = LTRIM(RTRIM(fac.room))
                     )
                    THEN LTRIM(RTRIM(fac.description))
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                     AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                    THEN LTRIM(RTRIM(fac.description)) + ' ' + LTRIM(RTRIM(fac.room))
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> '' THEN LTRIM(RTRIM(fac.description))
                WHEN ISNULL(LTRIM(RTRIM(fac.code)), '') <> '' THEN LTRIM(RTRIM(fac.code))
                ELSE ''
            END AS facility,
            '' AS profile_url,
            '' AS faculty_class
        FROM [mybusiness2.0].[hr].[persons] p

        OUTER APPLY (
            SELECT TOP 1 ed.*
            FROM [mybusiness2.0].[hr].[employee_directories] ed
            WHERE ed.person_id = p.id
              AND ISNULL(ed.locked, 0) = 0
              AND (ed.start_date IS NULL OR ed.start_date <= GETDATE())
              AND (ed.end_date IS NULL OR ed.end_date >= GETDATE())
            ORDER BY
              CASE WHEN ed.end_date IS NULL THEN 0 ELSE 1 END ASC,
              ed.start_date ASC,
              ed.created_at ASC,
              ed.id ASC
        ) ed

        OUTER APPLY (
            SELECT TOP 1 a.*
            FROM [mybusiness2.0].[hr].[assignments] a
            WHERE a.person_id = p.id
              AND ISNULL(a.active, 0) = 1
              AND (a.start_date IS NULL OR a.start_date <= GETDATE())
              AND (a.end_date IS NULL OR a.end_date >= GETDATE())
            ORDER BY
              CASE WHEN a.working_title_id IS NOT NULL THEN 0 ELSE 1 END ASC,
              CASE WHEN a.end_date IS NULL THEN 0 ELSE 1 END ASC,
              a.start_date ASC,
              a.created_at ASC,
              a.id ASC
        ) a

        LEFT JOIN [mybusiness2.0].[hr].[working_titles] wt ON wt.id = a.working_title_id
        LEFT JOIN [mybusiness2.0].[hr].[job_titles] jt ON jt.id = a.job_title_id
        -- Department for display: prefer assignment department, else person's home department
        LEFT JOIN [mybusiness2.0].[gn].[departments] d
            ON d.id = COALESCE(a.department_id, p.department_id)
        -- COB restriction: derive BU from that department (NOT from assignment.business_unit_id)
        LEFT JOIN [mybusiness2.0].[hr].[business_units] bu
            ON bu.id = d.business_unit_id
        LEFT JOIN [mybusiness2.0].[gn].[physical_locations] pl ON pl.id = COALESCE(a.public_establishment_id, a.physical_location_id)
        LEFT JOIN [mybusiness2.0].[gn].[facilities] fac ON fac.id = COALESCE(a.public_facility_id, a.facility_id)

        WHERE
            p.active = 1
            AND ed.id IS NOT NULL
            AND bu.code = 'AACBA'
            AND p.panther_id IN ($placeholders)

        ORDER BY
            ISNULL(p.last_name, '') ASC,
            ISNULL(p.first_name, '') ASC,
            ISNULL(p.nickname, '') ASC
        ";

        return DB::select($sql, $pids);
    }
}
