<?php

namespace App\Repositories\v1\cobapi\clients;

use Illuminate\Support\Facades\Http;

class Faculty180Client
{

    //TODO: Separate this into multiple clients in the future
    private int $activityExpertiseId = 13;
    private int $activityVitaeId = 1;
    private int $activityBiographyId = -3;
    private int $activityEducationId = -10;
    private int $activityPublicationsId = -21;
    private int $activityCoursesTaughtId = -23;
    private int $activityPositionsId = -9;



    public function getUsersDetailed(): array
    {
        $base  = rtrim(config('services.faculty180.base_url'), '/');
        $unit  = config('services.faculty180.unit_id');
        $token = config('services.faculty180.token');

        $resp = Http::timeout(30)->get($base . '/users', [
            'unitid' => $unit,
            'data'   => 'detailed',
            'token'  => $token,
        ]);

        $resp->throw();
        return $resp->json() ?? [];
    }

    public function getExpertiseActivitiesDetailed(): array
    {
        return $this->getActivitiesDetailed($this->activityExpertiseId, [
            'data' => 'detailed',
        ]);
    }

    public function getActivitiesDetailed(int $activityTypeId, array $extraQuery = []): array
    {
        $base  = rtrim(config('services.faculty180.base_url'), '/');
        $unit  = config('services.faculty180.unit_id');
        $token = config('services.faculty180.token');

        $query = array_merge([
            'unitid' => $unit,
            'data'   => 'detailed',
            'token'  => $token,
        ], $extraQuery);

        $resp = Http::timeout(30)->get($base . "/activities/{$activityTypeId}/", $query);
        $resp->throw();

        return $resp->json() ?? [];
    }

    public function getActivitiesDetailedNoUnit(int $activityTypeId, array $extraQuery = []): array
    {
        // Matches the Go pattern more closely (token + userlist, no unitid)
        $base  = rtrim(config('services.faculty180.base_url'), '/');
        $token = config('services.faculty180.token');

        $query = array_merge([
            'data'  => 'detailed',
            'token' => $token,
        ], $extraQuery);

        $resp = Http::timeout(30)->get($base . "/activities/{$activityTypeId}/", $query);
        $resp->throw();

        return $resp->json() ?? [];
    }

    public function getActivityAttachments(int $activityTypeId, int $activityInstanceId): array
    {
        $base  = rtrim(config('services.faculty180.base_url'), '/');
        $unit  = config('services.faculty180.unit_id');
        $token = config('services.faculty180.token');

        $resp = Http::timeout(30)->get($base . "/activities/{$activityTypeId}/{$activityInstanceId}/attachments", [
            'unitid' => $unit,
            'data'   => 'detailed',
            'token'  => $token,
        ]);

        $resp->throw();
        $json = $resp->json() ?? [];

        // If it comes back empty, try again without unitid (legacy style)
        if (empty($json)) {
            $resp2 = Http::timeout(30)->get($base . "/activities/{$activityTypeId}/{$activityInstanceId}/attachments", [
                'data'  => 'detailed',
                'token' => $token,
            ]);
            $resp2->throw();
            $json = $resp2->json() ?? [];
        }

        return $json;
    }

    public function usersByUseridDetailed(bool $relaxActiveCheck = true): array
    {
        $users = $this->getUsersDetailed();

        if (is_array($users) && isset($users['users']) && is_array($users['users'])) {
            $users = $users['users'];
        }

        $out = [];
        foreach ($users as $u) {
            if (!is_array($u)) continue;

            $userid = (string)($u['userid'] ?? '');
            if ($userid === '') continue;

            $status = mb_strtolower(trim((string)($u['employmentstatus'] ?? '')));

            if ($relaxActiveCheck) {
                if (in_array($status, ['inactive', 'terminated', 'retired'], true)) continue;
            } else {
                if ($status !== 'active') continue;
            }

            $out[$userid] = $u;
        }

        return $out;
    }

    public function activeUsersByUseridRelaxed(): array
    {
        return $this->usersByUseridDetailed(true);
    }

    public function expertiseAreasByUserid(): array
    {
        $payload = $this->getExpertiseActivitiesDetailed();
        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityExpertiseId);

        $out = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;

            $userid = (string)($row['userid'] ?? $row['facultyid'] ?? '');
            if ($userid === '') continue;

            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $uniq = [];
            foreach ($fields as $k => $v) {
                if (stripos((string)$k, 'area') === false) continue;
                if (!is_string($v)) continue;

                $val = trim($v);
                if ($val === '') continue;
                if ($this->isJunkAreaValue($val)) continue;

                $uniq[mb_strtolower($val)] = $val;
            }

            if (!empty($uniq)) {
                $out[$userid] = array_values($uniq);
            }
        }

        return $out;
    }

    /**
     * Repository-friendly: get expertise areas for PID (digits)
     * Strategy:
     *  A) Try /activities/13/?...&userlist=<pid> (if supported)
     *  B) Fallback: map pid -> userid via /users then use expertiseAreasByUserid()
     */
    public function expertiseAreasForPid(string $pid): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // A) Try userlist directly (might work depending on Faculty180 config)
        try {
            $payload = $this->getActivitiesDetailed($this->activityExpertiseId, [
                'userlist' => $pid,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityExpertiseId);
            $areas = $this->areasFromActivityRows($rows);
            if (!empty($areas)) return $areas;
        } catch (\Throwable $e) {
            // ignore + fallback
        }

        // B) Fallback: pid -> userid
        $userid = $this->useridForPid($pid);
        if ($userid === null) return [];

        $byUserid = $this->expertiseAreasByUserid();
        return $byUserid[$userid] ?? [];
    }

    public function vitaeActivityIdForPid(string $pid): ?int
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return null;

        // 1) Try with unitid
        $payload = $this->getActivitiesDetailed($this->activityVitaeId, [
            'userlist' => $pid,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityVitaeId);

        // 2) If empty, try without unitid (matches Go)
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityVitaeId, [
                'userlist' => $pid,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityVitaeId);
        }

        if (empty($rows)) return null;

        $last = $rows[count($rows) - 1];
        if (!is_array($last)) return null;

        $aid = preg_replace('/\D+/', '', (string)($last['activityid'] ?? '')) ?? '';
        if ($aid === '') return null;

        return (int)$aid;
    }

    public function vitaeDownloadUrlForPid(string $pid): string
    {
        $activityId = $this->vitaeActivityIdForPid($pid);
        if (!$activityId) return '';

        $attachmentsPayload = $this->getActivityAttachments($this->activityVitaeId, $activityId);
        return $this->extractFirstDownloadUrlRobust($attachmentsPayload);
    }

    private function useridForPid(string $pid): ?string
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return null;

        $users = $this->usersByUseridDetailed(true);

        foreach ($users as $userid => $u) {
            $uPid = $this->normalizePid($u['pid'] ?? null);
            if ($uPid !== '' && $uPid === $pid) {
                return (string)$userid;
            }
        }

        return null;
    }

    private function areasFromActivityRows(array $rows): array
    {
        $uniq = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            foreach ($fields as $k => $v) {
                if (stripos((string)$k, 'area') === false) continue;
                if (!is_string($v)) continue;

                $val = trim($v);
                if ($val === '') continue;
                if ($this->isJunkAreaValue($val)) continue;

                $uniq[mb_strtolower($val)] = $val;
            }
        }

        return array_values($uniq);
    }

    private function extractFirstDownloadUrlRobust(array $payload): string
    {
        if (array_is_list($payload)) {
            foreach ($payload as $item) {
                if (!is_array($item)) continue;
                $url = trim((string)($item['DownloadURL'] ?? $item['downloadurl'] ?? $item['download_url'] ?? $item['downloadUrl'] ?? ''));
                if ($url !== '') return $url;
            }
            return '';
        }

        if (isset($payload['attachments']) && is_array($payload['attachments'])) {
            return $this->extractFirstDownloadUrlRobust($payload['attachments']);
        }

        foreach ($payload as $v) {
            if (is_array($v)) {
                $url = $this->extractFirstDownloadUrlRobust($v);
                if ($url !== '') return $url;
            }
        }

        return '';
    }

    public function biographyHtmlForPid(string $pid): string
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return '';

        // 1) Try with unitid
        $payload = $this->getActivitiesDetailed($this->activityBiographyId, [
            'userlist' => $pid,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityBiographyId);

        // 2) Fallback: no unitid (Go-style)
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityBiographyId, [
                'userlist' => $pid,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityBiographyId);
        }

        if (empty($rows)) return '';

        // If multiple, take the last (same pattern as your Go VitaeID logic)
        $row = $rows[count($rows) - 1];
        if (!is_array($row)) return '';

        $fields = $row['fields'] ?? null;
        if (!is_array($fields)) return '';

        // Your sample shows fields["Biography"] exactly
        $bio = (string)($fields['Biography'] ?? '');

        return trim($bio);
    }

    public function educationsForPid(string $pid): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // A) Try using PID directly (sometimes works depending on tenant config)
        $rows = $this->educationActivityRowsForUserlist($pid);

        // B) Fallback: PID -> userid, then userlist=userid (this is what your Postman test proved)
        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->educationActivityRowsForUserlist($userid);
            }
        }

        if (empty($rows)) return [];

        // Build formatted titles + sort + dedupe
        $items = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $degree = $this->asCleanString($fields['Degree'] ?? '');
            $disc   = $this->asCleanString($fields['Discipline'] ?? '');
            $inst   = $this->asCleanString($fields['Granting Institution'] ?? '');

            if ($degree === '' && $disc === '' && $inst === '') continue;

            $year = (int)($fields['Year Conferred'] ?? 0);
            $highest = (int)($fields['Highest Degree Earned'] ?? 0);
            $terminal = (int)($fields['Terminal Degree'] ?? 0);

            $title = $this->formatEducationTitle($fields);

            if ($title === '') continue;

            $items[] = [
                'educationTitle' => $title,
                // sort helpers (not returned)
                '_highest' => $highest,
                '_terminal' => $terminal,
                '_rank' => $this->degreeRank($degree),
                '_year' => $year,
            ];
        }

        if (empty($items)) return [];

        // Deduplicate by educationTitle (your sample has duplicates)
        $uniq = [];
        foreach ($items as $it) {
            $k = mb_strtolower(trim($it['educationTitle']));
            $uniq[$k] = $it;
        }
        $items = array_values($uniq);

        // Sort similar to legacy: highest/terminal first, PhD first, then year desc
        usort($items, function ($a, $b) {
            if ($a['_highest'] !== $b['_highest']) return $b['_highest'] <=> $a['_highest'];
            if ($a['_terminal'] !== $b['_terminal']) return $b['_terminal'] <=> $a['_terminal'];
            if ($a['_rank'] !== $b['_rank']) return $a['_rank'] <=> $b['_rank'];
            return $b['_year'] <=> $a['_year'];
        });

        // Strip helper fields
        return array_map(fn ($it) => ['educationTitle' => $it['educationTitle']], $items);
    }

    public function highestDegreeSummaryForPid(string $pid): string
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return '';

        // A) Try PID directly
        $rows = $this->educationActivityRowsForUserlist($pid);

        // B) Fallback: pid -> userid
        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->educationActivityRowsForUserlist($userid);
            }
        }

        if (empty($rows)) return '';

        $candidates = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $degree   = $this->asCleanString($fields['Degree'] ?? '');
            $disc     = $this->asCleanString($fields['Discipline'] ?? '');
            $highest  = (int)($fields['Highest Degree Earned'] ?? 0);
            $terminal = (int)($fields['Terminal Degree'] ?? 0);

            $yearRaw = $fields['Year Conferred'] ?? null;
            $yearStr = $this->asCleanString($yearRaw);
            $yearNum = is_numeric($yearRaw) ? (int)$yearRaw : (preg_match('/\b(19|20)\d{2}\b/', (string)$yearStr, $m) ? (int)$m[0] : 0);

            if ($degree === '' && $disc === '' && $yearStr === '') continue;

            $candidates[] = [
                'degree'   => $degree,
                'disc'     => $disc,
                'yearStr'  => $yearStr,
                'yearNum'  => $yearNum,
                '_highest' => $highest,
                '_terminal'=> $terminal,
                '_rank'    => $this->degreeRank($degree),
            ];
        }

        if (empty($candidates)) return '';

        // Sort: HighestDegreeEarned desc, Terminal desc, degree rank asc (PhD first), year desc
        usort($candidates, function ($a, $b) {
            if ($a['_highest'] !== $b['_highest']) return $b['_highest'] <=> $a['_highest'];
            if ($a['_terminal'] !== $b['_terminal']) return $b['_terminal'] <=> $a['_terminal'];
            if ($a['_rank'] !== $b['_rank']) return $a['_rank'] <=> $b['_rank'];
            return $b['yearNum'] <=> $a['yearNum'];
        });

        $best = $candidates[0];

        // Format: "Ph.D. - 2017 Management" (or "- 10/2006" if that’s what Year Conferred contains)
        $out = $best['degree'];

        if ($best['yearStr'] !== '') {
            $out .= " - {$best['yearStr']}";
        } elseif ($best['yearNum'] > 0) {
            $out .= " - {$best['yearNum']}";
        }

        if ($best['disc'] !== '') {
            $out .= " {$best['disc']}";
        }

        return trim($out);
    }

    private function educationActivityRowsForUserlist(string $userlist): array
    {
        $userlist = trim((string)$userlist);
        if ($userlist === '') return [];

        // 1) with unitid
        $payload = $this->getActivitiesDetailed($this->activityEducationId, [
            'userlist' => $userlist,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityEducationId);

        // 2) fallback without unitid (legacy style)
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityEducationId, [
                'userlist' => $userlist,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityEducationId);
        }

        return $rows;
    }

    private function formatEducationTitle(array $fields): string
    {
        $degree = $this->asCleanString($fields['Degree'] ?? '');
        $disc   = $this->asCleanString($fields['Discipline'] ?? '');
        $inst   = $this->asCleanString($fields['Granting Institution'] ?? '');

        if ($degree === '' && $disc === '' && $inst === '') return '';

        // Left line: "Ph.D. in Computer Science"
        $left = $degree;
        if ($disc !== '') {
            $left = ($left !== '' ? $left . ' in ' : '') . $disc;
        }

        // Right line: "Indiana University, Bloomington, Indiana"
        // Your data uses "Indiana University - Bloomington" so normalize that
        $instFormatted = str_replace(' - ', ', ', $inst);

        // In your sample, City holds "Indiana" (acts like state)
        $city  = $this->asCleanString($fields['City'] ?? '');
        $state = $this->asCleanString($fields['State or Province'] ?? '');

        $suffix = $state !== '' ? $state : $city; // prefer state; fallback to city

        if ($suffix !== '' && stripos($instFormatted, $suffix) === false) {
            $instFormatted = $instFormatted !== '' ? ($instFormatted . ', ' . $suffix) : $suffix;
        }

        if ($left === '') return $instFormatted;
        if ($instFormatted === '') return $left;

        return $left . '<BR>' . $instFormatted;
    }

    private function degreeRank(string $degree): int
    {
        $d = mb_strtolower(trim($degree));
        if ($d === '') return 50;
        if (str_contains($d, 'ph.d')) return 0;
        if (str_starts_with($d, 'bachelor')) return 100;
        return 1;
    }

    private function asCleanString(mixed $v): string
    {
        $s = trim((string)($v ?? ''));
        if ($s === '') return '';
        // normalize any HTML entities if they show up in some fields
        $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return trim($s);
    }

    public function publicationsForPid(string $pid, string $ownerFullName = ''): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // A) Try PID directly
        $rows = $this->publicationActivityRowsForUserlist($pid);

        // B) Fallback: pid -> userid
        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->publicationActivityRowsForUserlist($userid);
            }
        }

        if (empty($rows)) return [];

        // Legacy statuses (tightened to only Completed/Published)
        $allowedStatuses = [
            'completed/published' => 'Completed/Published',
        ];

        $items = [];
        $seen  = []; // dedupe

        foreach ($rows as $row) {
            if (!is_array($row)) continue;

            $status = $this->extractBestStatus($row, $allowedStatuses);
            if ($status === '') continue;

            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            // Exclude books (handled by booksForPid)
            $type = mb_strtolower(trim((string)($fields['Type'] ?? '')));
            if ($type !== '' && str_contains($type, 'book')) {
                continue;
            }

            // STRICT legacy filter: require journal/outlet AND title (drops patents / partials / “authors+year only”)
            $titlePlain  = $this->stripTagsAndDecode($this->pickField($fields, ['Title', 'Article Title', 'Publication Title']));
            $journalPlain = $this->stripTagsAndDecode($this->pickField($fields, ['Journal', 'Publication/Outlet', 'Outlet', 'Venue', 'Publication Venue']));

            if ($titlePlain === '' || $journalPlain === '') {
                continue; // <- this removes your “authors + (year)” junk rows
            }

            $publicationYear = $this->stripTagsAndDecode((string)($fields['Year'] ?? ''));
            if ($publicationYear === '') $publicationYear = '0';

            $issueRelease = $this->stripTagsAndDecode((string)($fields['Date'] ?? ''));

            // Build a clean HTML citation (no double-escaped spans)
            $publicationTitle = $this->buildJournalCitationHtml(
                $row,
                $ownerFullName,
                $titlePlain,
                $journalPlain,
                $publicationYear
            );

            if ($this->looksLikeIncompletePublication($publicationTitle, $titlePlain, $journalPlain)) {
                continue;
            }

            $dedupeKey = $this->normalizeCitationForDedupe($publicationTitle);
            if ($dedupeKey === '' || isset($seen[$dedupeKey])) {
                continue;
            }
            $seen[$dedupeKey] = true;

            $items[] = [
                'publicationTitle'  => $publicationTitle,
                'issueRelease'      => $issueRelease,
                'publicationYear'   => (string)$publicationYear,
                'publicationStatus' => $status,

                '_sortYear' => (int)preg_replace('/\D+/', '', (string)$publicationYear),
                '_sortDate' => $this->sortKeyForIssueRelease($issueRelease),
            ];
        }

        if (empty($items)) return [];

        usort($items, function ($a, $b) {
            if ($a['_sortYear'] !== $b['_sortYear']) return $b['_sortYear'] <=> $a['_sortYear'];
            return $b['_sortDate'] <=> $a['_sortDate'];
        });

        return array_map(fn ($it) => [
            'publicationTitle'  => $it['publicationTitle'],
            'issueRelease'      => $it['issueRelease'],
            'publicationYear'   => $it['publicationYear'],
            'publicationStatus' => $it['publicationStatus'],
        ], $items);
    }

    private function publicationActivityRowsForUserlist(string $userlist): array
    {
        $userlist = trim((string)$userlist);
        if ($userlist === '') return [];

        // with unitid
        $payload = $this->getActivitiesDetailed($this->activityPublicationsId, [
            'userlist' => $userlist,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityPublicationsId);

        // fallback without unitid
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityPublicationsId, [
                'userlist' => $userlist,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityPublicationsId);
        }

        return $rows;
    }

    private function extractCompletedPublishedStatus(array $row): string
    {
        $statuses = $row['status'] ?? null;
        if (!is_array($statuses)) return '';

        foreach ($statuses as $s) {
            if (!is_array($s)) continue;
            $val = trim((string)($s['status'] ?? ''));
            if (mb_strtolower($val) === 'completed/published') {
                return $val;
            }
        }

        return '';
    }

    private function extractCitationOrBuildOne(array $row, string $ownerFullName): string
    {
        $fields = $row['fields'] ?? null;
        if (!is_array($fields)) return '';

        // 1) Prefer a provided citation field if it exists (some tenants have it)
        foreach (['Output Citation', 'Citation', 'Publication Citation', 'Formatted Citation'] as $k) {
            $v = $fields[$k] ?? null;
            if (is_string($v) && trim($v) !== '') {
                return $this->decodeIfHtmlEncoded(trim($v));
            }
        }

        // 2) Build a legacy-ish HTML citation from pieces
        $title   = $this->asString($fields['Title'] ?? '');
        $journal = $this->asString($fields['Journal'] ?? '');
        $year    = $this->asString($fields['Year'] ?? '');

        $authors = $this->buildAuthorsString($row, $ownerFullName);

        // mimic your legacy style (inline <p> blocks)
        $parts = [];

        if ($authors !== '') {
            $parts[] = '<p style="display: inline">' . $this->escapeHtmlButKeepPlain($authors) . '</p>';
        }

        if ($year !== '') {
            $parts[] = '<p style="display: inline"> (' . $this->escapeHtmlButKeepPlain($year) . '). </p>';
        }

        if ($title !== '') {
            // legacy often has double period in examples depending on data; we’ll add one.
            $parts[] = '<p style="display: inline">' . $this->escapeHtmlButKeepPlain($title) . '.</p>';
        }

        if ($journal !== '') {
            $parts[] = '<p style="display: inline"><i> ' . $this->escapeHtmlButKeepPlain($journal) . '</i></p>';
            $parts[] = '<p style="display: inline">.</p>';
        }

        return implode('', $parts);
    }

    private function buildAuthorsString(array $row, string $ownerFullName): string
    {
        $names = [];

        // include owner name if we have it
        $owner = trim($ownerFullName);
        if ($owner !== '') {
            $names[] = $this->formatNameAsLastInitial($owner);
        }

        $coauthors = $row['coauthors'] ?? null;
        if (is_array($coauthors)) {
            $tmp = [];

            foreach ($coauthors as $c) {
                if (!is_array($c)) continue;

                $first = (string)($c['firstname'] ?? '');
                $mid   = (string)($c['middleinitial'] ?? '');
                $last  = (string)($c['lastname'] ?? '');

                $a = $this->formatAuthorName($first, $mid, $last);
                if ($a !== '') $tmp[] = $a;
            }

            // make deterministic (since coauthors is an object)
            sort($tmp, SORT_NATURAL | SORT_FLAG_CASE);

            foreach ($tmp as $t) {
                // avoid duping the owner if it happens to appear
                if ($owner !== '' && mb_strtolower($t) === mb_strtolower($this->formatNameAsLastInitial($owner))) continue;
                $names[] = $t;
            }
        }

        $names = array_values(array_unique(array_filter($names)));
        $n = count($names);

        if ($n === 0) return '';
        if ($n === 1) return $names[0] . '.';
        if ($n === 2) return $names[0] . ' & ' . $names[1] . '.';

        // A, B., & C.
        $last = array_pop($names);
        return implode(', ', $names) . ', & ' . $last . '.';
    }

    private function formatAuthorName(string $first, string $middleInitial, string $last): string
    {
        $first = trim($first);
        $middleInitial = trim($middleInitial);
        $last = trim($last);

        if ($last === '') return '';

        $out = $last;

        if ($first !== '') {
            $out .= ' ' . mb_substr($first, 0, 1) . '.';
        }

        if ($middleInitial !== '') {
            $out .= ' ' . mb_substr($middleInitial, 0, 1) . '.';
        }

        return trim($out);
    }

    private function formatNameAsLastInitial(string $fullName): string
    {
        $fullName = trim($fullName);
        if ($fullName === '') return '';

        $parts = preg_split('/\s+/', $fullName) ?: [];
        if (count($parts) === 1) return $parts[0];

        $first = $parts[0];
        $last  = $parts[count($parts) - 1];

        return $this->formatAuthorName($first, '', $last);
    }

    private function decodeIfHtmlEncoded(string $s): string
    {
        // if it looks encoded (&lt;p&gt;...), decode
        if (stripos($s, '&lt;') !== false || stripos($s, '&gt;') !== false) {
            return html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return $s;
    }

    private function asString(mixed $v): string
    {
        if ($v === null) return '';
        if (is_int($v) || is_float($v)) return (string)$v;
        return trim((string)$v);
    }

    private function sortKeyForIssueRelease(string $s): int
    {
        $s = trim($s);
        if ($s === '') return 0;

        // Try YYYY/MM/DD or YYYY-MM-DD
        if (preg_match('/^(\d{4})[\/-](\d{2})[\/-](\d{2})$/', $s, $m)) {
            return ((int)$m[1] * 10000) + ((int)$m[2] * 100) + (int)$m[3];
        }

        // If it's just a year
        if (preg_match('/^\d{4}$/', $s)) {
            return (int)$s * 10000;
        }

        // fallback: strip digits
        $digits = preg_replace('/\D+/', '', $s) ?? '';
        return $digits === '' ? 0 : (int)$digits;
    }

    private function escapeHtmlButKeepPlain(string $s): string
    {
        // Title/journal/authors should be plain text inside our HTML tags
        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public function subjectsForPid(string $pid): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // A) Try PID directly
        $rows = $this->coursesTaughtRowsForUserlist($pid);

        // B) Fallback: pid -> userid
        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->coursesTaughtRowsForUserlist($userid);
            }
        }

        if (empty($rows)) return [];

        $uniq = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $title = $this->asCleanString($fields['Course Title'] ?? '');
            if ($title === '') continue;

            // optional: ignore obvious junk
            if (mb_strtolower($title) === 'tbd') continue;

            $uniq[mb_strtolower($title)] = $title;
        }

        $titles = array_values($uniq);
        if (empty($titles)) return [];

        sort($titles, SORT_NATURAL | SORT_FLAG_CASE);

        return array_map(fn ($t) => ['subjectTitle' => $t], $titles);
    }

    private function coursesTaughtRowsForUserlist(string $userlist): array
    {
        $userlist = trim((string)$userlist);
        if ($userlist === '') return [];

        // with unitid
        $payload = $this->getActivitiesDetailed($this->activityCoursesTaughtId, [
            'userlist' => $userlist,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityCoursesTaughtId);

        // fallback without unitid
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityCoursesTaughtId, [
                'userlist' => $userlist,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityCoursesTaughtId);
        }

        return $rows;
    }

    public function booksForPid(string $pid, string $ownerFullName = ''): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // Reuse the same -21 pull you already have for publications
        $rows = $this->publicationActivityRowsForUserlist($pid);

        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->publicationActivityRowsForUserlist($userid);
            }
        }

        if (empty($rows)) return [];

        $allowedStatuses = [
            'completed/published' => 'Completed/Published',
            'accepted'            => 'Accepted',
            'in press'            => 'In Press',
        ];

        $items = [];
        foreach ($rows as $row) {
            if (!is_array($row)) continue;

            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $type = trim((string)($fields['Type'] ?? ''));
            if (mb_strtolower($type) !== 'book') {
                // IMPORTANT: "Book Chapter" stays with articles, so we ignore it here
                continue;
            }

            $status = $this->extractBestStatus($row, $allowedStatuses);
            if ($status === '') continue; // only keep allowed statuses

            $year = $this->asString($fields['Year'] ?? '');
            if ($year === '') $year = '0';

            $citation = $this->buildBookCitationHtml($row, $ownerFullName);
            if (trim($citation) === '') continue;

            $items[] = [
                'title'  => $citation,
                'year'   => (string)$year,
                'Status' => $status,

                '_sortYear' => (int)preg_replace('/\D+/', '', (string)$year),
            ];
        }

        if (empty($items)) return [];

        usort($items, fn($a, $b) => $b['_sortYear'] <=> $a['_sortYear']);

        return array_map(fn($it) => [
            'title'  => $it['title'],
            'year'   => $it['year'],
            'Status' => $it['Status'],
        ], $items);
    }

    /**
     * Pick best status based on priority: Completed/Published > Accepted > In Press
     */
    private function extractBestStatus(array $row, array $allowedStatusesMap): string
    {
        $statuses = $row['status'] ?? null;
        if (!is_array($statuses)) return '';

        $seen = [];
        foreach ($statuses as $s) {
            if (!is_array($s)) continue;
            $val = trim((string)($s['status'] ?? ''));
            if ($val === '') continue;
            $seen[mb_strtolower($val)] = $val;
        }

        foreach (['completed/published', 'accepted', 'in press'] as $pick) {
            if (isset($seen[$pick]) && isset($allowedStatusesMap[$pick])) {
                return $allowedStatusesMap[$pick];
            }
        }

        return '';
    }

    private function buildBookCitationHtml(array $row, string $ownerFullName): string
    {
        $fields = $row['fields'] ?? null;
        if (!is_array($fields)) return '';

        // If your tenant ever provides a formatted citation, prefer it
        foreach (['Output Citation', 'Citation', 'Publication Citation', 'Formatted Citation'] as $k) {
            $v = $fields[$k] ?? null;
            if (is_string($v) && trim($v) !== '') {
                // DO NOT decode &lt;p&gt; in book titles (your legacy example shows it preserved)
                return trim($v);
            }
        }

        $title  = (string)($fields['Title'] ?? '');
        $year   = (string)($fields['Year'] ?? '');
        // Books often use Publisher/Press instead of Journal; keep this flexible:
        $press  = (string)($fields['Publisher'] ?? $fields['Press'] ?? $fields['Publisher/Press'] ?? $fields['Journal'] ?? '');

        $authors = $this->buildAuthorsString($row, $ownerFullName);

        $parts = [];

        if ($authors !== '') {
            $parts[] = '<p style="display: inline">' . $this->inlineSafeText($authors) . '</p>';
        }

        if (trim($year) !== '') {
            $parts[] = '<p style="display: inline"> (' . $this->inlineSafeText($year) . '). </p>';
        }

        if (trim($title) !== '') {
            $parts[] = '<p style="display: inline">' . $this->inlineSafeText($title) . '.</p>';
        }

        if (trim($press) !== '') {
            $parts[] = '<p style="display: inline"><i> ' . $this->inlineSafeText($press) . '</i></p>';
            $parts[] = '<p style="display: inline">.</p>';
        }

        return implode('', $parts);
    }

    /**
     * Avoid double-escaping.
     * - If value already contains &lt; or &gt;, we assume it is already safely encoded and keep it.
     * - Otherwise we escape it to avoid injecting raw HTML into our wrapper tags.
     */
    private function inlineSafeText(string $s): string
    {
        $s = trim($s);
        if ($s === '') return '';

        if (stripos($s, '&lt;') !== false || stripos($s, '&gt;') !== false) {
            return $s; // already encoded like your legacy example
        }

        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private function isJunkAreaValue(string $val): bool
    {
        $v = mb_strtolower(trim($val));
        return in_array($v, ['yes', 'no', 'true', 'false'], true);
    }

    private function normalizeActivitiesRows(array $payload, string $key): array
    {
        if (isset($payload[$key]) && is_array($payload[$key])) return $payload[$key];
        if (isset($payload[(int)$key]) && is_array($payload[(int)$key])) return $payload[(int)$key];
        if (array_is_list($payload)) return $payload;
        return [];
    }

    private function normalizePid(mixed $pid): string
    {
        $s = trim((string)($pid ?? ''));
        if ($s === '') return '';
        $s = preg_replace('/\D+/', '', $s) ?? '';
        return trim($s);
    }

    private function pickField(array $fields, array $keys): string
    {
        foreach ($keys as $k) {
            $v = $fields[$k] ?? null;
            if (is_string($v) && trim($v) !== '') return $v;
        }
        return '';
    }

    private function decodeHtmlEntitiesPossiblyTwice(string $s): string
    {
        $s = trim($s);
        if ($s === '') return '';

        $d1 = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (stripos($d1, '&lt;') !== false || stripos($d1, '&gt;') !== false) {
            $d2 = html_entity_decode($d1, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            return trim($d2);
        }
        return trim($d1);
    }

    private function stripTagsAndDecode(string $s): string
    {
        $s = $this->decodeHtmlEntitiesPossiblyTwice($s);
        $s = strip_tags($s);
        $s = preg_replace('/\s+/', ' ', $s) ?? '';
        return trim($s);
    }

    private function buildJournalCitationHtml(array $row, string $ownerFullName, string $title, string $journal, string $year): string
    {
        $authors = $this->buildAuthorsString($row, $ownerFullName);

        $parts = [];

        if ($authors !== '') {
            $parts[] = '<p style="display: inline">' . htmlspecialchars($authors, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</p>';
        }

        if (trim($year) !== '') {
            $parts[] = '<p style="display: inline"> (' . htmlspecialchars($year, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '). </p>';
        }

        // title/journal already decoded + stripped; safe to escape for HTML
        $parts[] = '<p style="display: inline">' . htmlspecialchars($title, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '.</p>';
        $parts[] = '<p style="display: inline"><i> ' . htmlspecialchars($journal, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</i></p>';
        $parts[] = '<p style="display: inline">.</p>';

        return implode('', $parts);
    }

    private function normalizeCitationForDedupe(string $html): string
    {
        $plain = $this->stripTagsAndDecode($html);
        $plain = mb_strtolower($plain);
        $plain = preg_replace('/[^\p{L}\p{N}]+/u', '', $plain) ?? '';
        return $plain;
    }

    private function looksLikeIncompletePublication(string $citationHtml, string $titlePlain, string $journalPlain): bool
    {
        // extra safety: even with title/journal required, drop suspiciously tiny records
        if (mb_strlen(trim($titlePlain)) < 8) return true;
        if (mb_strlen(trim($journalPlain)) < 3) return true;

        $plain = $this->stripTagsAndDecode($citationHtml);
        return mb_strlen($plain) < 40;
    }

    public function positionTitlesForPid(string $pid): array
    {
        $pid = $this->normalizePid($pid);
        if ($pid === '') return [];

        // A) Try PID directly
        $rows = $this->positionRowsForUserlist($pid);

        // B) Fallback: pid -> userid
        if (empty($rows)) {
            $userid = $this->useridForPid($pid);
            if ($userid !== null && trim($userid) !== '') {
                $rows = $this->positionRowsForUserlist($userid);
            }
        }

        return $this->positionTitlesFromRows($rows);
    }

    /**
     * Batch helper for AllFacultyNamesRepository.
     * Returns: [pid => [ ['title'=>..., 'order'=>...], ... ], ...]
     */
    public function positionTitlesByPid(array $pids): array
    {
        $uniq = [];
        foreach ($pids as $p) {
            $p = $this->normalizePid($p);
            if ($p !== '') $uniq[$p] = true;
        }
        $pids = array_keys($uniq);
        if (empty($pids)) return [];

        // Build pid<->userid maps once (for fallback)
        $users = $this->usersByUseridDetailed(true);
        $pidToUserid = [];
        $useridToPid = [];
        foreach ($users as $userid => $u) {
            $uPid = $this->normalizePid($u['pid'] ?? null);
            if ($uPid === '') continue;
            $pidToUserid[$uPid] = (string)$userid;
            $useridToPid[(string)$userid] = $uPid;
        }

        $out = [];

        // 1) Try calling with PIDs in userlist (often works, like your Postman example)
        foreach (array_chunk($pids, 50) as $chunk) {
            $rows = $this->positionRowsForUserlist(implode(',', $chunk));
            if (!empty($rows)) {
                foreach ($this->groupPositionRowsByPidOrUserid($rows, $useridToPid) as $pidKey => $rowsForPid) {
                    $out[$pidKey] = $this->positionTitlesFromRows($rowsForPid);
                }
            }
        }

        // 2) Fill any missing PIDs by retrying with userids
        $missing = array_values(array_filter($pids, fn($p) => !isset($out[$p])));
        if (!empty($missing)) {
            $userids = [];
            foreach ($missing as $p) {
                if (isset($pidToUserid[$p])) $userids[] = $pidToUserid[$p];
            }

            foreach (array_chunk($userids, 50) as $chunkUserids) {
                $rows = $this->positionRowsForUserlist(implode(',', $chunkUserids));
                if (empty($rows)) continue;

                foreach ($this->groupPositionRowsByPidOrUserid($rows, $useridToPid) as $pidKey => $rowsForPid) {
                    $out[$pidKey] = $this->positionTitlesFromRows($rowsForPid);
                }
            }
        }

        return $out;
    }

    private function positionRowsForUserlist(string $userlist): array
    {
        $userlist = trim((string)$userlist);
        if ($userlist === '') return [];

        // with unitid (same pattern as subjects/publications/etc.) :contentReference[oaicite:5]{index=5}
        $payload = $this->getActivitiesDetailed($this->activityPositionsId, [
            'userlist' => $userlist,
            'data'     => 'detailed',
        ]);

        $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityPositionsId);

        // fallback without unitid (Go-style)
        if (empty($rows)) {
            $payload = $this->getActivitiesDetailedNoUnit($this->activityPositionsId, [
                'userlist' => $userlist,
                'data'     => 'detailed',
            ]);
            $rows = $this->normalizeActivitiesRows($payload, (string)$this->activityPositionsId);
        }

        return $rows;
    }

    private function positionTitlesFromRows(array $rows): array
    {
        if (empty($rows)) return [];

        $items = [];
        $seen = [];

        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $fields = $row['fields'] ?? null;
            if (!is_array($fields)) continue;

            $title = $this->asCleanString($fields['Position Title'] ?? '');
            if ($title === '') continue;

            // Title-case if all-caps (PROFESSOR -> Professor)
            if (!preg_match('/[a-z]/', $title)) {
                $title = ucwords(mb_strtolower($title));
            }

            $order = (int)($fields['Order'] ?? 9999);

            $k = mb_strtolower(trim($title));
            if (isset($seen[$k])) continue;
            $seen[$k] = true;

            $items[] = ['title' => $title, 'order' => $order];
        }

        usort($items, function ($a, $b) {
            if ($a['order'] !== $b['order']) return $a['order'] <=> $b['order'];
            return strcasecmp($a['title'], $b['title']);
        });

        return $items;
    }

    /**
     * Groups raw activity rows by PID if userid is numeric PID, otherwise maps userid->pid using $useridToPid.
     */
    private function groupPositionRowsByPidOrUserid(array $rows, array $useridToPid): array
    {
        $grouped = [];
        foreach ($rows as $r) {
            if (!is_array($r)) continue;
            $uid = (string)($r['userid'] ?? $r['facultyid'] ?? '');
            if ($uid === '') continue;

            $pidKey = preg_match('/^\d+$/', $uid) ? $this->normalizePid($uid) : ($useridToPid[$uid] ?? '');
            if ($pidKey === '') continue;

            $grouped[$pidKey][] = $r;
        }
        return $grouped;
    }
}
