<?php

namespace App\Repositories\v1\cobapi;

use App\Repositories\v1\cobapi\clients\Faculty180Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class DirectoryByParametersRepository
{
    public function __construct(
        protected Faculty180Client $faculty180
    ) {}

    public function fetchDirectoryRows(?string $keyword, ?string $department): array
    {
        $keyword = trim((string) $keyword);
        $department = trim((string) $department);

        $keywordLike = ($keyword === '') ? '%' : '%' . $keyword . '%';
        $deptLike    = ($department === '') ? '%' : $department; // allow caller to include %

        $sql = "
        SELECT
            -- internal only (DO NOT expose): used to fetch interests from Faculty180
            ISNULL(p.panther_id, '') AS _pid_internal,

            ISNULL(p.nickname, '') AS employeeID,
            ISNULL(p.last_name, '') AS last_name,
            ISNULL(p.first_name, '') AS first_name,
            ISNULL(d.name, '') AS department_desc,
            ISNULL(p.business_email, '') AS email,
            CASE
                WHEN p.business_phone_number IS NULL OR LTRIM(RTRIM(p.business_phone_number)) = '' THEN ''
                WHEN p.business_phone_number_ext IS NULL OR LTRIM(RTRIM(p.business_phone_number_ext)) = '' THEN p.business_phone_number
                ELSE p.business_phone_number + ' x' + p.business_phone_number_ext
            END AS phone,
            ISNULL(p.avatar, '') AS profile_picture,

            ISNULL(COALESCE(wt.name, jt.name), '') AS title,

            ISNULL(pl.description, '') AS location,

            CASE
                WHEN fac.id IS NULL THEN ''
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                     AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                     AND (
                          fac.description LIKE '%' + LTRIM(RTRIM(fac.room)) + '%'
                          OR RIGHT(LTRIM(RTRIM(fac.description)), LEN(LTRIM(RTRIM(fac.room)))) = LTRIM(RTRIM(fac.room))
                     )
                    THEN LTRIM(RTRIM(fac.description))
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                     AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                    THEN LTRIM(RTRIM(fac.description)) + ' ' + LTRIM(RTRIM(fac.room))
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> '' THEN LTRIM(RTRIM(fac.description))
                WHEN ISNULL(LTRIM(RTRIM(fac.code)), '') <> '' THEN LTRIM(RTRIM(fac.code))
                ELSE ''
            END AS facility,

            '' AS profile_url,
            '' AS faculty_class
        FROM [mybusiness2.0].[hr].[persons] p

        OUTER APPLY (
            SELECT TOP 1 ed.*
            FROM [mybusiness2.0].[hr].[employee_directories] ed
            WHERE ed.person_id = p.id
              AND ISNULL(ed.locked, 0) = 0
              AND (ed.start_date IS NULL OR ed.start_date <= GETDATE())
              AND (ed.end_date IS NULL OR ed.end_date >= GETDATE())
            ORDER BY
              CASE WHEN ed.end_date IS NULL THEN 0 ELSE 1 END ASC,
              ed.start_date ASC,
              ed.created_at ASC,
              ed.id ASC
        ) ed

        OUTER APPLY (
            SELECT TOP 1 a.*
            FROM [mybusiness2.0].[hr].[assignments] a
            WHERE a.person_id = p.id
              AND ISNULL(a.active, 0) = 1
              AND (a.start_date IS NULL OR a.start_date <= GETDATE())
              AND (a.end_date IS NULL OR a.end_date >= GETDATE())
            ORDER BY
              CASE WHEN a.working_title_id IS NOT NULL THEN 0 ELSE 1 END ASC,
              CASE WHEN a.end_date IS NULL THEN 0 ELSE 1 END ASC,
              a.start_date ASC,
              a.created_at ASC,
              a.id ASC
        ) a

        LEFT JOIN [mybusiness2.0].[hr].[working_titles] wt
            ON wt.id = a.working_title_id
        LEFT JOIN [mybusiness2.0].[hr].[job_titles] jt
            ON jt.id = a.job_title_id

        LEFT JOIN [mybusiness2.0].[gn].[departments] d
            ON d.id = a.department_id
        LEFT JOIN [mybusiness2.0].[hr].[business_units] bu
            ON bu.id = a.business_unit_id

        LEFT JOIN [mybusiness2.0].[gn].[physical_locations] pl
            ON pl.id = COALESCE(a.public_establishment_id, a.physical_location_id)

        LEFT JOIN [mybusiness2.0].[gn].[facilities] fac
            ON fac.id = COALESCE(a.public_facility_id, a.facility_id)

        WHERE
            p.active = 1
            AND ed.id IS NOT NULL
            AND bu.code = 'AACBA'

            AND (ISNULL(d.name, '') LIKE ?)

            AND (
                ? = '%'
                OR (
                    ISNULL(p.first_name, '') LIKE ?
                    OR ISNULL(p.last_name, '') LIKE ?
                    OR ISNULL(p.nickname, '') LIKE ?
                    OR ISNULL(COALESCE(wt.name, jt.name), '') LIKE ?
                )
            )

        ORDER BY
            ISNULL(p.last_name, '') ASC,
            ISNULL(p.first_name, '') ASC,
            ISNULL(p.nickname, '') ASC
        ";

        return DB::select($sql, [
            $deptLike,
            $keywordLike,
            $keywordLike,
            $keywordLike,
            $keywordLike,
            $keywordLike,
        ]);
    }

    /**
     * Build: [ employeeID => [ ['interest' => '...'], ... ] ]
     * Same approach as DirectoryByLetter: cached expertiseAreasForPid(pid).
     */
    public function fetchInterestsByEmployeeId(array $directoryRows): array
    {
        if (empty($directoryRows)) return [];

        $pidByEmployee = [];
        foreach ($directoryRows as $r) {
            $employeeID = trim((string)($r->employeeID ?? ''));
            $pid = $this->normalizePid($r->_pid_internal ?? null);

            if ($employeeID !== '' && $pid !== '') {
                $pidByEmployee[$employeeID] = $pid;
            }
        }

        if (empty($pidByEmployee)) return [];

        $out = [];

        foreach ($pidByEmployee as $employeeID => $pid) {
            $areas = Cache::remember(
                'cobapi.faculty180.expertiseAreasForPid.' . $pid,
                now()->addMinutes(30),
                fn () => $this->faculty180->expertiseAreasForPid($pid)
            );

            if (empty($areas)) continue;

            $dedup = [];
            foreach ((array)$areas as $a) {
                $v = trim((string)$a);
                if ($v === '') continue;

                $lv = mb_strtolower($v);
                if (in_array($lv, ['yes', 'no', 'true', 'false'], true)) continue;

                $dedup[$lv] = $v;
            }

            if (empty($dedup)) continue;

            $vals = array_values($dedup);
            sort($vals, SORT_NATURAL | SORT_FLAG_CASE);

            $out[$employeeID] = array_map(fn ($v) => ['interest' => $v], $vals);
        }

        return $out;
    }

    private function normalizePid(mixed $pid): string
    {
        $s = trim((string)($pid ?? ''));
        if ($s === '') return '';
        return preg_replace('/\D+/', '', $s) ?? '';
    }
}
