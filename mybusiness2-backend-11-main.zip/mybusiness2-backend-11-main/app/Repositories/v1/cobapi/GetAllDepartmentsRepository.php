<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class GetAllDepartmentsRepository
{
    /**
     * COB departments only:
     * join gn.departments -> hr.business_units and filter by bu.code = 'AACBA'
     */
    public function viewAll(): array
    {
        return DB::table(DB::raw('[mybusiness2.0].[gn].[departments] AS d'))
            ->join(DB::raw('[mybusiness2.0].[hr].[business_units] AS bu'), 'bu.id', '=', 'd.business_unit_id')
            ->select(DB::raw('d.[name] AS department_desc'))
            ->where('bu.code', '=', 'AACBA')
            ->whereNotNull('d.name')
            ->where(DB::raw("LTRIM(RTRIM(d.[name]))"), '<>', '')
            ->distinct()
            ->orderBy('department_desc')
            ->get()
            ->all();
    }
}
