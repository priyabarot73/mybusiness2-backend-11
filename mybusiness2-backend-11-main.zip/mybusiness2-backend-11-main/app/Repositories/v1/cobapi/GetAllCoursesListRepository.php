<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class GetAllCoursesListRepository
{
    /**
     * Read from new table: [mybusiness2.0].[ac].[courses]
     * You can adjust filters if your “active” semantics evolve.
     */
    public function viewAll(): array
    {
        return DB::table(DB::raw('[mybusiness2.0].[ac].[courses]'))
            ->select([
                DB::raw('[code] AS courseID'),
                DB::raw('[name] AS courseName'),
                DB::raw('[description] AS courseDescription'),
                DB::raw("'9999' AS discontinueTerm"), // legacy compat
            ])
            ->where('active', 1)
            ->orderBy('courseID')
            ->get()
            ->all();
    }
}
