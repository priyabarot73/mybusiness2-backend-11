<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class ListAllTermsRepository
{
    public function viewAll(): array
    {
        $q = DB::table(DB::raw('[mybusiness2.0].[ac].[terms] AS t'))
            ->select([
                DB::raw('t.[number] AS Term'),
                DB::raw('t.[semester] AS Semester'),
                DB::raw('t.[year] AS Year'),
                DB::raw('t.[academic_year] AS AcademicYear'),

                DB::raw("CONVERT(VARCHAR(10), t.[begin_dt], 23) AS starting"),
                DB::raw("CONVERT(VARCHAR(10), t.[end_dt], 23) AS ending"),

                // TODO: map A/B session dates when confirmed
                DB::raw("'' AS startingA"),
                DB::raw("'' AS endingA"),
                DB::raw("'' AS startingB"),
                DB::raw("'' AS endingB"),
            ]);

        // IMPORTANT: SQL Server + Laravel double-bracketing fix
        $q->orderByRaw('t.[number] DESC');

        return $q->get()->all();
    }
}
