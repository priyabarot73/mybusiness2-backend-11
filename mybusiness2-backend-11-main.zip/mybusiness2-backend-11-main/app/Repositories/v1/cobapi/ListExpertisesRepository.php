<?php

namespace App\Repositories\v1\cobapi;

use App\Repositories\v1\cobapi\clients\Faculty180Client;

class ListExpertisesRepository
{
    protected Faculty180Client $client;

    public function __construct(Faculty180Client $client)
    {
        $this->client = $client;
    }

    public function viewAll(): array
    {
        // 1) Users
        $usersPayload = $this->client->getUsersDetailed();

        // Some APIs wrap results; support a few common shapes
        $users = $usersPayload['results'] ?? $usersPayload['data'] ?? $usersPayload;

        $activeUserIds = [];

        if (is_array($users)) {
            foreach ($users as $u) {
                if (!is_array($u)) continue;

                $status = strtolower(trim((string)($u['employmentstatus'] ?? '')));

                // Faculty180 may not use exactly "Active"
                // Keep anything that is NOT explicitly inactive
                if ($status !== '' && $status !== 'inactive') {
                    $userid = trim((string)($u['userid'] ?? ''));
                    if ($userid !== '') {
                        $activeUserIds[$userid] = true;
                    }
                }
            }
        }

        // Zero actives, fall back to "don’t filter" rather than returning empty
        $filterByActive = count($activeUserIds) > 0;

        // 2) Activities (expertise)
        $activitiesPayload = $this->client->getExpertiseActivitiesDetailed();

        // Payload might be keyed by "13" OR could just be a list
        $items = $activitiesPayload['13']
            ?? $activitiesPayload[13]
            ?? $activitiesPayload['results']
            ?? $activitiesPayload['data']
            ?? $activitiesPayload;

        $seen = [];
        $out = [];

        if (is_array($items)) {
            foreach ($items as $item) {
                if (!is_array($item)) continue;

                $userid = trim((string)($item['userid'] ?? ''));
                if ($filterByActive && ($userid === '' || empty($activeUserIds[$userid]))) {
                    continue;
                }

                $fields = $item['fields'] ?? [];
                if (!is_array($fields)) continue;

                foreach ($fields as $label => $val) {
                    // Only Area(s) fields
                    if (stripos((string)$label, 'area') === false) continue;

                    $area = trim((string)$val);
                    if ($area === '') continue;

                    $area = preg_replace('/\s+/', ' ', $area);

                    $key = mb_strtolower($area);
                    if (isset($seen[$key])) continue;
                    $seen[$key] = true;

                    $letter = mb_strtoupper(mb_substr(ltrim($area), 0, 1));

                    $out[] = [
                        'expertise_type' => $area,
                        'letter' => $letter,
                    ];
                }
            }
        }

        usort($out, fn($a, $b) => strcmp($a['expertise_type'], $b['expertise_type']));

        return $out;
    }

}
