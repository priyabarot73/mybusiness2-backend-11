<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class ListAllInstructorsRepository
{
    public function viewAll(): array
    {
        $q = DB::table(DB::raw('[mybusiness2.0].[ac].[instructors] AS i'))
            ->join(DB::raw('[mybusiness2.0].[hr].[persons] AS p'), 'p.id', '=', 'i.person_id')
            ->leftJoin(DB::raw('[mybusiness2.0].[hr].[employee_types] AS et'), 'et.id', '=', 'i.employee_type_id')
            ->select([
                DB::raw("LTRIM(RTRIM(ISNULL(p.[last_name], ''))) + ', ' + LTRIM(RTRIM(ISNULL(p.[first_name], ''))) AS Instructor"),
                DB::raw("ISNULL(p.[first_name], '') AS FirstName"),
                DB::raw("ISNULL(p.[last_name], '') AS LastName"),
                DB::raw("ISNULL(p.[nickname], '') AS InstructorID"),
            ])
            ->where('i.active', 1)
            ->where('p.active', 1)
            ->distinct();

        // Works with DISTINCT because these are selected aliases
        $q->orderByRaw('LastName ASC, FirstName ASC');

        return $q->get()->all();
    }
}
