<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class GetGroupsRepository
{
    public function viewAll(?string $filterType = null, ?string $filterID = null): array
    {
        $q = DB::table(DB::raw('[mybusiness2.0].[hr].[team_types] AS tt'))
            ->join(DB::raw('[mybusiness2.0].[hr].[teams] AS t'), 't.team_type_id', '=', 'tt.id')
            ->join(DB::raw('[mybusiness2.0].[hr].[employee_directories] AS ed'), 'ed.team_id', '=', 't.id')
            ->select([
                DB::raw('tt.[name] AS filterType'),
                DB::raw('t.[name]  AS filterID'),
                DB::raw('t.[name]  AS filterName'),
                DB::raw("'' AS filterDescription"),
            ])
            ->distinct();

        if (!empty($filterType)) {
            $q->whereRaw('LOWER(tt.[name]) = ?', [mb_strtolower($filterType)]);
        }
        if (!empty($filterID)) {
            $q->whereRaw('LOWER(t.[name]) = ?', [mb_strtolower($filterID)]);
        }

        // avoid Laravel double-bracketing
        $q->orderByRaw('tt.[name]')
            ->orderByRaw('t.[name]');

        return $q->get()->all();
    }

    /**
     * When filterType + filterID are provided, legacy COBAPI returns EMPLOYEES (array),
     * not { groups: [...] }.
     *
     * Source (new DB):
     * team_types.name (filterType) -> teams.name (filterID) -> employee_directories -> persons
     */
    public function viewEmployeesByGroupAndFilter(string $filterType, string $filterID): array
    {
        $sql = "
        SELECT
            -- legacy response keys
            ISNULL(p.nickname, '') AS employeeID,
            ISNULL(p.first_name, '') AS first_name,
            ISNULL(p.last_name, '') AS last_name,

            CASE
                WHEN p.avatar IS NULL OR LTRIM(RTRIM(p.avatar)) = '' THEN ''
                ELSE '/files/userpics/' + REPLACE(p.avatar, 'photos/', '')
            END AS photo,

            ISNULL(COALESCE(wt.name, jt.name), '') AS title,
            ISNULL(suf.name, '') AS suffix,

            -- Location: using facility description/room like directory (e.g. RB 253)
            CASE
                WHEN fac.id IS NULL THEN ''
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> '' AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                    THEN LTRIM(RTRIM(fac.description)) + ' ' + LTRIM(RTRIM(fac.room))
                WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> '' THEN LTRIM(RTRIM(fac.description))
                WHEN ISNULL(LTRIM(RTRIM(fac.code)), '') <> '' THEN LTRIM(RTRIM(fac.code))
                ELSE ''
            END AS location,

            ISNULL(p.business_email, '') AS email,

            CASE
                WHEN p.business_phone_number IS NULL OR LTRIM(RTRIM(p.business_phone_number)) = '' THEN ''
                WHEN p.business_phone_number_ext IS NULL OR LTRIM(RTRIM(p.business_phone_number_ext)) = '' THEN p.business_phone_number
                ELSE p.business_phone_number + ' x' + p.business_phone_number_ext
            END AS phone,

            '' AS departmentPhone,

            ISNULL(ed.appearance, 999999) AS orderBy,

            '' AS campus,
            '' AS cvLink,
            '' AS linkedin,
            '' AS personalWebUrl,

            -- TODO: derive properly later
            'true' AS faculty,
            '' AS faculty_class

        FROM [mybusiness2.0].[hr].[employee_directories] ed
        INNER JOIN [mybusiness2.0].[hr].[teams] t
            ON t.id = ed.team_id
        INNER JOIN [mybusiness2.0].[hr].[team_types] tt
            ON tt.id = t.team_type_id
        INNER JOIN [mybusiness2.0].[hr].[persons] p
            ON p.id = ed.person_id
        LEFT JOIN [mybusiness2.0].[hr].[suffixes] suf
            ON suf.id = p.suffix_id

        OUTER APPLY (
            SELECT TOP 1 a.*
            FROM [mybusiness2.0].[hr].[assignments] a
            WHERE a.person_id = p.id
              AND ISNULL(a.active, 0) = 1
              AND (a.start_date IS NULL OR a.start_date <= GETDATE())
              AND (a.end_date IS NULL OR a.end_date >= GETDATE())
            ORDER BY
              CASE WHEN a.working_title_id IS NOT NULL THEN 0 ELSE 1 END ASC,
              CASE WHEN a.end_date IS NULL THEN 0 ELSE 1 END ASC,
              a.start_date ASC,
              a.created_at ASC,
              a.id ASC
        ) a

        LEFT JOIN [mybusiness2.0].[hr].[working_titles] wt
            ON wt.id = a.working_title_id
        LEFT JOIN [mybusiness2.0].[hr].[job_titles] jt
            ON jt.id = a.job_title_id
        LEFT JOIN [mybusiness2.0].[gn].[facilities] fac
            ON fac.id = a.facility_id

        WHERE
            p.active = 1
            AND ISNULL(ed.locked, 0) = 0
            AND LOWER(tt.name) = LOWER(?)
            AND LOWER(t.name)  = LOWER(?)

        ORDER BY
            ISNULL(ed.appearance, 999999) ASC,
            ISNULL(p.last_name, '') ASC,
            ISNULL(p.first_name, '') ASC,
            ISNULL(p.nickname, '') ASC
    ";

        return DB::select($sql, [$filterType, $filterID]);
    }

}
