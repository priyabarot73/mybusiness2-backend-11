<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

use App\Repositories\v1\cobapi\clients\Faculty180Client;

class AllFacultyNamesRepository
{
    /**
     * Returns all COB faculty names (A-Z) with the legacy BasicFaculty shape.
     *
     * Strategy:
     * - Start from persons
     * - Require a visible employee_directory row (outer apply TOP 1)
     * - Pick ONE “main” assignment (outer apply TOP 1)
     * - Restrict to COB using business_units.code = 'AACBA'
     * - Restrict to faculty via ac.instructors + employee_types codes (e.g., FAC/ADJ)
     *
     * Interests are not included here (not migrated yet).
     */
    public function __construct(
        protected Faculty180Client $faculty180
    ) {}
    public function fetchAllFacultyRows(): array
    {
        return Cache::remember('cobapi_allFacultyNames', 300, function () {

            $sql = "
            SELECT
                p.panther_id AS _pid_internal,
                ISNULL(p.nickname, '') AS employeeID,
                ISNULL(p.last_name, '') AS last_name,
                ISNULL(p.first_name, '') AS first_name,

                ISNULL(d.name, '') AS department_desc,
                ISNULL(p.business_email, '') AS email,

                CASE
                    WHEN p.business_phone_number IS NULL OR LTRIM(RTRIM(p.business_phone_number)) = '' THEN ''
                    WHEN p.business_phone_number_ext IS NULL OR LTRIM(RTRIM(p.business_phone_number_ext)) = '' THEN p.business_phone_number
                    ELSE p.business_phone_number + ' x' + p.business_phone_number_ext
                END AS phone,

                ISNULL(p.avatar, '') AS profile_picture,

                ISNULL(COALESCE(wt.name, jt.name), '') AS title,

                -- raw campus only; final legacy location built in PHP
                ISNULL(pl.description, '') AS campus_location,

                CASE
                    WHEN fac.id IS NULL THEN ''

                    WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                         AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                         AND (
                              fac.description LIKE '%' + LTRIM(RTRIM(fac.room)) + '%'
                              OR RIGHT(LTRIM(RTRIM(fac.description)), LEN(LTRIM(RTRIM(fac.room)))) = LTRIM(RTRIM(fac.room))
                         )
                        THEN LTRIM(RTRIM(fac.description))

                    WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> ''
                         AND ISNULL(LTRIM(RTRIM(fac.room)), '') <> ''
                        THEN LTRIM(RTRIM(fac.description)) + ' ' + LTRIM(RTRIM(fac.room))

                    WHEN ISNULL(LTRIM(RTRIM(fac.description)), '') <> '' THEN LTRIM(RTRIM(fac.description))
                    WHEN ISNULL(LTRIM(RTRIM(fac.code)), '') <> '' THEN LTRIM(RTRIM(fac.code))
                    ELSE ''
                END AS facility,

                ISNULL(LTRIM(RTRIM(fac.code)), '') AS facility_code,
                ISNULL(LTRIM(RTRIM(fac.room)), '') AS facility_room,

                CASE
                  WHEN NULLIF(LTRIM(RTRIM(ISNULL(p.first_name,''))), '') IS NULL
                    OR NULLIF(LTRIM(RTRIM(ISNULL(p.last_name,''))),  '') IS NULL
                  THEN ''
                  ELSE
                    REPLACE(REPLACE(
                      REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(p.first_name,''))), ' ', '-'), '''', ''), '.', ''), ',', ''),
                      '--','-'
                    )
                    + '-' +
                    REPLACE(REPLACE(
                      REPLACE(REPLACE(REPLACE(LTRIM(RTRIM(ISNULL(p.last_name,''))),  ' ', '-'), '''', ''), '.', ''), ',', ''),
                      '--','-'
                    )
                END AS profile_url,

                ISNULL(et.code, '') AS faculty_class

            FROM [mybusiness2.0].[hr].[persons] p

            OUTER APPLY (
                SELECT TOP 1 ed.*
                FROM [mybusiness2.0].[hr].[employee_directories] ed
                WHERE ed.person_id = p.id
                  AND ISNULL(ed.locked, 0) = 0
                  AND (ed.start_date IS NULL OR ed.start_date <= GETDATE())
                  AND (ed.end_date IS NULL OR ed.end_date >= GETDATE())
                ORDER BY
                  CASE WHEN ed.end_date IS NULL THEN 0 ELSE 1 END ASC,
                  ed.start_date ASC,
                  ed.created_at ASC,
                  ed.id ASC
            ) ed

            OUTER APPLY (
                SELECT TOP 1 a.*
                FROM [mybusiness2.0].[hr].[assignments] a
                WHERE a.person_id = p.id
                  AND ISNULL(a.active, 0) = 1
                  AND (a.start_date IS NULL OR a.start_date <= GETDATE())
                  AND (a.end_date IS NULL OR a.end_date >= GETDATE())
                ORDER BY
                  CASE WHEN a.working_title_id IS NOT NULL THEN 0 ELSE 1 END ASC,
                  CASE WHEN a.end_date IS NULL THEN 0 ELSE 1 END ASC,
                  a.start_date ASC,
                  a.created_at ASC,
                  a.id ASC
            ) a

            INNER JOIN [mybusiness2.0].[ac].[instructors] i
                ON i.person_id = p.id
               AND ISNULL(i.active, 0) = 1

            INNER JOIN [mybusiness2.0].[hr].[employee_types] et
                ON et.id = i.employee_type_id
               AND ISNULL(et.active, 0) = 1

            LEFT JOIN [mybusiness2.0].[hr].[working_titles] wt
                ON wt.id = a.working_title_id
            LEFT JOIN [mybusiness2.0].[hr].[job_titles] jt
                ON jt.id = a.job_title_id

            LEFT JOIN [mybusiness2.0].[gn].[departments] d
                ON d.id = a.department_id
            LEFT JOIN [mybusiness2.0].[hr].[business_units] bu
                ON bu.id = a.business_unit_id

            LEFT JOIN [mybusiness2.0].[gn].[physical_locations] pl
                ON pl.id = COALESCE(a.public_establishment_id, a.physical_location_id)

            LEFT JOIN [mybusiness2.0].[gn].[facilities] fac
                ON fac.id = COALESCE(a.public_facility_id, a.facility_id)

            WHERE
                p.active = 1
                AND ed.id IS NOT NULL
                AND bu.code = 'AACBA'
                AND et.code IN ('FAC','ADJ')

            ORDER BY
                ISNULL(p.last_name, '') ASC,
                ISNULL(p.first_name, '') ASC,
                ISNULL(p.nickname, '') ASC
        ";

            $rows = DB::select($sql);

            // Gather PIDs (internal only)
            $pids = [];
            foreach ($rows as $r) {
                $pid = $this->normalizePid($r->_pid_internal ?? null);
                if ($pid !== '') $pids[$pid] = true;
            }

            // Pull Faculty180 position titles (-9) in batches
            $positionsByPid = $this->fetchFaculty180PositionsByPid(array_keys($pids));

            foreach ($rows as $row) {
                // existing transformations
                $row->location = $this->formatLegacyLocation(
                    (string)($row->campus_location ?? ''),
                    (string)($row->facility_code ?? ''),
                    (string)($row->facility_room ?? '')
                );

                $row->profile_picture = $this->storageUrl((string)($row->profile_picture ?? ''));

                // NEW: overwrite title using Faculty180 positions (-9)
                $pid = $this->normalizePid($row->_pid_internal ?? null);

                $dbTitleFallback = (string)($row->title ?? '');
                $dept = (string)($row->department_desc ?? '');

                $posItems = $positionsByPid[$pid] ?? [];
                $row->title = $this->buildTitleHtmlFromFaculty180($posItems, $dept, $dbTitleFallback);

                // Never leak PID
                unset($row->_pid_internal);
            }

            return $rows;
        });
    }

    private function formatLegacyLocation(string $campus, string $facilityCode, string $facilityRoom): string
    {
        $campus = trim($campus);
        $facilityShort = $this->formatFacilityForLocation($facilityCode, $facilityRoom);

        $addressLine = '';
        $cityLine = '';

        $c = mb_strtolower($campus);

        if (str_contains($c, 'modesto') || str_contains($c, 'maidique')) {
            $addressLine = '11200 S.W. 8th St';
            $cityLine = 'Miami, FL 33199';
        } elseif (str_contains($c, 'biscayne')) {
            $addressLine = '3000 NE 151st St';
            $cityLine = 'North Miami, FL 33181';
        } elseif (str_contains($c, 'brickell')) {
            $addressLine = '1101 Brickell Ave';
            $cityLine = 'Miami, FL 33131';
        }

        $out = $campus;

        if ($addressLine !== '') {
            $line2 = $addressLine;
            if ($facilityShort !== '') {
                $line2 .= ', ' . $facilityShort;
            }
            $out = ($out !== '' ? $out . '<BR>' : '') . $line2;
        }

        if ($cityLine !== '') {
            $out .= ($out !== '' ? '<BR>' : '') . $cityLine;
        }

        return $out;
    }

    private function formatFacilityForLocation(string $facilityCode, string $facilityRoom): string
    {
        $facilityCode = strtoupper(trim($facilityCode));
        $facilityRoom = strtoupper(trim($facilityRoom));

        $facilityCode = preg_replace('/\s+/', '', $facilityCode) ?? '';
        $facilityRoom = preg_replace('/\s+/', '', $facilityRoom) ?? '';

        if ($facilityCode === '' && $facilityRoom === '') {
            return '';
        }

        if ($facilityCode !== '' && $facilityRoom !== '') {
            // If code already ends with room, split it there
            if (str_ends_with($facilityCode, $facilityRoom)) {
                $prefix = substr($facilityCode, 0, strlen($facilityCode) - strlen($facilityRoom));
                $prefix = trim($prefix);

                if ($prefix !== '') {
                    return $prefix . ' ' . $facilityRoom;
                }

                return $facilityRoom;
            }

            // Fallback if code is just letters like RB and room is 307B
            return $facilityCode . ' ' . $facilityRoom;
        }

        // If only code exists, try regex split like RB307B -> RB 307B
        if ($facilityCode !== '') {
            if (preg_match('/^([A-Z]+)(\d+[A-Z]*)$/', $facilityCode, $m)) {
                return $m[1] . ' ' . $m[2];
            }
            return $facilityCode;
        }

        return $facilityRoom;
    }

    private function storageUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') return '';

        // Already absolute
        if (preg_match('/^https?:\/\//i', $path)) {
            return $path;
        }

        // Normalize
        $path = ltrim($path, '/');

        // If path already starts with "storage/", don't double it
        if (str_starts_with($path, 'storage/')) {
            $path = substr($path, strlen('storage/'));
        }

        $base = 'https://mybusiness2.fiu.edu/storage';
        return rtrim($base, '/') . '/' . $path;
    }

    private function normalizePid(mixed $pid): string
    {
        $s = trim((string)($pid ?? ''));
        if ($s === '') return '';
        $s = preg_replace('/\D+/', '', $s) ?? '';
        return trim($s);
    }

    /**
     * Returns: [pid => [ ['title'=>string,'order'=>int], ... ], ...]
     */
    private function fetchFaculty180PositionsByPid(array $pids): array
    {
        // build pid<->userid maps (for fallback)
        $users = $this->faculty180->usersByUseridDetailed(true); // relaxed active filter
        $pidToUserid = [];
        $useridToPid = [];

        foreach ($users as $userid => $u) {
            $uPid = $this->normalizePid($u['pid'] ?? null);
            if ($uPid === '') continue;
            $pidToUserid[$uPid] = (string)$userid;
            $useridToPid[(string)$userid] = $uPid;
        }

        $out = [];

        // 1) Try with PID userlist first (your Postman test shows this works)
        foreach (array_chunk($pids, 50) as $chunk) {
            $rows = $this->fetchPositionsRowsForUserlist(implode(',', $chunk));
            $this->mergePositionRowsIntoMap($out, $rows, $useridToPid);
        }

        // 2) Retry missing PIDs using userids
        $missing = array_values(array_filter($pids, fn($p) => !isset($out[$p])));
        if (!empty($missing)) {
            $userids = [];
            foreach ($missing as $p) {
                if (isset($pidToUserid[$p])) $userids[] = $pidToUserid[$p];
            }

            foreach (array_chunk($userids, 50) as $chunkUserids) {
                $rows = $this->fetchPositionsRowsForUserlist(implode(',', $chunkUserids));
                $this->mergePositionRowsIntoMap($out, $rows, $useridToPid);
            }
        }

        // Sort + dedupe within each pid
        foreach ($out as $pid => $items) {
            // dedupe by title, keep lowest order
            $uniq = [];
            foreach ($items as $it) {
                $k = mb_strtolower(trim($it['title']));
                if (!isset($uniq[$k]) || $it['order'] < $uniq[$k]['order']) {
                    $uniq[$k] = $it;
                }
            }
            $items = array_values($uniq);

            usort($items, function ($a, $b) {
                if ($a['order'] !== $b['order']) return $a['order'] <=> $b['order'];
                return strcasecmp($a['title'], $b['title']);
            });

            $out[$pid] = $items;
        }

        return $out;
    }

    private function fetchPositionsRowsForUserlist(string $userlist): array
    {
        $userlist = trim($userlist);
        if ($userlist === '') return [];

        // With unitid
        $payload = $this->faculty180->getActivitiesDetailed(-9, [
            'userlist' => $userlist,
            'data'     => 'detailed',
        ]);

        $rows = $payload['-9'] ?? $payload[-9] ?? [];
        if (!is_array($rows)) $rows = [];

        // Fallback without unitid
        if (empty($rows)) {
            $payload = $this->faculty180->getActivitiesDetailedNoUnit(-9, [
                'userlist' => $userlist,
                'data'     => 'detailed',
            ]);
            $rows = $payload['-9'] ?? $payload[-9] ?? [];
            if (!is_array($rows)) $rows = [];
        }

        return $rows;
    }

    private function mergePositionRowsIntoMap(array &$out, array $rows, array $useridToPid): void
    {
        foreach ($rows as $r) {
            if (!is_array($r)) continue;

            $uid = (string)($r['userid'] ?? $r['facultyid'] ?? '');
            if ($uid === '') continue;

            // If userid is numeric, it might be PID; otherwise map via users endpoint
            $pid = preg_match('/^\d+$/', $uid) ? $this->normalizePid($uid) : ($useridToPid[$uid] ?? '');
            if ($pid === '') continue;

            $fields = $r['fields'] ?? null;
            if (!is_array($fields)) continue;

            $title = $this->cleanFaculty180Title((string)($fields['Position Title'] ?? ''));
            if ($title === '') continue;

            $order = (int)($fields['Order'] ?? 9999);

            $out[$pid][] = ['title' => $title, 'order' => $order];
        }
    }

    private function cleanFaculty180Title(string $s): string
    {
        $s = trim($s);
        if ($s === '') return '';

        // decode &amp; etc
        $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $s = trim($s);

        // If it's ALL CAPS, convert to Title Case (PROFESSOR -> Professor)
        if ($s !== '' && !preg_match('/[a-z]/', $s)) {
            $s = ucwords(mb_strtolower($s));
        }

        return $s;
    }

    /**
     * Builds the AllFacultyNames "title" string like:
     * Title1<br>Title2<br>Professor<br>Department of X
     */
    private function buildTitleHtmlFromFaculty180(array $posItems, string $departmentDesc, string $dbTitleFallback): string
    {
        $lines = [];

        foreach ($posItems as $it) {
            $t = trim((string)($it['title'] ?? ''));
            if ($t !== '') $lines[] = $t;
        }

        // Fallback if Faculty180 gives nothing
        if (empty($lines)) {
            $t = trim($dbTitleFallback);
            if ($t === '') return '';
            $lines[] = $t;
        }

        $dept = trim($departmentDesc);
        if ($dept !== '') {
            // append dept at end unless it’s already in one of the lines
            $already = false;
            foreach ($lines as $ln) {
                if (stripos($ln, $dept) !== false) { $already = true; break; }
            }
            if (!$already) $lines[] = $dept;
        }

        return implode('<br>', $lines);
    }

    // TODO (COBAPI): interests source not migrated yet.
}
