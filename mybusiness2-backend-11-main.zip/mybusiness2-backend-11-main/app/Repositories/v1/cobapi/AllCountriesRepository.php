<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class AllCountriesRepository
{
    public function fetchAllCountriesRows(): array
    {
        return Cache::remember('cobapi_allCountries', 300, function () {

            $q = DB::table(DB::raw('[mybusiness2.0].[gn].[countries] AS c'))
                ->select([
                    // JSON expects "country_code", but DB column is COUNTRY_SHORT_CODE
                    DB::raw("RTRIM(ISNULL(c.[COUNTRY_SHORT_CODE], '')) AS country_code"),
                    DB::raw("ISNULL(c.[COUNTRY_DESC], '') AS country_desc"),
                ])
                ->where('c.active', 1)
                ->whereRaw("ISNULL(LTRIM(RTRIM(c.[COUNTRY_SHORT_CODE])), '') <> ''")
                ->distinct();

            // Avoid Laravel double-bracketing on SQL Server
            $q->orderByRaw("RTRIM(ISNULL(c.[COUNTRY_SHORT_CODE], ''))");

            return $q->get()->all();
        });
    }
}
