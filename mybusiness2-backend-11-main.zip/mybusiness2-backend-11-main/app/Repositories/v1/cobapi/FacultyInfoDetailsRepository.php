<?php

namespace App\Repositories\v1\cobapi;

use App\Repositories\v1\cobapi\clients\Faculty180Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class FacultyInfoDetailsRepository
{
    public function __construct(
        protected Faculty180Client $faculty180
    ) {}

    public function fetchFacultyMemberInfo(string $employeeID): ?array
    {
        $employeeID = trim($employeeID);

        $cacheKey = 'cobapi.faculty_info_details.' . md5(mb_strtolower($employeeID));

        return Cache::remember($cacheKey, now()->addMinutes(10), function () use ($employeeID) {

            $row = $this->fetchPersonRow($employeeID);
            if (!$row) return null;

            $pid = $this->normalizePid($row->_pid_internal ?? null);

            // Faculty180-derived pieces
            $vitaeUrl = $pid !== '' ? $this->faculty180->vitaeDownloadUrlForPid($pid) : '';
            $areas    = $pid !== '' ? $this->faculty180->expertiseAreasForPid($pid) : [];
            $bioEscaped = $pid !== '' ? $this->faculty180->biographyHtmlForPid($pid) : '';
            $bio = $bioEscaped !== '' ? html_entity_decode($bioEscaped, ENT_QUOTES | ENT_HTML5, 'UTF-8') : '';
            $educations = $pid !== '' ? $this->faculty180->educationsForPid($pid) : [];
            $ownerName = trim((string)($row->first_name ?? '')) . ' ' . trim((string)($row->last_name ?? ''));
            $publications = $pid !== '' ? $this->faculty180->publicationsForPid($pid, $ownerName) : [];
            $subjects = $pid !== '' ? $this->faculty180->subjectsForPid($pid) : [];
            $books = $pid !== '' ? $this->faculty180->booksForPid($pid, $ownerName) : [];

            // clean + dedupe + sort
            $dedup = [];
            foreach ($areas as $a) {
                $a = trim((string)$a);
                if ($a === '') continue;
                $dedup[mb_strtolower($a)] = $a;
            }
            $areas = array_values($dedup);
            sort($areas, SORT_NATURAL | SORT_FLAG_CASE);

            $interests = array_map(fn ($a) => ['interest' => $a], $areas);

            // employeeid (legacy key) now prefers nickname/email-local-part
            $employeeid = $this->deriveEmployeeId($row);

            $imageUrl = $this->storageUrl((string)($row->avatar ?? ''));

            $imageHighResUrl = $this->storageUrl((string)($row->high_res_avatar ?? ''));
            if ($imageHighResUrl === '') {
                $imageHighResUrl = $imageUrl;
            }

            // Titles array (legacy format)
            $titles = [];

            $deptText = trim((string)($row->department_desc ?? ''));

            $pos = $pid !== '' ? $this->faculty180->positionTitlesForPid($pid) : [];

            if (!empty($pos)) {
                $i = 0;
                foreach ($pos as $it) {
                    $t = trim((string)($it['title'] ?? ''));
                    if ($t === '') continue;

                    $isAcademic = preg_match('/\bprofessor\b|\blecturer\b|\binstructor\b|\badjunct\b/i', $t);

                    if ($isAcademic && $deptText !== '' && stripos($t, $deptText) === false) {
                        $t .= '<br>' . $deptText;
                    }

                    $titles[] = [
                        'titleName' => $t,
                        'orderBy'   => (string)$i,
                        'titleType' => $isAcademic ? '2WT' : '1AP',
                    ];
                    $i++;
                }
            } else {
                // fallback to old DB behavior if Faculty180 returns nothing
                $titleText = trim((string)($row->title ?? ''));
                if ($titleText !== '') {
                    if ($deptText !== '' && stripos($titleText, $deptText) === false) {
                        $titleText .= '<br>' . $deptText;
                    }
                    $titles[] = [
                        'titleName' => $titleText,
                        'orderBy'   => '0',
                        'titleType' => '2WT',
                    ];
                }
            }

            $location = $this->formatLegacyLocation(
                (string)($row->campus_location ?? ''),
                (string)($row->facility_code ?? ''),
                (string)($row->facility_room ?? '')
            );

            return [
                'employeeid'             => $employeeid,
                'name'                   => trim((string)($row->first_name ?? '')) . ' ' . trim((string)($row->last_name ?? '')),
                'imageUrl'               => $imageUrl,
                'imageHighResUrl'        => $imageHighResUrl,
                'vitaeUrl'               => $vitaeUrl,
                'email'                  => (string)($row->email ?? ''),
                'phoneNumber'            => (string)($row->phone ?? ''),
                'institution'            => 'College of Business<BR>Florida International University',
                'location'               => $location,
                'professionalActivities' => $bio,
                'educations'             => $educations,
                'interests'              => $interests,
                'titles'                 => $titles,
                'publications' => $publications,
                'subjects' => $subjects,
                'Books' => $books,

            ];
        });
    }

    private function fetchPersonRow(string $employeeID): ?object
    {
        $employeeID = trim($employeeID);

        $emailLike  = $employeeID . '@%';
        $avatarLike = '%' . $employeeID . '%';

        $sql = "
        SELECT TOP 1
            -- internal only
            p.panther_id AS _pid_internal,

            p.first_name,
            p.last_name,
            p.nickname,
            p.business_email AS email,

            CASE
                WHEN p.business_phone_number IS NULL OR LTRIM(RTRIM(p.business_phone_number)) = '' THEN ''
                WHEN p.business_phone_number_ext IS NULL OR LTRIM(RTRIM(p.business_phone_number_ext)) = '' THEN p.business_phone_number
                ELSE p.business_phone_number + ' x' + p.business_phone_number_ext
            END AS phone,

            p.avatar,
            ISNULL(p.high_res_avatar, '') AS high_res_avatar,

            ISNULL(d.name, '') AS department_desc,
            ISNULL(COALESCE(wt.name, jt.name), '') AS title,
            ISNULL(pl.description, '') AS campus_location,
            ISNULL(LTRIM(RTRIM(fac.code)), '') AS facility_code,
            ISNULL(LTRIM(RTRIM(fac.room)), '') AS facility_room

        FROM [mybusiness2.0].[hr].[persons] p

        OUTER APPLY (
            SELECT TOP 1 ed.*
            FROM [mybusiness2.0].[hr].[employee_directories] ed
            WHERE ed.person_id = p.id
              AND ISNULL(ed.locked, 0) = 0
              AND (ed.start_date IS NULL OR ed.start_date <= GETDATE())
              AND (ed.end_date IS NULL OR ed.end_date >= GETDATE())
            ORDER BY
              CASE WHEN ed.end_date IS NULL THEN 0 ELSE 1 END ASC,
              ed.start_date ASC,
              ed.created_at ASC,
              ed.id ASC
        ) ed

        OUTER APPLY (
            SELECT TOP 1 a.*
            FROM [mybusiness2.0].[hr].[assignments] a
            WHERE a.person_id = p.id
              AND ISNULL(a.active, 0) = 1
              AND (a.start_date IS NULL OR a.start_date <= GETDATE())
              AND (a.end_date IS NULL OR a.end_date >= GETDATE())
            ORDER BY
              CASE WHEN a.working_title_id IS NOT NULL THEN 0 ELSE 1 END ASC,
              CASE WHEN a.end_date IS NULL THEN 0 ELSE 1 END ASC,
              a.start_date ASC,
              a.created_at ASC,
              a.id ASC
        ) a

        LEFT JOIN [mybusiness2.0].[hr].[working_titles] wt ON wt.id = a.working_title_id
        LEFT JOIN [mybusiness2.0].[hr].[job_titles] jt ON jt.id = a.job_title_id
        LEFT JOIN [mybusiness2.0].[gn].[departments] d ON d.id = a.department_id
        LEFT JOIN [mybusiness2.0].[hr].[business_units] bu ON bu.id = a.business_unit_id
        LEFT JOIN [mybusiness2.0].[gn].[physical_locations] pl ON pl.id = COALESCE(a.public_establishment_id, a.physical_location_id)
        LEFT JOIN [mybusiness2.0].[gn].[facilities] fac ON fac.id = COALESCE(a.public_facility_id, a.facility_id)

        WHERE
            p.active = 1
            AND ed.id IS NOT NULL
            AND bu.code = 'AACBA'
            AND (
                p.nickname = ?
                OR p.business_email LIKE ?
                OR p.avatar LIKE ?
            )
        ORDER BY p.last_name ASC, p.first_name ASC
        ";

        $rows = DB::select($sql, [$employeeID, $emailLike, $avatarLike]);
        return $rows[0] ?? null;
    }

    private function deriveEmployeeId(object $row): string
    {
        // preferred: nickname (your standard across endpoints)
        $nick = trim((string)($row->nickname ?? ''));
        if ($nick !== '') return $nick;

        // fallback: email local-part
        $email = trim((string)($row->email ?? ''));
        if ($email !== '' && str_contains($email, '@')) {
            $local = strstr($email, '@', true);
            if ($local !== false && trim($local) !== '') return trim($local);
        }

        // fallback: avatar basename
        $avatar = trim((string)($row->avatar ?? ''));
        if ($avatar !== '') {
            $avatar = str_replace(['/files/userpics/', 'photos/'], '', $avatar);
            $base = pathinfo($avatar, PATHINFO_FILENAME);
            if (trim($base) !== '') return trim($base);
        }

        return '';
    }

    private function storageUrl(string $path): string
    {
        $path = trim($path);
        if ($path === '') return '';

        // Already absolute
        if (preg_match('/^https?:\/\//i', $path)) {
            return $path;
        }

        // Normalize leading slashes
        $path = ltrim($path, '/');

        // If stored as "/storage/...." or "storage/....", avoid doubling
        if (str_starts_with($path, 'storage/')) {
            $path = substr($path, strlen('storage/'));
        }

        $base = 'https://mybusiness2.fiu.edu/storage';
        return rtrim($base, '/') . '/' . $path;
    }

    private function formatLegacyLocation(string $campus, string $facilityCode, string $facilityRoom): string
    {
        $campus = trim($campus);
        $facilityShort = $this->formatFacilityForLocation($facilityCode, $facilityRoom);

        $addressLine = '';
        $cityLine = '';

        $c = mb_strtolower($campus);

        if (str_contains($c, 'modesto') || str_contains($c, 'maidique')) {
            $addressLine = '11200 S.W. 8th St';
            $cityLine = 'Miami, FL 33199';
        } elseif (str_contains($c, 'biscayne')) {
            $addressLine = '3000 NE 151st St';
            $cityLine = 'North Miami, FL 33181';
        } elseif (str_contains($c, 'brickell')) {
            $addressLine = '1101 Brickell Ave';
            $cityLine = 'Miami, FL 33131';
        }

        $out = $campus;

        if ($addressLine !== '') {
            $line2 = $addressLine;
            if ($facilityShort !== '') {
                $line2 .= ', ' . $facilityShort;
            }
            $out = ($out !== '' ? $out . '<BR>' : '') . $line2;
        }

        if ($cityLine !== '') {
            $out .= ($out !== '' ? '<BR>' : '') . $cityLine;
        }

        return $out;
    }

    private function formatFacilityForLocation(string $facilityCode, string $facilityRoom): string
    {
        $facilityCode = strtoupper(trim($facilityCode));
        $facilityRoom = strtoupper(trim($facilityRoom));

        $facilityCode = preg_replace('/\s+/', '', $facilityCode) ?? '';
        $facilityRoom = preg_replace('/\s+/', '', $facilityRoom) ?? '';

        if ($facilityCode === '' && $facilityRoom === '') {
            return '';
        }

        if ($facilityCode !== '' && $facilityRoom !== '') {
            // Example: RB307B + 307B => RB 307B
            if (str_ends_with($facilityCode, $facilityRoom)) {
                $prefix = substr($facilityCode, 0, strlen($facilityCode) - strlen($facilityRoom));
                $prefix = trim($prefix);

                if ($prefix !== '') {
                    return $prefix . ' ' . $facilityRoom;
                }

                return $facilityRoom;
            }

            // Example: RB + 307B => RB 307B
            return $facilityCode . ' ' . $facilityRoom;
        }

        // Only code exists: try splitting letters from room-like suffix
        if ($facilityCode !== '') {
            if (preg_match('/^([A-Z]+)(\d+[A-Z]*)$/', $facilityCode, $m)) {
                return $m[1] . ' ' . $m[2];
            }
            return $facilityCode;
        }

        return $facilityRoom;
    }

    private function normalizePid(mixed $pid): string
    {
        $s = trim((string)($pid ?? ''));
        if ($s === '') return '';
        $s = preg_replace('/\D+/', '', $s) ?? '';
        return trim($s);
    }
}
