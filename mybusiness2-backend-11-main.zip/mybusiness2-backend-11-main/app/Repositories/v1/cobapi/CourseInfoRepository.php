<?php

namespace App\Repositories\v1\cobapi;

use Illuminate\Support\Facades\DB;

class CourseInfoRepository
{
    /**
     * Returns one course by code (legacy: /CourseInfo/{courseID})
     * Maps to old API fields:
     *  - code -> courseID
     *  - name -> courseName
     *  - description -> courseDescription
     *  - discontinueTerm -> "9999" (legacy active indicator)
     */
    public function viewOne(string $courseID): ?object
    {
        $courseID = trim($courseID);

        if ($courseID === '') {
            return null;
        }

        return DB::table(DB::raw('[mybusiness2.0].[ac].[courses] AS c'))
            ->select([
                DB::raw('c.[code] AS courseID'),
                DB::raw('c.[name] AS courseName'),
                DB::raw("ISNULL(c.[description], '') AS courseDescription"),
                DB::raw("'9999' AS discontinueTerm"),
            ])
            ->where('c.active', 1)
            ->where('c.code', $courseID)
            ->first();
    }
}
