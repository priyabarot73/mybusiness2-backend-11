<?php

namespace App\Console\Commands;

// GLOBAL
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

// LOCAL
use App\Models\general\ImportJob;
use App\Models\general\SchedulePanther180;

class ImportExcelSchedulePanther180Command extends Command
{
    protected $signature = 'import:excel';
    protected $description = 'Imports data from pipe-delimited CSV files as scheduled in the database';

    public function handle(): void
    {
        // Aumentar límite de memoria si es necesario
        ini_set('memory_limit', '-1');

        // Obtener trabajos programados pendientes
        $jobs = ImportJob::where('scheduled_time', '<=', now()->format('H:i:s'))
            ->where('status', 'pending')
            ->get();

        if ($jobs->isEmpty()) {
            $this->info("There are no files pending import at this time.");
            return;
        }

        $this->info("Cleaning table before import...");
        SchedulePanther180::truncate();

        foreach ($jobs as $job) {
            try {
                $this->info("Processing file: {$job->file_name}");
                $job->update(['status' => 'processing']);

                $fullPath = $job->file_path;

                if (!file_exists($fullPath)) {
                    throw new \Exception("File not found: {$fullPath}");
                }

                $file = fopen($fullPath, 'r');

                if (!$file) {
                    throw new \Exception("Unable to open file: {$fullPath}");
                }

                $header = fgetcsv($file, 0, '|');

                if (!$header) {
                    throw new \Exception("Invalid or empty header in file: {$job->file_name}");
                }

                $importCount = 0;

                while (($row = fgetcsv($file, 0, '|')) !== false) {
                    $data = array_combine($header, $row);

                    if (!$data) continue;

                    SchedulePanther180::create([
                        'class_nbr' => $this->cleanText($data['Class Nbr'] ?? null),
                        'subject' => $this->cleanText($data['Subject'] ?? null),
                        'catalog' => $this->cleanText($data['Catalog'] ?? null),
                        'section' => $this->cleanText($data['Section'] ?? null),
                        'session' => $this->cleanText($data['Session'] ?? null),
                        'term' => $this->cleanText($data['Term'] ?? null),
                        'level' => $this->cleanText($data['Level'] ?? null),
                        'title' => $this->cleanText($data['Title'] ?? null),
                        'cap' => $this->cleanText($data['Cap'] ?? null),
                        'enrl' => $this->cleanText($data['Enrl'] ?? null),
                        'enrl_waitlist' => $this->cleanText($data['Enrl Waitlist'] ?? null),
                        'wait_cap' => $this->cleanText($data['Wait Cap'] ?? null),
                        'wait_tot' => $this->cleanText($data['Wait Tot'] ?? null),
                        'department' => $this->cleanText($data['Department'] ?? null),
                        'department_formal' => $this->cleanText($data['DepartmentFormal'] ?? null),
                        'campus' => $this->cleanText($data['Campus'] ?? null),
                        'location' => $this->cleanText($data['Location'] ?? null),
                        'mode' => $this->cleanText($data['Mode'] ?? null),
                        'units' => $this->cleanText($data['Units'] ?? null),
                        'grading' => $this->cleanText($data['Grading'] ?? null),
                        'facility' => $this->cleanText($data['Facility'] ?? null),
                        'meeting_time' => $this->cleanText($data['Meeting Time'] ?? null),
                        'meeting_days' => $this->cleanText($data['Meeting Days'] ?? null),
                        'last_name' => $this->cleanText($data['Last Name'] ?? null),
                        'first_name' => $this->cleanText($data['First Name'] ?? null),
                        'middle' => $this->cleanText($data['Middle'] ?? null),
                        'notes' => $this->cleanText($data['Notes'] ?? null),
                        'class_stat' => $this->cleanText($data['Class Stat'] ?? null),
                        'cancel_dt' => $this->cleanText($data['Cancel Dt'] ?? null),
                        'sch_print' => $this->cleanText($data['Sch Print'] ?? null),
                        'consent' => $this->cleanText($data['Consent'] ?? null),
                        'acad_group' => $this->cleanText($data['Acad Group'] ?? null),
                        'start_date' => $this->cleanText($data['Start Date'] ?? null),
                        'end_date' => $this->cleanText($data['End Date'] ?? null),
                        'course_id' => $this->cleanText($data['Course ID'] ?? null),
                        'offer_nbr' => $this->cleanText($data['Offer Nbr'] ?? null),
                        'include' => $this->cleanText($data['Include'] ?? null),
                        'calc_reqd' => $this->cleanText($data['Calc Reqd'] ?? null),
                        'extract_type' => $this->cleanText($data['Extract Type'] ?? null),
                        'lms_group_id' => $this->cleanText($data['LMS Group ID'] ?? null),
                        'lms_url' => $this->cleanText($data['LMS URL'] ?? null),
                        'class_ext_dttm' => $this->cleanText($data['Class Ext Dttm'] ?? null),
                        'enrl_ext_dttm' => $this->cleanText($data['Enrl Ext Dttm'] ?? null),
                        'authentication' => $this->cleanText($data['Authentication'] ?? null),
                        'instructor_id' => $this->cleanText($data['Instructor ID'] ?? null),
                        'component' => $this->cleanText($data['Component'] ?? null),
                        'location_descr' => $this->cleanText($data['Location Descr'] ?? null),
                    ]);

                    $importCount++;
                }

                fclose($file);

                $job->update([
                    'status' => 'completed',
                    'error_message' => null,
                ]);

                $this->info("Imported {$importCount} records from {$job->file_name}");
            } catch (\Throwable $e) {
                $job->update([
                    'status' => 'failed',
                    'error_message' => $e->getMessage(),
                ]);

                Log::error("Error importing {$job->file_name}: " . $e->getMessage());
                $this->error("Error: " . $e->getMessage());
            }
        }
    }

    private function cleanText($value): ?string
    {
        if (!$value) return null;

        // Asegura que sea UTF-8 válido
        $value = mb_convert_encoding($value, 'UTF-8', 'UTF-8');

        // Quita caracteres no imprimibles
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value);

        // Elimina caracteres que no puedan convertirse a UCS-2 (usado por SQL Server)
        $value = iconv('UTF-8', 'UTF-8//IGNORE', $value);

        return $value;
    }

}
