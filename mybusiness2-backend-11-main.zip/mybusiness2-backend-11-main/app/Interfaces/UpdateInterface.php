<?php

namespace App\Interfaces;

interface UpdateInterface
{
    public function update($id, array $request):object|null|array;
}
