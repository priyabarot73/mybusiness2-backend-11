<?php

namespace App\Interfaces;

interface ViewByIdInterface
{
    public function viewById($id);
}
