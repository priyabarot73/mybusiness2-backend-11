<?php

namespace App\Services\Support;

use App\Models\support\DistributionList;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class DistributionListRecipients
{
    /**
     * Returns a list of unique email addresses for a distribution list.
     * Includes:
     *  - direct members (distribution_list_members)
     *  - users by roles (distribution_list_roles -> roles -> model_has_roles -> users)
     */
    public function getEmailsByListId(string $listId, bool $onlyActive = true): array
    {
        $list = DistributionList::query()
            ->with([
                'members' => fn ($q) => $onlyActive ? $q->where('is_active', true) : $q,
                'roles'   => fn ($q) => $onlyActive ? $q->where('is_active', true) : $q,
            ])
            ->findOrFail($listId);

        if ($onlyActive && !$list->is_active) {
            return [];
        }

        // 1) Emails from (members)
        $memberEmails = collect($list->members)
            ->map(function ($m) {
                // priority: email saved in member, otherwise, the user->email
                $email = $m->email ?? ($m->user->email ?? null);
                return $email ? strtolower(trim($email)) : null;
            })
            ->filter()
            ->values();

        // 2) Emails from roles
        $roleIds = collect($list->roles)
            ->pluck('role_id')
            ->filter()
            ->values()
            ->all();

        $roleEmails = $this->getEmailsFromRoles($roleIds, $onlyActive);

        // Merge + unique
        return $memberEmails
            ->merge($roleEmails)
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    /**
     * Retrieves emails of users who have any of the given roles.
     * Adjust the table/model if your user table is in a different schema or has a different name.
     */
    private function getEmailsFromRoles(array $roleIds, bool $onlyActive): Collection
    {
        if (empty($roleIds)) {
            return collect();
        }

        // Spatie:
        // model_has_roles(role_id, model_type, model_id)
        // users: id, email, is_active (si lo tienes)
        $q = DB::table('model_has_roles as mhr')
            ->join('users as u', 'u.id', '=', 'mhr.model_id')
            ->whereIn('mhr.role_id', $roleIds)
            ->where('mhr.model_type', '=', User::class)
            ->select('u.email');

        // Check is active
        if ($onlyActive && $this->usersHasIsActiveColumn()) {
            $q->where('u.active', '=', 1);
        }

        return collect($q->pluck('email'))
            ->map(fn ($e) => $e ? strtolower(trim($e)) : null)
            ->filter()
            ->values();
    }

    private function usersHasIsActiveColumn(): bool
    {
        // Prevents errors if the column does not exist
        static $has = null;
        if ($has !== null) return $has;

        try {
            $cols = DB::getSchemaBuilder()->getColumnListing('users');
            $has = in_array('active', $cols, true);
        } catch (\Throwable $e) {
            $has = false;
        }

        return $has;
    }
}
