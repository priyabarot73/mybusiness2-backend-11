<?php

namespace App\Services\Support;

use App\Mail\DistributionListNotificationMail;
use Illuminate\Support\Facades\Mail;

class DistributionListMailer
{
    public function __construct(
        protected DistributionListRecipients $recipients
    ) {}

    public function sendToList(string $listId, string $subject, array $viewPayload): int
    {
        $emails = $this->recipients->getEmailsByListId($listId, true);

        if (empty($emails)) {
            return 0;
        }

        // Enviar (un solo correo con BCC a todos)
        // Si prefieres un correo por usuario, te lo adapto con queue.
        Mail::to($viewPayload['to'] ?? config('mail.from.address'))
            ->bcc($emails)
            ->send(new DistributionListNotificationMail($subject, $viewPayload));

        return count($emails);
    }
}
