<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class contractNotification extends Mailable
{
    use Queueable, SerializesModels;

    protected $request;
    public function __construct($request)
    {
        $this->request = $request;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->request['subject'],
            from: 'mailtrapLaravel@example.com',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'mail.contractNotificationEmail',
            with: [
                'date' => $this->request['date'],
                'prefix' => $this->request['prefix'],
                'supervisor_name' => $this->request['supervisor_name'],
                'person_name' => $this->request['person_name'],
                'contract_link' => $this->request['contract_link'],
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
