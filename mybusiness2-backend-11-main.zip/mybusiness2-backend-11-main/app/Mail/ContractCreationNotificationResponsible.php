<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ContractCreationNotificationResponsible extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    protected $request;
    public function __construct($request)
    {
        $this->request = $request;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'Contract Creation Notification Responsible',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'mail.ContractCreationNotificationResponsible',
            with: [
                'date' => $this->request['date'],
                'prefix' => $this->request['prefix'],
                #'supervisor_name' => $this->request['supervisor_name'],
                #'supervisor_name' => "Dillon",
                'supervisor_name' => $this->request['supervisor_name'],
                'instructor_name' => $this->request['instructor_name'],
                'contract_state' => $this->request['contract_state'],
                'description' => $this->request['description'],
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
