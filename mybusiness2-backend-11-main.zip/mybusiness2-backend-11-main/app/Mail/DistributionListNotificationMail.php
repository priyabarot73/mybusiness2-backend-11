<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class DistributionListNotificationMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public string $subjectLine,
        public array $payload = [] // datos para el blade
    ) {}

    public function build(): DistributionListNotificationMail
    {
        return $this
            ->subject($this->subjectLine)
            ->view('emails.support.distribution_list_notification')
            ->with($this->payload);
    }
}
