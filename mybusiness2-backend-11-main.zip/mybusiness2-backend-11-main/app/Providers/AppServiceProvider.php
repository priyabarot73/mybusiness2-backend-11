<?php

namespace App\Providers;

use App\Models\support\Ticket;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application Services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application Services.
     */
    public function boot(): void
    {
        Ticket::creating(function (Ticket $ticket) {
            if (!$ticket->code) {
                // simple y práctico (ajusta si quieres secuencia por año)
                $ticket->code = 'TCK-' . now()->format('Ymd') . '-' . strtoupper(str()->random(6));
            }
        });
    }
}
