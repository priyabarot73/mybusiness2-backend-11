<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;

//LOCAL IMPORT
use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ControlCloneSection extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.control_clone_sections';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'user'=>'string',
        'origin_term'=>'string',
        'destination_term'=>'string',
        'comments'=>'string'
    ];
}
