<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\ActivityNumber;
use App\Models\hr\ContractRateByProgram;

class Program extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.programs';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'degree_id'=>'uuid',
        'offering_id'=>'uuid',
        'program_level_id' => 'uuid',
        'program_grouping_id' => 'uuid',
        'fte' => 'boolean',
        'active'=>'boolean'
    ];

    public function programLevel() : BelongsTo
    {
        return $this->belongsTo(ProgramLevel::class);
    }
    public function programGrouping (): BelongsTo
    {
        return $this->belongsTo(ProgramGrouping::class);
    }
    public function termEffective(): BelongsTo
    {
        return $this->belongsTo(Term::class);
    }
    public function termDiscontinue(): BelongsTo
    {
        return $this->BelongsTo(Term::class);
    }
    public function course(): HasMany
    {
        return $this->hasMany(Course::class);
    }
    public function activityNumber(): HasMany
    {
        return $this->hasMany(ActivityNumber::class);
    }
    public function degree(): BelongsTo
    {
        return $this->belongsTo(Degree::class);
    }
    public function offering(): BelongsTo
    {
        return $this->belongsTo(Offering::class);
    }
    public function contractRates(): HasMany
    {
        return $this->hasMany(ContractRateByProgram::class, 'program_id');
    }

}
