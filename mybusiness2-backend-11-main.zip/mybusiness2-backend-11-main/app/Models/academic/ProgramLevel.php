<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class ProgramLevel extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.program_levels';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'level'=>'integer',
        'active'=>'boolean'
    ];

    public function program(): HasMany
    {
        return $this->hasMany(Program::class);
    }
}
