<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class Workload extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.workloads';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;
    public $incrementing = false;

    protected $fillable = [
        'instructor_id'=>'uuid',
        'academic_year'=>'string',
        'semester'=>'string',
        'workload'=>'float',
        'release'=>'float',
        'release_type'=>'string',
        'on_sabbatical'=>'boolean',
        'on_sick_leave'=>'boolean',
        'on_paternity_leave'=>'boolean',
        'workload_type'=>'string',
        'comment'=>'string'
    ];

    public function instructor():BelongsTo
    {
        return $this->belongsTo(\App\Models\academic\Instructor::class, 'instructor_id');
    }

    public function workLoadCourses(): HasMany
    {
        return $this->hasMany(WorkloadCourse::class, 'workload_id', 'id');
    }
}
