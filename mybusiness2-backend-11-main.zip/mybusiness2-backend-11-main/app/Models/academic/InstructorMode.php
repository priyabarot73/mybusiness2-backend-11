<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class InstructorMode extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.instructor_modes';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];


}
