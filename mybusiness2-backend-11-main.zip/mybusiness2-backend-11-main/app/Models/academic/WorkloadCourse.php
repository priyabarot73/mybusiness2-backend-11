<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class WorkloadCourse extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.workload_courses';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'workload_id'=>'uuid',
        'section_id'=>'uuid',
        'course_id'=>'uuid',
        'value'=>'float',
        'overload'=>'boolean',
        'adjusted'=>'float',
        'on_contract'=>'boolean'
    ];

    public function workload(): BelongsTo
    {
        return $this->belongsTo(Workload::class);
    }
    public function course():BelongsTo
    {
        return $this->belongsTo(Course::class)->orderBy('code');
    }
    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class);
    }
}
