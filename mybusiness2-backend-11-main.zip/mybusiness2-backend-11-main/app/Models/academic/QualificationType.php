<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class QualificationType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.qualification_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'order'=>'integer',
        'active'=>'boolean'
    ];

    public function instructors(): HasMany
    {
        return $this->hasMany(Instructor::class);
    }
}
