<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class SubQualification extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.sub_qualifications';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'description'=>'string',
        'active'=>'boolean'
    ];

    public function instructors(): HasMany
    {
        return $this->hasMany(Instructor::class);
    }
}
