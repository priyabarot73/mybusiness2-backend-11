<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\general\Facility;

class MeetingPatternHybrid extends Model
{
    use HasFactory, Uuid;

    protected $table = 'ac.meeting_pattern_hybrids';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'day',
        'date',
        'start_time',
        'end_time',
        'facility_id',
        'section_id',
        'instructor_id',
        'primary_instructor',
    ];

    protected $casts = [
        'day' => 'string',
        'date' => 'datetime',
        'start_time' => 'string',
        'end_time' => 'string',
        'facility_id' => 'string',
        'section_id' => 'string',
        'instructor_id' => 'string',
        'primary_instructor' => 'integer',
    ];

    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class);
    }

    public function instructor(): BelongsTo
    {
        return $this->belongsTo(Instructor::class);
    }
}
