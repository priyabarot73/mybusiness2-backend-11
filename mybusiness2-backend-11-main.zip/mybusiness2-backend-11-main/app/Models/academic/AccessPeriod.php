<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class AccessPeriod extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.access_periods';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'term_id'=>'uuid',
        'admin_beginning_date'=>'datetime',
        'admin_ending_date'=>'datetime',
        'admin_cancel_section_date'=>'datetime',
        'depart_beginning_date'=>'datetime',
        'depart_ending_date'=>'datetime'
    ];

    public function term(): BelongsTo
    {
        return $this->belongsTo(Term::class);
    }

}
