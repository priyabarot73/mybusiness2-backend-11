<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class InstructorMeetingPattern extends Model
{
    use HasFactory;

    protected $fillable = [
        'meeting_pattern_id'=>'uuid',
        'instructor_id'=>'uuid'
    ];
    public function meetingPattern():BelongsTo
    {
        return $this->belongsTo(MeetingPattern::class);
    }
    public function instructor():BelongsTo
    {
        return $this->belongsTo(Instructor::class);
    }
}
