<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class Degree extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.degrees';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function programs(): HasMany
    {
        return $this->hasMany(Program::class);
    }
}
