<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use App\Models\hr\Assignment;
use App\Models\hr\AssignmentContract;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Person;
use App\Models\hr\EmployeeType;
use App\Models\assessment\TenureType;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;

class Instructor extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.instructors';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'person_id' => 'uuid',
        'employee_type_id' => 'uuid',
        'tenure_type_id' => 'uuid',
        'doctorate' => 'boolean',
        'qualification'=> 'string',
        'qualification_type_id' => 'uuid',
        'sub_qualification_id' => 'uuid',
        'aacsb' => 'string',
        'active' => 'boolean'
    ];
    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function employeeType(): BelongsTo
    {
        return $this->belongsTo(EmployeeType::class);
    }
    public function qualificationType(): BelongsTo
    {
        return $this->belongsTo(QualificationType::class);
    }
    public function subQualification(): BelongsTo
    {
        return $this->belongsTo(SubQualification::class);
    }
    public function meetingPatterns(): HasMany
    {
        return $this->hasMany(MeetingPattern::class);
    }
    public function meetingPatternHybrids(): HasMany
    {
        return $this->hasMany(MeetingPatternHybrid::class);
    }
    public function tenureType(): BelongsTo
    {
        return $this->belongsTo(TenureType::class);
    }
    public function workloads(): HasMany
    {
        return $this->hasMany(Workload::class);
    }

    /**
     * ACTIVE instructor assignment (end_date NULL). Returns ONLY ONE.
     * If there is more than one (it shouldn't), take the most recent by start_date.
     */
    public function activeAssignment(): HasOne
    {
        $assignmentTable = (new Assignment)->getTable();

        return $this->hasOne(Assignment::class, 'person_id', 'person_id')
            ->whereNull($assignmentTable . '.end_date');
    }

    /**
     * Get assignment active during a given date range (TERM-based)
     */
    public function assignmentForTerm(Carbon|string $termStart, Carbon|string $termEnd): ?Assignment
    {
        return Assignment::where('person_id', $this->person_id)
            ->where('start_date', '<=', $termEnd)
            ->where(function ($q) use ($termStart) {
                $q->whereNull('end_date')
                ->orWhere('end_date', '>=', $termStart);
            })
            ->orderByDesc('start_date') // pick most recent if multiple overlap
            ->first();
    }


    /**
     * AssignmentContract associated with the ACTIVE assignment.
     * If there are multiple (historical) contracts, take the one from the assignment with NULL end_date.
     */
    public function activeAssignmentContract(): HasOneThrough
    {
        $assignmentTable = (new Assignment)->getTable();
        $contractTable   = (new AssignmentContract)->getTable();


        $rel = $this->hasOneThrough(
            AssignmentContract::class,
            Assignment::class,
            'person_id',
            'assignment_id',
            'person_id',
            'id'
        )->whereNull($assignmentTable . '.end_date');

        return $rel;
    }
}
