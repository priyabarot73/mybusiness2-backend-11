<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

//LOCAL IMPORT
use App\Traits\Uuid;

class CombinedSection extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.combined_sections';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;


    protected $fillable = [
        'section_id'=>'uuid',
        'section_id_combined'=>'uuid'
    ];

    public function mainSection(): BelongsTo
    {
        return $this->belongsTo(Section::class,'section_id');
    }

    public function combinedSection(): BelongsTo
    {
        return $this->belongsTo(Section::class,'section_id_combined');
    }
}
