<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

//LOCAL IMPORT
use App\Traits\Uuid;

class Session extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.sessions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'number'=>'string',
        'sess'=>'string',
        'active'=>'boolean'
    ];
}
