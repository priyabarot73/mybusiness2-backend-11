<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Person;
use App\Models\general\Campus;

class Section extends Model
{
    use HasFactory, Uuid;

    protected $table = 'ac.sections';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'caps',
        'term_id',
        'course_id',
        'sec_code',
        'sec_number',
        'sec_sess',
        'cap',
        'instructor_mode_id',
        'campus_id',
        'starting_date',
        'ending_date',
        'program_id',
        'cohorts',
        'status',
        'combined',
        'dynamic',
        'comment',
        'internal_note',
        'student_enrollment',

    ];

    protected $casts = [
        'caps'=>'boolean',
        'term_id'=>'string',
        'course_id'=>'string',
        'sec_code'=>'string',
        'sec_number'=>'string',
        'sec_sess'=>'string',
        'cap'=>'integer',
        'instructor_mode_id'=>'string',
        'campus_id'=>'string',
        'starting_date'=>'datetime',
        'ending_date'=>'datetime',
        'program_id'=>'string',
        'cohorts'=>'string',
        'status'=>'string',
        'combined'=>'boolean',
        'dynamic'=>'boolean',
        'comment'=>'string',
        'internal_note'=>'string',
        'student_enrollment'=>'string',
    ];


    public function term():BelongsTo
    {
        return $this->belongsTo(Term::class);
    }
    public function course():BelongsTo
    {
        return $this->belongsTo(Course::class);
    }
    public function campus():BelongsTo
    {
        return $this->belongsTo(Campus::class);
    }
    public function program():BelongsTo
    {
        return $this->belongsTo(Program::class);
    }
    public function meetingPatterns(): HasMany
    {
        return $this->hasMany(MeetingPattern::class);
    }
    public function meetingPatternHybrids(): HasMany
    {
        return $this->hasMany(MeetingPatternHybrid::class);
    }
    public function instructorMode(): BelongsTo
    {
        return $this->belongsTo(InstructorMode::class);
    }
    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function combinedSections(): HasMany
    {
        return $this->hasMany(CombinedSection::class);
    }
    public function workloadCourses(): HasMany
    {
        return $this->hasMany(WorkloadCourse::class);
    }
}
