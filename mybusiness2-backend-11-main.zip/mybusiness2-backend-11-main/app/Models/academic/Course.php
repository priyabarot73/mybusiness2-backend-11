<?php

namespace App\Models\academic;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Contract;
use App\Models\hr\ContractCourse;
use App\Models\general\Department;

class Course extends Model
{
    use HasFactory, Uuid;
    protected $table = 'ac.courses';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'credit'=>'float',
        'hour'=>'float',
        'references_number' =>'string',
        'description'=>'string',
        'department_id'=>'uuid',
        'program_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function department():BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function program():BelongsTo
    {
        return $this->belongsTo(Program::class);
    }

    public function contractCourses(): HasMany
    {
        return $this->hasMany(ContractCourse::class);
    }

    public function contracts(): BelongsToMany
    {
        return $this->belongsToMany(Contract::class, ContractCourse::class);
    }

}
