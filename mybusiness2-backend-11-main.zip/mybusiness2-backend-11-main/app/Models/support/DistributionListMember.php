<?php

namespace App\Models\support;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\User;

class DistributionListMember extends Model
{
    use HasFactory, Uuid;

    protected $table = 'su.distribution_list_members';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'distribution_list_id',
        'user_id',
        'email',
        'full_name',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function list(): BelongsTo
    {
        return $this->belongsTo(DistributionList::class, 'distribution_list_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
