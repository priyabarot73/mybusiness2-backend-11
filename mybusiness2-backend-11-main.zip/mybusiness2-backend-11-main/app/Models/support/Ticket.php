<?php

namespace App\Models\support;

// GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\User;

class Ticket extends Model
{
    use HasFactory, Uuid;

    protected $table = 'su.tickets';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'code','subject','description','status','priority','category','user_id','assigned_to','closed_at'
    ];

    protected $casts = [
        'closed_at' => 'datetime',
    ];

    // Relaciones
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(TicketMessage::class);
    }

    // Scopes útiles
    public function scopeOpen(Builder $q): Builder
    {
        return $q->whereIn('status', ['open','pending']);
    }

    public function scopeClosed(Builder $q): Builder
    {
        return $q->whereIn('status', ['resolved','closed']);
    }

    public function scopeHighPriority(Builder $q): Builder
    {
        return $q->whereIn('priority', ['high','urgent']);
    }

    // Helpers de dominio
    public function close(string $finalStatus = 'closed'): void
    {
        $this->forceFill([
            'status' => $finalStatus,
            'closed_at' => now(),
        ])->save();
    }

    public function reopen(): void
    {
        $this->forceFill([
            'status' => 'open',
            'closed_at' => null,
        ])->save();
    }
}
