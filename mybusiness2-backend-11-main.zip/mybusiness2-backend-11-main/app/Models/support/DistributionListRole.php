<?php

namespace App\Models\support;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use App\Traits\Uuid;
use App\Models\Role;

class DistributionListRole extends Model
{
    use HasFactory, Uuid;

    protected $table = 'su.distribution_list_roles';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'distribution_list_id',
        'role_id',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function list(): BelongsTo
    {
        return $this->belongsTo(DistributionList::class, 'distribution_list_id');
    }

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'role_id');
    }
}
