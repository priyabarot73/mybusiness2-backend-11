<?php

namespace App\Models\support;

// GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\User;
class TicketMessage extends Model
{
    use HasFactory, Uuid;

    protected $table = 'su.ticket_messages';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = ['ticket_id','user_id','message','is_internal'];

    protected $casts = [
        'is_internal' => 'boolean',
    ];

    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
