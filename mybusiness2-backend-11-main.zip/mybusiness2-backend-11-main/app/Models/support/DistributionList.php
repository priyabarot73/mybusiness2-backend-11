<?php

namespace App\Models\support;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\support\DistributionListRole;

class DistributionList extends Model
{
    use HasFactory, Uuid;

    protected $table = 'su.distribution_lists';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'name',
        'category',
        'is_active',
        'description',
        'created_by',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function members(): HasMany
    {
        return $this->hasMany(DistributionListMember::class, 'distribution_list_id');
    }

    public function roles(): HasMany
    {
        return $this->hasMany(DistributionListRole::class, 'distribution_list_id');
    }
}

