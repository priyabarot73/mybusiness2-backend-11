<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class ContractCategoryTypeSalaryAdmin extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_category_type_salary_admins';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_category_id'=>'uuid',
        'contract_type_id'=>'uuid',
        'salary_admin_plan_id'=>'uuid'
    ];

    public function contractCategory():BelongsTo
    {
        return $this->belongsTo(ContractCategory::class);
    }
    public function contractType():BelongsTo
    {
        return $this->belongsTo(ContractType::class);
    }
    public function salaryAdminPlant():BelongsTo
    {
        return $this->belongsTo(SalaryAdminPlan::class,'salary_admin_plan_id');
    }
}
