<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\academic\Program;
use App\Models\general\Department;

class ActivityNumber extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.activity_numbers';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'number',
        'name',
        'department_id',
        'program_id',
        'responsible_id',
        'active'
    ];
    public function department():BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function program():BelongsTo
    {
        return $this->belongsTo(Program::class);
    }
    public function responsible():BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function personActivityNumber():HasMany
    {
        return $this->hasMany(PersonActivityNumber::class);
    }
    public function contract():HasMany
    {
        return $this->hasMany(Contract::class);
    }
}
