<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Models\Role;
use App\Traits\Uuid;

class ContractRoleStateTransition extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_role_state_transitions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'role_id'=>'uuid',
        'contract_state_transition_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }
    public function contractStateTransition(): BelongsTo
    {
        return $this->belongsTo(ContractStateTransition::class, 'contract_state_transition_id', 'id');
    }
}
