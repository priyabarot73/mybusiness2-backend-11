<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class SalaryAdminPlan extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.salary_admin_plans';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code' => 'string',
        'name' => 'string',
        'pay_group_id' => 'uuid',
        'employee_classification_id' => 'uuid',
        'employee_type_id' => 'uuid',
        'person_organization_relationship_type_id' => 'uuid',
        'used_in' => 'string',
        'active' => 'boolean'
    ];

    public function payGroup(): BelongsTo
    {
        return $this->belongsTo(PayGroup::class);
    }

    public function employeeClassification(): BelongsTo
    {
        return $this->belongsTo(EmployeeClassification::class);
    }

    public function employeeType(): BelongsTo
    {
        return $this->belongsTo(EmployeeType::class);
    }

    public function personOrganizationRelationshipType(): BelongsTo
    {
        return $this->belongsTo(PersonOrganizationRelationshipType::class);
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }

    public function contractCategoryTypeSalaryAdmin(): HasMany
    {
        return $this->hasMany(ContractCategoryTypeSalaryAdmin::class);
    }
}
