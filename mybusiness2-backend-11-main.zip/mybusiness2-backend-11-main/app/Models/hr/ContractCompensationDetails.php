<?php

namespace App\Models\hr;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Traits\Uuid;
use App\Models\hr\ActivityNumber; // <-- importa el modelo

class ContractCompensationDetails extends Model
{
    use Uuid;

    protected $table = 'hr.contract_compensation_details';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'subject', 'catalog', 'section', 'program', 'activity_number', // <- aquí ya la tienes
        'enrolled', 'hours', 'base', 'credits', 'overload', 'weight', 'amount',
        'contract_id',
    ];

    // (opcional pero recomendado) no exponer el valor crudo:
    protected $hidden = ['activity_number'];

    // para que aparezca automáticamente en la salida JSON:
    protected $appends = ['activity_numbers'];

    /**
     * Relación al registro de ActivityNumber usando:
     *   foreignKey = activity_number (en este modelo)
     *   ownerKey   = number          (en ActivityNumber)
     */
    public function activityNumber(): BelongsTo
    {
        return $this->belongsTo(ActivityNumber::class, 'activity_number', 'number');
    }

    /**
     * Accessor: devuelve el arreglo "activity_numbers" con la forma que necesitas.
     * Lo devolvemos como arreglo (aunque normalmente sea 1) para que el contrato del API sea consistente.
     */
    public function getActivityNumbersAttribute(): array
    {
        $an = $this->activityNumber; // gracias al eager load no habrá N+1
        if (!$an) {
            return [];
        }

        return [[
            'name'   => (string) $an->name,
            'number' => (string) $an->number,
            'id'     => (string) $an->getKey(),
        ]];
    }

    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class, 'contract_id');
    }
}
