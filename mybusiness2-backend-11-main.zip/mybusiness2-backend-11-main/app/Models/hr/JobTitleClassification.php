<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class JobTitleClassification extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.job_title_classifications';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function contractStates(): HasMany
    {
        return $this->hasMany(ContractState::class);
    }
}
