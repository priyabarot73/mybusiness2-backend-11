<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class ContractCategory extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_categories';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'description'=>'string',
        'active'=>'boolean'
    ];

    public function assignmentContracts(): HasMany
    {
        return $this->hasMany(AssignmentContract::class);
    }

    public function contractCategoryTypeSalaryAdmin(): HasMany
    {
        return $this->hasMany(ContractCategoryTypeSalaryAdmin::class);
    }
}
