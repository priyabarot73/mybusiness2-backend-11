<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\general\Facility;
use App\Models\general\Department;
use App\Models\general\BusinessUnit;
use App\Models\general\AcademicGroup;
use App\Models\general\PhysicalLocation;

class Assignment extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.assignments';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'person_id'=>'uuid',
        'original_hire_date'=>'date',
        'salary_admin_plan_id'=>'uuid',
        'employee_class_id'=>'uuid',
        'employee_type_id'=>'uuid',
        'employee_responsibility_id'=>'uuid',
        'unit_status_id'=>'uuid',
        'position_number'=>'string',
        'fte'=>'string',
        'job_title_id'=>'uuid',
        'working_title_id'=>'uuid',
        'action_id'=>'uuid',
        'action_reason_id'=>'uuid',
        'start_date'=>'date',
        'end_date'=>'date',
        'business_unit_id'=>'uuid',
        'department_id'=>'uuid',
        'sub_department_id'=>'uuid',
        'academic_group_id'=>'uuid',
        'academic_organization_id'=>'uuid',
        'physical_location_id'=>'uuid',
        'facility_id'=>'uuid',
        'physical_public_establishment'=>'boolean',
        'public_establishment_id'=>'uuid',
        'public_facility_id'=>'uuid',
        'supervisor_id'=>'uuid',
        'active'=>'boolean',
    ];
    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function salaryAdminPlan(): BelongsTo
    {
        return $this->belongsTo(SalaryAdminPlan::class);
    }
    public function employeeClass(): BelongsTo
    {
        return $this->belongsTo(EmployeeClass::class);
    }
    public function employeeType(): BelongsTo
    {
        return $this->belongsTo(EmployeeTypeAssignment::class);
    }
    public function employeeResponsibility(): BelongsTo
    {
        return $this->belongsTo(EmployeeResponsibilityAssignment::class);
    }
    public function unitStatus(): BelongsTo
    {
        return $this->belongsTo(UnitStatus::class);
    }
    public function jobTitle(): BelongsTo
    {
        return $this->belongsTo(JobTitle::class);
    }
    public function workingTitle(): BelongsTo
    {
        return $this->belongsTo(WorkingTitle::class);
    }
    public function action(): BelongsTo
    {
        return $this->belongsTo(Action::class);
    }
    public function actionReason(): BelongsTo
    {
        return $this->belongsTo(ActionReason::class);
    }
    public function businessUnit(): BelongsTo
    {
        return $this->belongsTo(BusinessUnit::class);
    }
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function subDepartment(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function academicGroup(): BelongsTo
    {
        return $this->belongsTo(AcademicGroup::class);
    }
    public function academicOrganization(): BelongsTo
    {
        return $this->belongsTo(AcademicOrganization::class);
    }
    public function physicalLocation(): BelongsTo
    {
        return $this->belongsTo(PhysicalLocation::class);
    }
    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }
    public function publicEstablishment(): BelongsTo
    {
        return $this->belongsTo(PhysicalLocation::class);
    }
    public function publicFacility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }
    public function supervisor(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function assignmentContract(): HasOne
    {
        return $this->hasOne(AssignmentContract::class);
    }
}
