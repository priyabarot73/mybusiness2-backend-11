<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\general\Department;

class AcademicOrganization extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.academic_organizations';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'description'=>'string',
        'active'=>'boolean'
    ];

    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }

    public function department(): HasMany
    {
        return $this->hasMany(Department::class);
    }
}
