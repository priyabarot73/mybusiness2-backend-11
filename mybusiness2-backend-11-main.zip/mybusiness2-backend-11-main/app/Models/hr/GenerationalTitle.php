<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class GenerationalTitle extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.generational_titles';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function person(): HasMany
    {
        return $this->hasMany(Person::class);
    }
}
