<?php

namespace App\Models\hr;

use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EmployeeDirectory extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.employee_directories';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'person_id'=>'uuid',
        'team_id'=>'uuid',
        'appearance'=>'integer',
        'role'=>'string',
        'locked'=>'boolean',
        'start_date'=>'datetime',
        'end_date'=>'datetime',
    ];

    protected $casts = [
        'locked' => 'boolean',
        'appearance' => 'integer',
        'start_date' => 'datetime',
        'end_date' => 'datetime',
    ];

    public function persons(): BelongsTo
    {
        return $this->belongsTo(Person::class, 'person_id', 'id');
    }

    public function teams(): BelongsTo
    {
        return $this->belongsTo(Team::class, 'team_id', 'id');
    }

    public function teamType(): BelongsTo
    {
        return $this->belongsTo(TeamType::class, 'team_type_id', 'id');
    }
}
