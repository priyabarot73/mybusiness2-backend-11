<?php

namespace App\Models\hr;

// Global import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// Local import
use App\Traits\Uuid;

class ContractActivity extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_activities';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_id',
        'activity_number_id',
        'amount'
    ];

    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class);
    }

    public function activityNumber(): BelongsTo
    {
        return $this->belongsTo(ActivityNumber::class);
    }
}
