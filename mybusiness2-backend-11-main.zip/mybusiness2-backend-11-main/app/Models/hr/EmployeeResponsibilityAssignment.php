<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class EmployeeResponsibilityAssignment extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.employee_responsibility_assignments';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}
