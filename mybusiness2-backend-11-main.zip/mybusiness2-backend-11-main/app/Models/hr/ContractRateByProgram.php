<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;
use App\Models\academic\Program;

class ContractRateByProgram extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_rate_by_programs';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'program_id'=>'uuid',
        'contract_rate'=>'float',
        'active'=>'boolean'
    ];

    public function program(): BelongsTo
    {
        return $this->belongsTo(Program::class, 'program_id');
    }
}
