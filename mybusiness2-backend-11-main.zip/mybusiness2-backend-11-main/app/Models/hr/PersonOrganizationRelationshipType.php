<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class PersonOrganizationRelationshipType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.person_organization_relationship_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function salaryAdminPlan(): HasMany
    {
        return $this->hasMany(SalaryAdminPlan::class);
    }
}
