<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\general\Department;
use App\Models\general\BusinessUnit;

class JobTitle extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.job_titles';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'title_id'=>'integer',
        'active'=>'boolean'
    ];

    public function businessUnits(): HasMany
    {
        return $this->hasMany(BusinessUnit::class);
    }
    public function departments(): HasMany
    {
        return $this->hasMany(Department::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
    public function contracts():HasMany
    {
        return $this->hasMany(Contract::class);
    }
}
