<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class AssignmentContract extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.assignment_contracts';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'assignment_id' => 'uuid',
        'contract_number' => 'string',
        'contract_category_id' => 'uuid',
        'contract_type_id' => 'uuid'
    ];

    public function assignment():BelongsTo
    {
        return $this->belongsTo(Assignment::class);
    }
    public function contractCategory():BelongsTo
    {
        return $this->belongsTo(ContractCategory::class);
    }
    public function contractType():BelongsTo
    {
        return $this->belongsTo(ContractType::class);
    }
}
