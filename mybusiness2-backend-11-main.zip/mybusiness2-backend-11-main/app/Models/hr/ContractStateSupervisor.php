<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractStateSupervisor extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_state_supervisors';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'person_id',
        'contract_state_id'
    ];

    public function person():BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function contractState():BelongsTo
    {
        return $this->belongsTo(ContractState::class);
    }
}
