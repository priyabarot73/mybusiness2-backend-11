<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class ActionReason extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.action_reasons';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'action_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function action(): BelongsTo
    {
        return $this->belongsTo(Action::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}
