<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class SecondaryTeachingAppointment extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.secondary_teaching_appointments';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'description'=>'string',
        'active'=>'boolean'
    ];
    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class);
    }
}
