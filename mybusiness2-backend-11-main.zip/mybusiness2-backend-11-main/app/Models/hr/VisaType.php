<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class VisaType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.visa_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'type_desc'=>'string',
        'active'=>'boolean'
    ];

    public function person(): HasMany
    {
        return $this->hasMany(Person::class);
    }
}
