<?php

namespace App\Models\hr;

use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Team extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.teams';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'active'=>'boolean',
        'team_type_id'=>'uuid'
    ];

    public function teamType(): BelongsTo
    {
        return $this->belongsTo(TeamType::class, 'team_type_id', 'id');
    }
}
