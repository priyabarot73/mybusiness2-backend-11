<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

//LOCAL IMPORT

class TeamType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.team_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function teams(): HasMany
    {
        return $this->hasMany(Team::class);
    }
}
