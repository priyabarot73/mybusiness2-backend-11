<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractType extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name',
        'description',
        'teaching_duties',
        'teaching_credit_courses',
        'contract_type_level',
        'sec_employee_type_level',
        'active'
    ];
    public function contractTypeQuestion():HasMany
    {
        return $this->HasMany(ContractTypeQuestion::class);
    }
    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class);
    }
    public function assignmentContracts(): HasMany
    {
        return $this->hasMany(AssignmentContract::class);
    }
    public function contractCategoryTypeSalaryAdmin(): HasMany
    {
        return $this->hasMany(ContractCategoryTypeSalaryAdmin::class);
    }
}
