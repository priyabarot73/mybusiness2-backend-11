<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractTypeQuestion extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_type_questions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_type_id',
        'question_id'
    ];

    public function question():BelongsTo
    {
        return $this->belongsTo(Question::class);
    }

    public function contractType():BelongsTo
    {
        return $this->belongsTo(ContractType::class);
    }
}
