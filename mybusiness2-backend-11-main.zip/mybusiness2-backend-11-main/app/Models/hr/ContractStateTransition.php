<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractStateTransition extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_state_transitions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'source_state_id',
        'target_state_id',
        'name',
        'code',
        'message',
        'order',
        'active'
    ];

    public function sourceState(): BelongsTo
    {
        return $this->belongsTo(ContractState::class, 'source_state_id');
    }

    public function targetState(): BelongsTo
    {
        return $this->belongsTo(ContractState::class, 'target_state_id');
    }
    public function roleContractStateTransition(): HasMany
    {
        return $this->hasMany(ContractRoleStateTransition::class);
    }
}
