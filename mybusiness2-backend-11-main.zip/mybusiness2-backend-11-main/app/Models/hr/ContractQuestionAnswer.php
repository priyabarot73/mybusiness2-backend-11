<?php

namespace App\Models\hr;

// Global import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// Local import
use App\Traits\Uuid;

class ContractQuestionAnswer extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_question_answers';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_id',
        'question_id',
        'answer'
    ];
    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class);
    }

    public function question(): BelongsTo
    {
        return $this->belongsTo(Question::class);
    }
}
