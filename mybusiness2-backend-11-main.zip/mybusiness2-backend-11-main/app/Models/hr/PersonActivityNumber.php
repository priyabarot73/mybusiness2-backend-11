<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class PersonActivityNumber extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.person_activity_numbers';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'person_id',
        'activity_number_id'
    ];
    public function person():BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function activityNumber():BelongsTo
    {
        return $this->belongsTo(ActivityNumber::class);
    }
}
