<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;
use App\Models\academic\Term;
use App\Models\academic\Course;
use App\Models\general\Department;
use App\Models\general\ActivityTimeLine;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Contract extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contracts';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_name',
        'lump_sum',
        'person_id',
        'course_id',
        'job_title_id',
        'department_id',
        'supervisor_id',
        'contract_type_id',
        'secondary_teaching_appointment_id',
        'term_id',
        'enrollment',
        'start_date',
        'end_date',
        'cost_pid',
        'cost_pid_value',
        'hours_worked',
        'amount_pay',
        'explanation_justification',
        'selection_justification',
        'why_cant',
        'erac_number',
        'contract_number',
        'internal_comment',
        'contract_state_id',
        'category',
        'employee_type',
        'superseding',
        'superseding_contract_number',
        'superseding_contract_enrollment',
        'superseding_contract_amount',
    ];
    public function person():BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function jobTitle():BelongsTo
    {
        return $this->belongsTo(JobTitle::class);
    }
    public function department():BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function supervisor():BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function secondaryTeachingAppointment():BelongsTo
    {
        return $this->belongsTo(SecondaryTeachingAppointment::class);
    }
    public function contractType():BelongsTo
    {
        return $this->belongsTo(ContractType::class);
    }
    public function term():BelongsTo
    {
        return $this->belongsTo(Term::class);
    }
    public function course():BelongsTo
    {
        return $this->belongsTo(Course::class);
    }
    public function contractState():BelongsTo
    {
        return $this->belongsTo(ContractState::class);
    }
    public function contractSecondaryEmploymentWorkSchedules(): HasMany
    {
        return $this->hasMany(ContractSecondaryEmploymentWorkSchedule::class, 'contract_id');
    }
    public function contractQuestionAnswers(): HasMany
    {
        return $this->hasMany(ContractQuestionAnswer::class, 'contract_id');
    }
    public function contractHistories(): HasMany
    {
        return $this->hasMany(ContractHistory::class, 'contract_id');
    }
    public function contractActivities():HasMany
    {
        return $this->hasMany(ContractActivity::class);
    }

    public function contractAttachments(): HasMany
    {
        return $this->hasMany(ContractAttachment::class);
    }

    public function contractCompensationDetails(): HasMany
    {
        return $this->hasMany(ContractCompensationDetails::class, 'contract_id');
    }

    // All timeline activities for this contract
    public function activityTimeline(): HasMany
    {
        return $this->hasMany(ActivityTimeLine::class, 'action_id', 'id')
            ->where('category', 'Contract');
    }

    // The most recent activity (who modified/created it and when)
    public function latestHistory(): HasOne
    {
        // Requiere Laravel 8.42+ para latestOfMany(); si no, ver alternativa abajo
        return $this->hasOne(ActivityTimeLine::class, 'action_id', 'id')
            ->where('category', 'Contract')
            ->latestOfMany(); // by created_at
    }

    // If my Laravel version doesn't support latestOfMany(), use:
//    public function latestActivity()
//    {
//        return $this->hasOne(ActivityTimeLine::class, 'action_id', 'id')
//            ->where('category', 'Contract')
//            ->orderBy('created_at', 'desc');
//    }
}

