<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

//LOCAL IMPORT
use App\Traits\Uuid;

class ContractAttachment extends Model
{
    use Uuid;
    protected $table = 'hr.contract_attachments';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'attachment_filename',
        'contract_id'
    ];

    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class);
    }
}
