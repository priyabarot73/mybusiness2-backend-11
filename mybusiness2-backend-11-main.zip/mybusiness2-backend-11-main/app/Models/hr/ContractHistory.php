<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractHistory extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_histories';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;


    protected $fillable = [
        'contract_id',
        'supervisor_id',
        'state_id',
        'date',
        'notification_count',
        'comment'
    ];

    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class);
    }

    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class,'supervisor_id','id');
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(ContractState::class,'state_id','id');
    }

}
