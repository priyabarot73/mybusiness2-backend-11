<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\academic\Instructor;

class EmployeeType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.employee_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function salaryAdminPlan(): HasMany
    {
        return $this->hasMany(SalaryAdminPlan::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
    public function contractState(): HasMany
    {
        return $this->hasMany(ContractState::class);
    }
    public function instructors(): HasMany
    {
        return $this->hasMany(Instructor::class);
    }
}
