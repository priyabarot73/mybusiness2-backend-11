<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class Question extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.questions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'text'=>'string',
        'active'=>'boolean'
    ];

    public function contractTypeQuestion():HasMany
    {
        return $this->HasMany(ContractTypeQuestion::class);
    }

    public function answers(): HasMany
    {
        return $this->hasMany(ContractQuestionAnswer::class);
    }
}
