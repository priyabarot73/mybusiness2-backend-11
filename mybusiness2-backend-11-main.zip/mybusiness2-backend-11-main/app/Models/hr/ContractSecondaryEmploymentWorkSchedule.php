<?php

namespace App\Models\hr;

// Global import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractSecondaryEmploymentWorkSchedule extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.contract_secondary_employment_work_schedules';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'contract_id',
        'day',
        'from',
        'to'
    ];

    public function contract(): BelongsTo
    {
        return $this->belongsTo(Contract::class);
    }
}
