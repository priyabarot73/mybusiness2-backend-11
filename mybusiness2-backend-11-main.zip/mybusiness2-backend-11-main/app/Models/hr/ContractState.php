<?php

namespace App\Models\hr;

//Global Import
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//Local Import
use App\Traits\Uuid;

class ContractState extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.contract_states';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name',
        'contract_option_id',
        'code',
        'action',
        'active'
    ];

    public function contractOption(): BelongsTo
    {
        return $this->belongsTo(ContractOption::class);
    }
    public function supervisors(): HasMany
    {
        return $this->hasMany(ContractStateSupervisor::class);
    }
    public function contractStateTransition(): HasMany
    {
        return $this->hasMany(ContractStateTransition::class);
    }
    public function contractRoleStatuses():HasMany
    {
        return $this->hasMany(ContractRoleStatus::class);
    }

    public function outgoingTransitions(): HasMany // from the current state to others
    {
        return $this->hasMany(ContractStateTransition::class, 'source_state_id');
    }

    public function incomingTransitions(): HasMany // transitions that reach this state
    {
        return $this->hasMany(ContractStateTransition::class, 'target_state_id');
    }

    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class, 'contract_state_id');
    }
}
