<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class Action extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.actions';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'job_status'=>'string',
        'active'=>'boolean'
    ];

    public function actionReasons(): HasMany
    {
        return $this->hasMany(ActionReason::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}
