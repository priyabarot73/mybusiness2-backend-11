<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\Role;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ContractRoleStatus extends Model
{
    use Uuid;
    protected $table = 'hr.contract_role_statuses';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'role_id',
        'contract_states_id',
        'active'
    ];

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }
    public function contractState(): BelongsTo
    {
        return $this->belongsTo(ContractState::class, 'contract_states_id', 'id');
    }
}
