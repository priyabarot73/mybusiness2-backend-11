<?php

namespace App\Models\hr;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\User;
use App\Models\academic\Workload;
use App\Models\general\Department;
use App\Models\academic\Instructor;
use App\Models\general\BusinessUnit;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Person extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.persons';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'avatar'=>'string',
        'high_res_avatar'=>'string',
        'panther_id'=>'string',
        'prefix'=>'string',
        'first_name'=>'string',
        'middle_name'=>'string',
        'last_name'=>'string',
        'second_last_name'=>'string',
        'generational_title_id'=>'uuid',
        'suffix_id'=>'uuid',
        'nickname'=>'string',
        'birth_country'=>'string',
        'birth_city'=>'string',
        'gender'=>'string',
        'marital_status_id'=>'uuid',
        'as_of'=>'datetime',
        'disability'=>'boolean',
        'citizenship_type_id'=>'uuid',
        'citizenship_date'=>'datetime',
        'visa_type_id'=>'uuid',
        'visa_date'=>'datetime',
        'driver_license'=>'string',
        'country'=>'string',
        'city'=>'string',
        'military_status'=>'string',
        'ethnic_id'=>'uuid',
        'address'=>'string',
        'address_country'=>'string',
        'address_city'=>'string',
        'address_postal'=>'string',
        'business_phone_number'=>'string',
        'business_phone_number_ext'=>'string',
        'business_phone_number_usa'=>'boolean',
        'business_phone_number_public'=>'boolean',
        'personal_phone_number'=>'string',
        'personal_phone_number_ext'=>'string',
        'personal_phone_number_usa'=>'boolean',
        'personal_phone_number_public'=>'boolean',
        'business_email'=>'string',
        'business_email_public'=>'boolean',
        'personal_email'=>'string',
        'personal_email_public'=>'boolean',
        'department_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function generationalTitle() : BelongsTo
    {
        return $this->belongsTo(GenerationalTitle::class);
    }
    public function suffix() : BelongsTo
    {
        return $this->belongsTo(Suffix::class);
    }
    public function maritalStatus() : BelongsTo
    {
        return $this->belongsTo(MaritalStatus::class);
    }
    public function citizenshipType() : BelongsTo
    {
        return $this->belongsTo(CitizenshipType::class);
    }
    public function visaType() : BelongsTo
    {
        return $this->belongsTo(VisaType::class);
    }
    public function ethnic() : BelongsTo
    {
        return $this->belongsTo(Ethnicity::class);
    }
    public function businessUnits(): HasMany
    {
        return $this->hasMany(BusinessUnit::class);
    }
//    public function departments(): HasMany
//    {
//        return $this->hasMany(Department::class);
//    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
    public function activityNumbers(): HasMany
    {
        return $this->hasMany(ActivityNumber::class);
    }
    public function contracts(): HasMany
    {
        return $this->hasMany(Contract::class);
    }
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    public function workloads() :HasMany
    {
        return $this->hasMany(Workload::class);
    }
    public function personActivityNumbers():HasMany
    {
        return $this->hasMany(PersonActivityNumber::class);
    }
    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function instructor ():HasOne
    {
        return $this->hasOne(Instructor::class);
    }

    public function activeAssignment(): HasOne
    {
        $table = (new Assignment)->getTable();
        return $this->hasOne(Assignment::class)
            ->whereNull($table . '.end_date')
            ->orderByDesc($table . '.start_date');
    }

}
