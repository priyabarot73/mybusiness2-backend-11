<?php

namespace App\Models;

use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MailingGroupType extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.mailing_group_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $timestamps =true;

    protected $fillable = [
        $name,
        $reference_contract_id, //refers to any contract in the database that the mailing group was temporarily created for
        $contract_state_id, //status of the contract
        $active,
        
    ];

    public function mailingGroups()
    {
        return $this->hasMany(MailingGroup::class);
    }
}
