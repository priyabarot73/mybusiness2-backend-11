<?php

namespace App\Models;

//GLOBAL IMPORT
use Spatie\Permission\Models\Role as SpatieRole;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\ContractRoleStatus;
use App\Models\hr\ContractRoleStateTransition;

class Role extends SpatieRole
{
    use HasFactory,Uuid;
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    public function roleContractStateTransition(): HasMany
    {
        return $this->hasMany(ContractRoleStateTransition::class);
    }
    public function contractRoleStatuses():HasMany
    {
        return $this->hasMany(ContractRoleStatus::class);
    }
}
