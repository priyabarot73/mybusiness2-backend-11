<?php

namespace App\Models\assessment;


//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// local import
use App\Traits\Uuid;
use App\Models\academic\Instructor;


class TenureType extends Model
{
    use HasFactory, Uuid;

    protected $table = 'ass.tenure_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code' => 'string',
        'name' => 'string',
        'description' => 'string',
        'active' => 'boolean'
    ];

    public function instructors(): HasMany
    {
        return $this->hasMany(Instructor::class);
    }
}
