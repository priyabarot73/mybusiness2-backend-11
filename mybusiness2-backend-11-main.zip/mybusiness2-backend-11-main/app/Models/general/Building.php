<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class Building extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.buildings';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'campus_id'=>'uuid',
        'active'=>'boolean'
    ];
    public function campus(): BelongsTo
    {
        return $this->belongsTo(Campus::class);
    }

    public function rooms(): HasMany
    {
        return $this->hasMany(Facility::class);
    }
}
