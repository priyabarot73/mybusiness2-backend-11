<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Models\hr\Assignment;
use App\Traits\Uuid;

class AcademicGroup extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.academic_groups';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'description'=>'string',
        'active'=>'boolean'
    ];

    public function businessUnits(): HasMany
    {
        return $this->hasMany(BusinessUnit::class);
    }
    public function facilities(): HasMany
    {
        return $this->hasMany(Facility::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
    public function department(): HasMany
    {
        return $this->hasMany(Department::class);
    }
}
