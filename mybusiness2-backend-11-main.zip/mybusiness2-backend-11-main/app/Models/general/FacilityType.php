<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class FacilityType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.facility_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function facilities(): HasMany
    {
        return $this->hasMany(Facility::class);
    }
}
