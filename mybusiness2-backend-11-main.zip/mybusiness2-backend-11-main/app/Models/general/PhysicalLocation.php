<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Assignment;

class PhysicalLocation extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.physical_locations';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'name'=>'string',
        'description'=>'string',
        'short_description'=>'string',
        'address'=>'string',
        'city'=>'string',
        'zip_code'=>'string',
        'active'=>'boolean'
    ];
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}





