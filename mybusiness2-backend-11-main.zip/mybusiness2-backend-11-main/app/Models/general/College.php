<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class College extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.colleges';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'url'=>'string',
        'university_name' => 'string',
        'logo_left' => 'string',
        'logo_right' => 'string',
        'state' => 'string',
        'country' => 'string',
        'email' => 'string',
        'phone' => 'string',
        'address' => 'string',
        'active'=>'boolean'
    ];

    public function department(): HasMany
    {
        return $this->hasMany(Department::class);
    }
}
