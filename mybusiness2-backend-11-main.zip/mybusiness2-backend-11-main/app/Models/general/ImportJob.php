<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

//LOCAL IMPORT
use App\Traits\Uuid;

class ImportJob extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.import_jobs';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'file_path'=>'string',
        'file_name'=>'string',
        'scheduled_time'=>'datetime',
        'status'=>'string',
        'error_message'=>'string',
    ];
}
