<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Person;
use App\Models\hr\Contract;
use App\Models\hr\JobTitle;
use App\Models\hr\Assignment;
use App\Models\academic\Course;
use App\Models\hr\ActivityNumber;
use App\Models\hr\AcademicOrganization;

class Department extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.departments';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'number'=>'string',
        'name'=>'string',
        'description'=>'string',
        'business_unit_id'=>'uuid',
        'person_id'=>'uuid',
        'job_title_id'=>'uuid',
        'academic_organization_id'=>'uuid',
        'academic_group_id'=>'uuid',
        'parent_department_id'=>'uuid',
        'active'=>'boolean'
    ];
    public function course(): HasMany
    {
        return $this->hasMany(Course::class);
    }
    public function businessUnit(): BelongsTo
    {
        return $this->belongsTo(BusinessUnit::class);
    }
    public function jobTitle(): BelongsTo
    {
        return $this->belongsTo(JobTitle::class);
    }
    public function parentDepartment(): BelongsTo
    {
        return $this->belongsTo(Department::class, 'parent_department_id');
    }
    public function childDepartments(): HasMany
    {
        return $this->hasMany(Department::class, 'parent_department_id');
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
    public function activityNumber(): HasMany
    {
        return $this->hasMany(ActivityNumber::class);
    }
    public function contracts():HasMany
    {
        return $this->hasMany(Contract::class);
    }
    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function academicOrganization():BelongsTo
    {
        return $this->belongsTo(AcademicOrganization::class);
    }
    public function academicGroup():BelongsTo
    {
        return $this->belongsTo(AcademicGroup::class);
    }
}
