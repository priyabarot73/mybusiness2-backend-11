<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Person;

class ActivityTimeLine extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.activity_time_lines';
    protected $primaryKey = 'id';
    protected $keyType = 'string';

    protected $fillable = [
        'panther_id',
        'action_id',
        'action',
        'category',
        'description'
    ];

    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class, 'panther_id', 'panther_id');
    }
}
