<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;

class BusinessUnitType extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.business_unit_types';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'level'=>'integer',
        'code'=>'string',
        'name'=>'string',
        'active'=>'boolean'
    ];

    public function businessUnits(): HasMany
    {
        return $this->hasMany(BusinessUnit::class);
    }
}
