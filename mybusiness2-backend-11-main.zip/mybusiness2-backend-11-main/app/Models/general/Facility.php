<?php

namespace App\Models\general;

//GLOBAL IMPORT

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Assignment;
use App\Models\academic\MeetingPattern;

class Facility extends Model
{
    use HasFactory, Uuid;
    protected $table = 'gn.facilities';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'floor'=>'integer',
        'room'=>'integer',
        'capacity'=>'integer',
        'address'=>'string',
        'description'=>'string',
        'academic_group_id'=>'uuid',
        'facility_type_id'=>'uuid',
        'building_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function building(): BelongsTo
    {
        return $this->belongsTo(Building::class);
    }
    public function meetingPatterns():HasMany
    {
        return $this->hasMany(MeetingPattern::class);
    }
    public function academicGroup(): BelongsTo
    {
        return $this->belongsTo(AcademicGroup::class);
    }
    public function facilityType(): BelongsTo
    {
        return $this->belongsTo(FacilityType::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}
