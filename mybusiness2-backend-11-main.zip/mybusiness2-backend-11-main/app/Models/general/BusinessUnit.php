<?php

namespace App\Models\general;

//GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

//LOCAL IMPORT
use App\Traits\Uuid;
use App\Models\hr\Person;
use App\Models\hr\JobTitle;
use App\Models\hr\Assignment;

class BusinessUnit extends Model
{
    use HasFactory, Uuid;
    protected $table = 'hr.business_units';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'code'=>'string',
        'name'=>'string',
        'business_unit_type_id'=>'uuid',
        'academic_group_id'=>'uuid',
        'job_title_id'=>'uuid',
        'person_id'=>'uuid',
        'active'=>'boolean'
    ];

    public function businessUnitType(): BelongsTo
    {
        return $this->belongsTo(BusinessUnitType::class);
    }
    public function academicGroup(): BelongsTo
    {
        return $this->belongsTo(AcademicGroup::class);
    }
    public function jobTitle(): BelongsTo
    {
        return $this->belongsTo(JobTitle::class);
    }
    public function person(): BelongsTo
    {
        return $this->belongsTo(Person::class);
    }
    public function departments(): HasMany
    {
        return $this->hasMany(Department::class);
    }
    public function assignments(): HasMany
    {
        return $this->hasMany(Assignment::class);
    }
}
