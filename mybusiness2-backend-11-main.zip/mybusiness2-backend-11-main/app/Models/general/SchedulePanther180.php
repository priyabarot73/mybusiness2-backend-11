<?php

namespace App\Models\general;

// GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

// LOCAL IMPORT
use App\Traits\Uuid;

class SchedulePanther180 extends Model
{
    use HasFactory, Uuid;

    protected $table = 'gn.table_schedule_panther_180';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'class_nbr',
        'subject',
        'catalog',
        'section',
        'session',
        'term',
        'level',
        'title',
        'cap',
        'enrl',
        'enrl_waitlist',
        'wait_cap',
        'wait_tot',
        'department',
        'departmentformal',
        'campus',
        'location',
        'mode',
        'units',
        'grading',
        'facility',
        'meeting_time',
        'meeting_days',
        'last_name',
        'first_name',
        'middle',
        'notes',
        'class_stat',
        'cancel_dt',
        'sch_print',
        'consent',
        'acad_group',
        'start_date',
        'end_date',
        'course_id',
        'offer_nbr',
        'include',
        'calc_reqd',
        'extract_type',
        'lms_group_id',
        'lms_url',
        'class_ext_dttm',
        'enrl_ext_dttm',
        'authentication',
        'instructor_id',
        'component',
        'location_descr',
    ];
}
