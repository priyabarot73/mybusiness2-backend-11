<?php

namespace App\Models\general;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use App\Traits\Uuid;

class Country extends Model
{
    use HasFactory, Uuid;

    protected $table = 'gn.countries';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $timestamps = true;

    protected $fillable = [
        'country_code',
        'country_short_code',
        'country_desc',
        'country_short_desc',
        'active',
    ];

    protected $casts = [
        'active' => 'boolean',
    ];
}
