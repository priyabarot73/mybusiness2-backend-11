<?php

namespace App\Models;

use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MailingGroup extends Model
{
    use HasFactory, Uuid;

    protected $table = 'hr.mailing_groups';
    protected $primaryKey = 'id';
    protected $keyType = 'string';
    public $incrementing = false;
    public $timestamps =true;

    protected $fillable = [
        $mailing_group_type_id,
        $person_id, //refers to a person who is a relevant member of the group
        $active

    ];

    public function mailingGroupType()
    {
        return $this->belongsTo(MailingGroupType::class);
    }
}
