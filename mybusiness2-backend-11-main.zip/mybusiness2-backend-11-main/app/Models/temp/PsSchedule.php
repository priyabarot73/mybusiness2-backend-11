<?php

namespace App\Models\temp;

// GLOBAL IMPORT
use Illuminate\Database\Eloquent\Model;

class PsSchedule extends Model
{
    protected $table = 'temp.PS_SCHEDULE';
    public $incrementing = false;
    public $timestamps = false;
    protected $guarded = [];
}
